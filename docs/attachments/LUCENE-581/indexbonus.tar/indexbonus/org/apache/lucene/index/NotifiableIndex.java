package org.apache.lucene.index;

/**
 * Copyright 2006 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.notification.ContentUpdateListener;
import org.apache.lucene.index.notification.CreateListener;
import org.apache.lucene.index.notification.DeleteListener;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * @author karl wettin <kalle@snigel.net>
 *         Date: May 27, 2006
 *         Time: 8:34:29 AM
 *         <p/>
 *         Let you keep track of what documents in an index is beeing added or removed.
 */
public class NotifiableIndex extends IndexDecorator {

  public NotifiableIndex(Index index) {
    super(index);
  }

  public InterfaceIndexWriter openIndexWriter(Analyzer analyzer, boolean create) throws IOException {
    if (contentUpdateListeners.size() > 0
        || deleteListeners.size() > 0
        || createListeners.size() > 0) {
      return new InterfaceIndexWriterDecorator(indexWriterFactory(analyzer, create)) {

        LinkedList<Document> documents = new LinkedList<Document>();

        public void close() throws IOException {
          super.close();
          if (documents.size() > 0) {
            NotifiableIndex.this.notifyCreate(documents);
            documents.clear();
          }
        }

        public void addDocument(Document doc) throws IOException {
          super.addDocument(doc);
          documents.add(doc);
        }

        public void addDocument(Document doc, Analyzer analyzer) throws IOException {
          super.addDocument(doc, analyzer);
          documents.add(doc);
        }
      };
    } else {
      return indexWriterFactory(analyzer, create);
    }
  }

  public IndexReader openIndexReader() throws IOException {
    if (contentUpdateListeners.size() > 0 || deleteListeners.size() > 0) {
      return new IndexReaderDecorator(indexReaderFactory()) {
        private final LinkedList<Integer> deletions = new LinkedList<Integer>();

        protected void doUndeleteAll() throws IOException {
          super.doUndeleteAll();
          deletions.clear();
        }

        protected void doDelete(int docNum) throws IOException {
          super.doDelete(docNum);
          deletions.add(docNum);
        }

        protected void doCommit() throws IOException {
          super.doCommit();
          if (deletions.size() > 0) {
            NotifiableIndex.this.notifyDelete(deletions);
            deletions.clear();
          }
        }
      };
    } else {
      return indexReaderFactory();
    }
  }

  private Set<ContentUpdateListener> contentUpdateListeners = new HashSet<ContentUpdateListener>(25);
  private Set<CreateListener> createListeners = new HashSet<CreateListener>(25);
  private Set<DeleteListener> deleteListeners = new HashSet<DeleteListener>(25);
  //private Set<OptimizationListener> optimizationListeners = new HashSet<OptimizationListener>(25);

  public void notifyContentUpdate() throws IOException {
    for (ContentUpdateListener l : contentUpdateListeners) {
      l.onIndexContentUpdate(this);
    }
  }

  public void notifyCreate(List<Document> documents) throws IOException {
    notifyContentUpdate();
    for (CreateListener l : createListeners) {
      l.onIndexCreate(this, documents);
    }
  }

  public void notifyDelete(List documentNumbers) throws IOException {
    notifyContentUpdate();
    for (DeleteListener l : deleteListeners) {
      l.onIndexDelete(this, documentNumbers);
    }
  }

  //public void notifyOptimize(int[] oldDocumentNumbers, int[] replacedBy) throws IOException {
  //  for (OptimizationListener l : optimizationListeners) {
  //    l.onIndexOptimization(this, oldDocumentNumbers, replacedBy);
  //  }
  //}

  public Set<ContentUpdateListener> getContentUpdateListeners() {
    return contentUpdateListeners;
  }

  public Set<CreateListener> getCreateListeners() {
    return createListeners;
  }

  public Set<DeleteListener> getDeleteListeners() {
    return deleteListeners;
  }

  //public Set<OptimizationListener> getOptimizationListeners() {
  //  return optimizationListeners;
  //}
}
