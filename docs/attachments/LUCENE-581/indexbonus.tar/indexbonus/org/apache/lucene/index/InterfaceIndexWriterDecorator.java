package org.apache.lucene.index;
/**
 * Copyright 2006 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import org.apache.lucene.search.Similarity;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;

import java.io.PrintStream;
import java.io.IOException;

/**
 * @author karl wettin <kalle@snigel.net>
 * Date: May 16, 2006
 * Time: 1:41:49 AM
 *
 * Adds a layer of logic on any index writer.
 */
public class InterfaceIndexWriterDecorator implements InterfaceIndexWriter {
    private final InterfaceIndexWriter indexWriter;

    public InterfaceIndexWriterDecorator(InterfaceIndexWriter indexWriter) {
        this.indexWriter = indexWriter;
    }

    public void setSimilarity(Similarity similarity) {
        indexWriter.setSimilarity(similarity);
    }

    public Similarity getSimilarity() {
        return indexWriter.getSimilarity();
    }

    public void setMaxFieldLength(int maxFieldLength) {
        indexWriter.setMaxFieldLength(maxFieldLength);
    }

    public int getMaxFieldLength() {
        return indexWriter.getMaxFieldLength();
    }

    public void setInfoStream(PrintStream infoStream) {
        indexWriter.setInfoStream(infoStream);
    }

    public PrintStream getInfoStream() {
        return indexWriter.getInfoStream();
    }

    public void setCommitLockTimeout(long commitLockTimeout) {
        indexWriter.setCommitLockTimeout(commitLockTimeout);
    }

    public long getCommitLockTimeout() {
        return indexWriter.getCommitLockTimeout();
    }

    public void setWriteLockTimeout(long writeLockTimeout) {
        indexWriter.setWriteLockTimeout(writeLockTimeout);
    }

    public long getWriteLockTimeout() {
        return indexWriter.getWriteLockTimeout();
    }

    public void close() throws IOException {
        indexWriter.close();
    }

    public Analyzer getAnalyzer() {
        return indexWriter.getAnalyzer();
    }

    public int docCount() {
        return indexWriter.docCount();
    }

    public void addDocument(Document doc) throws IOException {
        indexWriter.addDocument(doc);
    }

    public void addDocument(Document doc, Analyzer analyzer) throws IOException {
        indexWriter.addDocument(doc, analyzer);
    }

    public void optimize() throws IOException {
        indexWriter.optimize();
    }
}
