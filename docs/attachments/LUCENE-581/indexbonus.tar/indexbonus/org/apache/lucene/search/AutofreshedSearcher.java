package org.apache.lucene.search;
/**
 * Copyright 2006 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.NotifiableIndex;
import org.apache.lucene.index.notification.ContentUpdateListener;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * @author karl wettin <kalle@snigel.net>
 *         Date: May 27, 2006
 *         Time: 2:50:11 AM
 *
 * Listens for updates and make sure the searcher always is up to date with the index.
 * Old searchers are kept alive
 */
public class AutofreshedSearcher implements ContentUpdateListener {

  private final NotifiableIndex index;
  private final long janitorDelayMillis;

  /**
   * @param index
   * @param janitorDelayMillis minimum time before closing old searchers.
   */
  public AutofreshedSearcher(NotifiableIndex index, long janitorDelayMillis) throws IOException {
    this.index = index;
    this.janitorDelayMillis = janitorDelayMillis;
    index.getContentUpdateListeners().add(this);
    reader = index.openIndexReader();
    searcher = new IndexSearcher(reader);
  }

  private LinkedList<LazyJanitorSchedule> trashcans = new LinkedList<LazyJanitorSchedule>();
  private Searcher searcher;
  private IndexReader reader;


  private class LazyJanitorSchedule {
    public LazyJanitorSchedule(Searcher searcher, IndexReader reader, long now) {
      eariestPickup = now + janitorDelayMillis;
      this.searcher = searcher;
      this.reader = reader;
    }

    private long eariestPickup;
    private Searcher searcher;
    private IndexReader reader;
  }

  public void onIndexContentUpdate(NotifiableIndex index) throws IOException {
    if (index.equals(this.index)) {
    long now = System.currentTimeMillis();
    for (Iterator<LazyJanitorSchedule> it = trashcans.iterator(); it.hasNext();) {
      LazyJanitorSchedule janitor = it.next();
      if (janitor.eariestPickup < now) {
        janitor.searcher.close();
        janitor.reader.close();
        it.remove();
      }
    }
    trashcans.addLast(new LazyJanitorSchedule(searcher, reader, now));
    reader = index.openIndexReader();
    searcher = new IndexSearcher(reader);
    }
  }

  public Searcher getSearcher() throws IOException {
    return searcher;
  }

}
