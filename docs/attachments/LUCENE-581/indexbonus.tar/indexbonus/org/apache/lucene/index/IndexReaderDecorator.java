package org.apache.lucene.index;
/**
 * Copyright 2006 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import org.apache.lucene.document.Document;

import java.io.IOException;
import java.util.Collection;

/**
 * @author karl wettin <kalle@snigel.net>
 * Date: May 16, 2006
 * Time: 1:17:56 AM
 *
 * Adds a layer of logic on any index reader.
 */
public abstract class IndexReaderDecorator extends IndexReader {

    private final IndexReader indexReader;

    public IndexReaderDecorator(IndexReader indexReader) {
        super(null);
        this.indexReader = indexReader;
    }

    public TermFreqVector[] getTermFreqVectors(int docNumber) throws IOException {
        return indexReader.getTermFreqVectors(docNumber);
    }

    public TermFreqVector getTermFreqVector(int docNumber, String field) throws IOException {
        return indexReader.getTermFreqVector(docNumber, field);
    }

    public int numDocs() {
        return indexReader.numDocs();
    }

    public int maxDoc() {
        return indexReader.maxDoc();
    }

    public Document document(int n) throws IOException {
        return indexReader.document(n);
    }

    public boolean isDeleted(int n) {
        return indexReader.isDeleted(n);
    }

    public boolean hasDeletions() {
        return indexReader.hasDeletions();
    }

    public byte[] norms(String field) throws IOException {
        return indexReader.norms(field);
    }

    public void norms(String field, byte[] bytes, int offset) throws IOException {
        indexReader.norms(field, bytes, offset);
    }

    protected void doSetNorm(int doc, String field, byte value) throws IOException {
        indexReader.doSetNorm(doc, field, value);
    }

    public TermEnum terms() throws IOException {
        return indexReader.terms();
    }

    public TermEnum terms(Term t) throws IOException {
        return indexReader.terms(t);
    }

    public int docFreq(Term t) throws IOException {
        return indexReader.docFreq(t);
    }

    public TermDocs termDocs() throws IOException {
        return indexReader.termDocs();
    }

    public TermPositions termPositions() throws IOException {
        return indexReader.termPositions();
    }

    protected void doDelete(int docNum) throws IOException {
        indexReader.doDelete(docNum);
    }

    protected void doUndeleteAll() throws IOException {
        indexReader.doUndeleteAll();
    }

    protected void doCommit() throws IOException {
        indexReader.doCommit();
    }

    protected void doClose() throws IOException {
        indexReader.doClose();
    }

    public Collection getFieldNames(FieldOption fldOption) {
        return indexReader.getFieldNames(fldOption);
    }

}
