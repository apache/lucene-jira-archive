package org.apache.lucene.search;
/**
 * Copyright 2006 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import org.apache.lucene.index.Term;
import org.apache.lucene.document.Document;

import java.io.IOException;

/**
 * @author karl wettin <kalle@snigel.net>
 * Date: May 27, 2006
 * Time: 9:27:02 AM
 *
 * Adds a layer of logic to any Searcher
 */
public class SearcherDecorator extends Searcher {

  private Searcher searcher;

  public SearcherDecorator() {
  }

  public SearcherDecorator(Searcher searcher) {
    this.searcher = searcher;
  }


  protected Searcher getSearcher() throws IOException {
    return searcher;
  }

  protected void setSearcher(Searcher searcher) {
    this.searcher = searcher;
  }

  public void search(Weight weight, Filter filter, HitCollector results) throws IOException {
    getSearcher().search(weight,filter, results);
  }

  public void close() throws IOException {
    getSearcher().close();
  }

  public int docFreq(Term term) throws IOException {
    return getSearcher().docFreq(term);
  }

  public int maxDoc() throws IOException {
    return getSearcher().maxDoc();
  }

  public TopDocs search(Weight weight, Filter filter, int n) throws IOException {
    return getSearcher().search(weight,filter, n);
  }

  public Document doc(int i) throws IOException {
    return getSearcher().doc(i);
  }

  public Query rewrite(Query query) throws IOException {
    return getSearcher().rewrite(query);
  }

  public Explanation explain(Weight weight, int doc) throws IOException {
    return getSearcher().explain(weight,doc);
  }

  public TopFieldDocs search(Weight weight, Filter filter, int n, Sort sort) throws IOException {
    return getSearcher().search(weight,filter, n,sort);
  }
}
