package org.apache.lucene.index.notification;
/**
 * Copyright 2006 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.document.Document;
import org.apache.lucene.index.Index;
import org.apache.lucene.index.NotifiableIndex;

import java.io.IOException;
import java.util.List;

/**
 * @author karl wettin <kalle@snigel.net>
 *         Date: May 16, 2006
 *         Time: 12:56:00 AM
 */
public interface CreateListener {
  public void onIndexCreate(NotifiableIndex index, List<Document> documents) throws IOException;
}
