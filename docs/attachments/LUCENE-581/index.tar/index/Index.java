package org.apache.lucene.index;

/**
 * Copyright 2006 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import java.io.IOException;

/**
 * @author karl wettin <kalle@snigel.net>
 *         Date: May 16, 2006
 *         Time: 12:53:25 AM
 */
public abstract class Index {

  /**
   *
   * @return a new instance of IndexReader that read and delete data from <code>this</code> index.
   * @throws IOException
   */
  protected abstract IndexReader indexReaderFactory() throws IOException;

  /**
   *
   * @param analyzer default analyzer
   * @param create if true, index will be (re)initialized.
   * @return a new instance of IndexWriter that add data to <code>this</code> index.
   * @throws IOException
   */
  protected abstract InterfaceIndexWriter indexWriterFactory(Analyzer analyzer, boolean create) throws IOException;

  /**
   * @return a new instance of Document that fits <code>this</code> index.
   */
  public abstract Document documentFactory();

  public InterfaceIndexWriter openIndexWriter(Analyzer analyzer, boolean create) throws IOException {
    return indexWriterFactory(analyzer, create);
  }

  public IndexReader openIndexReader() throws IOException {
    return indexReaderFactory();
  }


}
