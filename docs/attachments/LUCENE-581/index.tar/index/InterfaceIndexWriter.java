package org.apache.lucene.index;

/**
 * Copyright 2006 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.search.Similarity;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;

import java.io.PrintStream;
import java.io.IOException;

/**
 * @author karl wettin <kalle@snigel.net>
 * Date: May 16, 2006
 * Time: 1:38:11 AM
 */
public interface InterfaceIndexWriter {
    /**
     * Default value for the write lock timeout (1,000).
     */
    long WRITE_LOCK_TIMEOUT = 1000;
    /**
     * Default value for the commit lock timeout (10,000).
     */
    long COMMIT_LOCK_TIMEOUT = 10000;
    /**
     * Default value is 10,000. Change using {@link #setMaxFieldLength(int)}.
     */
    int DEFAULT_MAX_FIELD_LENGTH = 10000;

    /** Expert: Set the Similarity implementation used by this DirectoryIndexWriter.
     *
     * @see org.apache.lucene.search.Similarity#setDefault(org.apache.lucene.search.Similarity)
     */
    void setSimilarity(Similarity similarity);

    /** Expert: Return the Similarity implementation used by this DirectoryIndexWriter.
     *
     * <p>This defaults to the current value of {@link org.apache.lucene.search.Similarity#getDefault()}.
     */
    Similarity getSimilarity();

    /**
     * The maximum number of terms that will be indexed for a single field in a
     * document.  This limits the amount of memory required for indexing, so that
     * collections with very large files will not crash the indexing process by
     * running out of memory.<p/>
     * Note that this effectively truncates large documents, excluding from the
     * index terms that occur further in the document.  If you know your source
     * documents are large, be sure to set this value high enough to accomodate
     * the expected size.  If you set it to Integer.MAX_VALUE, then the only limit
     * is your memory, but you should anticipate an OutOfMemoryError.<p/>
     * By default, no more than 10,000 terms will be indexed for a field.
     */
    void setMaxFieldLength(int maxFieldLength);

    /**
     * @see #setMaxFieldLength
     */
    int getMaxFieldLength();

    /** If non-null, information about merges and a message when
     * maxFieldLength is reached will be printed to this.
     */
    void setInfoStream(PrintStream infoStream);

    /**
     * @see #setInfoStream
     */
    PrintStream getInfoStream();

    /**
     * Sets the maximum time to wait for a commit lock (in milliseconds).
     */
    void setCommitLockTimeout(long commitLockTimeout);

    /**
     * @see #setCommitLockTimeout
     */
    long getCommitLockTimeout();

    /**
     * Sets the maximum time to wait for a write lock (in milliseconds).
     */
    void setWriteLockTimeout(long writeLockTimeout);

    /**
     * @see #setWriteLockTimeout
     */
    long getWriteLockTimeout();

    /** Flushes all changes to an index and closes all associated files. */
    void close() throws IOException;

    /** Returns the analyzer used by this index. */
    Analyzer getAnalyzer();

    /** Returns the number of documents currently in this index. */
    int docCount();

    /**
     * Adds a document to this index.  If the document contains more than
     * {@link #setMaxFieldLength(int)} terms for a given field, the remainder are
     * discarded.
     */
    void addDocument(Document doc) throws IOException;

    /**
     * Adds a document to this index, using the provided analyzer instead of the
     * value of {@link #getAnalyzer()}.  If the document contains more than
     * {@link #setMaxFieldLength(int)} terms for a given field, the remainder are
     * discarded.
     */
    void addDocument(Document doc, Analyzer analyzer) throws IOException;

    /** Merges all segments together into a single segment, optimizing an index
        for search. */
    void optimize() throws IOException;
}
