/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Lucene" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Lucene", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package com.aetrion.lucene.store;

import java.io.IOException;
import java.util.Vector;

import org.apache.lucene.store.OutputStream;

/** Implementation of the Lucene OutputStream base class which stores data
    in memory and which provides a byte array of the data upon request.
    
    @author <a href="mailto:me@anthonyeden.com">Anthony Eden</a>
*/

public class DBOutputStream extends OutputStream{
    
    /** Default internal buffer size (1024). */
    
    public static final int BUFFER_SIZE = 1024;
    
    private int bufferSize = BUFFER_SIZE;
    private CloseListener closeListener;
    private int pointer = 0;
    private DBFile file = null;
    
    /** Construct a DBOutputStream using the specified DBFile object.
    
        @param file The DBFile object
    */
    
    public DBOutputStream(DBFile file){
        this.file = file;
    }
    
    /** Set the CloseListener.
    
        @param closeListener The CloseListener
    */
    
    public void setCloseListener(CloseListener closeListener){
        this.closeListener = closeListener;
    }
    
    /** Convert the data in this output stream to a byte array.  The length of
        all data in all internal buffers when combined can not exceed
        Intener.MAX_VALUE otherwise an IOException is thrown.
    
        @return A byte array
        @throws IOException
    */
    
    public byte[] toByteArray() throws IOException{
        long length = length();
        if(length > Integer.MAX_VALUE){
            throw new IOException("Buffer too long");
        }
        
        byte[] dest = new byte[(int)length];
        int destOffset = 0;
        int remainder = (int)length;
        int start = 0;
        while (remainder != 0) {
            int bufferNumber = start / bufferSize;
            int bufferOffset = start % bufferSize;
            int bytesInBuffer = bufferSize - bufferOffset;
            int bytesToCopy = bytesInBuffer >= remainder ? remainder : bytesInBuffer;
            byte[] buffer = (byte[])file.buffers.elementAt(bufferNumber);
            System.arraycopy(buffer, bufferOffset, dest, destOffset, bytesToCopy);
            destOffset += bytesToCopy;
            start += bytesToCopy;
            remainder -= bytesToCopy;
        }
        
        return dest;
    }

    /** Write the buffer in src to the output stream.
    
        @param src The source buffer
        @param len The length of the source buffer
    */
    
    public final void flushBuffer(byte[] src, int len) {
        int bufferNumber = pointer / bufferSize;
        int bufferOffset = pointer % bufferSize;
        int bytesInBuffer = bufferSize - bufferOffset;
        int bytesToCopy = bytesInBuffer >= len ? len : bytesInBuffer;

        if (bufferNumber == file.buffers.size())
            file.buffers.addElement(new byte[bufferSize]);

        byte[] buffer = (byte[])file.buffers.elementAt(bufferNumber);
        System.arraycopy(src, 0, buffer, bufferOffset, bytesToCopy);

        if (bytesToCopy < len) {			  // not all in one buffer
            int srcOffset = bytesToCopy;
            bytesToCopy = len - bytesToCopy;		  // remaining bytes
            bufferNumber++;
            if (bufferNumber == file.buffers.size())
                file.buffers.addElement(new byte[bufferSize]);
            buffer = (byte[])file.buffers.elementAt(bufferNumber);
            System.arraycopy(src, srcOffset, buffer, 0, bytesToCopy);
        }
        pointer += len;
        if (pointer > file.length)
            file.length = pointer;

        file.lastModified = System.currentTimeMillis();
    }
    
    /** Closes this stream to further operations.
    
        @throws IOException
    */

    public final void close() throws IOException {
        super.close();
        if(closeListener != null){
            closeListener.close();
        }
    }
    
    /** Sets current position in this file, where the next write will occur.
    
        @param pos The position
        @throws IOException
    */

    public final void seek(long pos) throws IOException {
        super.seek(pos);
        pointer = (int)pos;
    }
    
    /** The number of bytes in the file.
    
        @return The number of bytes in the file
        @throws IOException Any IO exception
    */
    
    public final long length() throws IOException {
        return file.length;
    }
    
    /** Callback interface which is executed when the OutputStream.close()
        method is called.  Calling this method writes the data in the buffers
        to the underlying database.
        
        @author <a href="mailto:me@anthonyeden.com">Anthony Eden [me@anthonyeden.com]</a> 
    */
    
    public interface CloseListener{
        
        /** Called when the output stream closes. */
    
        public void close();
    
    }
    
}

    
