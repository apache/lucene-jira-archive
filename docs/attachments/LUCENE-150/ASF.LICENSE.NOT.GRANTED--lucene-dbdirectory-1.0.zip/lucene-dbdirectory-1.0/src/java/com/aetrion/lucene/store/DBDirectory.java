/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Lucene" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Lucene", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

package com.aetrion.lucene.store;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.InputStream;
import org.apache.lucene.store.OutputStream;
import org.apache.lucene.store.Lock;

/** Directory implementation which stores index data in a database.  Data for
    multiple directories are stored in the same table.

    @author <a href="mailto:me@anthonyeden.com">Anthony Eden</a>
*/

public class DBDirectory extends Directory{
    
    /** The default table name where data is stored. (lucene_indeces) */
    
    public static final String DEFAULT_TABLE_NAME = "lucene_indeces";
    
    private DBDescriptor db = null;
    private String tableName = null;
    private String directoryName = null;
    
    /** Construct a new DBDirectory using the value of DEFAULT_TABLE_NAME as
        the table name.
    
        @param db The database descriptor
        @param directoryName The directory name
        @throws ClassNotFoundException If the JDBC driver class not found
        @throws InsantiationException If the JDBC driver cannot be created
        @throws IllegalAccessException
    */
    
    public DBDirectory(DBDescriptor db, String directoryName)
    throws ClassNotFoundException, InstantiationException, IllegalAccessException{
        this(db, DEFAULT_TABLE_NAME, directoryName);
    }
    
    /** Construct a new DBDirectory.
    
        @param db The database descriptor
        @param tableName The table name
        @param directoryName The directory name
        @throws ClassNotFoundException If the JDBC driver class not found
        @throws InsantiationException If the JDBC driver cannot be created
        @throws IllegalAccessException
    */
    
    public DBDirectory(DBDescriptor db, String tableName, String directoryName) 
    throws ClassNotFoundException, InstantiationException, IllegalAccessException{
        this.db = db;
        this.tableName = tableName;
        this.directoryName = directoryName;
        
        // load the JDBC driver
        Class.forName(db.driver).newInstance();
    }
    
    /** Returns an array of strings, one for each file in the directory.
    
        @return Files in directory
        @throws IOException
    */
    
    public String[] list() throws IOException{
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
            PreparedStatement ps = conn.prepareStatement(
                "select name from " + tableName + " where directory_name = ?");
            ps.setString(1, directoryName);
            ResultSet rs = ps.executeQuery();
            
            ArrayList names = new ArrayList();
            while(rs.next()){
                names.add(rs.getString("name"));
            }
            return (String[])names.toArray(new String[names.size()]);
        } catch(SQLException e){
            IOException ioException = new IOException("SQL error");
            ioException.initCause(e);
            throw ioException;
        } finally {
            close(conn);
        }
    }
    
    /** Returns true if a file with the given name exists.
    
        @param name The file name
        @return True if the file exists
        @throws IOException
    */
    
    public boolean fileExists(String name) throws IOException{
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
            PreparedStatement ps = conn.prepareStatement(
                "select name from " + tableName + " where name = ? and directory_name = ?");
            ps.setString(1, name);
            ps.setString(2, directoryName);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return true;
            } else {
                return false;
            }
        } catch(SQLException e){
            IOException ioException = new IOException("SQL error");
            ioException.initCause(e);
            throw ioException;
        } finally {
            close(conn);
        }
    }
    
    /** Returns the time the named file was last modified.
    
        @param name The file name
        @return True if the file was modified
        @throws IOException
    */
    
    public long fileModified(String name) throws IOException{
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
            PreparedStatement ps = conn.prepareStatement(
                "select lastmodified from " + tableName + " where name = ? and directory_name = ?");
            ps.setString(1, name);
            ps.setString(2, directoryName);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return rs.getLong("lastmodified");
            } else {
                throw new IOException("File not found: " + name);
            }
        } catch(SQLException e){
            IOException ioException = new IOException("SQL error");
            ioException.initCause(e);
            throw ioException;
        } finally {
            close(conn);
        }
    }
    
    /** Set the modified time of an existing file to now.
    
        @param name The file name
        @throws IOException
    */
    
    public void touchFile(String name) throws IOException{
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
            PreparedStatement ps = conn.prepareStatement(
                "update " + tableName + " set lastmodified = ? where name = ? and directory_name = ?");
            ps.setLong(1, System.currentTimeMillis());
            ps.setString(2, name);
            ps.setString(3, directoryName);
            int rowCount = ps.executeUpdate();
            if(rowCount < 1){
                throw new IOException("File not found: " + name);
            }
        } catch(SQLException e){
            IOException ioException = new IOException("SQL error");
            ioException.initCause(e);
            throw ioException;
        } finally {
            close(conn);
        }
    }
    
    /** Removes an existing file in the directory.
    
        @param name The file name
        @throws IOException
    */
    
    public void deleteFile(String name) throws IOException{
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
            PreparedStatement ps = conn.prepareStatement(
                "delete from " + tableName + " where name = ? and directory_name = ?");
            ps.setString(1, name);
            ps.setString(2, directoryName);
            int rowCount = ps.executeUpdate();
            if(rowCount < 1){
                throw new IOException("File not found: " + name);
            }
        } catch(SQLException e){
            IOException ioException = new IOException("SQL error");
            ioException.initCause(e);
            throw ioException;
        } finally {
            close(conn);
        }
    }
    
    /** Renames an existing file in the directory.
    
        @param from The original file name
        @param to The new file name
        @throws IOException
    */
    
    public void renameFile(String from, String to) throws IOException{
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
                
            PreparedStatement ps = conn.prepareStatement(
                "delete from " + tableName + " where name = ? and directory_name = ?");
            ps.setString(1, to);
            ps.setString(2, directoryName);
            ps.executeUpdate();
            
            ps = conn.prepareStatement(
                "update " + tableName + " set name= ? where name = ? and directory_name = ?");
            ps.setString(1, to);
            ps.setString(2, from);
            ps.setString(3, directoryName);
            int rowCount = ps.executeUpdate();
            if(rowCount < 1){
                throw new IOException("File not found: " + from);
            }
        } catch(SQLException e){
            IOException ioException = new IOException("SQL error");
            ioException.initCause(e);
            throw ioException;
        } finally {
            close(conn);
        }
    }
    
    /** Returns the length of a file in the directory.
    
        @param name The file name
        @return The length in bytes
        @throws IOException
    */
    
    public long fileLength(String name) throws IOException{
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
            PreparedStatement ps = conn.prepareStatement(
                "select length from " + tableName + " where name = ? and directory_name = ?");
            ps.setString(1, name);
            ps.setString(2, directoryName);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return rs.getLong("length");
            } else {
                throw new IOException("File not found: " + name);
            }
        } catch(SQLException e){
            IOException ioException = new IOException("SQL error");
            ioException.initCause(e);
            throw ioException;
        } finally {
            close(conn);
        }
    }
    
    /** Creates a new, empty file in the directory with the given name.
    
        @param name The file name
        @return The OutputStream for the file
        @throws IOException
    */
    
    public OutputStream createFile(final String name) throws IOException{
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
            PreparedStatement ps = conn.prepareStatement(
                "insert into " + tableName + " (name, lastmodified, length, directory_name) values (?,?,?,?)");
            ps.setString(1, name);
            ps.setLong(2, System.currentTimeMillis());
            ps.setLong(3, 0);
            ps.setString(4, directoryName);
            int rowCount = ps.executeUpdate();
            if(rowCount == 1){
                
                final DBOutputStream os = new DBOutputStream(new DBFile()); 
                os.setCloseListener(new DBOutputStream.CloseListener(){
                    public void close(){
                        closeStream(name, os);
                    }
                });
                return os;
                
            } else {
                throw new IOException("Error creating file");
            }
        } catch(SQLException e){
            IOException ioException = new IOException("SQL error");
            ioException.initCause(e);
            throw ioException;
        } finally {
            close(conn);
        }
    }
    
    /** Returns a stream reading an existing file.
    
        @param name The file name
        @return The InputStream
        @throws IOException
    */
    
    public InputStream openFile(String name) throws IOException{
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
            PreparedStatement ps = conn.prepareStatement(
                "select data from " + tableName + " where name = ? and directory_name = ?");
            ps.setString(1, name);
            ps.setString(2, directoryName);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                return new DBInputStream(readDataToFile(
                    rs.getBinaryStream("data")));
            } else {
                throw new IOException("File not found: " + name);
            }
        } catch(SQLException e){
            IOException ioException = new IOException("SQL error");
            ioException.initCause(e);
            throw ioException;
        } finally {
            close(conn);
        }
    }
    
    /** Construct a Lock.
    
        @param name The Lock name
        @return The Lock objects
    */
    
    public Lock makeLock(String name){
        return new DBLock(db, tableName, directoryName, name);
    }
    
    /** Close the directory. */
    
    public void close(){
        
    }
    
    /** Write the error message.
    
        @param message Error message
    */
    
    static void error(String message){
        error(message, null);
    }
    
    /** Write the error message.
    
        @param message Error message
        @param t The exception which caused the error (may be null)
    */
    
    static void error(String message, Throwable t){
        System.err.println(message);
        if(t != null){
            t.printStackTrace(System.err);
        }
        // log.error(message, t);
    }
    
    /** Close the output stream and write the data to the database.
    
        @param name The directory name
        @param os The OutputStream
    */
    
    private void closeStream(String name, DBOutputStream os){
        Connection conn = null;
        try{
            byte[] data = os.toByteArray();
            
            conn = DriverManager.getConnection(
                db.url, db.username, db.password);
            PreparedStatement ps = conn.prepareStatement(
                "update " + tableName + " set name = ?, lastmodified = ?, length = ?, data = ? where name = ? and directory_name = ?");
            ps.setString(1, name);
            ps.setLong(2, System.currentTimeMillis());
            ps.setLong(3, data.length);
            ps.setBytes(4, data);
            ps.setString(5, name);
            ps.setString(6, directoryName);
            int rowCount = ps.executeUpdate();
            if(rowCount != 1){
                error("No data saved");
            }
        } catch(SQLException e){
            error("SQL error saving data", e);
        } catch(IOException e){
            error("IO error saving data", e);
        } finally {
            close(conn);
        }
    }
    
    /** Read the data from the specified Java InputStream into the DBFile
        object.
        
        @param in The java.io.InputStream
        @return The DBFile
        @throws IOException
    */
    
    private DBFile readDataToFile(java.io.InputStream in) throws IOException{
        DBFile file = new DBFile();
        OutputStream out = new DBOutputStream(file);
        int b = -1;
        while((b = in.read()) != -1){
            out.writeByte((byte)b);
        }
        out.close();
        return file;
    }
    
    /** Close the JDBC connection.
    
        @param conn The connection to close
    */
    
    private void close(Connection conn){
        if(conn != null){
            try{
                conn.close();
            } catch(SQLException e){
                error("Error closing SQL connection", e);
            }
        }
    }
    
}
