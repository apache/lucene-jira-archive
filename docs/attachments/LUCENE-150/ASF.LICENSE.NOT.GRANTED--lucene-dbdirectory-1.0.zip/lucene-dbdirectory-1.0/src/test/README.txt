There are currently no test cases for the Lucene DBDirectory.
