/*  Create the Lucene indeces table for storing indeces.

    Author: Anthony Eden
*/

create table lucene_indeces (
    directory_name char(100) not null,
    name char(100) not null,
    lastmodified int(128) not null,
    length int(32) not null,
    data blob,
    primary key(directory_name, name)
);
