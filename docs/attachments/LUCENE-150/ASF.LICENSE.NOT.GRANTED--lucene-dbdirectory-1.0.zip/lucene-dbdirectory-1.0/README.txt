Lucene DBDirectory
--------------------

Implementation of the Lucene Directory interface which stores data in a 
JDBC-accessible database.

Usage:
--------------------

Example of using the DBDescriptor to store indeces in a database:

	// import necessary classes for DBDirectory
	import com.aetrion.lucene.store.DBDescriptor;
	import com.aetrion.lucene.store.DBDirectory;
	
	// construct the DBDescriptor
	DBDescriptor db = new DBDescriptor();
	db.driver = "org.gjt.mm.mysql.Driver";
	db.url = "jdbc:mysql://host:port/database";
	db.username = "username";
	db.password = "password";
	
	// construct the DBDirectory
	DBDirectory dbDirectory = new DBDirectory(db, directoryName);
	
	// construct the index writer using the DBDirectory
	IndexWriter writer = new IndexWriter(dbDirectory, 
		new StandardAnalyzer(), true);

And to use DBDirectory for searches just change the last line to:

	Searcher searcher = new IndexSearcher(dbDirectory);
	
Building:
--------------------

Copy the most recent version of the Lucene JAR file into the lib 
directory and then execute the Ant build script.
	
Notes:
--------------------

DBDirectory has been tested with and includes SQL scripts for the 
following databases:

 - MySQL
 
Currently DBDirectory requires that the underlying database supports
primary keys which can index on two columns.

For assistance please post a message to the Lucene-Users mailing list.
Information about this mailing list and Lucene in general can be found
at http://jakarta.apache.org/lucene .
