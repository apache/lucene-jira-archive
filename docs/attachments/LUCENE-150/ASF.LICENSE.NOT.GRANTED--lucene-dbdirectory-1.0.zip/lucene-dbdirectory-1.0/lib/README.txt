Make sure to copy the most recent lucene JAR into this directory before
trying to build DBDirectory.
