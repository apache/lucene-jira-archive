All tests performed using Java 1.6 with -Xmx512m -server.

debit and ps3 are servers, doing very little during the tests.
metis is a server, doing nothing besides the test.
pc286 is a workstation, with no user-activity during the test.
laptop is a laptop, with no user-activity during the test.

fast refers to sets and gets being without range-checking.
safe is with range-checking.
