package org.apache.lucene.search.trie;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;

import org.apache.lucene.search.Filter;
import org.apache.lucene.search.DocIdSet;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ConstantScoreQuery;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.TermDocs;
import org.apache.lucene.index.TermEnum;
import org.apache.lucene.index.Term;
import org.apache.lucene.util.OpenBitSet;
import org.apache.lucene.util.ToStringUtils;


/**
 * Implementation of a Lucene {@link Filter} that implements trie-based range filtering.
 * This filter depends on a specific structure of terms in the index that can only be created
 * by {@link TrieUtils} methods.
 * For more information, how the algorithm works, see the package description {@link org.apache.lucene.search.trie}.
 */
public final class TrieRangeFilter extends Filter {

  /**
   * Universal constructor (expert use only): Uses already trie-converted min/max values.
   * You can set <code>min</code> or <code>max</code> (but not both) to <code>null</code> to leave one bound open.
   * With <code>minInclusive</code> and <code>maxInclusive</code> can be choosen, if the corresponding
   * bound should be included or excluded from the range.
   */
  public TrieRangeFilter(final String[] fields, final int precisionStep,
    Long min, Long max, final boolean minInclusive, final boolean maxInclusive
  ) {
    this.fields=fields;
    this.precisionStep=precisionStep;
    this.min=min;
    this.max=max;
    this.minInclusive=minInclusive;
    this.maxInclusive=maxInclusive;
    this.minUnconverted=min;
    this.maxUnconverted=max;
  }

  /**
   * Generates a trie filter using the supplied field with range bounds in integer form (long).
   * You can set <code>min</code> or <code>max</code> (but not both) to <code>null</code> to leave one bound open.
   * With <code>minInclusive</code> and <code>maxInclusive</code> can be choosen, if the corresponding
   * bound should be included or excluded from the range.
   */
  public TrieRangeFilter(final String field, final String lowerPrecisionField, final int precisionStep,
    final Long min, final Long max, final boolean minInclusive, final boolean maxInclusive
  ) {
    this(
      new String[]{field, lowerPrecisionField==null ? (field+TrieUtils.LOWER_PRECISION_FIELD_NAME_SUFFIX) : lowerPrecisionField},
      precisionStep,min,max,minInclusive,maxInclusive
    );
  }

  /**
   * Generates a trie filter using the supplied field with range bounds in integer form (long).
   * You can set <code>min</code> or <code>max</code> (but not both) to <code>null</code> to leave one bound open.
   * With <code>minInclusive</code> and <code>maxInclusive</code> can be choosen, if the corresponding
   * bound should be included or excluded from the range.
   */
  public TrieRangeFilter(final String field, final int precisionStep,
    final Long min, final Long max, final boolean minInclusive, final boolean maxInclusive
  ) {
    this(
      new String[]{field, field+TrieUtils.LOWER_PRECISION_FIELD_NAME_SUFFIX},
      precisionStep,min,max,minInclusive,maxInclusive
    );
  }

  //@Override
  public String toString() {
    return toString(null);
  }

  public String toString(final String field) {
    final StringBuffer sb=new StringBuffer();
    if (!this.fields[0].equals(field)) sb.append(this.fields[0]).append(':');
    return sb.append(minInclusive ? '[' : '{')
      .append((minUnconverted==null) ? "*" : minUnconverted.toString())
      .append(" TO ")
      .append((maxUnconverted==null) ? "*" : maxUnconverted.toString())
      .append(maxInclusive ? ']' : '}').toString();
  }

  /*
  //@Override
  public final boolean equals(final Object o) {
    if (o instanceof TrieRangeFilter) {
      TrieRangeFilter q=(TrieRangeFilter)o;
      // trieVariants are singleton per type, so no equals needed.
      return (
        field==q.field && min.equals(q.min) && max.equals(q.max) &&
        TODO, nulls etc.
        precisionStep==q.precisionStep
      );
    } else return false;
  }

  //@Override
  public final int hashCode() {
    return Arrays.asList(fields).hashCode()+
      (min.hashCode()^0x14fa55fb)+(max.hashCode()^0x733fa5fe)+
      (trieVariant.TRIE_BITS^0x64365465);
  }
  */
  
  /**
   * Returns a DocIdSet that provides the documents which should be permitted or prohibited in search results.
   */
  //@Override
  public DocIdSet getDocIdSet(final IndexReader reader) throws IOException {
    // calculate the upper and lower bounds respecting the inclusive and null values.
    long minBound=(this.min==null) ? Long.MIN_VALUE : (
      minInclusive ? this.min.longValue() : (this.min.longValue()+1L)
    );
    long maxBound=(this.max==null) ? Long.MAX_VALUE : (
      maxInclusive ? this.max.longValue() : (this.max.longValue()-1L)
    );
    
    lastNumberOfTerms=0;
    if (minBound > maxBound) {
      // shortcut, no docs will match this
      return DocIdSet.EMPTY_DOCIDSET;
    } else {
      final OpenBitSet bits = new OpenBitSet(reader.maxDoc());
      final TermDocs termDocs = reader.termDocs();
      try {
        TrieUtils.splitLongRange(new TrieUtils.LongRangeBuilder() {
        
          public final void addRange(long min, long max, int shift) throws IOException {
            final String field = fields[Math.min(fields.length-1, shift/precisionStep)].intern(),
              lowerTerm=TrieUtils.longToPrefixCoded(min, shift),
              upperTerm=TrieUtils.longToPrefixCoded(max, shift);
            final int len=lowerTerm.length();
            assert upperTerm.length()==len;
            
            // find the docs
            final TermEnum enumerator = reader.terms(new Term(field, lowerTerm));
            try {
              do {
                final Term term = enumerator.term();
                if (term!=null && term.field()==field) {
                  // break out when upperTerm reached or length of term is different
                  final String t=term.text();
                  if (len!=t.length() || t.compareTo(upperTerm)>0) break;
                  // we have a good term, find the docs
                  lastNumberOfTerms++;
                  termDocs.seek(enumerator);
                  while (termDocs.next()) bits.set(termDocs.doc());
                } else break;
              } while (enumerator.next());
            } finally {
              enumerator.close();
            }
          }
        
        }, precisionStep, minBound, maxBound);
      } catch (Exception e) {
        if (e instanceof IOException) throw (IOException)e;
        throw new RuntimeException(e);
      } finally {
        termDocs.close();
      }
      return bits;
    }
  }
  
  /**
   * EXPERT: Return the number of terms visited during the last execution of {@link #getDocIdSet}.
   * This may be used for performance comparisons of different trie variants and their effectiveness.
   * This method is not thread safe, be sure to only call it when no query is running!
   * @throws IllegalStateException if {@link #getDocIdSet} was not yet executed.
   */
  public int getLastNumberOfTerms() {
    if (lastNumberOfTerms < 0) throw new IllegalStateException();
    return lastNumberOfTerms;
  }
  
  /** Returns this range filter as a query.
   * Using this method, it is possible to create a Query using <code>new TrieRangeFilter(....).asQuery()</code>.
   * This is a synonym for wrapping with a {@link ConstantScoreQuery},
   * but this query returns a better <code>toString()</code> variant.
   */
  public Query asQuery() {
    return new ConstantScoreQuery(this) {
    
      /** this instance return a nicer String variant than the original {@link ConstantScoreQuery} */
      //@Override
      public String toString(final String field) {
        // return a more convenient representation of this query than ConstantScoreQuery does:
        return ((TrieRangeFilter) filter).toString(field)+ToStringUtils.boost(getBoost());
      }

    };
  }

  // members
  private final String[] fields;
  private final int precisionStep;
  private final Long min,max;
  private final boolean minInclusive,maxInclusive;
  private Object minUnconverted,maxUnconverted;
  private int lastNumberOfTerms=-1;
}
