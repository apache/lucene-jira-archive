package org.apache.lucene.search.trie;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.SortField;
import org.apache.lucene.search.FieldCache;
import org.apache.lucene.search.ExtendedFieldCache;

/**
 * This is a helper class to construct the trie-based index entries for numerical values. TODO!
 */
public final class TrieUtils {

  /** The "helper" field containing the lower precision terms is the original fieldname with this appended. */
  public static final String LOWER_PRECISION_FIELD_NAME_SUFFIX="#trie";

  /** Numbers are stored at lower precision by shifting off lower bits.  The shift count is
   * stored as SHIFT_START+shift in the first character */
  public static final char SHIFT_START_LONG = (char)0x20;
  public static final char SHIFT_START_INT  = (char)0x60;

  /**
   * A parser instance for filling a {@link ExtendedFieldCache}, that parses prefix encoded fields as longs.
   */
  public static final ExtendedFieldCache.LongParser FIELD_CACHE_LONG_PARSER=new ExtendedFieldCache.LongParser(){
    public final long parseLong(final String val) {
      return prefixCodedToLong(val);
    }
  };
  
  /**
   * A parser instance for filling a {@link FieldCache}, that parses prefix encoded fields as ints.
   */
  public static final FieldCache.IntParser FIELD_CACHE_INT_PARSER=new FieldCache.IntParser(){
    public final int parseInt(final String val) {
      return prefixCodedToInt(val);
    }
  };

  /** Returns prefix coded bits after reducing the precision by "shift" bits.
   */
  public static String longToPrefixCoded(final long val, final int shift) {
    int nBits = 64-shift;
    int nChars = (nBits-1)/7 + 1;
    final char[] arr = new char[nChars+1];
    arr[0] = (char)(SHIFT_START_LONG + shift);
    long sortableBits = val ^ 0x8000000000000000L;
    sortableBits >>>= shift;
    while (nChars>=1) {
      // Store 7 bits per character for good efficiency when UTF-8 encoding.
      // The whole number is right-justified so that lucene can prefix-encode
      // the terms more efficiently.
      arr[nChars--] = (char)(sortableBits & 0x7f);
      sortableBits >>>= 7;
    }
    return new String(arr);
  }

  /** Returns prefix coded bits after reducing the precision by "shift" bits.
   */
  public static String intToPrefixCoded(final int val, final int shift) {
    int nBits = 32-shift;
    int nChars = (nBits-1)/7 + 1;
    final char[] arr = new char[nChars+1];
    arr[0] = (char)(SHIFT_START_INT + shift);
    int sortableBits = val ^ 0x80000000;
    sortableBits >>>= shift;
    while (nChars>=1) {
      // Store 7 bits per character for good efficiency when UTF-8 encoding.
      // The whole number is right-justified so that lucene can prefix-encode
      // the terms more efficiently.
      arr[nChars--] = (char)(sortableBits & 0x7f);
      sortableBits >>>= 7;
    }
    return new String(arr);
  }

  /** Returns a long from prefixCoded characters.
   * Rightmost bits will be zero for lower precision codes.
   */
  public static long prefixCodedToLong(final String prefixCoded) {
    final int len = prefixCoded.length();
    final int shift = prefixCoded.charAt(0)-SHIFT_START_LONG;
    if (shift>63 || shift<0) {
      throw new NumberFormatException("Invalid shift value in prefixCoded string (is encoded value really a LONG?)");
    }
    long sortableBits = 0L;
    for (int i=1; i<len; i++) {
      sortableBits <<= 7;
      final char ch = prefixCoded.charAt(i);
      if (ch>0x7f) {
        throw new NumberFormatException(
          "Invalid prefixCoded numerical value representation (char "+
          Integer.toHexString((int)ch)+" at position "+i+" is invalid)"
        );
      }
      sortableBits |= (long)(ch & 0x7f);
    }
    return (sortableBits << shift) ^ 0x8000000000000000L;
  }

  /** Returns an int from prefixCoded characters.
   * Rightmost bits will be zero for lower precision codes.
   */
  public static int prefixCodedToInt(final String prefixCoded) {
    final int len = prefixCoded.length();
    final int shift = prefixCoded.charAt(0)-SHIFT_START_INT;
    if (shift>31 || shift<0) {
      throw new NumberFormatException("Invalid shift value in prefixCoded string (is encoded value really an INT?)");
    }
    int sortableBits = 0;
    for (int i=1; i<len; i++) {
      sortableBits <<= 7;
      final char ch = prefixCoded.charAt(i);
      if (ch>0x7f) {
        throw new NumberFormatException(
          "Invalid prefixCoded numerical value representation (char "+
          Integer.toHexString((int)ch)+" at position "+i+" is invalid)"
        );
      }
      sortableBits |= (int)(ch & 0x7f);
    }
    return (sortableBits << shift) ^ 0x80000000;
  }

  /** Returns a sequence of coded numbers suitable for TrieRangeFilter.
   * Each successive string in the list has had it's precision reduced by "precisionStep".
   * For sorting, index the first full-precision value into a
   * separate field and the remaining values into another field.
   */
  public static String[] trieCodeLong(long val, int precisionStep) {
    String[] arr = new String[(64-1)/precisionStep+1];
    int idx = 0;
    for (int shift=0; shift<64; shift+=precisionStep) {
      arr[idx++] = longToPrefixCoded(val, shift);
    }
    return arr;
  }

  /** Returns a sequence of coded numbers suitable for TrieRangeFilter.
   * Each successive string in the list has had it's precision reduced by "precisionStep".
   * For sorting, index the first full-precision value into a
   * separate field and the remaining values into another field.
   */
  public static String[] trieCodeInt(int val, int precisionStep) {
    String[] arr = new String[(32-1)/precisionStep+1];
    int idx = 0;
    for (int shift=0; shift<32; shift+=precisionStep) {
      arr[idx++] = intToPrefixCoded(val, shift);
    }
    return arr;
  }

  /** Converts a <code>double</code> value to a sortable signed <code>long</code>.
   * @see #sortableLongToDouble
   */
  public static long doubleToSortableLong(double val) {
    long f = Double.doubleToLongBits(val);
    if (f<0) f ^= 0x7fffffffffffffffL;
    return f;
  }

  /** Converts a sortable <code>long</code> back to a <code>double</code>.
   * @see #doubleToSortableLong
   */
  public static double sortableLongToDouble(long val) {
    if (val<0) val ^= 0x7fffffffffffffffL;
    return Double.longBitsToDouble(val);
  }

  /** Converts a <code>float</code> value to a sortable signed <code>int</code>.
   * @see #sortableIntToFloat
   */
  public static int floatToSortableInt(float val) {
    int f = Float.floatToIntBits(val);
    if (f<0) f ^= 0x7fffffff;
    return f;
  }

  /** Converts a sortable <code>int</code> back to a <code>float</code>.
   * @see #floatToSortableInt
   */
  public static float sortableIntToFloat(int val) {
    if (val<0) val ^= 0x7fffffff;
    return Float.intBitsToFloat(val);
  }

  /** A factory method, that generates a {@link SortField} instance for sorting prefix encoded long values. */
  public static SortField getLongSortField(final String field) {
    return new SortField(field, FIELD_CACHE_LONG_PARSER);
  }
  
  /** A factory method, that generates a {@link SortField} instance for sorting prefix encoded long values. */
  public static SortField getLongSortField(final String field, boolean reverse) {
    return new SortField(field, FIELD_CACHE_LONG_PARSER, reverse);
  }
  
  /** A factory method, that generates a {@link SortField} instance for sorting prefix encoded int values. */
  public static SortField getIntSortField(final String field) {
    return new SortField(field, FIELD_CACHE_INT_PARSER);
  }
  
  /** A factory method, that generates a {@link SortField} instance for sorting prefix encoded int values. */
  public static SortField getIntSortField(final String field, boolean reverse) {
    return new SortField(field, FIELD_CACHE_INT_PARSER, reverse);
  }

  /** Indexes a series of trie coded values into a lucene {@link Document} using the given field names.
   * If the array of field names is shorter than the trieCoded one, all trieCoded values with higher index get the last field name.
   **/
  public static void addIndexedFields(Document doc, String[] fields, String[] trieCoded) {
    for (int i=0; i<trieCoded.length; i++) {
      final int fnum = Math.min(fields.length-1, i);
      final Field f = new Field(fields[fnum], trieCoded[i], Field.Store.NO, Field.Index.NOT_ANALYZED_NO_NORMS);
      f.setOmitTf(true);
      doc.add(f);
    }
  }

  /** Indexes the full precision value only in the main field (for sorting), and indexes all other
   * lower precision values in the lowerPrecision field (or <code>field+LOWER_PRECISION_FIELD_NAME_SUFFIX</code> if null).
   *
   * Example:  <code>addIndexedFields(doc,"myDouble", "myDoubleTrie", trieCode(doubleToSortableLong(1.414d), 4));</code>
   * Example:  <code>addIndexedFields(doc,"myLong", "myLongTrie", trieCode(123456L, 4));</code>
   **/
  public static void addIndexedFields(Document doc, String field, String lowerPrecisionField, String[] trieCoded) {
    addIndexedFields(doc, new String[]{field, lowerPrecisionField==null ? (field+LOWER_PRECISION_FIELD_NAME_SUFFIX) : lowerPrecisionField}, trieCoded);
  }

  /** Indexes the full precision value only in the main field (for sorting), and indexes all other
   * lower precision values in <code>field+LOWER_PRECISION_FIELD_NAME_SUFFIX</code>.
   *
   * Example:  <code>addIndexedFields(doc,"mydouble",  trieCodeLong(doubleToSortableLong(1.414d), 4));</code>
   * Example:  <code>addIndexedFields(doc,"mylong",  trieCodeLong(123456L, 4));</code>
   **/
  public static void addIndexedFields(Document doc, String field, String[] trieCoded) {
    addIndexedFields(doc, new String[]{field, field+LOWER_PRECISION_FIELD_NAME_SUFFIX}, trieCoded);
  }

  /** Splits a long range recursively */
  public static void splitLongRange(final LongRangeBuilder builder, final int precisionStep,
    final long minBound, final long maxBound
  ) throws Exception {
    splitLongRange(
      builder, precisionStep,
      minBound, minBound==Long.MIN_VALUE, maxBound, maxBound==Long.MAX_VALUE,
      0 /* start with no shift */
    );
  }
  
  private static void splitLongRange(
    final LongRangeBuilder builder, final int precisionStep,
    final long minBound, final boolean minBoundOpen, final long maxBound, final boolean maxBoundOpen,
    final int shift
  ) throws Exception {
    // calculate new bounds for inner precision
    final long diff = 1L << (shift+precisionStep),
      mask = diff-1L,
      nextMinBound = (minBoundOpen ? Long.MIN_VALUE : (minBound + diff)) & ~mask,
      nextMaxBound = (maxBoundOpen ? Long.MAX_VALUE : (maxBound - diff)) & ~mask;

    if (shift+precisionStep>63 || nextMinBound>=nextMaxBound) {
      // we are in the lowest precision or the next precision is not available
      builder.addRange(minBound, maxBound, shift);
    } else {
      if (!minBoundOpen) {
        builder.addRange(minBound, (nextMinBound - diff) | mask, shift);
      }
      if (!maxBoundOpen) {
        builder.addRange((nextMaxBound + diff) & ~mask, maxBound, shift);
      }
      splitLongRange(
        builder, precisionStep,
        nextMinBound,minBoundOpen,
        nextMaxBound,maxBoundOpen,
        shift+precisionStep
      );
    }
  }
  
  /** Splits an int range recursively */
  public static void splitIntRange(final IntRangeBuilder builder, final int precisionStep,
    final int minBound, final int maxBound
  ) throws Exception {
    splitIntRange(
      builder, precisionStep,
      minBound, minBound==Integer.MIN_VALUE, maxBound, maxBound==Integer.MAX_VALUE,
      0 /* start with no shift */
    );
  }
  
  private static void splitIntRange(
    final IntRangeBuilder builder, final int precisionStep,
    final int minBound, final boolean minBoundOpen, final int maxBound, final boolean maxBoundOpen,
    final int shift
  ) throws Exception {
    // calculate new bounds for inner precision
    final int diff = 1 << (shift+precisionStep),
      mask = diff-1,
      nextMinBound = (minBoundOpen ? Integer.MIN_VALUE : (minBound + diff)) & ~mask,
      nextMaxBound = (maxBoundOpen ? Integer.MAX_VALUE : (maxBound - diff)) & ~mask;

    if (shift+precisionStep>31 || nextMinBound>=nextMaxBound) {
      // we are in the lowest precision or the next precision is not available
      builder.addRange(minBound, maxBound, shift);
    } else {
      if (!minBoundOpen) {
        builder.addRange(minBound, (nextMinBound - diff) | mask, shift);
      }
      if (!maxBoundOpen) {
        builder.addRange((nextMaxBound + diff) & ~mask, maxBound, shift);
      }
      splitIntRange(
        builder, precisionStep,
        nextMinBound,minBoundOpen,
        nextMaxBound,maxBoundOpen,
        shift+precisionStep
      );
    }
  }
  
  /** Callback interface for splitLongRange */
  public static interface LongRangeBuilder {
    public void addRange(long min, long max, int shift) throws Exception;
  }
  
  /** Callback interface for splitIntRange */
  public static interface IntRangeBuilder {
    public void addRange(int min, int max, int shift) throws Exception;
  }
  
}
