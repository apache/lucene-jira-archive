package org.apache.lucene.search.trie;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.Random;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.RangeQuery;
import org.apache.lucene.util.LuceneTestCase;

public class TestTrieRangeFilter extends LuceneTestCase
{
  private static final long distance=66666;
  
  private static final RAMDirectory directory;
  private static final IndexSearcher searcher;
  static {
    try {    
      directory = new RAMDirectory();
      IndexWriter writer = new IndexWriter(directory, new WhitespaceAnalyzer(),
      true, MaxFieldLength.UNLIMITED);
      
      // Add a series of 10000 docs with increasing long values
      for (long l=0L; l<10000L; l++) {
        Document doc=new Document();
        // add fields, that have a distance to test general functionality
        TrieUtils.addIndexedFields(doc,"field8", TrieUtils.trieCodeLong(distance*l, 8));
        doc.add(new Field("field8", TrieUtils.longToPrefixCoded(distance*l, 0), Field.Store.YES, Field.Index.NO));
        TrieUtils.addIndexedFields(doc,"field4", TrieUtils.trieCodeLong(distance*l, 4));
        doc.add(new Field("field4", TrieUtils.longToPrefixCoded(distance*l, 0), Field.Store.YES, Field.Index.NO));
        TrieUtils.addIndexedFields(doc,"field2", TrieUtils.trieCodeLong(distance*l, 2));
        doc.add(new Field("field2", TrieUtils.longToPrefixCoded(distance*l, 0), Field.Store.YES, Field.Index.NO));
        // add ascending fields with a distance of 1 to test the correct splitting of range and inclusive/exclusive
        TrieUtils.addIndexedFields(doc,"ascfield8", TrieUtils.trieCodeLong(l, 8));
        TrieUtils.addIndexedFields(doc,"ascfield4", TrieUtils.trieCodeLong(l, 4));
        TrieUtils.addIndexedFields(doc,"ascfield2", TrieUtils.trieCodeLong(l, 2));
        writer.addDocument(doc);
      }
    
      writer.optimize();
      writer.close();
      searcher=new IndexSearcher(directory);
    } catch (Exception e) {
      throw new Error(e);
    }
  }
  
  private void testRange(int precisionStep) throws Exception {
    String field="field"+precisionStep;
    int count=3000;
    long lower=96666L, upper=lower + count*distance + 1234L;
    TrieRangeFilter f=new TrieRangeFilter(field, precisionStep, new Long(lower), new Long(upper), true, true);
    TopDocs topDocs = searcher.search(f.asQuery(), null, 10000, Sort.INDEXORDER);
    System.out.println("Found "+f.getLastNumberOfTerms()+" distinct terms in range for field '"+field+"'.");
    ScoreDoc[] sd = topDocs.scoreDocs;
    assertNotNull(sd);
    assertEquals("Score docs must match "+count+" docs, found "+sd.length+" docs", sd.length, count );
    Document doc=searcher.doc(sd[0].doc);
    assertEquals("First doc should be "+(2*distance), TrieUtils.prefixCodedToLong(doc.get(field)), 2*distance );
    doc=searcher.doc(sd[sd.length-1].doc);
    assertEquals("Last doc should be "+((1+count)*distance), TrieUtils.prefixCodedToLong(doc.get(field)), (1+count)*distance );
  }

  public void testRange_8bit() throws Exception {
    testRange(8);
  }
  
  public void testRange_4bit() throws Exception {
    testRange(4);
  }
  
  public void testRange_2bit() throws Exception {
    testRange(2);
  }
  
  private void testLeftOpenRange(int precisionStep) throws Exception {
    String field="field"+precisionStep;
    int count=3000;
    long upper=(count-1)*distance + 1234L;
    TrieRangeFilter f=new TrieRangeFilter(field, precisionStep, null, new Long(upper), true, true);
    TopDocs topDocs = searcher.search(f.asQuery(), null, 10000, Sort.INDEXORDER);
    System.out.println("Found "+f.getLastNumberOfTerms()+" distinct terms in left open range for field '"+field+"'.");
    ScoreDoc[] sd = topDocs.scoreDocs;
    assertNotNull(sd);
    assertEquals("Score docs must match "+count+" docs, found "+sd.length+" docs", sd.length, count );
    Document doc=searcher.doc(sd[0].doc);
    assertEquals("First doc should be 0", TrieUtils.prefixCodedToLong(doc.get(field)), 0L );
    doc=searcher.doc(sd[sd.length-1].doc);
    assertEquals("Last doc should be "+((count-1)*distance), TrieUtils.prefixCodedToLong(doc.get(field)), (count-1)*distance );
  }
  
  public void testLeftOpenRange_8bit() throws Exception {
    testLeftOpenRange(8);
  }
  
  public void testLeftOpenRange_4bit() throws Exception {
    testLeftOpenRange(4);
  }
  
  public void testLeftOpenRange_2bit() throws Exception {
    testLeftOpenRange(2);
  }
  
  private void testRightOpenRange(int precisionStep) throws Exception {
    String field="field"+precisionStep;
    int count=3000;
    long lower=(count-1)*distance + 1234L;
    TrieRangeFilter f=new TrieRangeFilter(field, precisionStep, new Long(lower), null, true, true);
    TopDocs topDocs = searcher.search(f.asQuery(), null, 10000, Sort.INDEXORDER);
    System.out.println("Found "+f.getLastNumberOfTerms()+" distinct terms in right open range for field '"+field+"'.");
    ScoreDoc[] sd = topDocs.scoreDocs;
    assertNotNull(sd);
    assertEquals("Score docs must match "+(10000-count)+" docs, found "+sd.length+" docs", sd.length, 10000-count );
    Document doc=searcher.doc(sd[0].doc);
    assertEquals("First doc should be "+(count*distance), TrieUtils.prefixCodedToLong(doc.get(field)), count*distance );
    doc=searcher.doc(sd[sd.length-1].doc);
    assertEquals("Last doc should be "+9999L*distance, TrieUtils.prefixCodedToLong(doc.get(field)), 9999L*distance );
  }
  
  public void testRightOpenRange_8bit() throws Exception {
    testRightOpenRange(8);
  }
  
  public void testRightOpenRange_4bit() throws Exception {
    testRightOpenRange(4);
  }
  
  public void testRightOpenRange_2bit() throws Exception {
    testRightOpenRange(2);
  }
  
  /*private void testRandomTrieAndClassicRangeQuery(int precisionStep) throws Exception {
    final Random rnd=newRandom();
    String field="field"+precisionStep;
    // 50 random tests, the tests may also return 0 results, if min>max, but this is ok
    for (int i=0; i<50; i++) {
      long lower=(long)(rnd.nextDouble()*10000L*distance);
      long upper=(long)(rnd.nextDouble()*10000L*distance);
      // test inclusive range
      TrieRangeFilter tq=new TrieRangeFilter(field, new Long(lower), new Long(upper), true, true, variant);
      RangeQuery cq=new RangeQuery(field, variant.longToTrieCoded(lower), variant.longToTrieCoded(upper), true, true);
      cq.setConstantScoreRewrite(true);
      TopDocs tTopDocs = searcher.search(tq, 1);
      TopDocs cTopDocs = searcher.search(cq, 1);
      assertEquals("Returned count for TrieRangeFilter and RangeQuery must be equal", tTopDocs.totalHits, cTopDocs.totalHits );
      // test exclusive range
      tq=new TrieRangeFilter(field, new Long(lower), new Long(upper), false, false, variant);
      cq=new RangeQuery(field, variant.longToTrieCoded(lower), variant.longToTrieCoded(upper), false, false);
      cq.setConstantScoreRewrite(true);
      tTopDocs = searcher.search(tq, 1);
      cTopDocs = searcher.search(cq, 1);
      assertEquals("Returned count for TrieRangeFilter and RangeQuery must be equal", tTopDocs.totalHits, cTopDocs.totalHits );
      // test left exclusive range
      tq=new TrieRangeFilter(field, new Long(lower), new Long(upper), false, true, variant);
      cq=new RangeQuery(field, variant.longToTrieCoded(lower), variant.longToTrieCoded(upper), false, true);
      cq.setConstantScoreRewrite(true);
      tTopDocs = searcher.search(tq, 1);
      cTopDocs = searcher.search(cq, 1);
      assertEquals("Returned count for TrieRangeFilter and RangeQuery must be equal", tTopDocs.totalHits, cTopDocs.totalHits );
      // test right exclusive range
      tq=new TrieRangeFilter(field, new Long(lower), new Long(upper), true, false, variant);
      cq=new RangeQuery(field, variant.longToTrieCoded(lower), variant.longToTrieCoded(upper), true, false);
      cq.setConstantScoreRewrite(true);
      tTopDocs = searcher.search(tq, 1);
      cTopDocs = searcher.search(cq, 1);
      assertEquals("Returned count for TrieRangeFilter and RangeQuery must be equal", tTopDocs.totalHits, cTopDocs.totalHits );
    }
  }
  
  public void testRandomTrieAndClassicRangeQuery_8bit() throws Exception {
    testRandomTrieAndClassicRangeQuery(8);
  }
  
  public void testRandomTrieAndClassicRangeQuery_4bit() throws Exception {
    testRandomTrieAndClassicRangeQuery(4);
  }
  
  public void testRandomTrieAndClassicRangeQuery_2bit() throws Exception {
    testRandomTrieAndClassicRangeQuery(2);
  }*/
  
  private void testRangeSplit(int precisionStep) throws Exception {
    final Random rnd=newRandom();
    String field="ascfield"+precisionStep;
    // 50 random tests
    for (int i=0; i<50; i++) {
      long lower=(long)(rnd.nextDouble()*10000L);
      long upper=(long)(rnd.nextDouble()*10000L);
      if (lower>upper) {
        long a=lower; lower=upper; upper=a;
      }
      // test inclusive range
      Query tq=new TrieRangeFilter(field, precisionStep, new Long(lower), new Long(upper), true, true).asQuery();
      TopDocs tTopDocs = searcher.search(tq, 1);
      assertEquals("Returned count of range query must be equal to inclusive range length", tTopDocs.totalHits, upper-lower+1 );
      // test exclusive range
      tq=new TrieRangeFilter(field, precisionStep, new Long(lower), new Long(upper), false, false).asQuery();
      tTopDocs = searcher.search(tq, 1);
      assertEquals("Returned count of range query must be equal to exclusive range length", tTopDocs.totalHits, Math.max(upper-lower-1, 0) );
      // test left exclusive range
      tq=new TrieRangeFilter(field, precisionStep, new Long(lower), new Long(upper), false, true).asQuery();
      tTopDocs = searcher.search(tq, 1);
      assertEquals("Returned count of range query must be equal to half exclusive range length", tTopDocs.totalHits, upper-lower );
      // test right exclusive range
      tq=new TrieRangeFilter(field, precisionStep, new Long(lower), new Long(upper), true, false).asQuery();
      tTopDocs = searcher.search(tq, 1);
      assertEquals("Returned count of range query must be equal to half exclusive range length", tTopDocs.totalHits, upper-lower );
    }
  }

  public void testRangeSplit_8bit() throws Exception {
    testRangeSplit(8);
  }
  
  public void testRangeSplit_4bit() throws Exception {
    testRangeSplit(4);
  }
  
  public void testRangeSplit_2bit() throws Exception {
    testRangeSplit(2);
  }
  
  private void testSorting(int precisionStep) throws Exception {
    final Random rnd=newRandom();
    String field="field"+precisionStep;
    // 10 random tests, the index order is ascending,
    // so using a reverse sort field should retun descending documents
    for (int i=0; i<10; i++) {
      long lower=(long)(rnd.nextDouble()*10000L*distance);
      long upper=(long)(rnd.nextDouble()*10000L*distance);
      if (lower>upper) {
        long a=lower; lower=upper; upper=a;
      }
      TrieRangeFilter tq=new TrieRangeFilter(field, precisionStep, new Long(lower), new Long(upper), true, true);
      TopDocs topDocs = searcher.search(tq.asQuery(), null, 10000, new Sort(TrieUtils.getLongSortField(field, true)));
      if (topDocs.totalHits==0) continue;
      ScoreDoc[] sd = topDocs.scoreDocs;
      assertNotNull(sd);
      long last=TrieUtils.prefixCodedToLong(searcher.doc(sd[0].doc).get(field));
      for (int j=1; j<sd.length; j++) {
        long act=TrieUtils.prefixCodedToLong(searcher.doc(sd[j].doc).get(field));
        assertTrue("Docs should be sorted backwards", last>act );
        last=act;
      }
    }
  }

  public void testSorting_8bit() throws Exception {
    testSorting(8);
  }
  
  public void testSorting_4bit() throws Exception {
    testSorting(4);
  }
  
  public void testSorting_2bit() throws Exception {
    testSorting(2);
  }
  
}
