

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Hits;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.document.Document;

import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import java.net.URL;
import java.net.MalformedURLException;
import java.io.*;



/**
 * A very simple applet that performs a Lucene search. This shows how Lucene
 * can be used from an unsigned applet to perform searches from a web browser
 * when either no server is present or when a server-based search mechanism cannot
 * be provided (for example, from a personal web site on your ISP's server).
 *
 * @author jons@wrq.com
 */
public class SimpleSearchApplet extends Applet implements ActionListener
{
	private List mHitList;
	private TextField mTerm;
	private Button mSearch;
	private IndexSearcher mSearcher;
	private Analyzer mAnalyzer;
	private Vector mCurrentResults = new Vector();

	/**
	 * Applet init. Creates a simple layout and adds a few controls to it for
	 * entering a search term and viewing the resulting document hits.
	 */
	public void init()
	{
		setLayout( new BorderLayout() );
		Panel p = new Panel( new GridBagLayout() );
		GridBagConstraints gbc = new GridBagConstraints();

		Label lbl = new Label("Enter search term:");
		mTerm = new TextField(20);
		mSearch = new Button("Search");
		mSearch.addActionListener( this );
		mHitList = new List(20);
		mHitList.addActionListener( this );

		gbc.anchor = GridBagConstraints.NORTHWEST;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		p.add( lbl, gbc );
		gbc.gridwidth = 2;
		p.add( mTerm, gbc );
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		p.add( mSearch, gbc );

		gbc.fill = GridBagConstraints.BOTH;
		p.add( mHitList, gbc );
		p.setSize( getSize() );
		add( p, BorderLayout.CENTER );
	}

	/**
	 * Applet start.
	 */
	public void start()
	{
		if ( mSearcher == null )
		{
			makeSearcher();
		}
	}

	/**
	 * Creates a RAMDirectory from which the index files are read, and creates
	 * a Lucene searcher and analyzer.
	 */
	private void makeSearcher()
	{
		try
		{
			Directory dir = makeRAMDir("indexfiles");
			mSearcher = new IndexSearcher( IndexReader.open(dir) );   //create an indexSearcher for our page
			mAnalyzer = new StandardAnalyzer();
		}
		catch ( IOException e )
		{
			e.printStackTrace();
		}
	}

	/**
	 * Creates a RAMDirectory for reading in and storing the Lucene
	 * index files.
	 * @param indexdir the name of the directory containing the search index files
	 * @return the RAMDirectory populated with the index files.
	 */
	private Directory makeRAMDir( String indexdir )
	{
		RAMDirectory ramdir = new RAMDirectory();
		try
		{
			URL url = new URL(getDocumentBase(), indexdir );
			BufferedReader br = getReaderForURL(url);       // BufferedReader points to either the directory of index files or to a file containing
																								// a list of the index files. In either case, reading a line at a time should give
																								// the name of each search index file.
			Vector filelist = new Vector();
			String theline;
			while ( (theline = br.readLine()) != null )
			{
				filelist.addElement(theline);
			}

			IndexOutput os;
			InputStream ixfileis;
			String filename;
			byte[] buff;
			int count = 0;
			for ( int i = 0; i < filelist.size(); i++ )
			{
				buff = new byte[2048];
				filename = (String)filelist.elementAt(i);
				os = ramdir.createOutput(  filename );
				String ur = url.toString();
				ixfileis = getStreamToIndexFile(ur, filename);  // read the file into the RAM file.
				if ( ixfileis != null )
				{
					while( true )
					{
						synchronized( buff )
						{
							count = ixfileis.read( buff );
							if( count < 0 )
								break;
							os.writeBytes( buff, count );
						}
					}
					ixfileis.close();
					os.close();
				}
			}
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
		return ramdir;
	}

	/**
	 * Gets a BufferedReader to the list of search index files. For a filesystem URL,
	 * the reader can get the list of index files from an url to just the directory. For
	 * an http URL, the reader needs to read from an index file that lives
	 * in the directory and the URL should point to a specific file. This method
	 * first tries to open a stream to the exact URL and if that fails (which it
	 * will if it's an http URL), the name "index" is appended to the URL and
	 * an attempt is made to open a stream to the file called "index" in the
	 * directory specified by the original URL.
	 *
	 * @param url the url to the directory containing the search index files. If
	 *                      the directory itself can't be accessed (because it's a webserver
	 *                      directory, for instance), the name "index" is appended to the
	 *                      url and an attempt is made to open a stream to the file
	 *                      called "index" within the directory.
	 * @return a BufferedReader to the index list.
	 */
	private BufferedReader getReaderForURL( URL url )
	{
		InputStream is = null;
		try
		{
			is = url.openStream();
		}
		catch ( IOException ioe )
		{
			try
			{
				String urlstr = url.toString();
				is = (new URL(urlstr + "/index")).openStream();
			}
			catch ( Exception e )
			{
				return null;
			}
		}
		return new BufferedReader( new InputStreamReader(is) );
	}

	/**
	 * Opens a stream to an index file.
	 * @param url the url to the location of the index files.
	 * @param filename the name of the index file desired.
	 * @return an InputStream to the file or null if the file cannot be accessed.
	 */
	private InputStream getStreamToIndexFile( String url, String filename )
	{
		InputStream is = null;
		try
		{
			URL u = new URL(url + "/" + filename);
			is = u.openStream();
		}
		catch ( Exception e )
		{
			e.printStackTrace();
		}
		return is;
	}

	/**
	 * Implementation of ActionListener method. This performs the search
	 * when the search button is clicked.
	 * @param e the event.
	 */
	public void actionPerformed( ActionEvent e )
	{
		Object source = e.getSource();  // source of the event
		if ( source == mSearch )            // Search button
		{
			mHitList.removeAll();
			mCurrentResults.removeAllElements();
			if ( mSearcher == null || mAnalyzer == null )
			{
				mHitList.add(  "Unable to perform search; could not create searcher and/or analyzer.");
			}
			try
			{
				Query query = QueryParser.parse(mTerm.getText(), "contents", mAnalyzer);
				Hits hits = mSearcher.search( query );
				if ( hits.length() == 0 )
				{
					mHitList.addItem( "Sorry, nothing found for your search." );
				}
				else
				{
					for ( int i = 0; i < hits.length(); i++ )
					{
						Document doc = hits.doc(i);
						mCurrentResults.addElement( doc );
						mHitList.addItem( doc.get("title" ) );
					}
				}
			}
			catch ( Exception pe )
			{
				pe.printStackTrace();
			}
		}
		else if ( source == mHitList && mCurrentResults.size() > 0 )      // Double-click in list of hits
		{
			// open url to page selected.
			Document hit = (Document)mCurrentResults.elementAt(mHitList.getSelectedIndex());
			String hiturl = hit.get("path");
			AppletContext context = getAppletContext();
			try
			{
				context.showDocument( new URL(getDocumentBase(), hiturl), "_blank" );
				context.showStatus( "Showing page " + hiturl + " for result \"" + hit.get("title") + "\"" );
			}
			catch ( MalformedURLException mue )
			{
				context.showStatus( "Unable to open page " + hiturl );
			}
		}
	}
}
