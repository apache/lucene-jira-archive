package demo.purelucene;

import java.text.DecimalFormat;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryFilter;
import org.apache.lucene.search.RangeFilter;

import sun.nio.cs.ext.SJIS;

/**
 * @author MAHarwood
 */
public class LuceneOnlyQuery
{

    private static IndexReader reader;
    private static IndexSearcher searcher;
    static DecimalFormat df=BuildLuceneOnlyIndex.getPriceFormat();

    public static void main(String[] args) throws Exception
    {
        reader=IndexReader.open(BuildLuceneOnlyIndex.LUCENE_ADS_INDEX_DIR);
        searcher=new IndexSearcher(reader);
        
        for(int i=0;i<50;i++)
        {
        doLuceneFilteredQuery("table",1,100);        
        doLuceneFilteredQuery("table",0,49);
        doLuceneFilteredQuery("table",51,Integer.MAX_VALUE);
        doLuceneFilteredQuery("table",0,49);
        doLuceneFilteredQuery("table",51,Integer.MAX_VALUE);
        doLuceneFilteredQuery("table",0,49);
        doLuceneFilteredQuery("table",51,Integer.MAX_VALUE);
        doLuceneFilteredQuery("table",49,76,true);
        doLuceneFilteredQuery("+bass guitar",501, Integer.MAX_VALUE,true);
        doLuceneFilteredQuery("ford",2, Integer.MAX_VALUE,true);
        }
        
        searcher.close();
        reader.close();

    }

    /**
     * @param string
     * @param string2
     * @throws ParseException
     */
    private static void doLuceneFilteredQuery(String queryText, int lowerPrice,int upperPrice) throws Exception
    {
        doLuceneFilteredQuery(queryText,lowerPrice,upperPrice,false);
    }
    private static void doLuceneFilteredQuery(String queryText, int lowerPrice,int upperPrice, boolean showResults) throws Exception
    {
        
        long start=System.currentTimeMillis();
        RangeFilter qf=new RangeFilter("pricePounds", df.format(lowerPrice), df.format(upperPrice),true,true);
        Query q=QueryParser.parse(queryText,"contents",BuildLuceneOnlyIndex.analyzer);
        Hits h=searcher.search(q,qf);
        long time=System.currentTimeMillis()-start;
        System.out.println("Got "+h.length()+" in "+time+" ms for query "+queryText
                + " price:"+lowerPrice+" to "+ upperPrice);
        if(showResults)
        {
            start=System.currentTimeMillis();
            for(int i=0;i<h.length();i++)
            {
                String line=h.doc(i).get("contents");
//                System.out.println(line);
            }
            time=System.currentTimeMillis()-start;
            System.out.println("get results content took "+ time+ " ms\n\n");
        }
    }
}
