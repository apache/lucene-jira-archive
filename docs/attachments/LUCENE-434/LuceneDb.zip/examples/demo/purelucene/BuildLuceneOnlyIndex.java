package demo.purelucene;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.FSDirectory;

/**
 * This is a control test to show Lucene query times
 */
public class BuildLuceneOnlyIndex
{

	//TODO !!!!change this setting to match where you want your index to be created!!
    public static final String LUCENE_ADS_INDEX_DIR = "c:/indexes/lucenedb/luceneonlyindex";
    
    private static final String ADS_FILE = "demoData/ads.txt";
    public static Analyzer analyzer=new StandardAnalyzer();    
    private static Pattern pricePattern;
    static DecimalFormat df=getPriceFormat();

    public static void main(String[] args) throws Exception
    {
		pricePattern=Pattern.compile("�([0-9]{1,5})", Pattern.CASE_INSENSITIVE);
		
		FSDirectory dir=FSDirectory.getDirectory(new File(LUCENE_ADS_INDEX_DIR),true);
		IndexWriter writer=new IndexWriter(dir, analyzer,true);
        
	        
	    	FileInputStream fis = new FileInputStream(ADS_FILE);
	    	BufferedReader d = new BufferedReader(new InputStreamReader(fis)); 
	    	String line = d.readLine();
	    	int lineCount=0;
	    	
	        long start=System.currentTimeMillis();
	    	while(line!=null)
	    	{
	    	    int pricePounds=0;
				Matcher priceMatcher=pricePattern.matcher(line);
				if(priceMatcher.find())
				{
					String price=priceMatcher.group(1);
					System.out.println("�"+price);
					pricePounds=Integer.parseInt(price);
				}
	    	    
	    	    Document doc=new Document();
	    	    Field f=new Field("contents",line,Field.Store.YES, Field.Index.TOKENIZED);	    	    	    	    
	    	    doc.add(f);
	    	    //now store price as zero-padded field
	    	    f=new Field("pricePounds",df.format(pricePounds),Field.Store.NO, Field.Index.UN_TOKENIZED);	    	    	    	    
	    	    doc.add(f);
	    	    writer.addDocument(doc);
	    	    
	    		line=d.readLine();	    		
	    		lineCount++;
	    	}
	    	d.close();
	    	writer.optimize();
	    	writer.close();
	        System.out.println("Inserted "+lineCount+" ads into index");	                
    }

    public static DecimalFormat getPriceFormat()
    {
        DecimalFormat df=new DecimalFormat();
        df.setMinimumIntegerDigits(8);
        return df;
    }
}
