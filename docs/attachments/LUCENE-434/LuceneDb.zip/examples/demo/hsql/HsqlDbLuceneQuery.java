package demo.hsql;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.BitSet;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.db.BitSetFilter;
import org.apache.lucene.db.CachedKeyMapImpl;
import org.apache.lucene.db.DBEmbeddedLuceneFunctions;
import org.apache.lucene.db.KeyMap;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;

import com.inperspective.utils.DBUtils;

import demo.derby.BuildDerbyDbWithLuceneIndex;

/** Class which demos integration of Lucene queries INSIDE embedded DB.
 * Currently uses DB to collect docid used in Lucene filter.
 * Next job is to make HSQL use Lucene to generate scores etc used in SQL  engine
 * @author Mark
 */
public class HsqlDbLuceneQuery
{
    //TODO Try make Lucene query part of SQL syntax -  can do this to limit selections:
    // select limit 0 10 * from ads order by pricepounds desc  - this selects 10 rows starting at pos 0. 

    
    static Connection conn=null;
    static IndexReader reader;
    static IndexSearcher searcher;
    private static KeyMap keyMap;

    public static void main(String[] args) throws Exception
    {
        reader=IndexReader.open(BuildHSqlDbWithLuceneIndex.LUCENE_ADS_INDEX_DIR);
        searcher=new IndexSearcher(reader);
        
        //open the database
        conn=BuildHSqlDbWithLuceneIndex.getConnection();
        
        //create the KeyMap used to link between Lucene docIds and equivalent RDBMS primary keys
        keyMap=new CachedKeyMapImpl(reader,"key");        
        
        
        //Example approach 1 - database results used to filter Lucene queries
        doRDBMSFilteredQuery("guitar",null);
        doRDBMSFilteredQuery("guitar","select id from ads where pricePounds<250");
        doRDBMSFilteredQuery("guitar","select id from ads where pricePounds>50 and pricePounds<250",true);
        doRDBMSFilteredQuery("+bass guitar","select id from ads where pricePounds>500 ",true);
        doRDBMSFilteredQuery("ford","select id from ads where pricePounds>1 ",true);
        doRDBMSFilteredQuery("+bass guitar","select id from ads where pricePounds<500 ",true);
        
        
        
        //Example approach 2 - Lucene used inside DB to filter database queries
        doRDBMSQuery("select top 10 adText, lucene_query('kitchen table',id) as MAXVAL from ads where pricePounds<100 " +
				"order by MAXVAL DESC");                
        doRDBMSQuery("select adText, lucene_score(id) as MATCH_SCORE from ads " +
                "where pricePounds<100 " +                
                "AND lucene_query('doesNotExist',id)>0 " +
				"order by MATCH_SCORE DESC");
        doRDBMSQuery("select top 10 adText, lucene_score(id) as MATCH_SCORE from ads " +
        		"where lucene_query('Kitchen table',id)>0 " +
				"order by MATCH_SCORE DESC");
        doRDBMSQuery("select top 10 adText from ads " +
        		"where lucene_query('Kitchen table',id)>0 " +
				"order by lucene_score(id) DESC");
        doRDBMSQuery("select top 10 lucene_highlight(adText) from ads " +
        		"where pricePounds <200 " +
        		"and lucene_query('bass guitar drums',id)>0 " +
				"order by lucene_score(id) DESC");
        doRDBMSQuery("select top 10 count(*) as numAds,pricePounds  from ads " +
        		"where pricePounds <500 " +
        		"and lucene_query('table',id)>0 " +
				"group by pricePounds order by numAds desc");
        
        doRDBMSQuery("select top 10 pricePounds , adText from ads " +
        		"where pricePounds =1 " +
        		"and lucene_query('table',id)>0 " +
				"order by lucene_score(id) desc");
        doRDBMSQuery("select top 10 lucene_score(id) as SCORE, " +
        		"lucene_highlight(adText) from ads " +
        		"where pricePounds <200 and pricePounds >1" +
        		"and lucene_query('drum kit',id)>0 " +
				"order by SCORE DESC, pricePounds ASC");                
        //Mix the lucene score and inverse of price (2000 - pricePounds) to rank results
        doRDBMSQuery("select top 10 lucene_score(id) AS score, pricePounds,lucene_score(id)*(5000-pricePounds) as MIXED_SCORE, " +
        		"lucene_highlight(adText) from ads " +
        		"where pricePounds <2000 and pricePounds >1" +
        		"and lucene_query('drum kit',id)>0 " +
				"order by MIXED_SCORE DESC");        
               
        
        searcher.close();
        reader.close();
        Statement s=conn.createStatement();
        s.execute("SHUTDOWN");	        
        s.close();
        conn.close();                
    }
    
    /**
     * @param string
     */
    private static void doRDBMSQuery(String rdbmsQuery)
    {
        Statement s=null;
        long start=System.currentTimeMillis();
        //Initialize the db embedded Lucene functions with reader,analyzer and keymap 
        DBEmbeddedLuceneFunctions.setQueryHandler(new DBEmbeddedLuceneFunctions(reader,new StandardAnalyzer(),keyMap));
        ResultSet rs=null;
        int rowNum=1;
        try
        {
	        s=conn.createStatement();
    	    rs=s.executeQuery(rdbmsQuery);
    	    ResultSetMetaData rm=rs.getMetaData();
    	    while(rs.next())
    	    {
    	        System.out.print("result "+rowNum++ +":");
    	        for(int i=1;i<=rm.getColumnCount();i++)
    	        System.out.print(rs.getString(i)+", ");
    	        System.out.println();
    	    }
        }
        catch(Exception e)
        {
            throw new RuntimeException("Error running rdbms query:"+e,e);
        }
        finally
        {
            DBUtils.tidyUp(s,rs);
        }
        long time=System.currentTimeMillis()-start;
        System.out.println("Query "+rdbmsQuery+"took "+time+"ms\n\n");
    }

    static void doRDBMSFilteredQuery(String luceneQuery, String rdbmsQuery) throws Exception
    {
        doRDBMSFilteredQuery(luceneQuery,rdbmsQuery,false);
    }
    static void doRDBMSFilteredQuery(String luceneQuery, String rdbmsQuery, boolean showResults) throws Exception
    {
        long start=System.currentTimeMillis();
        Query q=QueryParser.parse(luceneQuery, "contents",BuildHSqlDbWithLuceneIndex.analyzer);
        Hits h=null;
        if(rdbmsQuery!=null)
        {
            Filter filter=getGenericRDBMSFilter(rdbmsQuery);
            h=searcher.search(q, filter);
        }
        else
        {
            h=searcher.search(q);            
        }
        long time=System.currentTimeMillis()-start;
        if(rdbmsQuery==null)
        {
            System.out.println("Got "+h.length()+" docs in "+time+" ms");
        }
        else
        {
            System.out.println("Got "+h.length()+" using ["+luceneQuery+" and "+rdbmsQuery+"] in "+time+" ms");            
        }
        if(showResults)
        {
            start=System.currentTimeMillis();
            PreparedStatement ps=conn.prepareStatement("select adText from ads where id=?");
            for(int i=0;i<h.length();i++)
            {
                int rdbmsKey=keyMap.getRdbmsKey(h.id(i));
                showResult(ps,rdbmsKey);
            }
            ps.close();
            time=System.currentTimeMillis()-start;
            System.out.println("Got results in:"+time+" ms");
        }
        
    }
   

    private static void showResult(PreparedStatement ps,int rdbmsKey) 
    {
        ResultSet rs=null;
        try
        {
            ps.setInt(1,rdbmsKey);
    	    rs=ps.executeQuery();
    	    if(rs.next())
    	    {
//    	        System.out.println(rs.getString(1));
    	        rs.getString(1);
    	    }
        }
        catch(Exception e)
        {
            throw new RuntimeException("Error running rdbms query:"+e,e);
        }
        finally
        {
            try
            {
                rs.close();
            } catch (SQLException e1)
            {
                e1.printStackTrace();
            }
        }
        
    }

    
    /** 
     * This is a database-agnostic way of getting a list of keys for use in a filter 
     * @param rdbmsQuery
     * @return
     */
    private static Filter getGenericRDBMSFilter(String rdbmsQuery)
    {     
        final BitSet bits=new BitSet(reader.maxDoc());
        Statement s=null;
        ResultSet rs=null;
        try
        {
	        s=conn.createStatement();
    	    rs=s.executeQuery(rdbmsQuery);
    	    while(rs.next())
    	    {
    	        int rdbmsKey=rs.getInt(1);
//                bits.set(rdbms2Lucene[rdbmsKey]);
                bits.set(keyMap.getLuceneDocId(rdbmsKey));
    	    }
        }
        catch(Exception e)
        {
            throw new RuntimeException("Error running rdbms query:"+e,e);
        }
        finally
        {
            DBUtils.tidyUp(s,rs);
        }
        return new BitSetFilter(bits);
    }

}
