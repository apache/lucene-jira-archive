package demo.hsql;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.db.hsql.RegisterLuceneFunctionsWithHsql;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.FSDirectory;

import com.inperspective.utils.DBUtils;

/**
 * This is an experiment in using HQSQLDB to store all index content (rather
 * than keeping it as stored fields in Lucene. The only stored field (as opposed to
 * indexed field) in Lucene is the PK which links to HQSLDB
 * @author Mark Harwood
 */
public class BuildHSqlDbWithLuceneIndex
{
	//TODO !!!!change these settings to match where you want your index/database to be created!!
    private static final String JDBC_URL = "jdbc:hsqldb:c:\\indexes\\lucenedb\\hsql\\adsDb";
    public static final String LUCENE_ADS_INDEX_DIR = "c:\\indexes\\lucenedb\\hsql\\adsLuceneIndex";
    
    private static final String ADS_FILE = "demoData/ads.txt";            
    public static Analyzer analyzer=new StandardAnalyzer();
    private static Pattern pricePattern;

    public static void main(String[] args) throws Exception
    {
		pricePattern=Pattern.compile("�([0-9]{1,5})", Pattern.CASE_INSENSITIVE);
		
		FSDirectory dir=FSDirectory.getDirectory(new File(LUCENE_ADS_INDEX_DIR),true);
		IndexWriter writer=new IndexWriter(dir, analyzer,true);
        
        
        Connection c = getConnection();        
        Statement s=null;
        try
        {
	        s=c.createStatement();
	        
	        
	        //Create Lucene functions
	        RegisterLuceneFunctionsWithHsql.register(c);

	        //Create database tables
	        s.execute("DROP TABLE ads IF EXISTS");
	        s.execute("CREATE CACHED TABLE ads ( id INTEGER IDENTITY, " +
	        		"adText VARCHAR(256), " +
	        		"pricePounds INTEGER)");
	        
	        
	        // Load data
	    	FileInputStream fis = new FileInputStream(ADS_FILE);
	    	BufferedReader d = new BufferedReader(new InputStreamReader(fis)); 
	    	String line = d.readLine();
	    	int lineCount=0;
	    	
	    	//Unfortunately need DB-specific call to retrieve generated keys (unlike Derby)
	        PreparedStatement idps=c.prepareStatement("CALL IDENTITY()");
	        PreparedStatement ps=c.prepareStatement("INSERT INTO ads(adText,pricePounds)" +
					" VALUES(?,?)");
	    	while(line!=null)
	    	{
	    	    int pricePounds=0;
				Matcher priceMatcher=pricePattern.matcher(line);
				if(priceMatcher.find())
				{
					String price=priceMatcher.group(1);
					System.out.println("�"+price);
					pricePounds=Integer.parseInt(price);
				}
	    	    
	    	    ps.setString(1,line);
	    	    ps.setInt(2,pricePounds);
	    	    ps.executeUpdate();
	    	    
	    	    
	    	    
	    	    ResultSet rs=idps.executeQuery();
	    	    rs.next();
	    	    int key=rs.getInt(1);
	    	    
	    	    Document doc=new Document();
	    	    Field f=new Field("contents",line,Field.Store.NO, Field.Index.TOKENIZED);	    	    	    	    
	    	    doc.add(f);
	    	    f=new Field("key",""+key,Field.Store.YES, Field.Index.UN_TOKENIZED);	    	    	    	    
	    	    doc.add(f);
	    	    writer.addDocument(doc);
	    	    
	    		line=d.readLine();	    		
	    		lineCount++;
	    	}
	    	d.close();
	    	writer.optimize();
	    	writer.close();
	    	System.out.println("Creating RDBMS index");
	    	DBUtils.tidyUp(ps);
	    	DBUtils.tidyUp(idps);
	        s.execute("CREATE INDEX ADS_PRICE_INDEX ON ads (pricePounds)");
	        System.out.println("Inserted "+lineCount+" ads into DB");
	        
	        s.execute("SHUTDOWN");
	        
        }
        finally
        {
            DBUtils.tidyUp(c,s);
        }
        
        
    }

    /**
     * @return
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public static Connection getConnection() 
    {
        // Load the HSQL Database Engine JDBC driver
        // hsqldb.jar should be in the class path or made part of the current jar
        try
        {
        Class.forName("org.hsqldb.jdbcDriver");        
        Connection c = DriverManager.getConnection(JDBC_URL, "sa", "");
        return c;
        }
        catch(Exception e)
        {
            throw new RuntimeException("Error establising database connection:"+e,e);
        }
    }
}
