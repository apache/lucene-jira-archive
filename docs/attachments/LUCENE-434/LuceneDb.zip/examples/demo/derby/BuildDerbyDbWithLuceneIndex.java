package demo.derby;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.db.derby.RegisterLuceneFunctionsWithDerby;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.FSDirectory;

import com.inperspective.utils.DBUtils;

/**
 * This is an experiment in using Derby to store all index content (rather
 * than keeping it as stored fields in Lucene. The only stored field (as opposed to
 * indexed field) in Lucene is the PK which links to HQSLDB
 * @author Mark
 */
public class BuildDerbyDbWithLuceneIndex
{
	//TODO !!!!change these settings to match where you want your index/database to be created!!
    private static final String INDEX_LOCATION="c:/indexes/lucenedb/derby/adsDb";
    public static final String LUCENE_ADS_INDEX_DIR = "c:/indexes/lucenedb/derby/adsLuceneindex";
    
    
    
    private static final String JDBC_URL = "jdbc:derby:"+INDEX_LOCATION+";create=true";
    private static final String JDBC_SHUTDOWN_URL = "jdbc:derby:"+INDEX_LOCATION+";shutdown=true";
    private static final String ADS_FILE = "demoData/ads.txt";
    public static Analyzer analyzer=new StandardAnalyzer();
    private static Pattern pricePattern;

    public static void main(String[] args) throws Exception
    {
		pricePattern=Pattern.compile("�([0-9]{1,5})", Pattern.CASE_INSENSITIVE);
		
		FSDirectory dir=FSDirectory.getDirectory(new File(LUCENE_ADS_INDEX_DIR),true);
		IndexWriter writer=new IndexWriter(dir, analyzer,true);
        
        
        Connection c = getConnection();
        
        Statement s=null;
        try
        {
	        s=c.createStatement();        

	        //============Create Lucene-related functions===============        	        
	        RegisterLuceneFunctionsWithDerby.register(c);

	        //==========Create database tables=================
	        try
	        {
	            s.execute("DROP TABLE ads");
	        }
	        catch(Exception ignore){}
	        s.execute("CREATE TABLE ads ( " +
//	        		"id INTEGER IDENTITY, " +
	                "ID INTEGER NOT NULL GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) PRIMARY KEY,"+
	        		"adText LONG VARCHAR, " +
	        		"pricePounds INTEGER)");
	        

	        //Load data
	    	FileInputStream fis = new FileInputStream(ADS_FILE);
	    	BufferedReader d = new BufferedReader(new InputStreamReader(fis)); 
	    	String line = d.readLine();
	    	int lineCount=0;	    	
	        PreparedStatement ps=c.prepareStatement("INSERT INTO ads(adText,pricePounds)" +
					" VALUES(?,?)", Statement.RETURN_GENERATED_KEYS);
	    	while(line!=null)
	    	{
	    	    int pricePounds=0;
				Matcher priceMatcher=pricePattern.matcher(line);
				if(priceMatcher.find())
				{
					String price=priceMatcher.group(1);
					System.out.println("�"+price);
					pricePounds=Integer.parseInt(price);
				}
	    	    
	    	    ps.setString(1,line);
	    	    ps.setInt(2,pricePounds);
	    	    ps.executeUpdate();
	    	    ResultSet rs = ps.getGeneratedKeys();	    	    
	    	    rs.next();
	    	    int key=rs.getInt(1);
	    	    rs.close();
	    	    
	    	    Document doc=new Document();
	    	    Field f=new Field("contents",line,Field.Store.NO, Field.Index.TOKENIZED);	    	    	    	    
	    	    doc.add(f);
	    	    f=new Field("key",""+key,Field.Store.YES, Field.Index.UN_TOKENIZED);	    	    	    	    
	    	    doc.add(f);
	    	    writer.addDocument(doc);
	    	    
	    		line=d.readLine();	    		
	    		lineCount++;
	    	}
	    	d.close();
	    	writer.optimize();
	    	writer.close();
	    	System.out.println("Creating RDBMS index");
	    	DBUtils.tidyUp(ps);
	        s.execute("CREATE INDEX ADS_PRICE_INDEX ON ads (pricePounds)");
	        System.out.println("Inserted "+lineCount+" ads into DB");
        }
        finally
        {
            DBUtils.tidyUp(c,s);
        }
        
        shutdownDB();
        
    }

    public static void shutdownDB()
    {
        try
        {
            DriverManager.getConnection(JDBC_SHUTDOWN_URL);
        }
        catch(Exception e)
        {
            System.out.println("Shutdown produced an error- expected because documented as normal behaviour");
        }
    }

    public static Connection getConnection() 
    {
        // Load the Derby Database Engine JDBC driver
        // derby.jar should be in the class path 
        try
        {
	        Class.forName("org.apache.derby.jdbc.EmbeddedDriver");        
	        Connection c = DriverManager.getConnection(JDBC_URL, "", "");
	        return c;
        }
        catch(Exception e)
        {
            throw new RuntimeException("Error establising database connection:"+e,e);
        }
    }
}
