Lucene Database integration
===========================
17/09/2005 
Mark Harwood

This project shows how Lucene search functionality can be integrated with 
the Derby and HSQLDB pure Java databases.

For both databases the examples demonstrate:
1) how database results can be used to filter Lucene queries
2) how the SQL syntax can be extended to allow Lucene queries to run directly IN the database.

Some powerful queries which mix Lucene search facilities (fuzzy matching, phrases, 
relevance ranking, highlighting etc) can be mixed into single SQL statements eg
	select top 10 lucene_score(id) as SCORE
        	lucene_highlight(adText) from ads 
       		where pricePounds <200 and pricePounds >1
       		and lucene_query('"drum kit"',id)>0 
			order by SCORE DESC, pricePounds ASC

Some people may find this a very convenient/natural way of writing complex queries that mix 
database-based criteria with Lucene's capabilities. 
It should be noted though that a pure Lucene-based solution using custom filters etc is likely
to out-perform these database hybrids.

Running the code
================
* Make sure you have HSQLDB and Derby jars in your classpath (this has been tested with 
latest versions at time of writing: hsqldb 1.8.0.2 and Derby 10.1.1.0 ). The highlighter from the
Lucene "contrib" section is also required in the classpath.

* Amend the directory names used to create databases/indexes in the following Java files:
	demo.derby.BuildDerbyDbWithLuceneIndex
	demo.hsql.BuildHsqlDbWithLuceneIndex
	demo.purelucene.BuildLuceneOnlyIndex
* Compile all the code and run the above examples to create the databases/indexes from the 
demo data (a selection of classified ads)

* Now run and experiment with the example query code in these classes:
	demo.derby.DerbyDbLuceneQuery
	demo.hsql.HsqlDbWithLuceneIndex
	demo.purelucene.LuceneOnlyQuery
	
Next steps :automated indexing
==============================
Both these databases support Java-based triggers so it may be possible to build standard
triggers to automate the indexing of content as new database records are inserted. 
The difficult part I suspect is working out when to optimize/close/reopen readers and writers - 
especially when updates to existing records occur as this requires a reader.delete, 
reader.close then a writer.add.
Could be messy.
