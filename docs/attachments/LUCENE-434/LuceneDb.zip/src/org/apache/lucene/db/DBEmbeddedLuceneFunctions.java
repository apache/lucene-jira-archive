package org.apache.lucene.db;

import java.io.IOException;
import java.io.StringReader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.HitCollector;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;

/**
 * Provides user-defined DB functions for Lucene operations (query, score,highlight, querytime).
 * The static methods exposed to the database engine delegate to thread-specific instances by using
 * a threadlocal variable which holds user's choice of IndexReader/analyzer etc
 * These functions can be registered with a HSQL database like this:
 *	            s=conn.createStatement();
 *		        s.execute("CREATE ALIAS lucene_query FOR \""+DBEmbeddedLuceneFunctions.class.getName()
 *		                +".query\";");
 *		        s.execute("CREATE ALIAS lucene_score FOR \""+DBEmbeddedLuceneFunctions.class.getName()
 *		                +".score\";");
 *		        s.execute("CREATE ALIAS lucene_highlight FOR \""+DBEmbeddedLuceneFunctions.class.getName()
 *		                +".highlight\";");
 *  or in a Derby database like this:
 *  	        s.execute("CREATE FUNCTION lucene_query (query VARCHAR(255), id INTEGER) " +
 *	        		"RETURNS DOUBLE " +
 *	        		"PARAMETER STYLE JAVA " +
 *	        		"NO SQL " +
 *	        		"LANGUAGE JAVA " +
 *	        		"EXTERNAL NAME '"+DBEmbeddedLuceneFunctions.class.getName()+".query'");
 *
 *		        s.execute("CREATE FUNCTION lucene_score (id INTEGER) " +
 *	        		"RETURNS DOUBLE " +
 *	        		"PARAMETER STYLE JAVA " +
 *	        		"NO SQL " +
 *	        		"LANGUAGE JAVA " +
 *	        		"EXTERNAL NAME '"+DBEmbeddedLuceneFunctions.class.getName()+".score'");
 *
 *		        s.execute("CREATE FUNCTION lucene_highlight (text VARCHAR(2056)) " +
 *	        		"RETURNS LONG VARCHAR " +
 *	        		"PARAMETER STYLE JAVA " +
 *	        		"NO SQL " +
 *	        		"LANGUAGE JAVA " +
 *	        		"EXTERNAL NAME '"+DBEmbeddedLuceneFunctions.class.getName()+".highlight'");
 *
 *
 *	..and then used like this:
 *     //establish Lucene context for thread
 *     DBEmbeddedLuceneFunctions.setQueryHandler(new DBEmbeddedLuceneFunctions(reader,new StandardAnalyzer(),keyMap));
 *     ..
 *   then you can invoke SQL like this:
 *         resultSet=s.executeQuery("select top 10 lucene_score(id) as SCORE, " +
 *        		"lucene_highlight(adText) from ads " +
 *        		"where pricePounds <200 and pricePounds >1" +
 *        		"and lucene_query('drum kit',id)>0 " +
 *				"order by SCORE DESC, pricePounds ASC;
 * 
 * @author MAHarwood
 */
public class DBEmbeddedLuceneFunctions
{

    private KeyMap keyMap;
    static ThreadLocal threadLocal=new ThreadLocal();
    
    private IndexReader reader;
    float results[]=null;
    private Analyzer analyzer;
    private Query query;
    private Highlighter highlighter;
    String fieldName="contents"; //default highlight field name to "contents"    
    int timeTakenForQuery;

    /**
     * Initializes with Lucene objects used for subsequent queries
     * @param bits
     * @param keyMap
     */
    public DBEmbeddedLuceneFunctions(IndexReader reader, Analyzer analyzer,KeyMap keyMap)
    {
        this.reader=reader;
        this.analyzer=analyzer;
        this.keyMap=keyMap;
    }

    /**
     * Used by client code to initialize calling thread before going running the database
     * command
     * @param handler
     */
    public static void setQueryHandler(DBEmbeddedLuceneFunctions handler)
    {
        threadLocal.set(handler);        
    }
    /**
     * Fetches the current query handler for the calling thread
     * @return
     */
    public static DBEmbeddedLuceneFunctions getCurrentHandler()
    {
        return (DBEmbeddedLuceneFunctions) threadLocal.get();        
    }

    /**
     * A static method which can be called as a user-definable function INSIDE the database.
     * Returns a non-normalized Lucene score for the Lucene document associated with this
     * RDBMS primary key. Typically called in a "Where" clause eg where lucene_query('foo', id) >0
     * The actual handling of this method is passed off to a thread-specific instance.
     */
    public static double query(String query,int rdbmsKey)
    {
        DBEmbeddedLuceneFunctions queryFunction=getCurrentHandler();
        return queryFunction.threadSpecificQuery(query,rdbmsKey);        
    }

    /**
     * A static method which can be called as a user-definable function INSIDE the database.
     * Returns the amount of time in milliseconds running the Lucene query
     * The actual handling of this method is passed off to a thread-specific instance.
     */
    public static int queryTime()
    {
        DBEmbeddedLuceneFunctions queryFunction=getCurrentHandler();
        return queryFunction.threadSpecificQueryTime();        
    }


    /**
     * Used within the "select" part of the SQL query - returns the score from a query
     * A static method which can be called as a user-definable function INSIDE the database.
     * The actual handling of this method is passed off to a thread-specific instance.
     */
    public static double score(int rdbmsKey)
    {
        DBEmbeddedLuceneFunctions queryFunction=getCurrentHandler();
        return queryFunction.threadSpecificScore(rdbmsKey);        
    }
    /**
     * Used within the "select" part of SQL to highlight returned results.
     * A static method which can be called as a user-definable function INSIDE the database.
     * The actual handling of this method is passed off to a thread-specific instance.
     */
    public static String highlight(String text)
    {        
        DBEmbeddedLuceneFunctions queryFunction=getCurrentHandler();
        return queryFunction.threadSpecificHighlight(text);        
    }
    
    private String threadSpecificHighlight(String text)
    {
        if(highlighter==null)
        {
            highlighter=new Highlighter(new QueryScorer(query));
        }
        try
        {
            return highlighter.getBestFragments(analyzer.tokenStream(fieldName,new StringReader(text))
                    	,text,2,"...");
        }
        catch(Exception e)
        {
            throw new RuntimeException("Error highlighting text:"+e,e);
        }
    }
    /**
     * The thread-specific object's handling of this user-defined database function.
     */
    private int threadSpecificQueryTime()
    {        
        return timeTakenForQuery;
    }
    /**
     * The thread-specific object's handling of this user-defined database function. 
     */
    private double threadSpecificQuery(String queryText,int rdbmsKey)
    {
        if(results==null)
        {
        	//We haven't run the query - run once and stores all scores (could be a big array!)
            results=new float[reader.maxDoc()];
            long start=System.currentTimeMillis();
            IndexSearcher searcher=new IndexSearcher(reader);
            try
            {
                query=QueryParser.parse(queryText,fieldName, analyzer);
                query=query.rewrite(reader);
                
                searcher.search(query,new HitCollector(){
                    public void collect(int doc, float score)
                    {
                        results[doc]=score;                        
                    }});
            } catch (ParseException e)
            {
                throw new RuntimeException("Error parsing query:"+e,e);
            } catch (IOException e)
            {
                throw new RuntimeException("Error reading index:"+e,e);
            }
            finally
            {
                timeTakenForQuery=(int) (System.currentTimeMillis()-start);
            }
        }        
        return results[keyMap.getLuceneDocId(rdbmsKey)];
    }
    
    /**
     * The thread-specific object's handling of this user-defined database function.
     */
    private double threadSpecificScore(int rdbmsKey)
    {
        return results[keyMap.getLuceneDocId(rdbmsKey)];
    }

	public Analyzer getAnalyzer()
	{
		return analyzer;
	}

	public void setAnalyzer(Analyzer analyzer)
	{
		this.analyzer = analyzer;
	}

	public String getFieldName()
	{
		return fieldName;
	}

	public void setFieldName(String fieldName)
	{
		this.fieldName = fieldName;
	}

	public Highlighter getHighlighter()
	{
		return highlighter;
	}

	public void setHighlighter(Highlighter highlighter)
	{
		this.highlighter = highlighter;
	}
    
}
