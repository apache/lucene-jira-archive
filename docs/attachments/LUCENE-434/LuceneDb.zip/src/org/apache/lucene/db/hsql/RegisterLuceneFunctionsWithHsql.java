package org.apache.lucene.db.hsql;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.lucene.db.DBEmbeddedLuceneFunctions;

/**
 * Utility class to register DBEmbeddedLuceneFunctions static methods with HSQL database.
 * This only needs to be done once and registration persists across database shutdowns.
 * @author Mark
 *
 */
public class RegisterLuceneFunctionsWithHsql
{
	public static void register(Connection conn) throws SQLException
	{
		Statement s=conn.createStatement();
		try
		{
	        s.execute("CREATE ALIAS lucene_query FOR \""+DBEmbeddedLuceneFunctions.class.getName()
	                +".query\";");
	        s.execute("CREATE ALIAS lucene_score FOR \""+DBEmbeddedLuceneFunctions.class.getName()
	                +".score\";");
	        s.execute("CREATE ALIAS lucene_highlight FOR \""+DBEmbeddedLuceneFunctions.class.getName()
	                +".highlight\";");
		}
		finally
		{
			try{s.close();}catch(Exception ignore){}
		}
        
	}

}
