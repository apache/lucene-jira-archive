package org.apache.lucene.db.derby;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.lucene.db.DBEmbeddedLuceneFunctions;

/**
 * Utility class to register DBEmbeddedLuceneFunctions static methods with Derby database.
 * This only needs to be done once and registration persists across database shutdowns.
 * @author Mark
 *
 */
public class RegisterLuceneFunctionsWithDerby
{
	public static void register(Connection conn) throws SQLException
	{
		Statement s=conn.createStatement();
		try
		{
	        try
	        {
		        s.execute("DROP FUNCTION lucene_query");
	        }
	        catch(Exception ignore){}
	        s.execute("CREATE FUNCTION lucene_query (query VARCHAR(255), id INTEGER) " +
	        		"RETURNS DOUBLE " +
	        		"PARAMETER STYLE JAVA " +
	        		"NO SQL " +
	        		"LANGUAGE JAVA " +
	        		"EXTERNAL NAME '"+DBEmbeddedLuceneFunctions.class.getName()+".query'");
	        try
	        {
		        s.execute("DROP FUNCTION lucene_score");
	        }
	        catch(Exception ignore){}
	        s.execute("CREATE FUNCTION lucene_score (id INTEGER) " +
	        		"RETURNS DOUBLE " +
	        		"PARAMETER STYLE JAVA " +
	        		"NO SQL " +
	        		"LANGUAGE JAVA " +
	        		"EXTERNAL NAME '"+DBEmbeddedLuceneFunctions.class.getName()+".score'");
	        try
	        {
		        s.execute("DROP FUNCTION lucene_highlight");
	        }
	        catch(Exception ignore){}
	        s.execute("CREATE FUNCTION lucene_highlight (text VARCHAR(2056)) " +
	        		"RETURNS LONG VARCHAR " +
	        		"PARAMETER STYLE JAVA " +
	        		"NO SQL " +
	        		"LANGUAGE JAVA " +
	        		"EXTERNAL NAME '"+DBEmbeddedLuceneFunctions.class.getName()+".highlight'");
		}
		finally
		{
			try{s.close();}catch(Exception ignore){}
		}
        
	}

}
