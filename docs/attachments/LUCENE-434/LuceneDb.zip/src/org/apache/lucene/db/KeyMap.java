package org.apache.lucene.db;

/**
 * @author MAHarwood
 */
public interface KeyMap
{
    public int getLuceneDocId(int rdbmsKey);
    public int getRdbmsKey(int luceneDocId);
}
