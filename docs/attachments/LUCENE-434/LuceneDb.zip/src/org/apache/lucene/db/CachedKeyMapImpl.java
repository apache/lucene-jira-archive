package org.apache.lucene.db;

import org.apache.lucene.index.IndexReader;

/**
 * Look-up implementation for converting rdbms primary keys and lucene doc ids.
 * RDBMS keys are expected to be stored as fields inside Lucene (no index is required on this
 * Lucene field)
 * Uses 2 arrays loaded from Lucene index.
 * @author MAHarwood
 */
public class CachedKeyMapImpl implements KeyMap
{
    int numLuceneDocs;
    int[] lucene2Rdbms;
    int maxRdbmsKey=0;
    int[] rdbms2Lucene;

    public CachedKeyMapImpl(IndexReader reader, String keyFieldName)
    {
        int numLuceneDocs=reader.maxDoc();
        lucene2Rdbms=new int[numLuceneDocs];
        //TODO - array size may need to be bigger than Lucene Key size?
        //TODO how to manage holes?
        int rdbmsKey;
        int maxRdbmsKey=0;
        for(int luceneId=0;luceneId<numLuceneDocs;luceneId++)
        {
            try
            {
                rdbmsKey = Integer.parseInt(reader.document(luceneId).get(keyFieldName));
                lucene2Rdbms[luceneId]=rdbmsKey;
                maxRdbmsKey=Math.max(rdbmsKey,maxRdbmsKey);
            } catch (Exception e)
            {
                throw new RuntimeException("Error mapping key for doc#"+luceneId,e);
            }
        }
        
        rdbms2Lucene=new int[maxRdbmsKey+1];
        for(int luceneId=0;luceneId<numLuceneDocs;luceneId++)
        {
            rdbms2Lucene[lucene2Rdbms[luceneId]]=luceneId;    
        }
    }
    
    public final int getLuceneDocId(int rdbmsKey)
    {
        return rdbms2Lucene[rdbmsKey];
    }

    public final int getRdbmsKey(int luceneDocId)
    {
        return lucene2Rdbms[luceneDocId];
    }
}
