package org.apache.lucene.db;

import java.io.IOException;
import java.util.BitSet;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.Filter;

/**
 * @author MAHarwood
 */ 
public class BitSetFilter extends Filter
{
    BitSet bits;
    
    public BitSetFilter(BitSet bits)
    {
        super();
        this.bits = bits;
    }
    public BitSet bits(IndexReader reader) throws IOException
    {
        return bits;
    }    
}