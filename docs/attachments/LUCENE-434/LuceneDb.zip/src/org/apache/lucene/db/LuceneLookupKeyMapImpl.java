package org.apache.lucene.db;

import java.io.IOException;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermDocs;

/**
 * Non-cached look-up implementation for converting rdbms primary keys and lucene doc ids.
 * Uses Lucene index to lookup docs - rdbms key must be held inside Lucene as a 
 * stored and indexed field.
 * @author MAHarwood
 */
public class LuceneLookupKeyMapImpl implements KeyMap
{
    IndexReader reader;
    private String keyFieldName;

    public LuceneLookupKeyMapImpl(IndexReader reader, String keyFieldName)
    {
        this.keyFieldName=keyFieldName;
        this.reader=reader;
        
    }
    
    public final int getLuceneDocId(int rdbmsKey)
    {
        try
        {
            TermDocs td=reader.termDocs(new Term(keyFieldName,""+rdbmsKey));
            td.next();
            int docId=td.doc();
            return docId;
        } catch (IOException e)
        {
            throw new RuntimeException("Error reading doc id for rdbms key:"+rdbmsKey);
        }
    }

    public final int getRdbmsKey(int luceneDocId)
    {
        try
        {
            return  Integer.parseInt(reader.document(luceneDocId).get(keyFieldName));
        } 
        catch (Exception e)
        {
            throw new RuntimeException("Error reading rdbms key for lucene id:"+luceneDocId);
        }
    }
}
