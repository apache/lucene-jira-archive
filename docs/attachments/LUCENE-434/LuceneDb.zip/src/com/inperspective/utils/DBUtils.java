package com.inperspective.utils;

import java.sql.*;

/**
 * This class provides generally useful utilities for accessing databases through JDBC
 *
 *
 * @author  Mark Harwood
 * @version 1.0    07 Mar 2000
 */

/*
	This class provides generally useful utilities for accessing databases through JDBC
*/

public class DBUtils
{



    /**
     * Tidy up routine for JDBC objects with proper exception handling.
     * This is typically called from a try..finally construct after performing
     * some database activity.
     *
     * @param  conn the database Connection to be closed
     * @param  statement the Statement to be closed
     * @param  results the ResultSet to be closed
     * @return No return
     */
  public static void tidyUp(Connection conn, Statement statement, ResultSet results)
  {
        if (statement != null)
	{
		try
		{
			        statement.close();
		}
		catch(Exception ignore){}
	}

        if (results != null)
	{
		try
		{
			        results.close();
		}
		catch(Exception ignore){}
	}

        if (conn != null)
	{
		try
		{
			        conn.close();
		}
		catch(Exception ignore){}
	}
  }

    /**
     * Tidy up routine for JDBC objects with proper exception handling.
     * This is typically called from a try..finally construct after performing
     * some database activity.
     *
     * @param  conn the database Connection to be closed
     * @param  statement the Statement to be closed
     * @return No return
     */
  public static void tidyUp(Connection conn, Statement statement)
  {
	tidyUp(conn, statement,null);
  }

    /**
     * Tidy up routine for JDBC objects with proper exception handling.
     * This is typically called from a try..finally construct after performing
     * some database activity.
     *
     * @param  conn the database Connection to be closed
     * @return No return
     */
  public static void tidyUp(Connection conn)
  {
	tidyUp(conn, null,null);
  }


    /**
     * Tidy up routine for JDBC objects with proper exception handling.
     * This is typically called from a try..finally construct after performing
     * some database activity.
     *
     * @param  statement the Statement to be closed
     * @return No return
     */
  public static void tidyUp(Statement statement)
  {
	tidyUp(null, statement,null);
  }

    /**
     * Tidy up routine for JDBC objects with proper exception handling.
     * This is typically called from a try..finally construct after performing
     * some database activity.
     *
     * @param  statement the Statement to be closed
     * @param  results the ResultSet to be closed
     * @return No return
     */
  public static void tidyUp(Statement statement, ResultSet results)
  {
	tidyUp(null,statement,results);
  }


}
