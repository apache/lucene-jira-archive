package org.apache.lucene.store;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;
import java.util.Vector;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 * A database {@link Directory} implementation.
 * 
 * @version $Id: $
 * @author Amir Kibbar
 */
public final class DBDirectory extends Directory {
    /**
     * Creates a new <code>DBDirectory</code> instance using <code>props</code>
     * 
     * @param props database connection properties:<br>
     *            <table border="1">
     *            <tr>
     *            <td>key</td>
     *            <td>description</td>
     *            <td>values</td>
     *            <td>required?</td>
     *            </tr>
     *            <tr>
     *            <td>db.connection_method</td>
     *            <td>connection method - direct jdbc or jndi data source</td>
     *            <td>direct,jndi</td>
     *            <td>no. Default: direct</td>
     *            </tr>
     *            <tr>
     *            <td>db.jndi_name</td>
     *            <td>data source jndi name</td>
     *            <td>example: jdbc/MyDs</td>
     *            <td>only if db.connection_method=jndi</td>
     *            </tr>
     *            <tr>
     *            <td>db.driver</td>
     *            <td>jdbc driver classname</td>
     *            <td>example: com.mysql.jdbc.Driver</td>
     *            <td>only if db.connection_method=direct</td>
     *            </tr>
     *            <tr>
     *            <td>db.url</td>
     *            <td>database connection url</td>
     *            <td>example: jdbc:mysql://localhost:3306/myschema</td>
     *            <td>only if db.connection_method=direct</td>
     *            </tr>
     *            <tr>
     *            <td>db.username</td>
     *            <td>database username</td>
     *            <td>&nbsp;</td>
     *            <td>only if db.connection_method=direct</td>
     *            </tr>
     *            <tr>
     *            <td>db.password</td>
     *            <td>database password</td>
     *            <td>&nbsp;</td>
     *            <td>only if db.connection_method=direct</td>
     *            </tr>
     *            <tr>
     *            <td>db.sysdate</td>
     *            <td>the string that returns the current datetime value in this database</td>
     *            <td>example: sysdate</td>
     *            <td>no. Default: sysdate (fits Oracle, for MySql use sysdate())</td>
     *            </tr>
     *            <tr>
     *            <td>db.emptyblob</td>
     *            <td>the value of an empty blob in the database within a SQL statement</td>
     *            <td>example: empty_blob()</td>
     *            <td>no. Default: empty_blob() (fits Oracle, for MySql use '')</td>
     *            </tr>
     *            </table>
     */
    public static DBDirectory getDirectory(Properties props,String prefix) {
        return new DBDirectory(props,prefix);
    }

    private String prefix="";

    /**
     * default constructor to allow subclassing
     */
    protected DBDirectory() {
    }

    protected DBDirectory(Properties props,String prefix) {
        this.prefix=prefix;
        DBManager.initialize(props);
    }

    /**
     * Closes the store.
     */
    public void close() throws IOException {
        // nothing to do
    }

    /**
     * Creates a new, empty pseudo file in the pseudo directory with the given name. Returns a
     * stream writing this file.
     */
    public IndexOutput createOutput(String name) throws IOException {
        if(fileExists(name))
            throw new IOException("Cannot overwrite: "+prefix+"/"+name);
        DBFile file=new DBFile(prefix,name);
        return new DBIndexOutput(file);
    }

    /**
     * Removes an existing file in the directory.
     */
    public void deleteFile(String name) throws IOException {
        Connection conn=null;
        PreparedStatement stmt=null;
        try {
            conn=DBManager.getConnection();
            stmt=conn.prepareStatement("DELETE FROM LUCENE_INDEX WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,prefix);
            stmt.setString(2,name);
            stmt.execute();
            conn.commit();
        } catch(Exception e) {
            throw new IOException("cannot delete file "+name+". Reason: "+e.getMessage());
        } finally {
            DBManager.closeDbAccess(conn,stmt,null);
        }
    }

    /**
     * Returns true iff a file with the given name exists.
     */
    public boolean fileExists(String name) throws IOException {
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        try {
            conn=DBManager.getConnection();
            stmt=conn
                    .prepareStatement("SELECT COUNT(*) FROM LUCENE_INDEX WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,prefix);
            stmt.setString(2,name);
            rs=stmt.executeQuery();
            rs.next();
            return rs.getInt(1)==1;
        } catch(Exception e) {
            throw new IOException("cannot verify file: "+name+". Reason: "+e.getMessage());
        } finally {
            DBManager.closeDbAccess(conn,stmt,rs);
        }
    }

    /**
     * Returns the length of a file in the directory.
     */
    public long fileLength(String name) throws IOException {
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        try {
            conn=DBManager.getConnection();
            stmt=conn.prepareStatement("SELECT FILE_SIZE FROM LUCENE_INDEX "
                    +"WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,prefix);
            stmt.setString(2,name);
            rs=stmt.executeQuery();
            rs.next();
            return rs.getLong(1);
        } catch(Exception e) {
            throw new IOException("cannot verify file: "+name+". Reason: "+e.getMessage());
        } finally {
            DBManager.closeDbAccess(conn,stmt,rs);
        }
    }

    /**
     * Returns the time the named file was last modified.
     */
    public long fileModified(String name) throws IOException {
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        try {
            conn=DBManager.getConnection();
            stmt=conn.prepareStatement("SELECT LAST_MODIFIED FROM LUCENE_INDEX "
                    +"WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,prefix);
            stmt.setString(2,name);
            rs=stmt.executeQuery();
            rs.next();
            return rs.getLong(1);
        } catch(Exception e) {
            throw new IOException("cannot read file modification timestamp for: "+name+". Reason: "
                    +e.getMessage());
        } finally {
            DBManager.closeDbAccess(conn,stmt,rs);
        }
    }

    /**
     * Returns an array of strings, one for each pseudo file in the pseudo directory.
     */
    public String[] list() throws IOException {
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        try {
            conn=DBManager.getConnection();
            stmt=conn.prepareStatement("SELECT COUNT(*) FROM LUCENE_INDEX");
            rs=stmt.executeQuery();
            rs.next();
            int size=rs.getInt(1);
            rs.close();
            stmt.close();

            stmt=conn.prepareStatement("SELECT PREFIX,NAME FROM LUCENE_INDEX");
            rs=stmt.executeQuery();
            String[] result=new String[size];
            int i=0;
            while(rs.next()) {
                result[i++]=new String(rs.getString("PREFIX")+"/"+rs.getString("NAME"));
            }
            return result;
        } catch(SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBManager.closeDbAccess(conn,stmt,rs);
        }
    }

    /**
     * Construct a {@link Lock}.
     * 
     * @param name the name of the lock file
     */
    public Lock makeLock(String name) {
        return new DBLock(prefix,name);
    }

    /**
     * Returns a stream reading an existing file.
     */
    public IndexInput openInput(String name) throws IOException {
        return new DBIndexInput(new DBFile(prefix,name));
    }

    /**
     * Renames an existing file in the directory (prefix). If a file already exists with the new
     * name, then it is replaced. This replacement is atomic, since it is within a single database
     * transaction.
     */
    public void renameFile(String from,String to) throws IOException {
        Connection conn=null;
        PreparedStatement stmt=null;
        try {
            conn=DBManager.getConnection();
            stmt=conn.prepareStatement("DELETE FROM LUCENE_INDEX WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,prefix);
            stmt.setString(2,to);
            stmt.execute();
            stmt=conn.prepareStatement("UPDATE LUCENE_INDEX SET NAME=? WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,to);
            stmt.setString(2,prefix);
            stmt.setString(3,from);
            stmt.execute();
            conn.commit();
        } catch(SQLException e) {
            throw new IOException("Unable to rename file from "+from+" to "+to+". Reason: "
                    +e.getMessage());
        } finally {
            DBManager.closeDbAccess(conn,stmt,null);
        }
    }

    /**
     * Set the modified time of an existing file to now.
     */
    public void touchFile(String name) throws IOException {
        Connection conn=null;
        PreparedStatement stmt=null;
        try {
            conn=DBManager.getConnection();
            stmt=conn.prepareStatement("UPDATE LUCENE_INDEX SET LAST_MODIFIED="
                    +DBManager.getSysdateString()+" WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,prefix);
            stmt.setString(2,name);
            stmt.execute();
            conn.commit();
        } catch(SQLException e) {
            throw new IOException("Unable to touch file "+name+". Reason: "+e.getMessage());
        } finally {
            DBManager.closeDbAccess(conn,stmt,null);
        }
    }
}

/**
 * a pseudo file that represents a database entry
 * 
 * @author Amir Kibbar
 */
class DBFile {
    private Vector data=new Vector();
    private Date lastModified;
    private boolean loaded=false;
    private String name;
    private String prefix;
    private long size;

    public DBFile(String prefix,String name) {
        this.prefix=prefix;
        this.name=name;
    }

    public void addData(byte[] buffer) {
        data.add(buffer);
    }

    public void clearData() {
        data=new Vector();
    }

    public Vector getData() {
        return data;
    }

    public Date getLastModified() {
        return lastModified;
    }

    public String getName() {
        return name;
    }

    public String getPrefix() {
        return prefix;
    }

    public long getSize() {
        return size;
    }

    public boolean isLoaded() {
        return loaded;
    }

    public void setData(Vector data) {
        this.data=data;
    }

    public void setLastModified(Date lastModified) {
        this.lastModified=lastModified;
    }

    public void setLoaded(boolean loaded) {
        this.loaded=loaded;
    }

    public void setName(String name) {
        this.name=name;
    }

    public void setPrefix(String prefix) {
        this.prefix=prefix;
    }

    public void setSize(long size) {
        this.size=size;
    }
}

class DBIndexInput extends BufferedIndexInput {
    private DBFile file;
    private int pointer;

    public DBIndexInput(DBFile file) {
        this.file=file;
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        try {
            conn=DBManager.getConnection();
            stmt=conn.prepareStatement("SELECT * FROM LUCENE_INDEX WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,file.getPrefix());
            stmt.setString(2,file.getName());
            rs=stmt.executeQuery();
            rs.next();
            file.setLastModified(rs.getDate("LAST_MODIFIED"));
            file.setLoaded(true);
            file.setSize(rs.getLong("FILE_SIZE"));
            file.clearData();

            Blob blob=rs.getBlob("DATA");
            byte[] buffer=null;
            long pos=1;
            int length=0;
            while(pos<blob.length()) {
                length=BUFFER_SIZE>blob.length()-pos?(int)(blob.length()-pos+1):BUFFER_SIZE;
                buffer=blob.getBytes(pos,length);
                file.addData(buffer);
                pos+=BUFFER_SIZE>blob.length()-pos?(int)(blob.length()-pos+1):BUFFER_SIZE;
            }
        } catch(SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBManager.closeDbAccess(conn,stmt,rs);
        }
    }

    public void close() throws IOException {
        // nothing to do
    }

    public long length() {
        return file.getSize();
    }

    protected void readInternal(byte[] dest,int offset,int length) throws IOException {
        int remainder=length;
        int start=pointer;
        while(remainder!=0) {
            int bufferNumber=start/BUFFER_SIZE;
            int bufferOffset=start%BUFFER_SIZE;
            int bytesInBuffer=BUFFER_SIZE-bufferOffset;
            int bytesToCopy=bytesInBuffer>=remainder?remainder:bytesInBuffer;
            byte[] buffer=(byte[])file.getData().elementAt(bufferNumber);
            System.arraycopy(buffer,bufferOffset,dest,offset,bytesToCopy);
            offset+=bytesToCopy;
            start+=bytesToCopy;
            remainder-=bytesToCopy;
        }
        pointer+=length;
    }

    protected void seekInternal(long pos) throws IOException {
        pointer=(int)pos;
    }
}

class DBIndexOutput extends IndexOutput {
    private byte[] currentBuffer=null;
    private DBFile file;
    private int pointer=0;

    public DBIndexOutput(DBFile file) {
        this.file=file;
        // create pseudo file
        Connection conn=null;
        PreparedStatement stmt=null;
        try {
            conn=DBManager.getConnection();
            stmt=conn
                    .prepareStatement("INSERT INTO LUCENE_INDEX (PREFIX,NAME,LAST_MODIFIED,FILE_SIZE,DATA) "
                            +"VALUES (?,?,"
                            +DBManager.getSysdateString()
                            +",0,"
                            +DBManager.getEmptyBlob()+")");
            stmt.setString(1,file.getPrefix());
            stmt.setString(2,file.getName());
            stmt.execute();
            conn.commit();
        } catch(SQLException e) {
            throw new RuntimeException("Unable to create file "+file.getName()+". Reason: "
                    +e.getMessage());
        } finally {
            DBManager.closeDbAccess(conn,stmt,null);
        }
    }

    public DBIndexOutput(String prefix,String name) {
        this(new DBFile(prefix,name));
    }

    public void close() throws IOException {
        flush();
    }

    /**
     * flush the entire buffer
     */
    public void flush() throws IOException {
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;
        try {
            conn=DBManager.getConnection();

            stmt=conn
                    .prepareStatement("SELECT * FROM LUCENE_INDEX WHERE PREFIX=? AND NAME=? FOR UPDATE");
            stmt.setString(1,file.getPrefix());
            stmt.setString(2,file.getName());
            rs=stmt.executeQuery();
            rs.next();

            Blob blob=rs.getBlob("DATA");
            java.io.OutputStream out=blob.setBinaryStream(1l);

            byte[] buffer=null;
            int bufferCounter=0;
            for(Iterator i=file.getData().iterator();i.hasNext();) {
                buffer=(byte[])i.next();
                ++bufferCounter;
                if(i.hasNext()) {
                    out.write(buffer);
                }
            }
            if(buffer!=null)
                out.write(buffer,0,(int)file.getSize()-BufferedIndexOutput.BUFFER_SIZE
                        *(bufferCounter-1));

            rs.close();
            stmt.close();
            out.close();

            stmt=conn.prepareStatement("UPDATE LUCENE_INDEX SET DATA=?,FILE_SIZE=?,LAST_MODIFIED="
                    +DBManager.getSysdateString()+" WHERE PREFIX=? AND NAME=?");
            stmt.setBlob(1,blob);
            stmt.setLong(2,file.getSize());
            stmt.setString(3,file.getPrefix());
            stmt.setString(4,file.getName());
            stmt.execute();
            file.setSize(file.getSize());
            conn.commit();
        } catch(SQLException e) {
            throw new IOException("Unable to flush file "+file.getName()+". Reason: "
                    +e.getMessage());
        } catch(IndexOutOfBoundsException e) {
            throw new IOException("bullshit");
        } finally {
            DBManager.closeDbAccess(conn,stmt,rs);
        }
    }

    public long getFilePointer() {
        return file.getData().size()==0?0:BufferedIndexOutput.BUFFER_SIZE*(file.getData().size()-1)
                +pointer;
    }

    public long length() throws IOException {
        return file.getSize();
    }

    public void seek(long pos) throws IOException {
        int bufferNo=(int)(pos/BufferedIndexOutput.BUFFER_SIZE);
        int bufferPos=bufferNo==0?(int)pos:(int)(pos-pos/bufferNo);

        currentBuffer=(byte[])file.getData().elementAt(bufferNo);
        pointer=bufferPos;
    }

    public void writeByte(byte b) throws IOException {
        if(currentBuffer==null||pointer==BufferedIndexOutput.BUFFER_SIZE) {
            file.getData().add(currentBuffer=new byte[BufferedIndexOutput.BUFFER_SIZE]);
            pointer=0;
        }
        currentBuffer[pointer++]=b;
        if(file.getData().indexOf(currentBuffer)*BufferedIndexOutput.BUFFER_SIZE+pointer>file
                .getSize()) {
            file.setSize(file.getSize()+1);
        }
    }

    public void writeBytes(byte[] b,int length) throws IOException {
        for(int offset=0;offset<length;++offset) {
            writeByte(b[offset]);
        }
    }
}

class DBLock extends Lock {
    private String name;
    private String prefix;

    public DBLock(String prefix,String name) {
        this.prefix=prefix;
        this.name=name;
    }

    public boolean isLocked() {
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;

        try {
            conn=DBManager.getConnection();
            stmt=conn.prepareStatement("SELECT LOCKED FROM LUCENE_LOCK WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,prefix);
            stmt.setString(2,name);
            rs=stmt.executeQuery();
            rs.next();
            return rs.getBoolean(1);
        } catch(SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBManager.closeDbAccess(conn,stmt,rs);
        }
    }

    public boolean obtain() throws IOException {
        Connection conn=null;
        PreparedStatement stmt=null;
        ResultSet rs=null;

        try {
            // create lock if necessary
            conn=DBManager.getConnection();
            stmt=conn
                    .prepareStatement("SELECT COUNT(*) FROM LUCENE_LOCK WHERE PREFIX=? AND NAME=?");
            stmt.setString(1,prefix);
            stmt.setString(2,name);
            rs=stmt.executeQuery();
            rs.next();
            if(rs.getInt(1)==0) {
                rs.close();
                stmt.close();
                stmt=conn
                        .prepareStatement("INSERT INTO LUCENE_LOCK (prefix,name,locked) VALUES (?,?,true)");
                stmt.setString(1,prefix);
                stmt.setString(2,name);
                stmt.execute();
                return true;
            } else {
                rs.close();
                stmt.close();
            }

            // quickly obtain lock

            stmt=conn.prepareStatement("SELECT * FROM LUCENE_LOCK WHERE PREFIX=? AND NAME=? AND "
                    +"LOCKED=? FOR UPDATE");
            stmt.setString(1,prefix);
            stmt.setString(2,name);
            stmt.setBoolean(3,false);
            rs=stmt.executeQuery();
            rs.next();
            rs.close();
            stmt.close();

            // permanantly set lock
            stmt=conn.prepareStatement("UPDATE LUCENE_LOCK SET LOCKED=? WHERE PREFIX=? AND NAME=?");
            stmt.setBoolean(1,true);
            stmt.setString(2,prefix);
            stmt.setString(3,name);
            stmt.execute();
            return stmt.getUpdateCount()==1;
        } catch(SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if(conn!=null)
                try {
                    conn.commit();
                } catch(SQLException e) {
                    throw new IOException("Unable to obtain lock. Reason: "+e.getMessage());
                }
            DBManager.closeDbAccess(conn,stmt,rs);
        }
    }

    public void release() {
        Connection conn=null;
        PreparedStatement stmt=null;

        try {
            conn=DBManager.getConnection();
            stmt=conn.prepareStatement("UPDATE LUCENE_LOCK SET LOCKED=? WHERE PREFIX=? AND NAME=?");
            stmt.setBoolean(1,false);
            stmt.setString(2,prefix);
            stmt.setString(3,name);
            stmt.execute();
        } catch(SQLException e) {
            throw new RuntimeException(e);
        } finally {
            if(conn!=null)
                try {
                    conn.commit();
                } catch(SQLException e) {
                    throw new RuntimeException("Unable to release lock. Reason: "+e.getMessage());
                }
            DBManager.closeDbAccess(conn,stmt,null);
        }
    }
}

/**
 * A connection manager to allow opening a connection both directly and using jndi
 * 
 * @author Amir Kibbar
 */
class DBManager {
    private static boolean driverLoaded=false;
    private static DataSource ds=null;
    private static Properties props;

    static void closeDbAccess(Connection conn,PreparedStatement stmt,ResultSet rs) {
        try {
            if(rs!=null)
                rs.close();
            if(stmt!=null)
                stmt.close();
            if(conn!=null)
                conn.close();
        } catch(Exception e) {
            throw new RuntimeException(e);
        }
    }

    static Connection getConnection() throws SQLException {
        Connection result=null;
        try {
            if(props.getProperty("db.connection_method","direct").equals("direct")) {
                if(!driverLoaded) {
                    Class.forName(props.getProperty("db.driver"));
                    driverLoaded=true;
                }
                result=DriverManager.getConnection(props.getProperty("db.url"),props
                        .getProperty("db.username"),props.getProperty("db.password"));
            } else {
                if(ds==null) {
                    InitialContext ic=new InitialContext();
                    ds=(DataSource)ic.lookup(props.getProperty("db.jndi_name"));
                }
                result=ds.getConnection();
            }
        } catch(ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch(NamingException e) {
            throw new RuntimeException(e);
        }
        result.setAutoCommit(false);
        return result;
    }

    public static String getEmptyBlob() {
        return props.getProperty("db.emptyblob","empty_blob()");
    }

    static String getSysdateString() {
        return props.getProperty("db.sysdate","sysdate");
    }

    static void initialize(Properties props) {
        DBManager.props=props;
    }
}


