package org.apache.lucene.index;

import java.io.IOException;
import java.util.Properties;

import junit.framework.TestCase;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.store.DBDirectory;
import org.apache.lucene.store.Directory;

/**
 * @author goller
 * @author Amir Kibbar
 * @version $Id: $
 */
public class TestDBIndex extends TestCase {
    public void testDocCount() throws IOException {
        Properties props=new Properties();
        props.put("db.connection_method","direct");
        props.put("db.driver","com.mysql.jdbc.Driver");
        props.put("db.url","jdbc:mysql://localhost:3306/lucene");
        props.put("db.username","lucene");
        props.put("db.password","lucene");
        props.put("db.sysdate","sysdate()");
        props.put("db.emptyblob","''");
        
        Directory dir=DBDirectory.getDirectory(props,"myindex");

        IndexWriter writer=null;
        IndexReader reader=null;
        int i;

        writer=new IndexWriter(dir,new WhitespaceAnalyzer(),true);

        // add 100 documents
        for(i=0;i<100;i++) {
            addDoc(writer);
        }
        assertEquals(100,writer.docCount());
        writer.close();

        // delete 40 documents
        reader=IndexReader.open(dir);
        for(i=0;i<40;i++) {
            reader.deleteDocument(i);
        }
        reader.close();

        // test doc count before segments are merged/index is optimized
        writer=new IndexWriter(dir,new WhitespaceAnalyzer(),false);
        assertEquals(100,writer.docCount());
        writer.close();

        reader=IndexReader.open(dir);
        assertEquals(100,reader.maxDoc());
        assertEquals(60,reader.numDocs());
        reader.close();

        // optimize the index and check that the new doc count is correct
        writer=new IndexWriter(dir,new WhitespaceAnalyzer(),false);
        writer.optimize();
        assertEquals(60,writer.docCount());
        writer.close();

        // check that the index reader gives the same numbers.
        reader=IndexReader.open(dir);
        assertEquals(60,reader.maxDoc());
        assertEquals(60,reader.numDocs());
        reader.close();
    }

    private void addDoc(IndexWriter writer) throws IOException {
        Document doc=new Document();
        doc.add(new Field("content","aaa",Field.Store.NO,Field.Index.TOKENIZED));
        writer.addDocument(doc);
    }
}









