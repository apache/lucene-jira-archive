package org.apache.lucene.misc;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2004 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Lucene" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Lucene", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */
 
import java.io.IOException;
import java.io.StringReader;

import junit.framework.TestCase;

/**
 * Test class for the TrigramLanguageGuesser
 * 
 * Tests just try to stress compliance to the API, not to
 * measure the quelity of the guesser
 * 
 * @author Jean-Fran�ois Halleux
 * @version $version$
 */
public class TestTrigramLanguageGuesser extends TestCase {

	private String dataDir;

	protected void setUp() {
		dataDir = System.getProperty("dataDir");
	}

	public void testLanguageGuesser() throws IOException {

		//0. Constructor
		boolean rteFlag = false;
		try {
			LanguageGuesser lg = new TrigramLanguageGuesser("XYZ123");
		} catch (RuntimeException rte) {
			rteFlag = true;
		}
		assertEquals(true, rteFlag);

		String guessedLanguage;
	
		LanguageGuesser lg = new TrigramLanguageGuesser(dataDir+"/org/apache/lucene/misc/trifiles");

		//1. guessLanguage(Reader)

		//Test null reader
		boolean iaeFlag = false;
		try {
			lg.guessLanguage(null);
		} catch (IllegalArgumentException iae) {
			iaeFlag = true;
		}
		assertEquals(iaeFlag, true);

		//Test empty reader
		guessedLanguage = lg.guessLanguage(new StringReader(""));
		assertEquals(guessedLanguage.length(), 2);

		//Test normal case
		guessedLanguage = lg.guessLanguage(new StringReader("hello world"));
		assertEquals(guessedLanguage.length(), 2);

		//2. guessLanguage(Reader,int)

		//Test null reader
		iaeFlag = false;
		try {
			lg.guessLanguage(null, 0);
		} catch (IllegalArgumentException iae) {
			iaeFlag = true;
		}
		assertEquals(iaeFlag, true);

		//maxTrigrams < 1
		iaeFlag = false;
		try {
			lg.guessLanguage(null, -100);
		} catch (IllegalArgumentException iae) {
			iaeFlag = true;
		}
		assertEquals(iaeFlag, true);

		//Test empty reader
		guessedLanguage = lg.guessLanguage(new StringReader(""), 10);
		assertEquals(guessedLanguage.length(), 2);

		//maxTrigrams == 1
		String guessedLanguage1 =
			lg.guessLanguage(new StringReader("Hello World"), 1);
		assertEquals(guessedLanguage1.length(), 2);

		//Less maxTrigrams than what there are
		String guessedLanguage2 =
			lg.guessLanguage(new StringReader("Hello World"), 3);
		assertEquals(guessedLanguage2.length(), 2);

		//More maxTrigrams than what there really are
		String guessedLanguage3 =
			lg.guessLanguage(new StringReader("Hello World"), 100);
		assertEquals(guessedLanguage3.length(), 2);

		//Much more maxTrigrams than what there really are
		String guessedLanguage4 =
			lg.guessLanguage(new StringReader("Hello World"), 10000);
		assertEquals(guessedLanguage4.length(), 2);

		//3 and 4 should give the same results - TrigramLangageGuesser is deterministic
		assertEquals(guessedLanguage3, guessedLanguage4);

		//3. guessLanguages(Reader)

		//Test null reader
		iaeFlag = false;
		try {
			lg.guessLanguages(null);
		} catch (IllegalArgumentException iae) {
			iaeFlag = true;
		}
		assertEquals(iaeFlag, true);

		//Test empty reader
		LanguageProbability[] lpa = lg.guessLanguages(new StringReader(""));
		if (lpa.length > 0)
			assertTrue(true);
		else
			assertTrue(false);
		for (int i = 0; i < lpa.length; i++) {
			LanguageProbability lp = lpa[i];
			//all prob should be 0.0
			assertEquals(lp.probability, 0.0f, 0.0001);
			//Codes should be ISO
			assertEquals(lp.isoCode.length(), 2);
		}

		//Test non-empty reader
		lpa = lg.guessLanguages(new StringReader("Hello World"));
		if (lpa.length > 0)
			assertTrue(true);
		else
			assertTrue(false);
		for (int i = 0; i < lpa.length; i++) {
			LanguageProbability lp = lpa[i];
			//first prob should be 1.0
			if (i == 0) {
				assertEquals(lp.probability, 1.0f, 0.0001);
			}
			//Codes should be ISO
			assertEquals(lp.isoCode.length(), 2);
			//Sorted in decreasing order of probability
			if (i > 0) {
				if (lp.probability < lpa[i - 1].probability)
					assertTrue(true);
				else
					assertTrue(false);
			}
		}
	}

}