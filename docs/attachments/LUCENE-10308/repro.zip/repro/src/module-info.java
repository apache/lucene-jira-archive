module org.apache.lucene.luke {
  requires java.desktop;
  requires java.logging;
  requires org.apache.logging.log4j;
}
