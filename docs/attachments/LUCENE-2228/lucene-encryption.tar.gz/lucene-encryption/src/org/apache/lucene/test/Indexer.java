package org.apache.lucene;


import java.util.GregorianCalendar;
import java.util.ArrayList;
import java.io.*;


import org.apache.lucene.store.*;
import org.apache.lucene.document.*;
import org.apache.lucene.analysis.*;
import org.apache.lucene.index.*;
import org.apache.lucene.search.*;
import org.apache.lucene.queryParser.*;
import org.apache.lucene.util.*;


public class Indexer {
    private static final String USAGE = "java Indexer <index_dir> <word_bag> <num_docs>";
    private static final byte[] KEY = new byte[]{
            0x00, 0x01, 0x00, 0x03, 0x04, 0x05, 0x06, 0x07,
                0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
                0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17
        };
    private static final int MAX_WORDS = 50;
    public static void main(String[] args) throws Exception
    {
        BufferedReader br;
        IndexWriter iw;
        Directory dir;
        ArrayList words;
        String strLine;
        int num_docs;

        if(args.length != 3)
        {
            System.err.println(USAGE);
            System.exit(1);
        }

        br = new BufferedReader(
                new InputStreamReader(
                    new DataInputStream(
                        new FileInputStream(args[1]))));
        
        words = new ArrayList(100000);
        while((strLine = br.readLine()) != null)
            words.add(strLine);

        num_docs = Integer.valueOf(args[2]);
        dir = new AESDirectory(new File(args[0]), KEY);

       iw = new IndexWriter(dir, 
               new SimpleAnalyzer(),
               true,
               IndexWriter.MaxFieldLength.UNLIMITED);
       for(int i = 0; i < num_docs; i++)
       {
           if(i % 500 == 0)
               System.out.println("Indexing " + i);
           Document doc = new Document();
           String w = "";
           for(int j = i; j < i + MAX_WORDS; j++)
               w += words.get(j%words.size()) + " ";
           doc.add(new Field("contents", w, Field.Store.YES, Field.Index.NOT_ANALYZED));
           iw.addDocument(doc);
       }
       System.out.println("Num Indexed: " + iw.numDocs());
       iw.close();
       IndexReader ir = IndexReader.open(dir);
       System.out.println("MaxDoc: " + ir.maxDoc());
    }
}
