package org.apache.lucene.store;

import java.io.File;
import java.io.IOException;
import org.apache.lucene.util.AESReader;
import org.apache.lucene.util.AESWriter;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import javax.crypto.spec.SecretKeySpec;

/**
 * AESDirectory provides the ability for Lucene to read and write to an AES encrypted random access file using AESWriter and AESReader
 *  <br />
 * All rights reserved by the IIT IR Lab. (c)2009 Jordan Wilberding(jordan@ir.iit.edu)  and Jay Mundrawala(mundra@ir.iit.edu)
 *
 * @author Jay Mundrawala
 * @author Jordan Wilberding
 */

public class AESDirectory extends FSDirectory {

    public static int BLOCKS_PER_PAGE = 64;
    private SecretKeySpec key;
    private int blocks_per_page;

    public AESDirectory(File path, LockFactory lockFactory, byte[] key,
            int blocks_per_page) throws IOException
    {
        super(path, lockFactory);
        this.blocks_per_page = blocks_per_page;
        this.key = new SecretKeySpec(key, "AES");
    }

    public AESDirectory(File path, LockFactory lockFactory, byte[] key) throws IOException
    {
        this(path, lockFactory, key, BLOCKS_PER_PAGE);
    }

    public AESDirectory(File path, byte[] key) throws IOException
    {
        this(path, null, key, BLOCKS_PER_PAGE);
    }

    public AESDirectory(File path, byte[] key, int blocks_per_page) throws IOException
    {
        this(path, null, key, blocks_per_page);
    }
    @Override
    /** Returns the length in bytes of a file in the directory. */
    public long fileLength(String name) {
        ensureOpen();
        File file = new File(directory, name);
        long length;
        AESReader aes;
        try{
            aes = new AESReader(file,key,blocks_per_page);
            length = aes.length();
            aes.close();
        }catch(Exception e){
            e.printStackTrace();
            throw new RuntimeException("There was a problem reading the file: " + name);
        }

        return length;
    }

    @Override
    public IndexOutput createOutput(String name) throws IOException {
        initOutput(name);
        return new AESIndexOutput(new File(directory, name), key, blocks_per_page);
    }

    @Override
    public IndexInput openInput(String name, int bufferSize) throws IOException {
        ensureOpen();
        return new AESIndexInput(new File(directory, name), bufferSize, key, blocks_per_page);
    }

    protected static class AESIndexInput extends BufferedIndexInput {
        protected static class Descriptor extends AESReader {
            // remember if the file is open, so that we don't try to close it
            // more than once
            protected volatile boolean isOpen;
            long position;
            final long length;

            public Descriptor(File file, SecretKeySpec key, int blocks_per_page) throws Exception {
                super(file, key,blocks_per_page);
                isOpen=true;
                length=length();
            }

            public void close() throws IOException {
                if (isOpen) {
                    isOpen=false;
                    super.close();
                }
            }

            protected void finalize() throws Throwable {
                try {
                    close();
                } finally {
                    super.finalize();
                }
            }
        }

        protected final Descriptor file;
        boolean isClone;

        public AESIndexInput(File path, SecretKeySpec key, int blocks_per_page) throws IOException {
            this(path, BufferedIndexInput.BUFFER_SIZE,key, blocks_per_page);
        }

        public AESIndexInput(File path, int bufferSize, SecretKeySpec key, int blocks_per_page) throws IOException {
            super(bufferSize);
            try{
                file = new Descriptor(path, key, blocks_per_page);
            }catch(IOException e){
                throw e;
            }catch(Exception e){
                e.printStackTrace();
                throw new RuntimeException("Bad File");
            }
        }

        /** IndexInput methods */
        protected void readInternal(byte[] b, int offset, int len)
            throws IOException {
            synchronized (file) {
                try{
                    long position = getFilePointer();
                    if (position != file.position) {
                        file.seek(position);
                        file.position = position;
                    }
                    int total = 0;
                    do {
                        int i = file.read(b, offset+total, len-total);
                        if (i == -1)
                            throw new IOException("read past EOF");
                        file.position += i;
                        total += i;
                    } while (total < len);
                }catch(IOException e){
                    throw e;
                }catch(Exception e){
                    throw new RuntimeException(e);
                }
            }
        }

        public void close() throws IOException {
            // only close the file if this is not a clone
            if (!isClone) file.close();
        }

        protected void seekInternal(long position) {
        }

        public long length() {
            return file.length;
        }

        public Object clone() {
            AESIndexInput clone = (AESIndexInput)super.clone();
            clone.isClone = true;
            return clone;
        }


    }


    protected static class AESIndexOutput extends BufferedIndexOutput {
        AESWriter file = null;

        // remember if the file is open, so that we don't try to close it
        // more than once
        private volatile boolean isOpen;

        public AESIndexOutput(File path, SecretKeySpec key, int blocks_per_page) throws IOException {
            try{
                file = new AESWriter(path,key,blocks_per_page);
            }catch(IOException e){
                throw e;
            }catch(Exception e){
                e.printStackTrace();
                throw new IOException("Bad File");
            }
            isOpen = true;
        }

        /** output methods: */
        public void flushBuffer(byte[] b, int offset, int size) throws IOException {
            try{
                file.write(b, offset, size);
                file.flush();
            }catch(Exception e){
                throw new RuntimeException(e);
            }
            //file.flush();
        }
        public void close() throws IOException {
            // only close the file if it has not been closed yet
            if (isOpen) {
                boolean success = false;
                try {
                    super.close();
                    success = true;
                } finally {
                    isOpen = false;
                    if (!success) {
                        try {
                            file.close();
                        } catch (Exception t) {
                            // Suppress so we don't mask original exception
                        }
                    } else{
                        try{
                            file.close();
                        }catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            }
        }

        /** Random-access methods */
        public void seek(long pos) throws IOException {
            try{
                super.seek(pos);
                file.seek(pos);
            }catch(Exception e){
                throw new RuntimeException(e);
            }
        }
        public long length() throws IOException {
            return file.length();
        }
        public void setLength(long length) throws IOException {
            try{
                file.setLength(length);
            }catch(IOException e){
                throw e;
            }catch(Exception e){
                throw new RuntimeException(e);
            }
        }
    }
}
