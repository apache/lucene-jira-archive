package org.apache.lucene.util;

import java.io.*;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.KeyGenerator;

import java.util.*;

import java.security.Security;
/**
 * AESWriter is responsible for writing AES encrypted  files to disk. 
 * This class will abstract the encryption and decryption process from the user.
 * <br />
 * All rights reserved by the IIT IR Lab. (c)2009 Jordan Wilberding(jordan@ir.iit.edu)  and Jay Mundrawala(mundra@ir.iit.edu)
 *
 * @author Jay Mundrawala
 * @author Jordan Wilberding
 */

public class AESWriter
{
   /* AES using 16 byte block sizes */
   private static final int BLOCKSIZE = 16;
   public static final int DEFAULT_PAGESIZE = 32;
   //public boolean LOG = false;

   private RandomAccessFile raf;

   /* Encryption Cipher */
   private Cipher ecipher;

   /* Decryption Cipher. This is needed if a seek occurs and entire blocks are not
    *  overwritten. */
   private Cipher dcipher;
   
   /* Encryption pending buffer. If there is a block that is not entirly filled, this buffer
    * will be used. */
   private byte[] buffer;
   private byte[] ciphertext;

   /* Initialization vector for buffer */
   private byte[] cur_iv;
   
   /* Current byte in the buffer */
   private int buffer_pos;

   /* Start position of buffer */
   private long buffer_start;

   /* Number of byte in the buffer */
   private int buffer_size;
 
   /* Length of the encrypted file */ 
   private long end;

   /* Contains the state of the padding */
   private boolean isPadded;

   /* Key */
   private SecretKeySpec key;

   /* Used to generate init vectors */
   private KeyGenerator ivgen;

   /* Blocks(16 bytes) per page */
   private int page_size;

   /* Bytes per page */
   private long page_size_in_bytes;

   /* File pointer in encrypted file...not the physical one */
   private long cur_fp;

   /* was the buffer modified? */
   private boolean modified;

   /* An object to sync on */
   private Boolean lock = new Boolean(false);

   /* File name */
   private String name;

   /* force gets set if setLength is called. 
	* It means that the file cannot grow after setLength as been called */
   private boolean force;

   /* Used for logging */
   //private RandomAccessFile log;
   

   /**
	* Creates an encrypted random access file that uses the AES encryption algorithm in CBC mode.
	* @param file File to create.
	* @param key Key used to initialize the ciphers.
	* @param page_size Number of 16-byte blocks per page.
	*/
   public AESWriter(File file, SecretKeySpec key, int page_size) throws Exception
   {
	   this.raf = new RandomAccessFile(file,"rw");
	   this.key = key;
	   this.name = file.getName();

	   /* Used during debugging. Maybe if java had macros, I wouldnt have to comment this stuff out */
	   /*if(LOG){
		 log = new RandomAccessFile("testwritedata/" + name, "rw"); 
		 log.seek(log.length());
		 }*/

	   /* Only allow writing on new files. Lucene specifies that a new writer
		* will be created only for new files.
		*/
	   if(raf.length() != 0)
		   throw new RuntimeException("File already Exists");

	   /* unpadding with dcipher does not work for some reason.
		* It seems that it wants the last 2 blocks of memory before it
		* decrypts. That is why unpadding is done manually */
	   this.ecipher = Cipher.getInstance("AES/CBC/NoPadding");
	   this.dcipher = Cipher.getInstance("AES/CBC/NoPadding");

	   /* Initialize the ciphers. We should clean this up depending on the mode.
		* We need 2 only if the mode is allows reading and writing
		*/
	   this.page_size = page_size;
	   this.page_size_in_bytes = BLOCKSIZE*this.page_size;

	   /* Initialize the internal buffer. Decrypted blocks are stored here */
	   this.buffer = new byte[BLOCKSIZE*page_size];
	   this.ciphertext = new byte[buffer.length];

	   this.isPadded = false;
	   this.ivgen = KeyGenerator.getInstance("AES");
	   this.initCiphers(generateIV());
   }


   /**
	* Generates a random initialization vector.
	* @return a randomly generated IV
	*/
   private IvParameterSpec generateIV(){
      return new IvParameterSpec(ivgen.generateKey().getEncoded());
      
   }

   /**
	* Initialize the encrption and decryption ciphers.
	* @param ivps The initialization vector to use or null. If null, an IV will be randomly generated.
	*/
   private void initCiphers(IvParameterSpec ivps) throws java.security.InvalidKeyException, 
		   java.security.InvalidAlgorithmParameterException
   {
	   if(ivps == null)
		   ivps = generateIV();

	   /* Store the IV bytes */
	   this.cur_iv = ivps.getIV();
	   
	   /* Init the ciphers with ivps */
	   this.ecipher.init(Cipher.ENCRYPT_MODE, this.key,ivps);
	   this.dcipher.init(Cipher.DECRYPT_MODE, this.key,ivps);
   }

   /**
	* Flushes all remaining data to disk, pads the file, and then closes the underlying file stream
	*/
   public void close() throws java.io.IOException, javax.crypto.ShortBufferException,javax.crypto.IllegalBlockSizeException,
		  javax.crypto.BadPaddingException,java.security.InvalidKeyException,java.security.InvalidAlgorithmParameterException
   {
	   synchronized(lock){

		   /*if(LOG)
			 log.writeBytes(name + " w:close\n");
			 */
		   if(!isPadded || modified)
			   writePage(true);
		   if(!this.isPadded){
			   throw new RuntimeException("NO PADDING: this.end=" + this.end + ";this.cur_fp=" + this.cur_fp + ";this.buffer_size="+this.buffer_size +
					   ";this.buffer_pos=" + this.buffer_pos + ";this.buffer_start=" + this.buffer_start + ";this.force=" + this.force);
		   }
		   this.raf.close();
	   }
   }

   /**
	* Writes any data in the buffer to disk and any additional padding needed.
	*/
   public void flush() throws java.io.IOException, javax.crypto.ShortBufferException, javax.crypto.IllegalBlockSizeException,
		  javax.crypto.BadPaddingException,java.security.InvalidKeyException,java.security.InvalidAlgorithmParameterException
   {
      synchronized(lock){
		  /*if(LOG)
			log.writeBytes(name + " w:flush\n");
			*/
		  writePage(true);
      }
   }

   /**
	* Returns the file position in the encrypted file. 
	* @return Returns the current position in this file, where the next write will occur.
	*/
   public long getFilePointer() throws java.io.IOException
   {
      return this.cur_fp;
   }

   /**
	* The number of bytes in the file.
	* @return the size off the file
	*/
   public long length() throws java.io.IOException
   {
      return end;
   }

   /**
	* Sets the position where the next write will occurs
	* @param pos the position where the next write will occur
	*/
   public void seek(long pos) throws java.io.IOException, javax.crypto.ShortBufferException,javax.crypto.IllegalBlockSizeException,
		 javax.crypto.BadPaddingException,java.security.InvalidKeyException,java.security.InvalidAlgorithmParameterException
   {
	   synchronized(lock){
		   /*if(LOG)
			   log.writeBytes(name + " w:pos " + pos +"\n");
			   */
		   this._seek(pos);
	   }
   }

   /**
	* Sets the position where the next write will occurs
	* @param pos the position where the next write will occur
	*/
   private void _seek(long pos) throws java.io.IOException, javax.crypto.ShortBufferException,javax.crypto.IllegalBlockSizeException,
		  javax.crypto.BadPaddingException,java.security.InvalidKeyException,java.security.InvalidAlgorithmParameterException
  {
	  long _page; /* physical starting address of the page that contains pos */

	  /* flush data in buffer */
	  writePage(true);

	  /* Convert pos to physical block */
	  long _phys_pos = this.encryptedAddrToPhysicalAddr(pos);

	  /* Convert physical block to physical address */
	  _page = _phys_pos/(this.page_size_in_bytes + BLOCKSIZE);
	  _page *= (this.page_size_in_bytes + BLOCKSIZE);

	  /* set cur_fp to physical block address */
	  this.raf.seek(_page);
	  this.cur_fp = pos;
	  this.fillBuffer();
	  this.buffer_start = pos/page_size_in_bytes*page_size_in_bytes;

	  /* set buffer_pos to point to pos in the buffer */
	  this.buffer_pos = (int)(this.cur_fp % this.page_size_in_bytes);

  }

   /**
	* Writes an array of bytes to this file.
	* @param b array of bytes to write
	* @param off offset in b to start 
	* @param len number of bytes to write
	*/
   public void write(byte[] b, int off, int len) throws java.io.IOException, javax.crypto.ShortBufferException,
		  javax.crypto.IllegalBlockSizeException,java.security.InvalidKeyException,
		  java.security.InvalidAlgorithmParameterException, javax.crypto.BadPaddingException
   {
      int _len;
      synchronized(lock){
         /*if(LOG){
            log.writeBytes(name + " w:write " + b.length + " " + off + " " + len + "\n");
            log.write(b);
         }*/

         while(len > 0){
			 this.modified = true;

			 //Minimum of len and available is the number of bytes to write
			 _len = (int)Math.min(len, this.page_size_in_bytes - this.buffer_pos);
			 System.arraycopy(b, off, this.buffer, this.buffer_pos, _len);

			 if(this.cur_fp + _len > this.end){
				 this.isPadded = false;
			 }


			 len -= _len;
			 off += _len;
			 this.buffer_pos += _len;
			 this.cur_fp += _len;
			 this.buffer_size = Math.max(this.buffer_size, this.buffer_pos);
			 this.end = Math.max(this.cur_fp, this.end);

			 if(this.buffer_pos == this.page_size_in_bytes){
				 /* write current page */
				 this.writePage();
				 /* load next page */
				 this.fillBuffer();
			 }

		 }
	  }
   }

   private void writePage() throws java.io.IOException, javax.crypto.ShortBufferException, 
           javax.crypto.IllegalBlockSizeException,javax.crypto.BadPaddingException,java.security.InvalidKeyException,
           java.security.InvalidAlgorithmParameterException
   {
      writePage(false);
   }

   /**
	* Writes the internal buffer to disk.
	* @param flush_pad if set to true, padding is guaranteed to be added. Otherwise, padding will only be added if
	* there are not enough bytes to make a complete block.
	*/
   private void writePage(boolean flush_pad) throws java.io.IOException, javax.crypto.ShortBufferException, 
		   javax.crypto.IllegalBlockSizeException,javax.crypto.BadPaddingException,java.security.InvalidKeyException,
		   java.security.InvalidAlgorithmParameterException
   {

	   this.modified = false;

	   /* set underlying file position */
	   this.raf.seek(encryptedAddrToPhysicalAddr(this.buffer_start) - BLOCKSIZE);
	   this.raf.write(this.cur_iv);

	   /* determine number of bytes to write */
	   int len = (this.buffer_size + BLOCKSIZE-1)/BLOCKSIZE*BLOCKSIZE; 

	   /* number of padding bytes */
	   int no_padding = BLOCKSIZE - (this.buffer_size % BLOCKSIZE);


	   if(no_padding < BLOCKSIZE && no_padding > 0)
	   {
		   /* Does not need a full block of padding...easy */
		   this.isPadded = true;
		   for(int i = buffer_size; i < len;i++){
			   this.buffer[i]=(byte)no_padding;
		  }
	   }else if(flush_pad && no_padding == BLOCKSIZE && this.cur_fp/page_size_in_bytes == this.end/page_size_in_bytes){
		   /* Needs a full block of padding...only pad if on the last page and flush_pad is true */
		   if(!this.isPadded)
		   {
			   /* Write padding bytes to buffer */
			   for(int i = len; i< len + BLOCKSIZE; i++)
				   this.buffer[i] = BLOCKSIZE;
			   if(this.page_size_in_bytes - this.buffer_size >= BLOCKSIZE){
				   /* Make sure the page isnt full...should never happen */
				   this.isPadded = true;
				   len += BLOCKSIZE;
			   }else{
				   throw new RuntimeException("Page should not be full: " + buffer_size);
			   }
		   }
	   }

	   /* Encrypt data and write to disk */
	   this.ecipher.doFinal(this.buffer,0,len,this.ciphertext,0);
	   this.raf.write(this.ciphertext,0,len);

   }

   /**
	* Reads a page from the underlying file and initialize the ciphers. 
	* If there is no page to read, the ciphers get initialized
	* with a random IV. */
   private void fillBuffer() throws java.io.IOException, javax.crypto.ShortBufferException, 
		   javax.crypto.IllegalBlockSizeException, java.security.InvalidKeyException,
		   java.security.InvalidAlgorithmParameterException, javax.crypto.BadPaddingException
   {
	   int       _end;
	   long      _cur_fp;
	   byte[]    _iv; 

	   _iv       = new byte[BLOCKSIZE];

	   this.buffer_start = this.cur_fp/page_size_in_bytes*page_size_in_bytes;
	   _cur_fp   = encryptedAddrToPhysicalAddr(this.buffer_start) - BLOCKSIZE; 

	   /* Read IV */
	   this.raf.seek(_cur_fp);
	   if(_cur_fp  >= this.raf.length()){
		   /* generate a random IV and write it to disk */
		   _iv = generateIV().getIV();
		   this.raf.write(_iv);
	   }else{
		   this.raf.readFully(_iv);
	   }

	   _cur_fp += BLOCKSIZE;

	   /* Read page */
	   this.buffer_size = _end = this.raf.read(this.buffer,0, (int)this.page_size_in_bytes);

	   if(_end == -1){
		   this.buffer_size = 0;
		   this.initCiphers(new IvParameterSpec(_iv));
		   this.buffer_pos = 0;
		   return;
	   }

	   /* reinit ciphers and decrypt page */
	   this.initCiphers(new IvParameterSpec(_iv));
	   this.buffer_pos = 0;
	   this.dcipher.doFinal(this.buffer,0,_end,this.buffer,0);
   }


   /**
	* Set the size of the file. To use this method, it must be called immediately after this object is created.
	* Also, when this method is called, the file length may not be extended.
	* @param newLen The new size of the file.
	*/
   public void setLength(long newLen) throws java.io.IOException,javax.crypto.ShortBufferException,
		  javax.crypto.BadPaddingException, java.security.InvalidKeyException, javax.crypto.IllegalBlockSizeException,
		  java.security.InvalidAlgorithmParameterException
   {
      synchronized(lock){
        /*if(LOG) 
           log.writeBytes(name + " w:setLength " + newLen + "\n"); 
		   */
		  force = true;
		  long _len = newLen + BLOCKSIZE - (newLen % BLOCKSIZE);
		  int no_padding = (int)(BLOCKSIZE - (newLen % BLOCKSIZE));
		  long num_blocks = (_len + BLOCKSIZE - 1)/BLOCKSIZE;
		  long num_pages = (num_blocks + this.page_size-1)/this.page_size;

		  this.raf.setLength(_len + num_pages*BLOCKSIZE);
		  this.end = newLen;

		  byte[] _iv;
		  this.raf.seek(0);
		  this.buffer_start = 0;

		  long _cur = 0;

		  for(int i =0; i < num_pages; i++){
			  if(this.raf.getFilePointer() % (page_size_in_bytes + BLOCKSIZE) != 0)
				  throw new RuntimeException("Debug::Incorrect file postion;fp=" + this.raf.getFilePointer());

			  if(i == num_pages - 1){
				  /* Last page needs padding */
				  _iv = generateIV().getIV();
				  this.raf.write(_iv);
				  int _num = (int)(_len - _cur);
				  byte[] data = new byte[_num];
				  for(int j = _num -1; j >= _num - no_padding; j--)
				  {
					  data[j] = (byte)no_padding;
				  }
				  this.initCiphers(new IvParameterSpec(_iv));
				  this.ecipher.doFinal(data,0,_num,data,0);
				  this.raf.write(data);

				  this.isPadded = true;
				  _cur += _num;


			  }else{
				  /* generate and write random IV to file */
				  _iv = generateIV().getIV();
				  this.raf.write(_iv);
				  this.raf.seek(this.raf.getFilePointer() + page_size_in_bytes);

				  _cur+= page_size_in_bytes;
			  }


		  }
		  /* Seek to the beginning of the file */
		  this.raf.seek(0);
		  this.cur_fp = 0;
		  this.buffer_start = 0;
		  this.buffer_pos = 0;
		  /* load first page */
		  this.fillBuffer();
	  }
   }

   private static void printBarr(byte[] p){
	   for(int i =0; i < p.length; i++)
		   System.out.print(p[i] + " ");
	   System.out.println();
   }

   /**
	* Calculates the number of init vectors preceding a given block. The block of virtual address m
	* is determined by m/BLOCKSIZE.
	* @param block how many IVs are found before this block
	* @return number of IVs found before block
	*/
   private long numPageIVBlocksAt(long block){
      return (block/((long)page_size)) +1;
   }

   /**
	* Calculates the physical address of the given virtual address.
	* @param m the virtual file pointer
	* @return the address of where m actually lies in the underlying file
	*/
   private long encryptedAddrToPhysicalAddr(long m){
      long block = m/BLOCKSIZE;
      return ((block + (numPageIVBlocksAt(block))) * BLOCKSIZE) + (m % BLOCKSIZE);
   }

   /**
	* A simple test program.
	*/

   public static void main(String[] args) throws Exception{
	   String file;
	   int page_size;
	   long file_size;
	   Random rand = new Random(100);
	   file = args[0];
	   page_size = Integer.parseInt(args[1]);
	   file_size = Long.parseLong(args[2]);

	   SecretKeySpec key = new SecretKeySpec(new byte[]{
		   0x00, 0x01, 0x00, 0x03, 0x04, 0x05, 0x06, 0x07,
					 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
					 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17 
	   },"AES");

	   AESWriter writer = new AESWriter(new File(file),key,page_size);
	   writer.setLength(file_size);
	   byte[] b = new byte[(int)file_size];
	   rand.nextBytes(b);
	   writer.write(b,0,b.length);

	   System.out.println("Filesize: " + writer.length());
	   int iterations = 200;

	   for(int i = 0; i < iterations; i++){
		   long pos = (long)rand.nextInt((int)file_size);
		   int len = rand.nextInt((int)file_size - (int)pos);
		   writer.seek(pos);
		   if(writer.getFilePointer() != pos){
			   System.err.println("FilePos not properly set");
			   System.exit(1);
		   }
		   //System.out.println("Pos=" + pos + ";Len=" + len);

		   for(int j = (int)pos; j < (int)pos+len; j++){
			   b[j] = (byte)(rand.nextInt() & 0xFF);
		   }
		   writer.write(b,(int)pos,len);
	   }


	   writer.close();

	   AESReader reader = new AESReader(new File(file),key,page_size);
	   if(reader.length() != file_size)
	   {
		   System.out.println("Incorrect Filesize");
		   System.exit(1); 
	   }
	   for(int i =0; i < reader.length(); i++)
	   {
		   int br = (reader.read() & 0xFF);
		   int bs = b[i] & 0xFF;
		   if(br != bs){
			   System.out.println("data not correctly written");
			   System.out.println("Expected=" + bs + ";Got=" + br);
			   System.exit(1);
		   }
	   }
	   System.out.println("Success");

   }
   
}
