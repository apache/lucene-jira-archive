package org.apache.lucene.util;

import java.io.*;
import java.io.DataOutput;
import java.io.DataInput;
import java.io.RandomAccessFile;
import java.io.File;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.KeyGenerator;
import java.security.Security;

import java.util.Random;

/** 
 * AESReader provides the ability to read and write to an AES encrypted random access file.
 *  <br />
 * All rights reserved by the IIT IR Lab. (c)2009 Jordan Wilberding(jordan@ir.iit.edu)  and Jay Mundrawala(mundra@ir.iit.edu)
 *
 * @author Jay Mundrawala
 * @author Jordan Wilberding
 */
public class AESReader
{
   /* AES using 16 byte block sizes */
   private static final int BLOCKSIZE = 16;
   //public boolean LOG = false;

   /* Underlying file to write to */
   private RandomAccessFile raf;

   /* Decryption Cipher */
   private Cipher dcipher;

   /* Current Initialization Vector */
   private byte[] cur_iv;

   /* Encryption/Decryption buffer */
   private byte[] buffer;

   /* Internal filePos. We cannot use raf's because that one
    * will always be aligned an a 16 byte boundary
    */
   private long filePos;

   /* Start location of buffer in physical file */
   private long bufferStart;

   /* Number of valid bytes in the buffer */
   private int bufferLength;

   /* Current position in buffer */
   private int bufferPosition;

   /* address of last block. */
   private long end;

   /* Blocks per page */
   private int page_size;

   /* Key used to decrypt data */
   private SecretKeySpec key;
   
   /* Object to sync on */
   private Boolean lock = new Boolean(false);

   /* Name of file */
   private String name;

   //private RandomAccessFile log;

   /**
	* Creates an encrypted random access file reader that uses the AES encryption algorithm in CBC mode.
	* @param file File to read.
	* @param key Key used to initialize the ciphers.
	* @param page_size Number of 16-byte blocks per page. Must be the same number used when writing the file.
	*/
   public AESReader(File file, SecretKeySpec key, int page_size) throws IOException,
		  java.security.NoSuchAlgorithmException,java.security.InvalidKeyException,
		  javax.crypto.ShortBufferException,javax.crypto.NoSuchPaddingException,
		  java.security.InvalidAlgorithmParameterException,
		  javax.crypto.IllegalBlockSizeException,javax.crypto.IllegalBlockSizeException,
		  javax.crypto.BadPaddingException,javax.crypto.BadPaddingException
   {
	   /*
		  if(LOG){
		  log = new RandomAccessFile("testreaddata/" + name,"rw");
		  log.seek(log.length());
		  }
		  */
	   long page_size_in_bytes;
	   long prev_pos;
	   int nread;
	   int buf_size;
	   int no_padding;
	   int no_data;

	   this.name            = file.getName();
	   this.raf             = new RandomAccessFile(file,"r");
	   page_size_in_bytes   = page_size*BLOCKSIZE;
	   prev_pos	            = this.raf.getFilePointer();
	   this.dcipher         = Cipher.getInstance("AES/CBC/NoPadding");
	   this.buffer          = new byte[page_size*BLOCKSIZE];
	   this.cur_iv          = new byte[BLOCKSIZE];
	   this.key             = key;
	   this.page_size       = page_size;

	   //check padding and determine end(file length)
	   this.raf.seek(Math.max(this.raf.length() - page_size_in_bytes,0));
	   this.raf.readFully(this.cur_iv);

	   nread = this.raf.read(buffer);
	   dcipher.init(Cipher.DECRYPT_MODE,key, new IvParameterSpec(this.cur_iv));
	   buf_size = dcipher.doFinal(buffer,0,nread,buffer,0);

	   if(buf_size != nread)
		   throw new IOException("Not enough bytes decrypted");

	   no_padding = buffer[buf_size - 1];
	   no_data = BLOCKSIZE - no_padding;

	   if(no_data < 0 || no_data > BLOCKSIZE)
		   throw new IOException("Bad padding: " + no_padding);

	   for(int i = buf_size - BLOCKSIZE + no_data; i < buf_size; i++){
		   if(no_padding != buffer[i])
			   throw new IOException(
					   "Bad padding @ byte " + (buf_size - i) + ". Expected: " 
					   + no_padding + ". Value: " + buffer[i]
					   );

	   }

	   long blocks = this.raf.length()/BLOCKSIZE -1;
	   long pageivs = blocks/(page_size+1) + 1;
	   this.end = this.raf.length() - no_padding - (pageivs * BLOCKSIZE);



	   //refill the buffer
	   seek(prev_pos);

   }

   /**
	* Creates an encrypted random access file reader that uses the AES encryption algorithm in CBC mode.
	* @param name File to read.
	* @param key Key used to initialize the ciphers.
	* @param page_size Number of 16-byte blocks per page. Must be the same number used when writing the file.
	*/
   public AESReader(String name,SecretKeySpec key, int page_size) throws IOException,
		  java.security.NoSuchAlgorithmException,java.security.InvalidKeyException,
		  javax.crypto.ShortBufferException, javax.crypto.NoSuchPaddingException,
		  java.security.InvalidAlgorithmParameterException,
		  javax.crypto.IllegalBlockSizeException,javax.crypto.IllegalBlockSizeException,
		  javax.crypto.BadPaddingException,javax.crypto.BadPaddingException
   {
      this(new File(name),key, page_size);
   }

   /**
    * Close the underlying RandomAccessFile 
	*/
   public void close() throws java.io.IOException
   {
      /*if(LOG)
         log.writeBytes(name + " r:close\n");
	  */
      this.raf.close();
   }

   /** 
	* Get the current position in the file 
	*/
   public long getFilePointer() throws java.io.IOException
   {
      return this.filePos;
   }

   /** 
	* Get the number of bytes in the encrypted file. This size is equal to the physical file size
	* minus the number of padding blocks and IV blocks
	* @return size of file
	*/
   public long length()
   {
      return this.end;
   }
   
   /** Read the next byte from the file.
	* @return -1 if eof has been reached, the next byte otherwise.
	*/
   public int read() throws java.io.IOException, javax.crypto.ShortBufferException, 
		  javax.crypto.IllegalBlockSizeException,javax.crypto.BadPaddingException,
		  java.security.InvalidAlgorithmParameterException,java.security.InvalidKeyException
   {
      byte[] b = new byte[1];
      int numRead = read(b);
      if(numRead == -1)
         return -1;

      return (int) b[0] & 0xFF;

   }

   /**
	* Try to fill the given buffer with the next bytes from the file.
	* @param b byte array to fill with bytes
	* @return -1 if eof has been reached, the number of bytes copied into the given buffer otherwise.
	*/
   public int read(byte[] b) throws java.io.IOException, javax.crypto.ShortBufferException, 
		  javax.crypto.IllegalBlockSizeException,javax.crypto.BadPaddingException,
		  java.security.InvalidAlgorithmParameterException,java.security.InvalidKeyException
   {
      return this.read(b, 0,b.length);
   }


   /**
	* Read bytes from the file into the given byte array 
	* @param b byte array to copy bytes to
	* @param offset position in b to start copying data
	* @param len number of bytes to copy to the given byte array 
	* @return -1 if eof has been reached, the number of bytes copied into b otherwise.
	*/
   public int read(byte[] b, int offset, int len) throws java.io.IOException,
		  javax.crypto.ShortBufferException, javax.crypto.IllegalBlockSizeException,
		  javax.crypto.BadPaddingException,java.security.InvalidKeyException,
		  java.security.InvalidAlgorithmParameterException
   {

      if(this.filePos >= this.end){
         return -1;
      }
      if(len <= 0)
         return 0;

      synchronized(lock){
         /* if(LOG)
            log.writeBytes(name + " r:read "+ b.length + " " + offset + " " + len + "\n");
			*/
         int remaining = len;
		 /* Time to get next page when position in the buffer is geq its length */
         if(bufferPosition >= bufferLength)
            refill();

         if(len <= bufferLength - bufferPosition){
			 /* Enough bytes in the internal buffer...just copy them to b */
            System.arraycopy(buffer,bufferPosition,b,offset,len);
            bufferPosition += len;
            filePos += len;
            remaining = 0;
         }else{
			 /* Will need to start loading next pages to read len bytes */
            while(remaining > 0 && filePos < end){
               int available = bufferLength - bufferPosition;
               if(available > 0){
                  int to_read = Math.min(available,remaining);
                  System.arraycopy(buffer,bufferPosition,b,offset,to_read);
                  remaining -= to_read;
                  offset += to_read;
                  bufferPosition += to_read;
                  filePos += to_read;
               }else{
                  refill();   
               }
            }
         }
		 
         return len - remaining;
      }
   }

   /** 
	* Sets the file pointer so that the next byte read will be at pos. 
	* Seeking past the end of the file is not allowed.
	* @param pos position to seek to.
	*/
   public void seek(long pos) throws java.io.IOException,javax.crypto.ShortBufferException, 
		  javax.crypto.IllegalBlockSizeException,javax.crypto.BadPaddingException,
		  java.security.InvalidKeyException,java.security.InvalidAlgorithmParameterException
   {
      /* flush buffer */
      if(pos >= end || pos < 0){
         throw new RuntimeException("Pos: " + pos + " end: " + end + " file: " + name);
      }
      synchronized(lock){
         /*if(LOG)
            log.writeBytes(name + " r:seek " + pos + "\n");
			*/
         this.filePos = pos;
         refill();

      }
   }

   /**
	* refill will make sure that this.filePos is in the internal buffer and decrypted. It reads
	* 1 page from disk including the IV used to encrypt the page, and decrpyts the page which is
	* then stored in the internal buffer.
	*/
   private void refill() throws java.io.IOException,javax.crypto.ShortBufferException, 
		   javax.crypto.IllegalBlockSizeException,javax.crypto.BadPaddingException,
		   java.security.InvalidKeyException,java.security.InvalidAlgorithmParameterException
   {
      int buf_size;
	  int nread;

	  /* address of filePos in the file */
      long strt_addr = encryptedAddrToPhysicalAddr(this.filePos);
	  
	  /* set bufferStart to the first byte of the IV of the page that contains
	   * filePos.
	   */
      this.bufferStart = strt_addr/((long)page_size*BLOCKSIZE + BLOCKSIZE);
	  this.bufferStart *= ((long)page_size*BLOCKSIZE + BLOCKSIZE);

	  /* Seek to the IV */
      this.raf.seek(bufferStart);
	  this.bufferStart += BLOCKSIZE;

	  /* read the IV */
	  this.raf.readFully(this.cur_iv);

	  /* initialize the cipher with the IV that was read */
	  this.dcipher.init(Cipher.DECRYPT_MODE,this.key,new IvParameterSpec(this.cur_iv));
	  
	  /* Read and decrypt the ciphertext */
	  nread = this.raf.read(buffer);
	  buf_size = dcipher.doFinal(buffer,0,nread,buffer,0);

	  if(buf_size != nread)
		  throw new IOException("Not enough bytes decrypted");

	  this.bufferLength = buf_size;
	  this.bufferPosition = (int)(this.filePos % buffer.length);

   }

   /**
	* Calculates the number of init vectors preceding a given block. The block of virtual address m
	* is determined by m/BLOCKSIZE.
	* @param block how many IVs are found before this block
	* @return number of IVs found before block
	*/

   private long numPageIVBlocksAt(long block){
	   return (block/((long)page_size)) +1;
   }

   /**
	* Calculates the physical address of the given virtual address.
	* @param m the virtual file pointer
	* @return the address of where m actually lies in the underlying file
	*/
   private long encryptedAddrToPhysicalAddr(long m){
	   long block = m/BLOCKSIZE;
	   return ((block + (numPageIVBlocksAt(block))) * BLOCKSIZE) + (m % BLOCKSIZE);
   }

   /**
	* A simple test program.
	*/
   public static void main(String[] args) throws Exception
   {
	   int pagesize = 4;
	   int nbytes = 0;
	   String file_name = null;
	   File f;
	   RandomAccessFile raf;
	   byte[] b;
	   IvParameterSpec iv;
	   AESReader reader;
	   Random rand;
	   Cipher ecipher;

	   KeyGenerator ivgen = KeyGenerator.getInstance("AES");

	   SecretKeySpec key = new SecretKeySpec(new byte[]{
		   0x00, 0x01, 0x00, 0x03, 0x04, 0x05, 0x06, 0x07,
					 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
					 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17 
	   },"AES");
	   
	   if(args.length != 2 && args.length != 3){
		   System.out.println("Usage: java org.apache.lucene.AESReader file_name file_size [blocks per page]");
		   System.exit(1);
	   }else{
		   try{
			   file_name = args[0];
			   nbytes = Integer.parseInt(args[1]);
		   }catch(Exception e){
			   System.out.println("Usage: java org.apache.lucene.AESReader file_name file_size [blocks per page]");
			   System.exit(1);
		   }
		   try{
			   pagesize = Integer.parseInt(args[2]);
		   }catch(Exception e){

		   }
	   }
	   System.out.println("File: " + file_name);
	   System.out.println("File Size: " + nbytes);
	   System.out.println("Blocks Per Page: " + pagesize);
	   
	   f   = new File(file_name);
	   raf = new RandomAccessFile(f, "rw");
	   b    = new byte[nbytes + BLOCKSIZE - (nbytes % BLOCKSIZE)];
	   
	   System.out.println("Bytes: " + b.length);
	   rand = new Random();
	   rand.nextBytes(b);

	   ecipher = Cipher.getInstance("AES/CBC/NoPadding");


	   int no_padding = b.length - nbytes;
	   int page_size = BLOCKSIZE*pagesize;
	   int num_blocks = (b.length + BLOCKSIZE - 1)/BLOCKSIZE;
	   //System.out.println("Num blocks: " + num_blocks);
	   int num_pages = (num_blocks+pagesize-1)/pagesize;
	   int cur = 0;

	   for(int i = nbytes; i < b.length; i++){
		   b[i] = (byte)no_padding;
		   //System.out.println("adding padding: " + b[i]);
	   }

	   //System.out.println("Num Pages: " + num_pages);

	   for(int i = 0; i < num_pages; i++)
	   {
		   iv = generateIV(ivgen);
		   ecipher.init(Cipher.ENCRYPT_MODE, key, iv);
		   //System.out.println("Writing IV at " + raf.getFilePointer());
		   byte[] ivba = iv.getIV();
		   raf.write(ivba,0,ivba.length);
		   //System.out.println("Write IV");
		   /*
		   for(int j = 0; j < ivba.length; j++)
			   System.out.print(ivba[j] + " ");
		   System.out.println();
		   */

		   byte[] data;
		   if(i == num_pages -1){
			   int num = b.length - cur;
			   data = new byte[num];
			   ecipher.doFinal(b,cur,num,data,0);
			   cur += num;
		   }else{
			   data = new byte[page_size];
			   ecipher.doFinal(b,cur,page_size,data,0);
			   cur += page_size;
		   }
		   raf.write(data);
	   }



	   reader = new AESReader(f,key,pagesize);

	   if(reader.length() != nbytes){
		   System.err.println("Incorrect file size: Expected=" + nbytes + ";Got=" + reader.length());
	   }
       System.out.println("Checking file sequentially");
	   for(int i = 0; i < nbytes; i++)
	   {
		   byte r = (byte)reader.read();
		   if(r != b[i]){
			   System.err.println(i + ": Read=" + r + ";Expected=" + b[i]);
			   System.exit(1);
		   }
	   }
       System.out.println("Checking with seeks");
	   int iterations = nbytes;
	   for(int i = 0; i < iterations; i++){
           if(i%100 == 0)
               System.out.println("Iteration " + i);
		   byte[] data = new byte[b.length];
		   long pos = (long)rand.nextInt(nbytes);
		   int len = rand.nextInt(nbytes - (int)pos);
		   reader.seek(pos);
		   if(reader.getFilePointer() != pos){
			   System.err.println("FilePos not properly set");
			   System.exit(1);
		   }
		   //System.out.println("Pos=" + pos + ";Len=" + len);
		   reader.read(data,(int)pos,len);

		   for(int j = (int)pos; j < (int)pos+len; j++){
			   if(data[j] != b[j]){
				   System.err.println("data[j] != b[j];j=" + j);
				   System.exit(1);
			   }
		   }
		   
	   }

	   System.err.println("Success");
	   System.exit(0);

   }
   private static IvParameterSpec generateIV(KeyGenerator ivgen){
      return new IvParameterSpec(ivgen.generateKey().getEncoded());
   }

}
