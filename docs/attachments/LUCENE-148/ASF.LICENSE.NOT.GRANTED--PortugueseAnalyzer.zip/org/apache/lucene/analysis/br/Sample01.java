package org.apache.lucene.analysis.br;

import java.io.*;
import java.net.*;
import java.util.*;

public class Sample01 extends BrazilianStemmer {

    public static void main(String argv[]) {

        Sample01            brStemmer ;
        String              word ;

        brStemmer = new Sample01() ;

        word = "quickly" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quieto" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quietos" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quilate" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quilates" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quilinhos" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quilo" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quilombo" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quilom�tricas" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quilom�tricos" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quil�metro" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quil�metros" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quilos" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "qu�mica" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "qu�micas" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "qu�mico" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "qu�micos" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quimioterapia" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quimioter�picos" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());

        word = "quimono" ;
        brStemmer.stem(word) ;
        System.out.println(brStemmer.log());
    }

}
