package org.apache.lucene.queryParser.lucene2.processors;



import java.util.List;

import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.QueryParserWrapper;
import org.apache.lucene.queryParser.lucene2.config.AllowLeadingWildcardAttribute;
import org.apache.lucene.queryParser.lucene2.config.LowercaseExpandedTermsAttribute;
import org.apache.lucene.queryParser.nodes.FieldQueryNode;
import org.apache.lucene.queryParser.nodes.FuzzyQueryNode;
import org.apache.lucene.queryParser.nodes.ParametricQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.nodes.WildcardQueryNode;
import org.apache.lucene.queryParser.processors.QueryNodeProcessorImpl;


/**
 * This processor verifies if the attribute {@link LowercaseExpandedTermsAttribute} is defined
 * in the {@link QueryConfigHandler}. If it is and the expanded terms should be lowercased, it looks 
 * for every {@link WildcardQueryNode}, {@link FuzzyQueryNode} and {@link ParametricQueryNode} and
 * lowercase its term.
 * <br/>
 * @see QueryParserWrapper#setLowercaseExpandedTerms(boolean)
 * @see LowercaseExpandedTermsAttribute
 */
public class LowercaseExpandedTermsQueryNodeProcessor extends QueryNodeProcessorImpl {
    
    public LowercaseExpandedTermsQueryNodeProcessor() {
        // empty constructor
    }
    
    public QueryNode process(QueryNode queryTree) throws QueryNodeException {
        
        if (getQueryConfigHandler().hasAttribute(LowercaseExpandedTermsAttribute.class)) {
            
            if (((LowercaseExpandedTermsAttribute) getQueryConfigHandler().getAttribute(LowercaseExpandedTermsAttribute.class)).isLowercaseExpandedTerms()) { 
                return super.process(queryTree);    
            }
            
        }
        
        return queryTree;
        
    }

    protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException {
        
        if (node instanceof WildcardQueryNode ||
                node instanceof FuzzyQueryNode ||
                node instanceof ParametricQueryNode) {
            
            FieldQueryNode fieldNode = (FieldQueryNode) node;
            fieldNode.setText(fieldNode.getText().toString().toLowerCase()); 
            
        }
        
        return node;
        
    }

    protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException {
        
        return node;
        
    }

    protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException {
        
        return children;
        
    }
    
}
