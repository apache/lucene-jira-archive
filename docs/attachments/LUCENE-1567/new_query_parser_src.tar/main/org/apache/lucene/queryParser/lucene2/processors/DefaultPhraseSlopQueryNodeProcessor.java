package org.apache.lucene.queryParser.lucene2.processors;



import java.util.List;

import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.QueryParserWrapper;
import org.apache.lucene.queryParser.lucene2.config.DefaultPhraseSlopAttribute;
import org.apache.lucene.queryParser.lucene2.nodes.MultiPhraseQueryNode;
import org.apache.lucene.queryParser.nodes.SlopQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.nodes.TokenizedPhraseQueryNode;
import org.apache.lucene.queryParser.processors.QueryNodeProcessorImpl;


/**
 * This processor verifies if the attribute {@link DefaultPhraseSlopAttribute} is defined
 * in the {@link QueryConfigHandler}. If it is, it looks 
 * for every {@link TokenizedPhraseQueryNode} and {@link MultiPhraseQueryNode} that does
 * not have any {@link SlopQueryNode} applied to it and creates an {@link SlopQueryNode}
 * and apply to it. The new {@link SlopQueryNode} has the same slop value defined in the attribute. 
 * <br/>
 * @see SlopQueryNode
 * @see DefaultPhraseSlopAttribute
 * @see QueryParserWrapper#setPhraseSlop(int)
 */
public class DefaultPhraseSlopQueryNodeProcessor extends QueryNodeProcessorImpl {
    
    private boolean processChildren = true;
    
    private int defaultPhraseSlop; 
    
    public DefaultPhraseSlopQueryNodeProcessor() {
        // empty constructor
    }
    
    public QueryNode process(QueryNode queryTree) throws QueryNodeException {
        QueryConfigHandler queryConfig = getQueryConfigHandler();
        
        if (queryConfig != null) {
            
            if (queryConfig.hasAttribute(DefaultPhraseSlopAttribute.class)) {
                this.defaultPhraseSlop = ((DefaultPhraseSlopAttribute) queryConfig.getAttribute(DefaultPhraseSlopAttribute.class)).getDefaultPhraseSlop();
                
                return super.process(queryTree);
                
            }
            
        }

        return queryTree;
        
    }

    protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException {
        
        if (node instanceof TokenizedPhraseQueryNode ||
                node instanceof MultiPhraseQueryNode) {
            
            return new SlopQueryNode(node, this.defaultPhraseSlop);
            
        }

        return node;
        
    }

    protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException {
        
        if (node instanceof SlopQueryNode) {
            this.processChildren = false;
            
        }
        
        return node;
        
    }
    
    protected void processChildren(QueryNode queryTree)
            throws QueryNodeException {
        
        if (this.processChildren) {
            super.processChildren(queryTree);
            
        } else {
            this.processChildren = true;
        }
        
    }

    @Override
    protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException {
    
        return children;
        
    }
        
}
