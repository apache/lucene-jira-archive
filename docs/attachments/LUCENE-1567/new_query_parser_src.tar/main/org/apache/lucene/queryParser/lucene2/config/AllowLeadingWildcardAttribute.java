package org.apache.lucene.queryParser.lucene2.config;



import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.AllowLeadingWildcardProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by {@link AllowLeadingWildcardProcessor} processor and must be defined in
 * the {@link QueryConfigHandler}. It basically tells the processor if it should allow leading wildcard. 
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setAllowLeadingWildcard(boolean)
 */
public class AllowLeadingWildcardAttribute extends Attribute {
    
    private static final long serialVersionUID = -2804763012723049527L;
    
    private boolean allowLeadingWildcard = true;
    
    public AllowLeadingWildcardAttribute() {
        // empty constructor
    }
    
    void setAllowLeadingWildcard(boolean allowLeadingWildcard) {
        this.allowLeadingWildcard = allowLeadingWildcard;
    }
    
    public boolean isAllowLeadingWildcard() {
        return this.allowLeadingWildcard;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {
        
        if (other instanceof AllowLeadingWildcardAttribute && 
                ((AllowLeadingWildcardAttribute) other).allowLeadingWildcard == this.allowLeadingWildcard) {
            
           return true; 
            
        }
        
        return false;
        
    }

    public int hashCode() {
        return this.allowLeadingWildcard ? -1 : Integer.MAX_VALUE;
    }

    public String toString() {
        return "<allowLeadingWildcard allowLeadingWildcard=" + this.allowLeadingWildcard + "/>";
    }
    
}