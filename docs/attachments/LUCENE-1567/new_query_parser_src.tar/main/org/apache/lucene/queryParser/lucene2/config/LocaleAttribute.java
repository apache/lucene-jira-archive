package org.apache.lucene.queryParser.lucene2.config;



import java.util.Locale;

import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.ParametricRangeQueryNodeProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by  processor {@link ParametricRangeQueryNodeProcessor} and
 * must be defined in the {@link QueryConfigHandler}. This attribute tells the
 * processor what is the default {@link Locale} used to parse a date.
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setLocale(Locale)
 */
public class LocaleAttribute extends Attribute {

    private static final long serialVersionUID = -6804760312720049526L;

    private Locale locale = Locale.getDefault();

    public LocaleAttribute() {
        // empty constructor
    }

    void setLocale(Locale locale) {
        this.locale = locale;
    }

    public Locale getLocale() {
        return this.locale;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {

        if (other instanceof LocaleAttribute) {
            LocaleAttribute localeAttr = (LocaleAttribute) other;

            if (localeAttr.locale == this.locale
                    || (this.locale != null && localeAttr.locale != null && this.locale.equals(localeAttr.locale))) {

                return true;

            }

        }

        return false;

    }

    public int hashCode() {
        return (this.locale == null) ? 0 : this.locale.hashCode();
    }

    public String toString() {
        return "<localeAttribute locale=" + this.locale + "/>";
    }

}