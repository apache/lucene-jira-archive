package org.apache.lucene.queryParser.processors;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.nodes.QueryNode;


/**
 * @see org.apache.lucene.queryParser.processors.QueryNodeProcessor
 */
public abstract class QueryNodeProcessorImpl implements QueryNodeProcessor {
    
    private ArrayList<ChildrenList> childrenListPool = new ArrayList<ChildrenList>();

    private QueryConfigHandler queryConfig;
    
    public QueryNodeProcessorImpl() {
        // empty constructor
    }
    
    public QueryNodeProcessorImpl(QueryConfigHandler queryConfigHandler) {
        this.queryConfig = queryConfigHandler;
    }

    public QueryNode process(QueryNode queryTree) throws QueryNodeException {
        return processIteration(queryTree);
    }
    
    private QueryNode processIteration(QueryNode queryTree) throws QueryNodeException {
        queryTree = preProcessNode(queryTree);

        processChildren(queryTree);

        queryTree = postProcessNode(queryTree);

        return queryTree;
        
    }

    protected void processChildren(QueryNode queryTree)
            throws QueryNodeException {

        List<QueryNode> children = queryTree.getChildren();
        ChildrenList newChildren;

        if (children != null && children.size() > 0) {

            newChildren = allocateChildrenList();

            try {

                for (QueryNode child : children) {
                    child = processIteration(child);

                    if (child == null) {
                        throw new NullPointerException();

                    }

                    newChildren.add(child);

                }

                List<QueryNode> orderedChildrenList = setChildrenOrder(newChildren);

                queryTree.set(orderedChildrenList);

            } finally {
                newChildren.beingUsed = false;
            }

        }

    }

    private ChildrenList allocateChildrenList() {
        ChildrenList list = null;

        for (ChildrenList auxList : this.childrenListPool) {
            
            if (!auxList.beingUsed) {
                list = auxList;
                list.clear();

                break;

            }

        }

        if (list == null) {
            list = new ChildrenList();
            this.childrenListPool.add(list);

        }

        list.beingUsed = true;

        return list;

    }
    
    public void setQueryConfigHandler(QueryConfigHandler queryConfigHandler) {
        this.queryConfig = queryConfigHandler;
    }
    
    public QueryConfigHandler getQueryConfigHandler() {
        return this.queryConfig;
    }

    abstract protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException;

    abstract protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException;

    abstract protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException;

    private static class ChildrenList extends ArrayList<QueryNode> {

        private static final long serialVersionUID = -2613518456949297135L;

        boolean beingUsed;

    }

}