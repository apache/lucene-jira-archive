package org.apache.lucene.queryParser.lucene2.config;



import org.apache.lucene.queryParser.config.FieldConfig;
import org.apache.lucene.queryParser.lucene2.processors.MultiFieldQueryNodeProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by {@link MultiFieldQueryNodeProcessor} processor and it should
 * be defined in a {@link FieldConfig}. This processor uses this attribute to define
 * which boost a specific field should have when none is defined to it.
 * <br/><br/>
 * @see org.apache.lucene.queryParser.lucene2.MultiFieldQueryParserWrapper
 */
public class BoostAttribute extends Attribute {
    
    private static final long serialVersionUID = -2104763012523049527L;
    
    private float boost = 1.0f;
    
    public BoostAttribute() {
        // empty constructor
    }
    
    void setBoost(float boost) {
        this.boost = boost;
    }
    
    public float getBoost() {
        return this.boost;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {
        
        if (other instanceof BoostAttribute && other != null && 
                ((BoostAttribute) other).boost == this.boost) {
            
           return true; 
            
        }
        
        return false;
        
    }

    public int hashCode() {
        return Float.valueOf(this.boost).hashCode();
    }

    public String toString() {
        return "<boost boost=" + this.boost + "/>";
    }
    
}