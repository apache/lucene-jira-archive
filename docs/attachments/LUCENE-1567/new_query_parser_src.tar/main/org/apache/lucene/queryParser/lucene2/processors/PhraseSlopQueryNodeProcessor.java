package org.apache.lucene.queryParser.lucene2.processors;



import java.util.List;

import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.lucene2.nodes.MultiPhraseQueryNode;
import org.apache.lucene.queryParser.nodes.SlopQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.nodes.TokenizedPhraseQueryNode;
import org.apache.lucene.queryParser.processors.QueryNodeProcessorImpl;


/**
 * This processor removes invalid {@link SlopQueryNode} objects in the query node tree.
 * A {@link SlopQueryNode} is invalid if its child is neither a {@link TokenizedPhraseQueryNode}
 * nor a {@link MultiPhraseQueryNode}.
 * <br/>
 * @see SlopQueryNode 
 */
public class PhraseSlopQueryNodeProcessor extends QueryNodeProcessorImpl {
    
    public PhraseSlopQueryNodeProcessor() {
        // empty constructor
    }

    protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException {
        
        if (node instanceof SlopQueryNode) {
            SlopQueryNode phraseSlopNode = (SlopQueryNode) node;
            
            if (!(phraseSlopNode.getChild() instanceof TokenizedPhraseQueryNode) &&
                    !(phraseSlopNode.getChild() instanceof MultiPhraseQueryNode)) {
                return phraseSlopNode.getChild();
            }
            
        }
        
        return node;
        
    }

    protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException {
        
        return node;
        
    }

    protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException {
        
        return children;
        
    }
    
}
