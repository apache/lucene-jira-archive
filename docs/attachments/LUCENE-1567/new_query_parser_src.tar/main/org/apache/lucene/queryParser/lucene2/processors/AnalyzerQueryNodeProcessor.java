package org.apache.lucene.queryParser.lucene2.processors;



import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.CachingTokenFilter;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.analysis.tokenattributes.TermAttribute;
import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.config.AnalyzerAttribute;
import org.apache.lucene.queryParser.lucene2.config.PositionIncrementsAttribute;
import org.apache.lucene.queryParser.lucene2.nodes.LuceneBooleanQueryNode;
import org.apache.lucene.queryParser.lucene2.nodes.MultiPhraseQueryNode;
import org.apache.lucene.queryParser.nodes.FieldQueryNode;
import org.apache.lucene.queryParser.nodes.FuzzyQueryNode;
import org.apache.lucene.queryParser.nodes.GroupQueryNode;
import org.apache.lucene.queryParser.nodes.NoTokenFoundQueryNode;
import org.apache.lucene.queryParser.nodes.ParametricQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.nodes.TokenizedPhraseQueryNode;
import org.apache.lucene.queryParser.nodes.WildcardQueryNode;
import org.apache.lucene.queryParser.processors.QueryNodeProcessorImpl;

/**
 * This processor verifies if the attribute {@link AnalyzerQueryNodeProcessor} is defined
 * in the {@link QueryConfigHandler}. If it is and the analyzer is not <code>null</code>, it looks 
 * for every {@link FieldQueryNode} that is not {@link WildcardQueryNode}, 
 * {@link FuzzyQueryNode} or {@link ParametricQueryNode} contained in the query node tree, then 
 * it applies the analyzer to that {@link FieldQueryNode} object.
 * <br/><br/>
 * If the analyzer return only one term, the returned term is set to the {@link FieldQueryNode}
 * and it's returned. 
 * <br/><br/>
 * If the analyzer return more than one term, a {@link TokenizedPhraseQueryNode}
 * or {@link MultiPhraseQueryNode} is created, whether there is one or more terms at the same
 * position, and it's returned.
 * <br/><br/>
 * If no term is returned by the analyzer a {@link NoTokenFoundQueryNode} object is returned.
 * <br/>
 * @see Analyzer
 * @see TokenStream
 */
public class AnalyzerQueryNodeProcessor extends QueryNodeProcessorImpl {

	private Analyzer analyzer;

    private boolean positionIncrementsEnabled;

    public AnalyzerQueryNodeProcessor() {
        // empty constructor
    }

    /* (non-Javadoc)
     * @see com.ibm.ilel.query.processors.QueryNodeProcessorImpl#process(com.ibm.ilel.query.nodes.QueryNode)
     */
    public QueryNode process(QueryNode queryTree) throws QueryNodeException {

        if (getQueryConfigHandler().hasAttribute(AnalyzerAttribute.class)) {

            this.analyzer = ((AnalyzerAttribute) getQueryConfigHandler().getAttribute(
                    AnalyzerAttribute.class)).getAnalyzer();

            this.positionIncrementsEnabled = false;

            if (getQueryConfigHandler().hasAttribute(
                    PositionIncrementsAttribute.class)) {

                if (((PositionIncrementsAttribute) getQueryConfigHandler().getAttribute(
                        PositionIncrementsAttribute.class)).isPositionIncrementsEnabled()) {

                    this.positionIncrementsEnabled = true;

                }

            }

            if (this.analyzer != null) {
                return super.process(queryTree);
            }

        }

        return queryTree;

    }

    /* (non-Javadoc)
     * @see com.ibm.ilel.query.processors.QueryNodeProcessorImpl#postProcessNode(com.ibm.ilel.query.nodes.QueryNode)
     */
    @Override
    protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException {

        // TODO: it should check if it's an instance of "TextableNode" interface instead of FieldQueryNode
        if (node instanceof FieldQueryNode
                && !(node instanceof WildcardQueryNode)
                && !(node instanceof FuzzyQueryNode)
                && !(node instanceof ParametricQueryNode)) {

            FieldQueryNode fieldNode = ((FieldQueryNode) node);
            String text = fieldNode.getTextAsString();
            String field = fieldNode.getFieldAsString();

            TokenStream source = this.analyzer.tokenStream(field,
                    new StringReader(text));
            CachingTokenFilter buffer = new CachingTokenFilter(source);

            //PositionIncrementAttribute posIncrAtt = null;
            int numTokens = 0;
            int positionCount = 0;
            boolean severalTokensAtSamePosition = false;

//            if (buffer.hasAttribute(PositionIncrementAttribute.class)) {
//                posIncrAtt = (PositionIncrementAttribute) buffer.getAttribute(PositionIncrementAttribute.class);
//            }

            org.apache.lucene.analysis.Token reusableToken = null;
            org.apache.lucene.analysis.Token nextToken = null;

            // TODO: use this block when Lucene releases the new TokenStream API
            /*try {
                
                while (buffer.incrementToken()) {
                    numTokens++;
                    int positionIncrement = (posIncrAtt != null) ? posIncrAtt.getPositionIncrement()
                            : 1;
                    if (positionIncrement != 0) {
                        positionCount += positionIncrement;

                    } else {
                        severalTokensAtSamePosition = true;
                    }

                }
                 
            } catch (IOException e) {
                // ignore
            }*/
            
           // TODO: this block should be removed when Lucene releases the new TokenStream API
            reusableToken = new org.apache.lucene.analysis.Token();
            while (true) {
                try {
                    nextToken = buffer.next(reusableToken);
                } catch (IOException e) {
                    nextToken = null;
                }
                if (nextToken == null)
                    break;
                numTokens++;
                if (nextToken.getPositionIncrement() != 0)
                    positionCount += nextToken.getPositionIncrement();
                else
                    severalTokensAtSamePosition = true;
            }

            try {
                // rewind the buffer stream
                buffer.reset();

                // close original stream - all tokens buffered
                source.close();
            } catch (IOException e) {
                // ignore
            }

//            if (!buffer.hasAttribute(TermAttribute.class)) {
//                return new NoTokenFoundQueryNode();
//            }

            //TermAttribute termAtt = (TermAttribute) buffer.getAttribute(TermAttribute.class);

            if (numTokens == 0) {
                return new NoTokenFoundQueryNode();

            } else if (numTokens == 1) {
                String term = null;
                try {
                    //// TODO: use this block when Lucene releases the new TokenStream API
                    /*boolean hasNext;
                    hasNext = buffer.incrementToken();
                    assert hasNext == true;
                    term = termAtt.term();*/

                    // TODO: this block should be removed when Lucene releases the new TokenStream API
                    nextToken = buffer.next(reusableToken);
                    assert nextToken != null;
                    term = nextToken.term();

                } catch (IOException e) {
                    // safe to ignore, because we know the number of tokens
                }

                fieldNode.setText(term);

                return fieldNode;

            } else if (severalTokensAtSamePosition) {
                if (positionCount == 1) {
                    // no phrase query:
                    LinkedList<QueryNode> children = new LinkedList<QueryNode>();

                    for (int i = 0; i < numTokens; i++) {
                        String term = null;
                        try {
                            // TODO: use this block when Lucene releases the new TokenStream API
                            /*boolean hasNext = buffer.incrementToken();
                            assert hasNext == true;
                            term = termAtt.term();*/

                            // TODO: this block should be removed when Lucene releases the new TokenStream API
                            nextToken = buffer.next(reusableToken);
                            assert nextToken != null;
                            term = nextToken.term();

                        } catch (IOException e) {
                            // safe to ignore, because we know the number of tokens
                        }

                        children.add(new FieldQueryNode(field, term, -1, -1));

                    }

                    return new GroupQueryNode(new LuceneBooleanQueryNode(
                            children, true));

                } else {
                    // phrase query:
                    MultiPhraseQueryNode mpq = new MultiPhraseQueryNode();

                    List<FieldQueryNode> multiTerms = new ArrayList<FieldQueryNode>();
                    int position = -1;
                    int i = 0;
                    for (; i < numTokens; i++) {
                        String term = null;
                        int positionIncrement = 1;
                        try {
                            // TODO: use this block when Lucene releases the new TokenStream API
                            /*boolean hasNext = buffer.incrementToken();
                            assert hasNext == true;
                            term = termAtt.term();
                            if (posIncrAtt != null) {
                                positionIncrement = posIncrAtt.getPositionIncrement();
                            }*/

                            // TODO: this block should be removed when Lucene releases the new TokenStream API
                            nextToken = buffer.next(reusableToken);
                            assert nextToken != null;
                            term = nextToken.term();
                            positionIncrement = nextToken.getPositionIncrement();

                        } catch (IOException e) {
                            // safe to ignore, because we know the number of tokens
                        }

                        if (positionIncrement > 0 && multiTerms.size() > 0) {

                            for (FieldQueryNode termNode : multiTerms) {
                                
                                if (this.positionIncrementsEnabled) {
                                    termNode.setPositionIncrement(position);

                                } else {
                                    termNode.setPositionIncrement(i);
                                }

                                mpq.add(termNode);

                            }

                            multiTerms.clear();

                        }

                        position += positionIncrement;
                        multiTerms.add(new FieldQueryNode(field, term, -1, -1));

                    }

                    for (FieldQueryNode termNode : multiTerms) {

                        if (this.positionIncrementsEnabled) {
                            termNode.setPositionIncrement(position);

                        } else {
                            termNode.setPositionIncrement(i);
                        }

                        mpq.add(termNode);

                    }

                    return mpq;

                }

            } else {

                TokenizedPhraseQueryNode pq = new TokenizedPhraseQueryNode();

                int position = -1;

                for (int i = 0; i < numTokens; i++) {
                    String term = null;
                    int positionIncrement = 1;

                    try {
                        // TODO: use this block when Lucene releases the new TokenStream API
                        /*boolean hasNext = buffer.incrementToken();
                        assert hasNext == true;
                        term = termAtt.term();

                        if (posIncrAtt != null) {
                            positionIncrement = posIncrAtt.getPositionIncrement();
                        }*/

                        // TODO: this block should be removed when Lucene releases the new TokenStream API
                        nextToken = buffer.next(reusableToken);
                        assert nextToken != null;
                        term = nextToken.term();
                        positionIncrement = nextToken.getPositionIncrement();

                    } catch (IOException e) {
                        // safe to ignore, because we know the number of tokens
                    }

                    FieldQueryNode newFieldNode = new FieldQueryNode(field,
                            term, -1, -1);

                    if (this.positionIncrementsEnabled) {
                        position += positionIncrement;
                        newFieldNode.setPositionIncrement(position);

                    } else {
                        newFieldNode.setPositionIncrement(i);
                    }

                    pq.add(newFieldNode);

                }

                return pq;

            }

        }

        return node;

    }

    /* (non-Javadoc)
     * @see com.ibm.ilel.query.processors.QueryNodeProcessorImpl#preProcessNode(com.ibm.ilel.query.nodes.QueryNode)
     */
    protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException {

        return node;

    }

    /* (non-Javadoc)
     * @see com.ibm.ilel.query.processors.QueryNodeProcessorImpl#setChildrenOrder(java.util.List)
     */
    protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException {

        return children;

    }

}
