package org.apache.lucene.queryParser.lucene2.config;



import org.apache.lucene.document.DateTools;
import org.apache.lucene.document.DateTools.Resolution;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.ParametricRangeQueryNodeProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by {@link ParametricRangeQueryNodeProcessor} processor and
 * must be defined in the {@link QueryConfigHandler}. This attribute tells the
 * processor which {@link Resolution} to use when parsing the date.
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setDateResolution(DateTools.Resolution)
 */
public class DateResolutionAttribute extends Attribute {

    private static final long serialVersionUID = -6804360312723049526L;

    private DateTools.Resolution dateResolution;

    public DateResolutionAttribute() {
        // empty constructor
    }

    void setDateResolution(DateTools.Resolution dateResolution) {
        this.dateResolution = dateResolution;
    }

    public DateTools.Resolution getDateResolution() {
        return this.dateResolution;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {

        if (other instanceof DateResolutionAttribute) {
            DateResolutionAttribute dateResAttr = (DateResolutionAttribute) other;

            if (dateResAttr.getDateResolution() == getDateResolution()
                    || dateResAttr.getDateResolution().equals(
                            getDateResolution())) {

                return true;

            }

        }

        return false;

    }

    public int hashCode() {
        return (this.dateResolution == null) ? 0 : this.dateResolution.hashCode();
    }

    public String toString() {
        return "<dateResolutionAttribute dateResolution='" + this.dateResolution + "'/>";
    }

}