package org.apache.lucene.queryParser.lucene2.config;



import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.AnalyzerQueryNodeProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by {@link AnalyzerQueryNodeProcessor} processor and must be defined in
 * the {@link QueryConfigHandler}. It provides to this processor the {@link Analyzer}, if there is one,
 * which will be used to analyze the query terms. 
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#getAnalyzer()
 */
public class AnalyzerAttribute extends Attribute {
    
    private static final long serialVersionUID = -6804760312723049526L;
    
    private Analyzer analyzer;
    
    public AnalyzerAttribute() {
        // empty constructor
    }
    
    void setAnalyzer(Analyzer analyzer) {
        this.analyzer = analyzer;
    }
    
    public Analyzer getAnalyzer() {
        return this.analyzer;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {
        
        if (other instanceof AnalyzerAttribute) {
            AnalyzerAttribute analyzerAttr = (AnalyzerAttribute) other;

            if (analyzerAttr.analyzer == this.analyzer
                    || (this.analyzer != null && analyzerAttr.analyzer != null && this.analyzer.equals(analyzerAttr.analyzer))) {

                return true;

            }

        }
        
        return false;
        
    }

    public int hashCode() {
        return (this.analyzer == null) ? 0 : this.analyzer.hashCode();
    }

    public String toString() {
        return "<analyzerAttribute analyzer='" + this.analyzer + "'/>";
    }
    
}