package org.apache.lucene.queryParser.lucene2.processors;



import java.util.List;

import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.lucene2.parser.QueryParser;
import org.apache.lucene.queryParser.nodes.PrefixWildcardQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.processors.QueryNodeProcessorImpl;
import org.apache.lucene.search.PrefixQuery;


/**
 * The {@link QueryParser} creates {@link PrefixWildcardQueryNode} nodes which
 * have values containing the prefixed wildcard. However, Lucene {@link PrefixQuery}
 * cannot contain the prefixed wildcard. So, this processor basically removed the
 * prefixed wildcard from the {@link PrefixWildcardQueryNode} value.
 * <br/>
 * @see PrefixQuery
 * @see PrefixWildcardQueryNode
 */
public class PrefixWildcardQueryNodeProcessor extends QueryNodeProcessorImpl {
    
    public PrefixWildcardQueryNodeProcessor() {
        // empty constructor
    }

    protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException {
        
        if (node instanceof PrefixWildcardQueryNode) {
            PrefixWildcardQueryNode prefixWildcardNode = (PrefixWildcardQueryNode) node;
            CharSequence text = prefixWildcardNode.getText();
            
            prefixWildcardNode.setText(text.subSequence(0, text.length() - 1));
            
        }
        
        return node;
        
    }

    protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException {
        
        return node;
        
    }

    protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException {
        
        return children;
        
    }
    
}
