package org.apache.lucene.queryParser.lucene2.config;



import java.util.Locale;

import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.ParametricRangeQueryNodeProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by  processor {@link ParametricRangeQueryNodeProcessor} and
 * must be defined in the {@link QueryConfigHandler}. This attribute tells the
 * processor what is the default {@link Locale} used to parse a date.
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setLowercaseExpandedTerms(boolean)
 */
public class LowercaseExpandedTermsAttribute extends Attribute {
    
    private static final long serialVersionUID = -2804760312723049527L;
    
    private boolean lowercaseExpandedTerms = true;
    
    public LowercaseExpandedTermsAttribute() {
        // empty constructor
    }
    
    void setLowercaseExpandedTerms(boolean lowercaseExpandedTerms) {
        this.lowercaseExpandedTerms = lowercaseExpandedTerms;
    }
    
    public boolean isLowercaseExpandedTerms() {
        return this.lowercaseExpandedTerms;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {
        
        if (other instanceof LowercaseExpandedTermsAttribute && 
                ((LowercaseExpandedTermsAttribute) other).lowercaseExpandedTerms == this.lowercaseExpandedTerms) {
            
           return true; 
            
        }
        
        return false;
        
    }

    public int hashCode() {
        return this.lowercaseExpandedTerms ? -1 : Integer.MAX_VALUE;
    }

    public String toString() {
        return "<lowercaseExpandedTerms lowercaseExpandedTerms=" + this.lowercaseExpandedTerms + "/>";
    }
    
}