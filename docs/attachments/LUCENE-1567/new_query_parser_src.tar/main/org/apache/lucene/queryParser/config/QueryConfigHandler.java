package org.apache.lucene.queryParser.config;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.queryParser.processors.QueryNodeProcessor;
import org.apache.lucene.util.Attribute;
import org.apache.lucene.util.AttributeSource;

/**
 * {@link QueryConfigHandler} should be implemented by classes that intends 
 * to provide configuration to {@link QueryNodeProcessor} objects.
 * 
 * This class extends {@link AttributeSource}, so {@link Attribute}s can be
 * attached to it.
 * 
 * The class that implements this class should also provides {@link FieldConfig}
 * objects for each collection field.
 * 
 * @see Attribute
 * @see FieldConfig
 */
public abstract class QueryConfigHandler extends AttributeSource {
    
    /**
     * The class that implements this method should return an implementation
     * of {@link FieldConfig} for a specific field name. If the implemented {@link QueryConfigHandler}
     * does not know a specific field name, it may return <code>null</code>, indicating there is no configuration
     * for that field. 
     * 
     * @param fieldName the field name
     * @return a {@link FieldConfig} object containing the field name configuration or <code>null</code>, 
     * if the implemented {@link QueryConfigHandler} has no configuration for that field
     */
    public abstract FieldConfig getFieldConfig(CharSequence fieldName);
    
}