package org.apache.lucene.queryParser.lucene2.config;



import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.PhraseSlopQueryNodeProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by {@link PhraseSlopQueryNodeProcessor} processor and
 * must be defined in the {@link QueryConfigHandler}. This attribute tells the
 * processor what is the default phrase slop when no slop is defined in a phrase.
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setPhraseSlop(int)
 */
public class DefaultPhraseSlopAttribute extends Attribute {
    
    private static final long serialVersionUID = -2104763012527049527L;
    
    private int defaultPhraseSlop = 1;
    
    public DefaultPhraseSlopAttribute() {
        // empty constructor
    }
    
    void setDefaultPhraseSlop(int defaultPhraseSlop) {
        this.defaultPhraseSlop = defaultPhraseSlop;
    }
    
    public int getDefaultPhraseSlop() {
        return this.defaultPhraseSlop;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {
        
        if (other instanceof DefaultPhraseSlopAttribute && other != null && 
                ((DefaultPhraseSlopAttribute) other).defaultPhraseSlop == this.defaultPhraseSlop) {
            
           return true; 
            
        }
        
        return false;
        
    }

    public int hashCode() {
        return Integer.valueOf(this.defaultPhraseSlop).hashCode();
    }

    public String toString() {
        return "<defaultPhraseSlop defaultPhraseSlop=" + this.defaultPhraseSlop + "/>";
    }
    
}