package org.apache.lucene.queryParser.lucene2.config;



import java.text.Collator;
import java.util.HashMap;
import java.util.Locale;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.DateTools;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.queryParser.config.FieldConfig;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.nodes.RangeQueryNode;
import org.apache.lucene.queryParser.lucene2.processors.LuceneQueryNodeProcessorPipeline;
import org.apache.lucene.queryParser.nodes.PrefixWildcardQueryNode;
import org.apache.lucene.queryParser.nodes.WildcardQueryNode;


/**
 * This query configuration handler is used for almost every processor defined
 * in the {@link LuceneQueryNodeProcessorPipeline} processor pipeline. It holds
 * attributes that reproduces the configuration that could be set on the
 * old query parser: {@link QueryParser}.
 * <br/>
 * @see LuceneQueryNodeProcessorPipeline
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper
 */
public class LuceneQueryConfigHandler extends QueryConfigHandler {
    
    private LowercaseExpandedTermsAttribute lowercaseExpandedTermsAttr;
    
    private DefaultOperatorAttribute defaultOperatorAttribute;
    
    private AllowLeadingWildcardAttribute allowLeadingWildcardAttribute;
    
    private DefaultPhraseSlopAttribute defaultPhraseSlopAttribute;
    
    private PositionIncrementsAttribute positionIncrementsAttribute;
    
    private ConstantScoreRewriteAttribute constantScoreRewriteAttribute;
    
    private RangeCollatorAttribute rangeCollatorAttribute;
    
    private DateTools.Resolution defaultDateResolution;
    
    private AnalyzerAttribute analyzerAttr;
    
    private LocaleAttribute localeAttribute;
    
    private HashMap<CharSequence, DateTools.Resolution> dateResolutions;
    
    public LuceneQueryConfigHandler() {
    	// setting the old QueryParser default values
        Collator collator = null;
        Locale locale = Locale.getDefault();
        int defaultPhraseSlop = 0;
        boolean lowercaseExpandedTerms = true;
        boolean allowLeadingWildcard = true;
        boolean constantScoreRewrite = true;
        boolean positionIncrementsEnabled = false;
        this.defaultDateResolution = null;
        
        this.rangeCollatorAttribute = ((RangeCollatorAttribute) addAttribute(RangeCollatorAttribute.class));
        this.rangeCollatorAttribute.setDateResolution(collator);
        
        this.defaultOperatorAttribute = ((DefaultOperatorAttribute) addAttribute(DefaultOperatorAttribute.class));
        this.defaultOperatorAttribute.setDefaultAND(false);
        
        this.analyzerAttr = ((AnalyzerAttribute) addAttribute(AnalyzerAttribute.class));
        this.analyzerAttr.setAnalyzer(null);
	    
        this.lowercaseExpandedTermsAttr = ((LowercaseExpandedTermsAttribute) addAttribute(LowercaseExpandedTermsAttribute.class));
        this.lowercaseExpandedTermsAttr.setLowercaseExpandedTerms(lowercaseExpandedTerms);
        
        this.constantScoreRewriteAttribute = ((ConstantScoreRewriteAttribute) addAttribute(ConstantScoreRewriteAttribute.class));
        this.constantScoreRewriteAttribute.setConstantScoreRewrite(constantScoreRewrite);
        
        this.allowLeadingWildcardAttribute = ((AllowLeadingWildcardAttribute) addAttribute(AllowLeadingWildcardAttribute.class));
        this.allowLeadingWildcardAttribute.setAllowLeadingWildcard(allowLeadingWildcard);
        
        this.positionIncrementsAttribute = ((PositionIncrementsAttribute) addAttribute(PositionIncrementsAttribute.class));
        this.positionIncrementsAttribute.setPositionIncrementsEnabled(positionIncrementsEnabled);
        
        this.localeAttribute = ((LocaleAttribute) addAttribute(LocaleAttribute.class));
        this.localeAttribute.setLocale(locale);
        
        this.defaultPhraseSlopAttribute = ((DefaultPhraseSlopAttribute) addAttribute(DefaultPhraseSlopAttribute.class));
        this.defaultPhraseSlopAttribute.setDefaultPhraseSlop(defaultPhraseSlop);
        
    }

	public FieldConfig getFieldConfig(CharSequence fieldName) {
        // TODO: cache a field config when it's constructed for the first time,
        // consecutive calls could return the cached object
        
        if (fieldName != null) {
            FieldConfig fieldConfig = new FieldConfig(fieldName);
            
            DateResolutionAttribute dateResolutionAttr = (DateResolutionAttribute) fieldConfig.addAttribute(DateResolutionAttribute.class);
            DateTools.Resolution dateRes = null;
            
            if (this.dateResolutions != null) {
                dateRes = this.dateResolutions.get(fieldName.toString());
            }
            
            if (dateRes == null) {
                dateRes = this.defaultDateResolution;
            }
            
            dateResolutionAttr.setDateResolution(dateRes);
            
            return fieldConfig;
            
        }
        
        return null;
        
    }
    
    /** 
     * Sets the collator used to determine index term inclusion in ranges
     * for RangeQuerys.
     * <p/>
     * <strong>WARNING:</strong> Setting the rangeCollator to a non-null
     * collator using this method will cause every single index Term in the
     * Field referenced by lowerTerm and/or upperTerm to be examined.
     * Depending on the number of index Terms in this Field, the operation could
     * be very slow.
     *
     *  @param collator the collator to use when constructing RangeQuerys
     */
    public void setRangeCollator(Collator collator) {
        this.rangeCollatorAttribute.setDateResolution(collator);
    }

    public void setAndAsDefaultOperator(boolean defaultAnd) {
        this.defaultOperatorAttribute.setDefaultAND(defaultAnd);
    }
    
    /**
     * Set to <code>true</code> to allow leading wildcard characters.
     * <p>
     * When set, <code>*</code> or <code>?</code> are allowed as 
     * the first character of a PrefixQuery and WildcardQuery.
     * Note that this can produce very slow
     * queries on big indexes. 
     * <p>
     * Default: false.
     */
    public void setLowercaseExpandedTerms(boolean lowercaseExpandedTerms) {
        this.lowercaseExpandedTermsAttr.setLowercaseExpandedTerms(lowercaseExpandedTerms);
    }
    
    /**
     * Set to <code>true</code> to allow leading wildcard characters.
     * <p>
     * When set, <code>*</code> or <code>?</code> are allowed as 
     * the first character of a PrefixQuery and WildcardQuery.
     * Note that this can produce very slow
     * queries on big indexes. 
     * <p>
     * Default: false.
     */
    public void setAllowLeadingWildcard(boolean allowLeadingWildcard) {
        this.allowLeadingWildcardAttribute.setAllowLeadingWildcard(allowLeadingWildcard);
    }
    
    /**
     * Set to <code>true</code> to enable position increments in result query.
     * <p>
     * When set, result phrase and multi-phrase queries will
     * be aware of position increments.
     * Useful when e.g. a StopFilter increases the position increment of
     * the token that follows an omitted token.
     * <p>
     * Default: false.
     */
    public void setPositionIncrementsEnabled(boolean enabled) {
        this.positionIncrementsAttribute.setPositionIncrementsEnabled(enabled);
    }
    
    /**
     * By default QueryParser uses constant-score rewriting
     * when creating a {@link PrefixWildcardQueryNode}, {@link WildcardQueryNode} or {@link RangeQueryNode}. This implementation is generally preferable because it 
     * a) Runs faster b) Does not have the scarcity of terms unduly influence score 
     * c) avoids any "TooManyBooleanClauses" exception.
     * However, if your application really needs to use the
     * old-fashioned BooleanQuery expansion rewriting and the above
     * points are not relevant then set this option to <code>true</code>
     * Default is <code>false</code>.
     */
    public void setConstantScoreRewrite(boolean constantScoreRewrite) {
        this.constantScoreRewriteAttribute.setConstantScoreRewrite(constantScoreRewrite);
    }
    
    /**
     * Sets the default date resolution used by RangeQueries for fields for which no
     * specific date resolutions has been set. Field specific resolutions can be set
     * with {@link #setDateResolution(String, DateTools.Resolution)}.
     *  
     * @param dateResolution the default date resolution to set
     */
    public void setDateResolution(DateTools.Resolution dateResolution) {
        this.defaultDateResolution = dateResolution;
    }
    
    /**
     * Set locale used by date range parsing.
     */
    public void setLocale(Locale locale) {
        this.localeAttribute.setLocale(locale);
    }
    
    /**
     * Sets the default slop for phrases.  If zero, then exact phrase matches
     * are required.  Default value is zero.
     */
    public void setDefaultPhraseSlop(int defaultPhraseSlop) {
        this.defaultPhraseSlopAttribute.setDefaultPhraseSlop(defaultPhraseSlop);
    }
    
    public void setAnalyzer(Analyzer analyzer) {
    	this.analyzerAttr.setAnalyzer(analyzer);
    }
    
    /**
     * Sets the default date resolution used by {@link RangeQueryNode} for fields for which no
     * specific date resolutions has been set. Field specific resolutions can be set
     * with {@link #setDateResolution(String, DateTools.Resolution)}.
     *  
     * @param dateResolution the default date resolution to set
     */
    public void setDateResolution(String fieldName, DateTools.Resolution dateResolution) {
        
        if (this.dateResolutions == null) {
            this.dateResolutions = new HashMap<CharSequence, DateTools.Resolution>();
        }
        
        if (fieldName != null) {
            this.dateResolutions.put(fieldName.toString(), dateResolution);
        }
        
    }
    
}
