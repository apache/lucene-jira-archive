package org.apache.lucene.queryParser.lucene2.processors;



import java.util.List;

import org.apache.lucene.messages.MessageImpl;
import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.QueryParserWrapper;
import org.apache.lucene.queryParser.lucene2.config.AllowLeadingWildcardAttribute;
import org.apache.lucene.queryParser.messages.QueryParserMessages;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.nodes.WildcardQueryNode;
import org.apache.lucene.queryParser.processors.QueryNodeProcessorImpl;


/**
 * This processor verifies if the attribute {@link AllowLeadingWildcardAttribute} is defined
 * in the {@link QueryConfigHandler}. If it is and leading wildcard is not allowed, it looks 
 * for every {@link WildcardQueryNode} contained in the query node tree and throws an exception
 * if any of them has a leading wildcard ('*' or '?').
 * <br/>
 * @see QueryParserWrapper#setAllowLeadingWildcard(boolean)
 * @see AllowLeadingWildcardAttribute
 */
public class AllowLeadingWildcardProcessor extends QueryNodeProcessorImpl {
    
    public AllowLeadingWildcardProcessor() {
        // empty constructor
    }
    
    public QueryNode process(QueryNode queryTree) throws QueryNodeException {
        
        if (getQueryConfigHandler().hasAttribute(AllowLeadingWildcardAttribute.class)) {
            
            if (!((AllowLeadingWildcardAttribute) getQueryConfigHandler().getAttribute(AllowLeadingWildcardAttribute.class)).isAllowLeadingWildcard()) { 
                return super.process(queryTree);    
            }
            
        }
        
        return queryTree;
        
    }

    protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException {
        
        if (node instanceof WildcardQueryNode) {
            WildcardQueryNode wildcardNode = (WildcardQueryNode) node;
            
            switch (wildcardNode.getText().charAt(0)) {
                
                case '*' :
                case '?' :
                    // TODO: create a message for this exception: "'*' not allowed as first character in PrefixQuery"
                    throw new QueryNodeException(new MessageImpl(QueryParserMessages.EMPTY_MESSAGE));
                
            }
            
        }
        
        return node;
        
    }

    protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException {
        
        return node;
        
    }

    protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException {
        
        return children;
        
    }
    
}
