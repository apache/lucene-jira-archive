package org.apache.lucene.queryParser.lucene2.builders;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.builders.QueryTreeBuilder;
import org.apache.lucene.queryParser.lucene2.nodes.LuceneBooleanQueryNode;
import org.apache.lucene.queryParser.lucene2.nodes.MultiPhraseQueryNode;
import org.apache.lucene.queryParser.lucene2.nodes.RangeQueryNode;
import org.apache.lucene.queryParser.lucene2.processors.LuceneQueryNodeProcessorPipeline;
import org.apache.lucene.queryParser.nodes.BooleanQueryNode;
import org.apache.lucene.queryParser.nodes.BoostQueryNode;
import org.apache.lucene.queryParser.nodes.FieldQueryNode;
import org.apache.lucene.queryParser.nodes.FuzzyQueryNode;
import org.apache.lucene.queryParser.nodes.GroupQueryNode;
import org.apache.lucene.queryParser.nodes.MatchAllDocsQueryNode;
import org.apache.lucene.queryParser.nodes.MatchNoDocsQueryNode;
import org.apache.lucene.queryParser.nodes.ModifierQueryNode;
import org.apache.lucene.queryParser.nodes.SlopQueryNode;
import org.apache.lucene.queryParser.nodes.PrefixWildcardQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.nodes.TokenizedPhraseQueryNode;
import org.apache.lucene.queryParser.nodes.WildcardQueryNode;
import org.apache.lucene.search.Query;


/**
 * This query tree builder only defines the necessary map to build a {@link Query} object. 
 * It should be used to generate a {@link Query} object from a query node tree processed by
 * a {@link LuceneQueryNodeProcessorPipeline}.
 * <br/>
 * @see QueryTreeBuilder
 * @see LuceneQueryNodeProcessorPipeline
 */
public class LuceneQueryTreeBuilder extends QueryTreeBuilder implements LuceneQueryBuilder {
    
    public LuceneQueryTreeBuilder() {
        setBuilder(GroupQueryNode.class, new GroupQueryNodeBuilder());
        setBuilder(FieldQueryNode.class, new FieldQueryNodeBuilder());
        setBuilder(BooleanQueryNode.class, new BooleanQueryNodeBuilder());
        setBuilder(FuzzyQueryNode.class, new FuzzyQueryNodeBuilder());
        setBuilder(BoostQueryNode.class, new BoostQueryNodeBuilder());
        setBuilder(ModifierQueryNode.class, new ModifierQueryNodeBuilder());
        setBuilder(WildcardQueryNode.class, new WildcardQueryNodeBuilder());
        setBuilder(TokenizedPhraseQueryNode.class, new PhraseQueryNodeBuilder());
        setBuilder(MatchNoDocsQueryNode.class, new MatchNoDocsQueryNodeBuilder());
        setBuilder(PrefixWildcardQueryNode.class, new PrefixWildcardQueryNodeBuilder());
        setBuilder(RangeQueryNode.class, new RangeQueryNodeBuilder());
        setBuilder(SlopQueryNode.class, new SlopQueryNodeBuilder());
        setBuilder(LuceneBooleanQueryNode.class, new LuceneBooleanQueryNodeBuilder());
        setBuilder(MultiPhraseQueryNode.class, new MultiPhraseQueryNodeBuilder());
        setBuilder(MatchAllDocsQueryNode.class, new MatchAllDocsQueryNodeBuilder());
        
    }

    public Query build(QueryNode queryNode) throws QueryNodeException {
        return (Query) super.build(queryNode);
    }
    
}
