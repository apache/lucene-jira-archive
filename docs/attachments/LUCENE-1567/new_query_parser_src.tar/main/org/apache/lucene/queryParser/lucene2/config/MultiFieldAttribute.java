package org.apache.lucene.queryParser.lucene2.config;



import java.util.Arrays;

import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.MultiFieldQueryNodeProcessor;
import org.apache.lucene.util.Attribute;


/**
 * This attribute is used by {@link MultiFieldQueryNodeProcessor} processor and
 * must be defined in the {@link QueryConfigHandler}. This attribute tells the
 * processor to which fields the terms in the query should be expanded.
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.MultiFieldQueryParserWrapper
 */
public class MultiFieldAttribute extends Attribute {

    private static final long serialVersionUID = -6809760312720049526L;

    private CharSequence[] fields;

    public MultiFieldAttribute() {
        // empty constructor
    }

    void setFields(CharSequence[] fields) {
        this.fields = fields;
    }

    public CharSequence[] getFields() {
        return this.fields;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {

        if (other instanceof MultiFieldAttribute) {
            MultiFieldAttribute fieldsAttr = (MultiFieldAttribute) other;

            return Arrays.equals(this.fields, fieldsAttr.fields);
            
        }

        return false;

    }

    public int hashCode() {
        return Arrays.hashCode(this.fields);
    }

    public String toString() {
        return "<fieldsAttribute fields=" + Arrays.toString(this.fields) + "/>";
    }

}