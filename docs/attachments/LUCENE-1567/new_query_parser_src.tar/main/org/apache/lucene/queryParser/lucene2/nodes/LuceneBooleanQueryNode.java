package org.apache.lucene.queryParser.lucene2.nodes;



import java.util.List;

import org.apache.lucene.queryParser.nodes.BooleanQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Similarity;


/**
 * A {@link LuceneBooleanQueryNode} has the same behavior as {@link BooleanQueryNode}.
 * It only indicates if the coord should be enabled or not for this
 * boolean query.
 * <br/>
 *  @see Similarity#coord(int, int)
 *  @see BooleanQuery
 */
public class LuceneBooleanQueryNode extends BooleanQueryNode {
    
    private static final long serialVersionUID = 1938287817191138787L;
    
    private boolean disableCoord;
    
    /**
     * @param clauses
     */
    public LuceneBooleanQueryNode(List<QueryNode> clauses, boolean disableCoord) {
        super(clauses);
        
        this.disableCoord = disableCoord;
        
    }
    
    public boolean isDisableCoord() {
        return this.disableCoord;
    }
        
}
