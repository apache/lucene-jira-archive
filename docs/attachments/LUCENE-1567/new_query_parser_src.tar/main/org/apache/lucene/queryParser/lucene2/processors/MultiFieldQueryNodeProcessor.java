package org.apache.lucene.queryParser.lucene2.processors;



import java.util.LinkedList;
import java.util.List;

import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.config.FieldConfig;
import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.MultiFieldQueryParserWrapper;
import org.apache.lucene.queryParser.lucene2.config.BoostAttribute;
import org.apache.lucene.queryParser.lucene2.config.MultiFieldAttribute;
import org.apache.lucene.queryParser.nodes.BooleanQueryNode;
import org.apache.lucene.queryParser.nodes.BoostQueryNode;
import org.apache.lucene.queryParser.nodes.FieldableNode;
import org.apache.lucene.queryParser.nodes.GroupQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.processors.QueryNodeProcessorImpl;


/**
 * This processor is used to expand terms so the query looks for
 * the same term in different fields. It also boosts a query based
 * on its field.
 * <br/><br/>
 * This processor looks for every {@link FieldableNode} contained in the query node tree.
 * If a {@link FieldableNode} is found, it checks if there is a {@link MultiFieldAttribute} 
 * defined in the {@link QueryConfigHandler}. If there is, the {@link FieldableNode} is 
 * cloned N times and the clones are added to a {@link BooleanQueryNode} together with the original node. 
 * N is defined by the number of fields that it will be expanded to. The {@link BooleanQueryNode} is returned.
 * <br/><br/>  
 * This processor also looks a {@link BoostAttribute} for each field in the {@link QueryConfigHandler}.
 * If there is a {@link BoostAttribute} in a specific field, this boost is applied to the {@link FieldableNode}.
 * <br/>
 * @see BoostAttribute
 * @see MultiFieldAttribute
 * @see MultiFieldQueryParserWrapper
 */
public class MultiFieldQueryNodeProcessor extends QueryNodeProcessorImpl {

    private boolean processChildren = true;

    public MultiFieldQueryNodeProcessor() {
        // empty constructor
    }

    protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException {

        return node;

    }

    private QueryNode addBoost(FieldableNode node) throws QueryNodeException {
        FieldConfig fieldConfig = getQueryConfigHandler().getFieldConfig(
                node.getField());

        if (fieldConfig != null) {

            if (fieldConfig.hasAttribute(BoostAttribute.class)) {
                float boost = ((BoostAttribute) fieldConfig.getAttribute(BoostAttribute.class)).getBoost();

                return new BoostQueryNode(node, boost);

            }

        }

        return node;

    }

    protected void processChildren(QueryNode queryTree)
            throws QueryNodeException {

        if (this.processChildren) {
            super.processChildren(queryTree);
            
        } else {
            this.processChildren = true;
        }
        
        
    }

    protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException {
        
        if (node instanceof FieldableNode) {
            this.processChildren = false;
            FieldableNode fieldNode = (FieldableNode) node;

            if (fieldNode.getField() == null) {

                if (!getQueryConfigHandler().hasAttribute(
                        MultiFieldAttribute.class)) {
                    throw new IllegalArgumentException(
                            "MultiFieldAttribute should be set on the QueryConfigHandler");
                }

                CharSequence[] fields = ((MultiFieldAttribute) getQueryConfigHandler().getAttribute(
                        MultiFieldAttribute.class)).getFields();

                if (fields != null && fields.length > 0) {
                    fieldNode.setField(fields[0]);
                    QueryNode boostedNode = addBoost(fieldNode);

                    if (fields.length == 1) {
                        return boostedNode;

                    } else {
                        LinkedList<QueryNode> children = new LinkedList<QueryNode>();
                        children.add(boostedNode);

                        for (int i = 1; i < fields.length; i++) {
                            try {
                                fieldNode = (FieldableNode) fieldNode.cloneTree();
                                fieldNode.setField(fields[i]);
                                boostedNode = addBoost(fieldNode);

                                children.add(boostedNode);

                            } catch (CloneNotSupportedException e) {
                                // should never happen
                            }

                        }

                        return new GroupQueryNode(
                                new BooleanQueryNode(children));

                    }

                }

            }

        }

        return node;

    }

    protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException {

        return children;

    }

}