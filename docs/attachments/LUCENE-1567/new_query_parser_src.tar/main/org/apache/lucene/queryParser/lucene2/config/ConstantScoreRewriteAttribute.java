package org.apache.lucene.queryParser.lucene2.config;



import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.ParametricRangeQueryNodeProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by {@link ParametricRangeQueryNodeProcessor} processor and
 * should be defined in the {@link QueryConfigHandler} used by this processor. It
 * basically tells the processor if the constant score rewrite is enabled.
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setConstantScoreRewrite(boolean)
 */
public class ConstantScoreRewriteAttribute extends Attribute {
    
    private static final long serialVersionUID = -2104763012723049527L;
    
    private boolean constantScoreRewrite = true;
    
    public ConstantScoreRewriteAttribute() {
        // empty constructor
    }
    
    void setConstantScoreRewrite(boolean constantScoreRewrite) {
        this.constantScoreRewrite = constantScoreRewrite;
    }
    
    public boolean isConstantScoreRewrite() {
        return this.constantScoreRewrite;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {
        
        if (other instanceof ConstantScoreRewriteAttribute && 
                ((ConstantScoreRewriteAttribute) other).constantScoreRewrite == this.constantScoreRewrite) {
            
           return true; 
            
        }
        
        return false;
        
    }

    public int hashCode() {
        return this.constantScoreRewrite ? -1 : Integer.MAX_VALUE;
    }

    public String toString() {
        return "<constantScoreRewrite constantScoreRewrite=" + this.constantScoreRewrite + "/>";
    }
    
}