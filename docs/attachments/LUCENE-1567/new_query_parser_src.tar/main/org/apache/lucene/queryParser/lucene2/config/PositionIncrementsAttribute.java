package org.apache.lucene.queryParser.lucene2.config;



import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.AnalyzerQueryNodeProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by {@link AnalyzerQueryNodeProcessor} processor and
 * must be defined in the {@link QueryConfigHandler}. This attribute tells the
 * processor if the position increment is enabled.
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setEnablePositionIncrements(boolean)
 */
public class PositionIncrementsAttribute extends Attribute {
    
    private static final long serialVersionUID = -2804763012793049527L;
    
    private boolean positionIncrementsEnabled = true;
    
    public PositionIncrementsAttribute() {
        // empty constructor
    }
    
    void setPositionIncrementsEnabled(boolean positionIncrementsEnabled) {
        this.positionIncrementsEnabled = positionIncrementsEnabled;
    }
    
    public boolean isPositionIncrementsEnabled() {
        return this.positionIncrementsEnabled;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {
        
        if (other instanceof PositionIncrementsAttribute && other != null &&
                ((PositionIncrementsAttribute) other).positionIncrementsEnabled == this.positionIncrementsEnabled) {
            
           return true; 
            
        }
        
        return false;
        
    }

    public int hashCode() {
        return this.positionIncrementsEnabled ? -1 : Integer.MAX_VALUE;
    }

    public String toString() {
        return "<positionIncrements positionIncrementsEnabled=" + this.positionIncrementsEnabled + "/>";
    }
    
}