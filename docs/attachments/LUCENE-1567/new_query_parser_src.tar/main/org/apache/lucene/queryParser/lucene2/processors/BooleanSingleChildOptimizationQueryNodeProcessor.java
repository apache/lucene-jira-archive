package org.apache.lucene.queryParser.lucene2.processors;



import java.util.List;

import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.lucene2.nodes.BooleanModifierNode;
import org.apache.lucene.queryParser.nodes.BooleanQueryNode;
import org.apache.lucene.queryParser.nodes.ModifierQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.nodes.ModifierQueryNode.Modifier;
import org.apache.lucene.queryParser.processors.QueryNodeProcessorImpl;


/**
 * This processor removes every {@link BooleanQueryNode} that contains only one
 * child and returns this child. If this child is {@link ModifierQueryNode}
 * that was defined by the user. A modifier is not defined by the user when it's a {@link BooleanModifierNode}
 * <br/>
 * @see ModifierQueryNode
 */
public class BooleanSingleChildOptimizationQueryNodeProcessor extends QueryNodeProcessorImpl {
    
    public BooleanSingleChildOptimizationQueryNodeProcessor() {
        // empty constructor
    }

    protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException {
        
        if (node instanceof BooleanQueryNode) {
            List<QueryNode> children = node.getChildren();
            
            if (children != null && children.size() == 1) {
                QueryNode child = children.get(0);
                
                if (child instanceof ModifierQueryNode) {
                    ModifierQueryNode modNode = (ModifierQueryNode) child;
                    
                    if (modNode instanceof BooleanModifierNode ||
                            modNode.getModifier() == Modifier.MOD_NONE) {
                        
                        return child;
                        
                    }
                    
                    
                } else {
                    return child;
                }
                
            }
            
        }
        
        return node;
        
    }

    protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException {
        
        return node;
        
    }

    protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException {
        
        return children;
        
    }
    
}
