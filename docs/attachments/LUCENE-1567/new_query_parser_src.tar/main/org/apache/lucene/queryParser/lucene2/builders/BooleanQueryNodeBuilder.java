package org.apache.lucene.queryParser.lucene2.builders;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.List;

import org.apache.lucene.messages.MessageImpl;
import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.builders.QueryTreeBuilder;
import org.apache.lucene.queryParser.messages.QueryParserMessages;
import org.apache.lucene.queryParser.nodes.BooleanQueryNode;
import org.apache.lucene.queryParser.nodes.ModifierQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.BooleanQuery.TooManyClauses;


/**
 * Builds a {@link BooleanQuery} object from a {@link BooleanQueryNode} object.
 * Every children in the {@link BooleanQueryNode} object must be already
 * tagged using {@link QueryTreeBuilder#QUERY_TREE_BUILDER_TAGID} with
 * a {@link Query} object.
 * <br/><br/>
 * It takes in consideration if the children is a {@link ModifierQueryNode}
 * to define the {@link BooleanClause}.
 */
public class BooleanQueryNodeBuilder implements LuceneQueryBuilder {

    public BooleanQueryNodeBuilder() {
        // empty constructor
    }

    public BooleanQuery build(QueryNode queryNode) throws QueryNodeException {
        BooleanQueryNode booleanNode = (BooleanQueryNode) queryNode;

        BooleanQuery bQuery = new BooleanQuery();
        List<QueryNode> children = booleanNode.getChildren();

        if (children != null) {

            for (QueryNode child : children) {
                Object obj = child.getTag(QueryTreeBuilder.QUERY_TREE_BUILDER_TAGID);

                if (obj != null) {
                    Query query = (Query) obj;

                    try {
                        bQuery.add(query, getModifierValue(child));
                    } catch (TooManyClauses ex) {

                        // TODO: create a good message for this exception
                        throw new QueryNodeException(new MessageImpl(
                                QueryParserMessages.EMPTY_MESSAGE), ex);

                    }

                }

            }

        }

        return bQuery;

    }

    private static BooleanClause.Occur getModifierValue(QueryNode node)
            throws QueryNodeException {

        if (node instanceof ModifierQueryNode) {
            ModifierQueryNode mNode = ((ModifierQueryNode) node);
            switch (mNode.getModifier()) {
                case MOD_REQ:
                    return BooleanClause.Occur.MUST;
                case MOD_NOT:
                    return BooleanClause.Occur.MUST_NOT;

                // TODO: what should be the best way to get the default modifier
                case MOD_NONE:
                    return BooleanClause.Occur.SHOULD;

            }

        }

        return BooleanClause.Occur.SHOULD;

    }

}
