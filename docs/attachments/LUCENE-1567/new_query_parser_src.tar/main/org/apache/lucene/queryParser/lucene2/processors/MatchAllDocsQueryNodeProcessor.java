package org.apache.lucene.queryParser.lucene2.processors;



import java.util.List;

import org.apache.lucene.queryParser.QueryNodeException;
import org.apache.lucene.queryParser.nodes.MatchAllDocsQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;
import org.apache.lucene.queryParser.nodes.WildcardQueryNode;
import org.apache.lucene.queryParser.processors.QueryNodeProcessorImpl;
import org.apache.lucene.search.MatchAllDocsQuery;


/**
 * This processor converts every {@link WildcardQueryNode} that is "*:*" to
 * {@link MatchAllDocsQueryNode}.
 * 
 * @see MatchAllDocsQueryNode
 * @see MatchAllDocsQuery
 */
public class MatchAllDocsQueryNodeProcessor extends QueryNodeProcessorImpl {
    
    public MatchAllDocsQueryNodeProcessor() {
        // empty constructor
    }

    protected QueryNode postProcessNode(QueryNode node)
            throws QueryNodeException {
        
        if (node instanceof WildcardQueryNode) {
            WildcardQueryNode wildcardNode = (WildcardQueryNode) node;
            
            if (wildcardNode.getField().toString().equals("*") &&
                    wildcardNode.getText().toString().equals("*")) { 
                
                return new MatchAllDocsQueryNode();
                
            }
                
        }
        
        return node;
        
    }

    protected QueryNode preProcessNode(QueryNode node)
            throws QueryNodeException {

        return node;
        
    }

    protected List<QueryNode> setChildrenOrder(List<QueryNode> children)
            throws QueryNodeException {

        return children;
        
    }
    
}
