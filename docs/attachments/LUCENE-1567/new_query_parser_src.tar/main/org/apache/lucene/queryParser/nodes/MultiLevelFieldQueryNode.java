package org.apache.lucene.queryParser.nodes;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.apache.lucene.queryParser.parser.EscapeQuerySyntax;
import org.apache.lucene.queryParser.parser.EscapeQuerySyntax.Type;


/**
 * A {@link MultiLevelFieldQueryNode} is used for to store queries like
 * /company/USA/California
 * /product/shoes/brown
 * QueryText are objects that contain the text, begin position and
 * end position in the query.
 * 
 * Example how the text parser creates these objects:
 * 
 * List values = ArrayList();
 * values.add(new MultiLevelFieldQueryNode.QueryText("company", 1, 7));
 * values.add(new MultiLevelFieldQueryNode.QueryText("USA", 9, 12));
 * values.add(new MultiLevelFieldQueryNode.QueryText("California", 14, 23));
 * QueryNode q = new MultiLevelFieldQueryNode(values);
 * 
 */
public class MultiLevelFieldQueryNode extends QueryNodeImpl implements FieldableNode {

    private static final long serialVersionUID = -8325921322405804789L;

    public static class QueryText {
        CharSequence value = null;
        /**
         * The term's begin position.
         */
        int begin;

        /**
         * The term's end position.
         */
        int end;

        /**
         * @param value - text value 
         * @param begin - position in the query string
         * @param end - position in the query string
         */
        public QueryText(CharSequence value, int begin, int end) {
            super();
            this.value = value;
            this.begin = begin;
            this.end = end;
        }
        
        public QueryText clone() throws CloneNotSupportedException {
        	QueryText clone=(QueryText)super.clone();
        	clone.value = this.value;
            clone.begin = this.begin;
            clone.end = this.end;            
            return clone;
        }
    }

    private List<QueryText> values = null;
    /**
     * @param pValues - List of QueryText objects
     */
    public MultiLevelFieldQueryNode(List<QueryText> pValues) {
        this.values = pValues;
    }

    public CharSequence getField() {
        //first value contains the field name
        return this.values.get(0).value;
    }
    
    public CharSequence getText() {
        //second value contains the text value
        return this.values.get(1).value;
    }
    
    CharSequence getTermEscaped(EscapeQuerySyntax escaper){
        return escaper.escape(this.values.get(1).value, Locale.getDefault(), Type.NORMAL);
    }
    
    CharSequence getTermEscapeQuoted(EscapeQuerySyntax escaper){
        return escaper.escape(this.values.get(1).value, Locale.getDefault(), Type.STRING);
    }

    public void setField(CharSequence fieldName) {
        List<QueryNode> children = getChildren();
        
        if (children != null) {
        
            for (QueryNode child : children) {
                
                if (child instanceof FieldableNode) {
                    ((FieldableNode) child).setField(fieldName);
                }
                
            }
        
        }
        
    }
    
    public CharSequence toQueryString(EscapeQuerySyntax escaper) {
        if (isDefaultField(this.values.get(0).value)) {
            return "/DEFAULT/" + getTermEscaped(escaper);
        } else {
            return "/" + this.values.get(0).value + "/\"" + getTermEscaped(escaper) + "\"";
        }
    }
    
    public String toString() {
        QueryText text = this.values.get(0);
        
        return "<multilevelfield start='" + text.begin 
               + "' end='" + text.end 
               + "' field='" + text.value + "' text='" + this.values.get(1).value +"'/>";
    }
    
    public QueryNode cloneTree() throws CloneNotSupportedException {
    	MultiLevelFieldQueryNode clone=(MultiLevelFieldQueryNode)super.cloneTree();
            
        // copy children
        if (this.values != null) {
            List<QueryText> localValues = new ArrayList<QueryText>();
            for (QueryText value : this.values) {
            	localValues.add(value.clone());
            }
            clone.values = localValues;
        }
        
        return clone;
    }
}
