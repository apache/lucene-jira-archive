package org.apache.lucene.queryParser.lucene2.config;



import java.text.Collator;

import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.processors.ParametricRangeQueryNodeProcessor;
import org.apache.lucene.search.RangeQuery;
import org.apache.lucene.util.Attribute;


/**
 * This attribute is used by {@link ParametricRangeQueryNodeProcessor} processor and
 * must be defined in the {@link QueryConfigHandler}. This attribute tells the
 * processor which {@link Collator} should be used for a {@link RangeQuery}
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setRangeCollator(Collator)
 */
public class RangeCollatorAttribute extends Attribute {

    private static final long serialVersionUID = -6804360312723049526L;

    private Collator rangeCollator;

    public RangeCollatorAttribute() {
        // empty constructor
    }

    void setDateResolution(Collator rangeCollator) {
        this.rangeCollator = rangeCollator;
    }

    public Collator getRangeCollator() {
        return this.rangeCollator;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {

        if (other instanceof RangeCollatorAttribute) {
            RangeCollatorAttribute rangeCollatorAttr = (RangeCollatorAttribute) other;

            if (rangeCollatorAttr.rangeCollator == this.rangeCollator
                    || rangeCollatorAttr.rangeCollator.equals(
                            this.rangeCollator)) {

                return true;

            }

        }

        return false;

    }

    public int hashCode() {
        return (this.rangeCollator == null) ? 0 : this.rangeCollator.hashCode();
    }

    public String toString() {
        return "<rangeCollatorAttribute rangeCollator='" + this.rangeCollator + "'/>";
    }

}