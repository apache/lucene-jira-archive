package org.apache.lucene.queryParser.lucene2.nodes;



import org.apache.lucene.queryParser.lucene2.processors.GroupQueryNodeProcessor;
import org.apache.lucene.queryParser.nodes.ModifierQueryNode;
import org.apache.lucene.queryParser.nodes.QueryNode;

/**
 * A {@link BooleanModifierNode} has the same behaviour as {@link ModifierQueryNode},
 * it only indicates that this modifier was added by {@link GroupQueryNodeProcessor}
 * and not by the user.
 * <br/>
 * @see ModifierQueryNode
 */
public class BooleanModifierNode extends ModifierQueryNode {
    
    private static final long serialVersionUID = -557816496416587068L;

    public BooleanModifierNode(QueryNode node, Modifier mod) {
        super(node, mod);
    }
    
}
