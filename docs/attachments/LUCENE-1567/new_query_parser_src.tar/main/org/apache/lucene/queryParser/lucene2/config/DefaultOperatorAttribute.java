package org.apache.lucene.queryParser.lucene2.config;



import org.apache.lucene.queryParser.config.QueryConfigHandler;
import org.apache.lucene.queryParser.lucene2.QueryParserWrapper;
import org.apache.lucene.queryParser.lucene2.processors.GroupQueryNodeProcessor;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by {@link GroupQueryNodeProcessor} processor and
 * must be defined in the {@link QueryConfigHandler}. This attribute tells the
 * processor which is the default boolean operator when no operator is defined between
 * terms.
 * <br/>
 * @see QueryParserWrapper#setDefaultOperator(org.apache.lucene.queryParser.QueryParser.Operator)
 */
public class DefaultOperatorAttribute extends Attribute {
    
    private static final long serialVersionUID = -6804760312723049526L;
    
    private boolean usingAND = false;
    
    public DefaultOperatorAttribute() {
        // empty constructor
    }

    public void setDefaultAND(boolean bool) {
        this.usingAND = bool;
    }
    
    public boolean isDefaultAND() {
        return this.usingAND;
    }

    public void clear() {
        throw new UnsupportedOperationException();
    }

    public void copyTo(Attribute target) {
        throw new UnsupportedOperationException();
    }

    public boolean equals(Object other) {

        if (other instanceof DefaultOperatorAttribute) {
            DefaultOperatorAttribute defaultOperatorAttr = (DefaultOperatorAttribute) other;

            if (defaultOperatorAttr.isDefaultAND() == this.isDefaultAND()) {
                return true;

            }

        }
        
        return false;
        
    }

    public int hashCode() {
       return new Boolean(this.isDefaultAND()).hashCode();
    }

    public String toString() {
        return "<defaultOperatorAttribute defaultOperator=" + this.isDefaultAND() + "/>";
    }
    
}