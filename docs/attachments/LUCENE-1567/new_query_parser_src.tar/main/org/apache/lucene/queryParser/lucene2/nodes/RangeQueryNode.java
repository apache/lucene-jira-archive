package org.apache.lucene.queryParser.lucene2.nodes;



import java.text.Collator;

import org.apache.lucene.queryParser.nodes.ParametricQueryNode;
import org.apache.lucene.queryParser.nodes.ParametricRangeQueryNode;


/**
 * This query node represents a Lucene range query. It also holds which
 * collator will be used by the range query and if the constant score rewrite is enabled.
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setConstantScoreRewrite(boolean)
 * @see org.apache.lucene.queryParser.lucene2.QueryParserWrapper#setRangeCollator(Collator)
 * @see org.apache.lucene.search.RangeQuery
 */
public class RangeQueryNode extends ParametricRangeQueryNode {

    private static final long serialVersionUID = 7400866652044314657L;
    
    private Collator collator;
    
    private boolean constantScoreRewrite;
    
    /**
     * @param lower
     * @param upper
     */
    public RangeQueryNode(ParametricQueryNode lower, ParametricQueryNode upper, Collator collator, boolean constantScoreRewrite) {
        super(lower, upper);
        
        this.constantScoreRewrite = constantScoreRewrite;
        this.collator = collator;
        
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder("<range>\n\t");
        sb.append(this.getUpperBound()).append("\n\t");
        sb.append(this.getLowerBound()).append("\n");
        sb.append("</range>\n");
        
        return sb.toString();
        
    }

    /**
     * @return the collator
     */
    public Collator getCollator() {
        return this.collator;
    }

    /**
     * @return the constantScoreRewrite
     */
    public boolean isConstantScoreRewrite() {
        return this.constantScoreRewrite;
    }
    
}
