package org.apache.lucene.queryParser;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.queryParser.lucene2.QueryParserWrapper;
import org.apache.lucene.util.Parameter;

@SuppressWarnings("deprecation")
/**
 * This class is a Wrapper for the old lucene 2.4 QueryParser
 * 
 * @deprecated this class will be removed soon, it's a temporary class to be
 * used
 */
public class QueryParser extends QueryParserWrapper {
	/**
	 * The default operator for parsing queries. Use
	 * {@link QueryParser#setDefaultOperator} to change it.
	 */
	static public final class Operator extends Parameter {
		private Operator(String name) {
			super(name);
		}

		static public final Operator OR = new Operator("OR");
		static public final Operator AND = new Operator("AND");
	}

	// the nested class:
	/** Alternative form of QueryParser.Operator.AND */
	public static final Operator AND_OPERATOR = Operator.AND;
	/** Alternative form of QueryParser.Operator.OR */
	public static final Operator OR_OPERATOR = Operator.OR;

	public QueryParser(String defaultField, Analyzer analizer) {
		super(defaultField, analizer);
	}

	/**
	 * Returns a String where those characters that QueryParser expects to be
	 * escaped are escaped by a preceding <code>\</code>.
	 */
	public static String escape(String s) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			// These characters are part of the query syntax and must be escaped
			if (c == '\\' || c == '+' || c == '-' || c == '!' || c == '('
					|| c == ')' || c == ':' || c == '^' || c == '[' || c == ']'
					|| c == '\"' || c == '{' || c == '}' || c == '~'
					|| c == '*' || c == '?' || c == '|' || c == '&') {
				sb.append('\\');
			}
			sb.append(c);
		}
		return sb.toString();
	}

}
