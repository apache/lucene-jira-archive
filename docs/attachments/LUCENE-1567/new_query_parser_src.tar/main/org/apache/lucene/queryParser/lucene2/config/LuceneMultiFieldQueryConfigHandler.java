package org.apache.lucene.queryParser.lucene2.config;



import java.util.Map;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.DateTools.Resolution;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.queryParser.config.FieldConfig;
import org.apache.lucene.queryParser.lucene2.MultiFieldQueryParserWrapper;
import org.apache.lucene.queryParser.lucene2.QueryParserWrapper;


/**
 * This configuration handler holds every configuration supported by {@link LuceneQueryConfigHandler}
 * plus a field boost mapping and the list of fields that should be used to expand each term.
 * <br/>
 * @see org.apache.lucene.queryParser.lucene2.MultiFieldQueryParserWrapper
 */
public class LuceneMultiFieldQueryConfigHandler extends LuceneQueryConfigHandler {

    private Map<CharSequence, Float> boosts;
    
    public LuceneMultiFieldQueryConfigHandler(CharSequence[] fields, Map<CharSequence, Float> boosts) {
        MultiFieldAttribute multiFieldAttr = (MultiFieldAttribute) addAttribute(MultiFieldAttribute.class);
        multiFieldAttr.setFields(fields);
        
        this.boosts = boosts;
        
    }
    
    public FieldConfig getFieldConfig(CharSequence fieldName) {
        FieldConfig fc = super.getFieldConfig(fieldName);
        
        if (this.boosts != null) {
            BoostAttribute boostAttr = (BoostAttribute) fc.addAttribute(BoostAttribute.class);
            Float boost = this.boosts.get(fieldName);
            
            if (boost != null) {
                boostAttr.setBoost(boost.floatValue());
            }
            
        }
        
        return fc;
        
    }
   
}
