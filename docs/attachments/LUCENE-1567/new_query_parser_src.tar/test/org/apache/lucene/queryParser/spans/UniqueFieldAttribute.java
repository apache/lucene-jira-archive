package org.apache.lucene.queryParser.spans;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.queryParser.nodes.FieldableNode;
import org.apache.lucene.util.Attribute;

/**
 * This attribute is used by the {@link UniqueFieldQueryNodeProcessor}
 * processor. It holds a value that defines which is the unique field name
 * that should be set in every {@link FieldableNode}.<br/><br/>
 * 
 * @see UniqueFieldQueryNodeProcessor
 */
public class UniqueFieldAttribute extends Attribute {
	
	private static final long serialVersionUID = 8553318595851064232L;
	
	private CharSequence uniqueField;
	
	public UniqueFieldAttribute() {
		clear();
	}

	@Override
	public void clear() {
		this.uniqueField = "";
	}
	
	public void setUniqueField(CharSequence uniqueField) {
		this.uniqueField = uniqueField;
	}
	
	public CharSequence getUniqueField() {
		return this.uniqueField;
	}

	@Override
	public void copyTo(Attribute target) {
		
		if (!(target instanceof UniqueFieldAttribute)) {
			throw new IllegalArgumentException("cannot copy the values from attribute UniqueFieldAttribute to an instance of " + target.getClass().getName());
		}
		
		UniqueFieldAttribute uniqueFieldAttr = (UniqueFieldAttribute) target;
		uniqueFieldAttr.uniqueField = uniqueField.toString();
		
	}

	@Override
	public boolean equals(Object other) {
		
		if (other instanceof UniqueFieldAttribute) {
			
			return ((UniqueFieldAttribute) other).uniqueField.equals(this.uniqueField);
			
		}
		
		return false;
		
	}

	@Override
	public int hashCode() {
		return this.uniqueField.hashCode();
	}

	@Override
	public String toString() {
		return "<uniqueField uniqueField='" + this.uniqueField + "'/>";
	}

}
