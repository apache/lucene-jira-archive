package org.apache.lucene.search;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.text.ParseException;

import org.apache.lucene.document.DateField;
import org.apache.lucene.document.DateTools;

/**
 * Expert: returns a comparator for sorting ScoreDocs for encoded
 * <code>long</code> field values. This is an abstract class which contains
 * two implementations of DecodedLongSortComparator for decoding 
 * <code>String</code> field values to their corresponding <code>long</code>
 * values based upon the encoding/decoding functionalities of the DateField.java
 * and DateTools.java classes. 
 * 
 * <p>
 * Created: Apr 21, 2005
 * 
 * @author Rasik Pandey
 * @since 1.4.3
 * @see DecodedLongSortComparator.decode()
 */
public abstract class TimeSortComparatorSource extends DecodedLongSortComparatorSource {

  /**SortComparatorSource implemenation for sorting <code>String</code>
   * encoded time values as <code>long</code> values using the DateField.java
   * utility class to decode these values
   */
  static final SortComparatorSource DATEFIELD = new DecodedLongSortComparatorSource() {
    /**
     * Decodes a time field value encoded as a <code>String</code> 
     * to a <code>long</code> value using the <code>DateField.java</code> 
     * utility class.
     * 
     * @param termtext <code>String</code> term value
     * @return Term value decoded to a <code>long</code> value
     * @throws ParseException
     */
    protected long decode(String termtext) throws ParseException {
      return DateField.stringToTime(termtext);
    }
  };

  /**SortComparatorSource implemenation for sorting <code>String</code>
   * encoded time values as <code>long</code> values using the DateTools.java
   * utility class to decode these values
   */
  static final SortComparatorSource DATETOOLS = new DecodedLongSortComparatorSource() {
    /**
     * Decodes a time field value encoded as a <code>String</code> 
     * to a <code>long</code> value using the <code>DateTools.java</code> 
     * utility class.
     * 
     * @param termtext <code>String</code> term value
     * @return Term value decoded to a <code>long</code> value
     * @throws ParseException
     */
    protected long decode(String termtext) throws ParseException {
      return DateTools.stringToTime(termtext);
    }
  };

}
