package org.apache.lucene.search;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.text.ParseException;

import org.apache.lucene.document.DateField;
import org.apache.lucene.document.DateTools;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermDocs;
import org.apache.lucene.index.TermEnum;

/**
 * Expert: returns a comparator for sorting ScoreDocs for <code>long</code>
 * field values.
 * 
 * <p>
 * Created: Apr 21, 2005
 * 
 * @author Rasik Pandey
 * @since 1.4.3
 */
public class LongSortComparator extends SortComparator {

  interface LongParser {
    /** Return an integer representation of this field's value. */
    public long parseLong(String string);
  }

  static final LongParser LONG_PARSER = new LongParser() {
    public long parseLong(String value) {
      return Long.parseLong(value);
    }
  };

  static final LongParser DATEFIELD_LONG_PARSER = new LongParser() {
    public long parseLong(String value) {
      return DateField.stringToTime(value);
    }
  };

  static final LongParser DATETOOLS_LONG_PARSER = new LongParser() {
    public long parseLong(String value) {
      try {
        return DateTools.stringToTime(value);
      } catch (ParseException e) {
        e.printStackTrace();
        return LongSortComparator.LONG_PARSER.parseLong(value);//default behavior
      }
    }
  };

  /**
   * Expert: Maintains caches of term values as <code>long</code> values.
   */
  public static class LongFieldCacheImpl extends FieldCacheImpl {
    public long[] getLongs(IndexReader reader, String field, LongParser parser)
        throws IOException {
      field = field.intern();
      Object ret = lookup(reader, field, SortField.CUSTOM);
      if (ret == null) {
        final long[] retArray = new long[reader.maxDoc()];
        if (retArray.length > 0) {
          TermDocs termDocs = reader.termDocs();
          TermEnum termEnum = reader.terms(new Term(field, ""));
          try {
            if (termEnum.term() == null) {
              throw new RuntimeException("no terms in field " + field);
            }
            do {
              Term term = termEnum.term();
              if (term.field() != field)
                break;
              long termval = parser.parseLong(term.text());
              termDocs.seek(termEnum);
              while (termDocs.next()) {
                retArray[termDocs.doc()] = termval;
              }
            } while (termEnum.next());
          } finally {
            termDocs.close();
            termEnum.close();
          }
        }
        store(reader, field, SortField.CUSTOM, retArray);
        return retArray;
      }
      return (long[]) ret;
    }
  };

  /** Expert: The cache used internally by sorting and range query classes. */
  public static LongFieldCacheImpl DEFAULT = new LongFieldCacheImpl();
  
  private LongParser _parser;//defaulted
  
  public LongSortComparator (){
    this(LongSortComparator.LONG_PARSER);//defaulted
  }
  public LongSortComparator (LongParser parser){
    this._parser = parser;
  }

  /**
   * Creates a comparator for the field in the given index.
   * 
   * @param reader
   *          Index to create comparator for.
   * @param fieldname
   *          Field to create comparator for.
   * @return Comparator of ScoreDoc objects.
   * @throws IOException
   *           If an error occurs reading the index.
   */
  public ScoreDocComparator newComparator(final IndexReader reader,
      final String fieldname) throws IOException {
    final String field = fieldname.intern();
    final long[] fieldOrder = LongSortComparator.DEFAULT.getLongs(reader,
        field, this._parser);
    return new ScoreDocComparator() {

      public final int compare(final ScoreDoc i, final ScoreDoc j) {
        final long fi = fieldOrder[i.doc];
        final long fj = fieldOrder[j.doc];
        if (fi < fj)
          return -1;
        if (fi > fj)
          return 1;
        return 0;
      }

      public Comparable sortValue(final ScoreDoc i) {
        return new Long(fieldOrder[i.doc]);
      }

      public int sortType() {
        return SortField.CUSTOM;
      }
    };
  }

   /* (non-Javadoc)
   * @see org.apache.lucene.search.SortComparator#getComparable(java.lang.String)
   */
  protected Comparable getComparable(String termtext) {
    return new Long(this._parser.parseLong(termtext));
  }
  
}
