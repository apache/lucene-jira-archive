package org.apache.lucene.store;

import java.io.IOException;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.store.Lock;
import org.apache.lucene.store.LockFactory;

public class FilterDirectory extends Directory {
        protected Directory in;
        
        public FilterDirectory(Directory in) {
                this.in = in;
        }

        @Override
        public void close() throws IOException {
                this.in.close();
        }

        @Override
        public IndexOutput createOutput(String name) throws IOException {
                return this.in.createOutput(name);
        }

        @Override
        public void deleteFile(String name) throws IOException {
                this.in.deleteFile(name);
        }

        @Override
        public boolean fileExists(String name) throws IOException {
                return this.in.fileExists(name);
        }

        @Override
        public long fileLength(String name) throws IOException {
                return this.in.fileLength(name);
        }

        @Override
        public long fileModified(String name) throws IOException {
                return this.in.fileModified(name);
        }

        @Override
        public String[] list() throws IOException {
                return this.in.list();
        }

        @Override
        public IndexInput openInput(String name) throws IOException {
                return this.in.openInput(name);
        }

        @Override
        public void renameFile(String from, String to) throws IOException {
                this.in.renameFile(from, to);
        }

        @Override
        public void touchFile(String name) throws IOException {
                this.in.touchFile(name);
        }
        
        @Override
        public Lock makeLock(String name) {
      return this.in.makeLock(name);
        }

        @Override
        public void clearLock(String name) throws IOException {
                this.in.clearLock(name);
        }

        @Override
        public void setLockFactory(LockFactory lockFactory) {
                this.in.setLockFactory(lockFactory);
        }

        @Override
        public LockFactory getLockFactory() {
                return this.in.getLockFactory();
        }

        @Override
        public String getLockID() {
                return this.in.getLockID();
        }

        public void sync(String name) throws IOException {
            super.sync(name);
        }
}
