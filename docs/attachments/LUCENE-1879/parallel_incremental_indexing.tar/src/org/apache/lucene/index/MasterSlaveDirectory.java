package org.apache.lucene.index;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FilterDirectory;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.store.Lock;
import org.apache.lucene.store.LockFactory;
import org.apache.lucene.store.NoLockFactory;

public class MasterSlaveDirectory {
    private static boolean isMasterFile(String name) {
        return (name.startsWith(IndexFileNames.SEGMENTS) || name.endsWith("."
                + IndexFileNames.DELETES_EXTENSION));
    }

    public static class Master extends FilterDirectory {
        private List<Directory> slaveDirs = new LinkedList<Directory>();

        public Master(Directory in) {
            super(in);
        }

        public MasterSlaveDirectory.Slave addSlaveDirectory(Directory slave) {
            this.slaveDirs.add(slave);
            return new Slave(this, slave);
        }

        @Override
        public void sync(String name) throws IOException {
            if (this.in.fileExists(name)) {
                this.in.sync(name);
            }
            if (!isMasterFile(name)) {
                for (Directory d : this.slaveDirs) {
                    if (d.fileExists(name)) {
                        d.sync(name);
                    }
                }
            }
        }
        
        @Override
        public void deleteFile(String name) throws IOException {
            if (this.in.fileExists(name)) {
                this.in.deleteFile(name);
            }
            if (!isMasterFile(name)) {
                for (Directory d : this.slaveDirs) {
                    if (d.fileExists(name)) {
                        d.deleteFile(name);
                    }
                }
            }
        }

        @Override
        public String[] list() throws IOException {
            Set<String> s = new HashSet<String>();
            String[] list = this.in.list();
            if (list != null) {
                for (String n : list) {
                    s.add(n);
                }
            }
            for (Directory d : this.slaveDirs) {
                list = d.list();
                if (list != null) {
                    for (String n : list) {
                        s.add(n);
                    }
                }
            }
            return s.toArray(new String[s.size()]);
        }

        
    }

    public static class Slave extends FilterDirectory {
        private Directory masterDir;

        private Slave(Directory masterDir, Directory in) {
            super(in);
            this.masterDir = masterDir;
        }

        @Override
        public IndexOutput createOutput(String name) throws IOException {
            if (isMasterFile(name)) {
                return new DummyIndexOutput();
            }

            return this.in.createOutput(name);
        }

        @Override
        public void sync(String name) throws IOException {
         // do nothing; master handles sync'ing also in the slave dirs
        }
        
        @Override
        public void deleteFile(String name) throws IOException {
            // do nothing; master handles deletions also in the slave dirs
        }

        @Override
        public boolean fileExists(String name) throws IOException {
            return this.in.fileExists(name) || this.masterDir.fileExists(name);
        }

        @Override
        public long fileLength(String name) throws IOException {
            if (isMasterFile(name)) {
                return this.masterDir.fileLength(name);
            } else {
                return this.in.fileLength(name);
            }
        }

        @Override
        public long fileModified(String name) throws IOException {
            if (isMasterFile(name)) {
                return this.masterDir.fileModified(name);
            } else {
                return this.in.fileModified(name);
            }
        }

        @Override
        public String[] list() throws IOException {
            Set<String> s = new HashSet<String>();
            String[] list = this.in.list();
            if (list != null) {
                for (String n : list) {
                    s.add(n);
                }
            }
            list = this.masterDir.list();
            if (list != null) {
                for (String n : list) {
                    s.add(n);
                }
            }
            return s.toArray(new String[s.size()]);
        }

        @Override
        public IndexInput openInput(String name) throws IOException {
            if (isMasterFile(name)) {
                return this.masterDir.openInput(name);
            } else {
                return this.in.openInput(name);
            }
        }

        @SuppressWarnings("deprecation")
        @Override
        public void renameFile(String from, String to) throws IOException {
            if (!isMasterFile(from)) {
                this.in.renameFile(from, to);
            }

        }

        @Override
        public void touchFile(String name) throws IOException {
            if (!isMasterFile(name)) {
                this.in.touchFile(name);
            }
        }

        @Override
        public Lock makeLock(String lockName) {
            return NoLockFactory.getNoLockFactory().makeLock(lockName);
        }
        

        @Override
        public void clearLock(String name) throws IOException {
            // nothing to do
        }

        @Override
        public void setLockFactory(LockFactory lockFactory) {
            // always use NoLockFactory
        }

        @Override
        public LockFactory getLockFactory() {
            return NoLockFactory.getNoLockFactory();
        }
    }

    private static class DummyIndexOutput extends IndexOutput {
        private long length;

        private long pos;

        @Override
        public void close() throws IOException {
            // do nothing
        }

        @Override
        public void flush() throws IOException {
            // do nothing
        }

        @Override
        public long getFilePointer() {
            return 0;
        }

        @Override
        public long length() throws IOException {
            return this.length;
        }

        @Override
        public void seek(long p) throws IOException {
            this.pos = p;
        }

        @Override
        public void writeByte(byte b) throws IOException {
            this.pos++;
            if (this.pos > this.length) {
                this.length = this.pos;
            }
        }

        @Override
        public void writeBytes(byte[] b, int offset, int len)
                throws IOException {
            this.pos += len;
            if (this.pos > this.length) {
                this.length = this.pos;
            }
        }

    }

}
