package org.apache.lucene.index;

import java.io.IOException;


public abstract class IndexSegmentsAccessor {
    public static boolean isMultiSegmentReader(IndexReader reader) {
        return reader instanceof MultiSegmentReader;
    }
    
    public static String getSegmentNameFromSegmentReader(IndexReader reader) {
        return ((SegmentReader) reader).getSegmentName();
    }
    
    public static IndexReader[] getSubReadersFromParallelReader(ParallelReader pReader) {
        return pReader.getSubReaders();
    }
    
    public static IndexReader getInputReaderFromFilterIndexReader(FilterIndexReader fReader) {
        return fReader.in;
    }
    
    public static IndexReader getSubReaderFromMultiSegmentIndexReader(IndexReader reader, int segment) {
        MultiSegmentReader msr = (MultiSegmentReader) reader;
        return msr.getSubReaders()[segment];
    }
    
    public static IndexSegmentsAccessor getAccessor(IndexReader reader) {
        if (reader instanceof SegmentReader) {
            SegmentReader segmentReader = (SegmentReader) reader;
                return new SingleSegmentAccessor(segmentReader, segmentReader.getSegmentName());
        }
        if (reader instanceof MultiSegmentReader) {
                return new MultiSegmentAccessor((MultiSegmentReader) reader);
        }
        return null;
    }


    public abstract int getNumSegments();
    
    public abstract int getMaxDoc(int segment);
    
    public abstract int getNumDocs(int segment);
    
    public abstract int getNumDeletedDocs(int segment);
    
    public abstract IndexReader getSegmentReader(int segment) throws IOException;
    
    public abstract String getSegmentName(int segment);

    public static class SingleSegmentAccessor extends IndexSegmentsAccessor {
        private IndexReader reader;
        private String segmentName;
        
        public SingleSegmentAccessor(IndexReader segmentReader, String segmentName) {
                this.reader = segmentReader;
                this.segmentName = segmentName;
        }
        
        public int getMaxDoc(int segment) {
                return this.reader.maxDoc();
        }

        public int getNumDocs(int segment) {
                return this.reader.numDocs();
        }

        public int getNumSegments() {
                return 1;
        }

        public int getNumDeletedDocs(int segment) {
                return this.reader.numDeletedDocs();
        }

        public IndexReader getSegmentReader(int segment) {
                return this.reader;
        }
        
        public String getSegmentName(int segment) {
            return this.segmentName;
        }
        
        
}

    public static class MultiSegmentAccessor extends IndexSegmentsAccessor {
        private MultiSegmentReader reader;
        
        public MultiSegmentAccessor(IndexReader reader) {
                this.reader = (MultiSegmentReader) reader;
        }
        
        public int getMaxDoc(int segment) {
                return this.reader.subReaders[segment].maxDoc();
        }

        public int getNumDocs(int segment) {
                return this.reader.subReaders[segment].numDocs();
        }

        public int getNumSegments() {
                return this.reader.subReaders.length;
        }

        public int getNumDeletedDocs(int segment) {
                return this.reader.subReaders[segment].numDeletedDocs();
        }
        
        public IndexReader getSegmentReader(int segment) throws IOException {
                return this.reader.subReaders[segment];
        }     
        
        public String getSegmentName(int segment) {
            return this.reader.subReaders[segment].getSegmentName();
        }
    }

}
