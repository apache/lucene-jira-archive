package org.apache.lucene.index;

import java.io.IOException;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.ParallelDirectory;

public class ParallelIndexBuilder {
    private final static String INITIAL_SEGMENT_NAME = "_0";
    
    private Directory targetIndexDir;
    private Directory tempDirectory;
    
    private IndexSegmentsIterator sourceSegmentsIterator;
    private IndexWriter segmentWriter;
    private SegmentInfo curSegment;
    
    private SegmentInfos segmentInfos;
    private Analyzer analyzer;
    private MaxFieldLength maxFieldLength;
    
    private ParallelDirectory parallelDirectory;
    
    
    public ParallelIndexBuilder(Analyzer analyzer, MaxFieldLength mfl, IndexSegmentsIterator sourceSegments, final Directory parallelIndexDir, final Directory tempDirectory) throws IOException {
        this.targetIndexDir = parallelIndexDir;
        this.maxFieldLength = mfl;
        if (tempDirectory.list().length > 0) {
            throw new IllegalArgumentException("Temp directory must be empty.");
        }
        this.tempDirectory = tempDirectory;
        this.sourceSegmentsIterator = sourceSegments;
        if (this.sourceSegmentsIterator.hasNext()) {
            this.curSegment = this.sourceSegmentsIterator.next();
        } else {
            throw new IllegalArgumentException("No segments found.");
        }
        this.analyzer = analyzer;
        ParallelDirectory.DirectorySelector selector = new ParallelDirectory.DirectorySelector() {
            public Directory select(String name) {
                if (name.endsWith("." + IndexFileNames.COMPOUND_FILE_EXTENSION)) {
                    return parallelIndexDir;
                } else {
                    return tempDirectory;
                }
            }                
        };
        
        ParallelDirectory.FileNameAcceptor fileDeleteAcceptor = new ParallelDirectory.FileNameAcceptor() {
            public boolean accept(String name) {
                if (name.endsWith("." + IndexFileNames.COMPOUND_FILE_EXTENSION)) {
                    return false;
                }
                return true;
            }
        };
        
        this.parallelDirectory = new ParallelDirectory(new Directory[] {tempDirectory, parallelIndexDir}, selector);
        this.parallelDirectory.setFileDeleteAcceptor(fileDeleteAcceptor);

        this.segmentInfos = new SegmentInfos();
        openIndexWriter();
    }
    
    private void openIndexWriter() throws IOException {
        this.segmentWriter = new IndexWriter(this.parallelDirectory, this.analyzer, noDeletesPolicy, this.maxFieldLength);
        this.segmentWriter.setUseCompoundFile(false);
    }
    
    private void maybeSwitchSegment() throws IOException {
        int diff = this.segmentWriter.maxDoc() - this.curSegment.docCount;
        if (diff < 0) {
            return;
        }
        
        if (diff > 0) {
            throw new IOException("Too many documents were added before segment could be switched.");
        }
        
        flushSegment();
        switchSegment();
    }

    private void flushSegment() throws IOException {
        this.segmentWriter.close();
        writeCompoundFile();
        clearDirectory(this.tempDirectory);
    }
    
    @SuppressWarnings("unchecked")
    private void switchSegment() throws IOException {
        this.curSegment.dir = this.targetIndexDir;
        this.segmentInfos.add(this.curSegment);
        if (this.sourceSegmentsIterator.hasNext()) {
            this.curSegment = this.sourceSegmentsIterator.next();
            openIndexWriter();
        } else {
            this.curSegment = null;
        }
    }
    
    private void writeCompoundFile() throws IOException {
        final String segmentName = this.curSegment.name;
        
        this.parallelDirectory.setFileNameMapper(new ParallelDirectory.FileNameMapper() {

            public String to(String from) {
               if (!from.endsWith("." + IndexFileNames.COMPOUND_FILE_EXTENSION) && from.startsWith(segmentName)) {
                   return INITIAL_SEGMENT_NAME + from.substring(segmentName.length());
               }
               return from;
            }

            public String from(String to) {
                if (!to.endsWith("." + IndexFileNames.COMPOUND_FILE_EXTENSION) && to.startsWith(INITIAL_SEGMENT_NAME)) {
                    return segmentName + to.substring(2);
                }
                return to;
             }

            
        });
        
//        List<?> segmentFiles = this.curSegment.files();
//        for (int i = 0; i < segmentFiles.size(); i++) {
//            String fileName = (String) segmentFiles.get(i);
//            if (fileName.endsWith("." + IndexFileNames.DELETES_EXTENSION) || fileName.contains(".s")) {
//                ParallelDirectory.copyFile(this.sourceIndexDir, this.targetIndexDir, fileName);
//            }
//        }

        CompoundFileWriter writer = new CompoundFileWriter(this.parallelDirectory, segmentName + "." + IndexFileNames.COMPOUND_FILE_EXTENSION);
        String[] files = this.parallelDirectory.list();
        for (String f : files) {
            if (f.startsWith(segmentName)) {
                writer.addFile(f);
            }
        }
        writer.close();
        this.parallelDirectory.setFileNameMapper(null);
    }
    
    public void addDocument(Document doc) throws CorruptIndexException, IOException {
        this.segmentWriter.addDocument(doc);
        maybeSwitchSegment();
    }

    public void addDocument(Document doc, Analyzer a) throws CorruptIndexException, IOException {
        this.segmentWriter.addDocument(doc, a);
        maybeSwitchSegment();        
    }
    
    public void addIndexNoOptimize(IndexReader reader) throws IOException {
        this.segmentWriter.addIndexes(new IndexReader[] {reader});
        maybeSwitchSegment();
    }
    
//    private void writeSegmentsFile() throws IOException {
//        this.segmentInfos.prepareCommit(this.targetIndexDir);
//        this.segmentInfos.finishCommit(this.targetIndexDir);
//    }
    
    private static void clearDirectory(Directory dir) throws IOException {
        String[] files = dir.list();
        for (String f : files) {
            dir.deleteFile(f);
        }
    }
    
    public void close() throws IOException {
        if (this.curSegment != null) {
            throw new IOException("Parallel index docCount mismatch.");
        }
        //writeSegmentsFile();
    }
    
    public void abort() throws IOException {
        this.segmentWriter.rollback();
    }
    
    @SuppressWarnings("unchecked")
    final static IndexDeletionPolicy noDeletesPolicy = new IndexDeletionPolicy() {
        public void onCommit(List commits) throws IOException {/* do nothing */}
        public void onInit(List commits)   throws IOException {/* do nothing */}
    };
}
