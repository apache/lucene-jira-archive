package org.apache.lucene.index;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MasterSlaveMergePolicy extends FilterLogMergePolicy {
    private Set<SlaveMergePolicy> slaves;

    public MasterSlaveMergePolicy(LogMergePolicy in) {
        super(in);
        this.maxMergeSize = in.maxMergeSize;
        this.minMergeSize = in.minMergeSize;
        this.maxMergeDocs = in.maxMergeDocs;
        this.slaves = new HashSet<SlaveMergePolicy>();
    }

    public MergePolicy addSlavePolicy(MergePolicy s) {
        SlaveMergePolicy slave = new SlaveMergePolicy(s);
        this.slaves.add(slave);
        return slave;
    }

    @Override
    public MergeSpecification findMerges(SegmentInfos segmentInfos,
            IndexWriter writer) throws CorruptIndexException, IOException {
        MergeSpecification spec = super.findMerges(segmentInfos, writer);
        if (spec != null) {
            for (SlaveMergePolicy slave : this.slaves) {
                slave.addMergeSpec(cloneMergeSpec(spec, segmentInfos));
            }
            //System.out.println("Master: " + spec.segString(writer.getDirectory()));
        }

        return spec;
    }

    @Override
    public MergeSpecification findMergesForOptimize(SegmentInfos segmentInfos,
            IndexWriter writer, int maxSegmentCount, @SuppressWarnings("unchecked") Set segmentsToOptimize)
            throws CorruptIndexException, IOException {
        MergeSpecification spec = super.findMergesForOptimize(segmentInfos,
                writer, maxSegmentCount, segmentsToOptimize);
        if (spec != null) {
            for (SlaveMergePolicy slave : this.slaves) {
                slave.addMergeSpecForOptimize(cloneMergeSpec(spec, segmentInfos));
            }
        }
        return spec;

    }

    @Override
    public MergeSpecification findMergesToExpungeDeletes(
            SegmentInfos segmentInfos, IndexWriter writer)
            throws CorruptIndexException, IOException {
        MergeSpecification spec = super.findMergesToExpungeDeletes(
                segmentInfos, writer);
        if (spec != null) {
            for (SlaveMergePolicy slave : this.slaves) {
                slave.addMergeSpecForExpungeDeletes(cloneMergeSpec(spec,
                        segmentInfos));
            }
        }
        return spec;

    }

    private static class SlaveMergePolicy extends FilterMergePolicy {
        private List<MergeSpecification> mergeSpecs = new ArrayList<MergeSpecification>();

        private List<MergeSpecification> mergeSpecsForOptimize = new ArrayList<MergeSpecification>();

        private List<MergeSpecification> mergeSpecsForExpungeDeletes = new ArrayList<MergeSpecification>();

        public SlaveMergePolicy(MergePolicy in) {
            super(in);
        }

        void addMergeSpec(MergeSpecification spec) {
            synchronized (this.mergeSpecs) {
                this.mergeSpecs.add(spec);
            }
        }

        void addMergeSpecForOptimize(MergeSpecification spec) {
            synchronized (this.mergeSpecsForOptimize) {
                this.mergeSpecsForOptimize.add(spec);
            }
        }

        void addMergeSpecForExpungeDeletes(MergeSpecification spec) {
            synchronized (this.mergeSpecsForExpungeDeletes) {
                this.mergeSpecsForExpungeDeletes.add(spec);
            }
        }

        @Override
        MergeSpecification findMerges(SegmentInfos segmentInfos,
                IndexWriter writer) throws CorruptIndexException, IOException {
            MergeSpecification spec = null;
            synchronized (this.mergeSpecs) {
                if (this.mergeSpecs.isEmpty()) {
                    return null;
                }
                spec = this.mergeSpecs.remove(0);
                setSegmentInfos(spec, segmentInfos);
                //System.out.println("Slave: " + spec.segString(writer.getDirectory()));
            }

            return spec;
        }

        @Override
        MergeSpecification findMergesForOptimize(SegmentInfos segmentInfos,
                IndexWriter writer, int maxSegmentCount, @SuppressWarnings("unchecked") Set segmentsToOptimize)
                throws CorruptIndexException, IOException {
            MergeSpecification spec = null;
            synchronized (this.mergeSpecsForOptimize) {
                if (this.mergeSpecsForOptimize.isEmpty()) {
                    return null;
                }
                spec = this.mergeSpecsForOptimize.remove(0);
                setSegmentInfos(spec, segmentInfos);
            }
            return spec;
        }

        @Override
        MergeSpecification findMergesToExpungeDeletes(
                SegmentInfos segmentInfos, IndexWriter writer)
                throws CorruptIndexException, IOException {
            MergeSpecification spec = null;
            synchronized (this.mergeSpecsForExpungeDeletes) {
                if (this.mergeSpecsForExpungeDeletes.isEmpty()) {
                    return null;
                }
                spec = this.mergeSpecsForExpungeDeletes.remove(0);
            }
            setSegmentInfos(spec, segmentInfos);
            return spec;
        }
    }

    private static class ExtendedOneMerge extends OneMerge {
        int[] segmentInfoIndexes;

        public ExtendedOneMerge(int[] segmentInfoIndexes, SegmentInfos infos,
                boolean useCompoundFile) {
            super(infos, useCompoundFile);
            this.segmentInfoIndexes = segmentInfoIndexes;
        }

    }

    @SuppressWarnings("unchecked")
    static MergeSpecification cloneMergeSpec(MergeSpecification spec,
            SegmentInfos infos) {
        if (spec == null) {
            return null;
        }

        Map<SegmentInfo, Integer> infosMap = new HashMap<SegmentInfo, Integer>();
        for (int i = 0; i < infos.size(); i++) {
            SegmentInfo info = (SegmentInfo) infos.get(i);
            infosMap.put(info, i);
        }

        MergeSpecification clone = new MergeSpecification();
        for (int i = 0; i < spec.merges.size(); i++) {
            OneMerge oneMerge = (OneMerge) spec.merges.get(i);
            int[] segmentInfoIndexes = new int[oneMerge.segments.size()];
            for (int j = 0; j < segmentInfoIndexes.length; j++) {
                segmentInfoIndexes[j] = infosMap.get(oneMerge.segments.get(j));
            }
            OneMerge oneMergeClone = new ExtendedOneMerge(segmentInfoIndexes,
                    shallowClone(oneMerge.segments), oneMerge.useCompoundFile);
            clone.merges.add(oneMergeClone);
        }

        return clone;
    }

    @SuppressWarnings("unchecked")
    static SegmentInfos shallowClone(SegmentInfos infos) {
        SegmentInfos clone = new SegmentInfos();
        clone.addAll(infos);
        return clone;
    }

    @SuppressWarnings("unchecked")
    static void setSegmentInfos(MergeSpecification spec, SegmentInfos infos) {
        for (int i = 0; i < spec.merges.size(); i++) {
            ExtendedOneMerge oneMerge = (ExtendedOneMerge) spec.merges.get(i);
            SegmentInfos mergeInfos = oneMerge.segments;
            SegmentInfos masterInfos = (SegmentInfos) mergeInfos.clone();
            mergeInfos.clear();
            for (int j = 0; j < oneMerge.segmentInfoIndexes.length; j++) {
                SegmentInfo slaveInfo = (SegmentInfo) infos.get(oneMerge.segmentInfoIndexes[j]);
                SegmentInfo masterInfo = (SegmentInfo) masterInfos.get(mergeInfos.size());
                masterInfo.dir = slaveInfo.dir;

                mergeInfos.add(masterInfo);
            }
        }
    }

}
