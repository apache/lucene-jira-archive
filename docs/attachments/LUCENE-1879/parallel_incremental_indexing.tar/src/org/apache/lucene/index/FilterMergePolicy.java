package org.apache.lucene.index;

import java.io.IOException;
import java.util.Set;

public class FilterMergePolicy extends MergePolicy {
    private MergePolicy mergePolicy;

    public FilterMergePolicy(MergePolicy in) {
        this.mergePolicy = in;
    }

    void close() {
        this.mergePolicy.close();
    }

    MergeSpecification findMerges(SegmentInfos segmentInfos, IndexWriter writer)
            throws CorruptIndexException, IOException {
        return this.mergePolicy.findMerges(segmentInfos, writer);
    }

    MergeSpecification findMergesForOptimize(SegmentInfos segmentInfos,
            IndexWriter writer, int maxSegmentCount, @SuppressWarnings("unchecked") Set segmentsToOptimize)
            throws CorruptIndexException, IOException {
        return this.mergePolicy.findMergesForOptimize(segmentInfos, writer,
                maxSegmentCount, segmentsToOptimize);
    }

    MergeSpecification findMergesToExpungeDeletes(SegmentInfos segmentInfos,
            IndexWriter writer) throws CorruptIndexException, IOException {
        return this.mergePolicy.findMergesToExpungeDeletes(segmentInfos, writer);
    }

    boolean useCompoundDocStore(SegmentInfos segments) {
        return this.mergePolicy.useCompoundDocStore(segments);
    }

    boolean useCompoundFile(SegmentInfos segments, SegmentInfo newSegment) {
        return this.mergePolicy.useCompoundFile(segments, newSegment);
    }

}
