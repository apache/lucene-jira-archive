package org.apache.lucene.index;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.lucene.store.Directory;

public class IndexSegmentsIterator implements Iterator<SegmentInfo> {
    private Iterator<SegmentInfo> it;
    
    public IndexSegmentsIterator(final Directory dir) throws IOException {
        final List<SegmentInfo> list = new LinkedList<SegmentInfo>();
        new SegmentInfos.FindSegmentsFile(dir) {
            @Override
            protected Object doBody(String segmentFileName) throws CorruptIndexException,
                    IOException {
                SegmentInfos infos = new SegmentInfos();
                infos.read(dir, segmentFileName);
                for (int i = 0; i < infos.size(); i++) {
                    list.add((SegmentInfo)((SegmentInfo) infos.get(i)).clone());
                }
                return null;
            }
            
        }.run();
        
        this.it = list.iterator();
    }
    
    public boolean hasNext() {
        return this.it.hasNext();
    }

    public SegmentInfo next() {
        return this.it.next();
    }

    public void remove() {
        throw new UnsupportedOperationException("Remove not supported.");
        
    }

}
