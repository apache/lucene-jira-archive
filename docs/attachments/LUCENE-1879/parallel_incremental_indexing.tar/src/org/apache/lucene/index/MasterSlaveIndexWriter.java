package org.apache.lucene.index;

import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.Directory;

public class MasterSlaveIndexWriter extends IndexWriter {
        public interface FlushListener {
                public void flush(LastSegmentReaderProvider lastSegmentReaderProvider, IndexWriter slaveIndexWriter, String segmentName) throws IOException;
        }
        
        public static final class LastSegmentReaderProvider {
            private Map<Directory, IndexReader> lastSegmentReaders = new HashMap<Directory, IndexReader>();
            private SegmentInfo lastSegmentInfo;
            
            private LastSegmentReaderProvider(SegmentInfo lastSegmentInfo) throws IOException {
                this.lastSegmentReaders = new HashMap<Directory, IndexReader>();
                this.lastSegmentInfo = lastSegmentInfo;
                this.lastSegmentReaders.put(lastSegmentInfo.dir, SegmentReader.get(true, null, this.lastSegmentInfo, false));
            }
            
            public IndexReader getLastMasterSegmentReader() throws IOException {
                return this.lastSegmentReaders.get(this.lastSegmentInfo.dir);
            }
            
            public IndexReader getLastSegmentReader(Directory dir) throws IOException {
                IndexReader lastSegmentReader = this.lastSegmentReaders.get(dir);
                if (lastSegmentReader == null) {
                    SegmentInfo cloneInfo = (SegmentInfo) this.lastSegmentInfo.clone();
                    cloneInfo.dir = dir;
                    lastSegmentReader = SegmentReader.get(true, null, cloneInfo, false);
                    this.lastSegmentReaders.put(dir, lastSegmentReader);
                }
                return lastSegmentReader;
            }
            
            private void close() throws IOException {
                for (IndexReader r : this.lastSegmentReaders.values()) {
                    r.close();
                }
                
                this.lastSegmentReaders.clear();
            }
        }
        
        static class Slave {
                IndexWriter slaveIndexWriter;
                FlushListener listener;
                
                Slave(IndexWriter slaveIndexWriter, FlushListener listener) {
                        this.slaveIndexWriter = slaveIndexWriter;
                        this.listener = listener;
                }
                
                void flush(LastSegmentReaderProvider lastSegmentReaderProvider, String segmentName) throws IOException {
                    if (this.listener != null) {
                        this.listener.flush(lastSegmentReaderProvider, this.slaveIndexWriter, segmentName);
                    }
                    this.slaveIndexWriter.flush(false, true, false);
                }
        }
        
        private List<Slave> slaves;
        private MasterSlaveMergePolicy masterMergePolicy;
        private double maxRAMSizeBytes;
        private boolean inRollback;
        
        public MasterSlaveIndexWriter(Directory dir, Analyzer analyzer, boolean create, 
                        IndexDeletionPolicy deletionPolicy, MaxFieldLength mfl) throws IOException {
                super(dir, analyzer, create, deletionPolicy, mfl);
                super.setRAMBufferSizeMB(Double.MAX_VALUE);
                this.inRollback = false;
                this.slaves = new LinkedList<Slave>();
                this.masterMergePolicy = new MasterSlaveMergePolicy((LogMergePolicy) super.getMergePolicy());
                super.setMergePolicy(this.masterMergePolicy);
                
                final List<Slave> slaveList = this.slaves;
                super.setMergeScheduler(new MergeScheduler() {

                        @Override
                        void close() throws CorruptIndexException, IOException {
                                // nothing to do
                        }

                        @Override
                        void merge(IndexWriter writer) throws CorruptIndexException,
                                        IOException {
                            while(true) {
                                MergePolicy.OneMerge merge = writer.getNextMerge();
                                if (merge == null)
                                  break;
                                writer.mergeInit(merge);
                                for (Slave s : slaveList) {
                                        s.slaveIndexWriter.maybeMerge();
                                }
                                
                                writer.merge(merge);
                              }
                        }
                        
                });
                if (super.maxDoc() > 0) {
                    this.lastFlushedSegmentInfo = super.newestSegment();
                }
        }
        


    @Override
    public void setMergeScheduler(MergeScheduler mergeScheduler) throws IOException {
            throw new UnsupportedOperationException("Can't be changed for this writer.");
    }
        
    @Override
    public void setMergePolicy(MergePolicy mp) {
                throw new UnsupportedOperationException("Can't be changed for this writer.");
    }
    
    @Override
    public void setMaxBufferedDocs(int maxBufferedDocs) {
        throw new UnsupportedOperationException("This writer only supports flush by RAM size.");
    }
        
    @Override
    public void setMaxBufferedDeleteTerms(int maxBufferedDeletes) {
        throw new UnsupportedOperationException("This writer only supports flush by RAM size.");
    }

    @Override
    public void setRAMBufferSizeMB(double mb) {
        this.maxRAMSizeBytes = mb * 1024 * 1024;
    }
    
    @Override
    public void addDocument(Document doc, Analyzer a) throws IOException {
        maybeFlush();
        super.addDocument(doc, a);
    }

    @Override
    public void updateDocument(Term term, Document doc, Analyzer a) throws IOException {
        maybeFlush();
        super.updateDocument(term, doc, a);
    }
    
    @Override
    public void deleteDocuments(Term term) throws CorruptIndexException, IOException {
        maybeFlush();
        super.deleteDocuments(term);
    }

    @Override
    public void deleteDocuments(Term[] terms) throws CorruptIndexException, IOException {
        maybeFlush();
        super.deleteDocuments(terms);
    }

    @Override
    public void deleteDocuments(Query query) throws CorruptIndexException, IOException {
        maybeFlush();
        super.deleteDocuments(query);
    }

    @Override
    public void deleteDocuments(Query[] queries) throws CorruptIndexException, IOException {
        maybeFlush();
        super.deleteDocuments(queries);
    }
    
    @SuppressWarnings("deprecation")
    @Override
    public void addIndexes(Directory[] dirs) throws IOException {
        throw new UnsupportedOperationException("Not supported.");
    }
    
    @Override
    public void addIndexes(IndexReader[] readers) throws IOException {
        throw new UnsupportedOperationException("Not supported.");
    }
    
    @Override
    public void expungeDeletes(boolean doWait) {
        throw new UnsupportedOperationException("Not supported.");
    }
    
    @Override
    public void optimize(int maxNumSegments, boolean doWait) throws IOException {
        throw new UnsupportedOperationException("Not supported.");
        }
    
    private void maybeFlush() throws IOException {
        if (ramSizeInBytes() > this.maxRAMSizeBytes) {
                flush(true, true, false);
                checkConsistency();
        }
    }
        
    public void addSlaveIndexWriter(IndexWriter slaveIndexWriter) throws IOException {
        addSlaveIndexWriter(slaveIndexWriter, null);
    }
    
    public void addSlaveIndexWriter(IndexWriter slaveIndexWriter, FlushListener listener) throws IOException {
            slaveIndexWriter.setMergePolicy(this.masterMergePolicy.addSlavePolicy(slaveIndexWriter.getMergePolicy()));
            slaveIndexWriter.setMaxBufferedDocs(Integer.MAX_VALUE);
            slaveIndexWriter.setMaxBufferedDeleteTerms(Integer.MAX_VALUE);
            slaveIndexWriter.setMergeScheduler(new SerialMergeScheduler());

            this.slaves.add(new Slave(slaveIndexWriter, listener));
    }
    
    private SegmentInfo lastFlushedSegmentInfo = null; 
    
    @Override
    void doAfterFlush() throws IOException {
        if (!this.inRollback && !this.slaves.isEmpty() && maxDoc() > 0) {
            SegmentInfo segmentToFlush = this.newestSegment();
            if (this.lastFlushedSegmentInfo != segmentToFlush) {
                            // open SegmentReader on last segment
                    LastSegmentReaderProvider lastSegmentReaderProvider = new LastSegmentReaderProvider(segmentToFlush);
                    
                    // now call all slaves so that they can build their indexes
                    for (Slave s : this.slaves) {
                            s.flush(lastSegmentReaderProvider, segmentToFlush.name);
                    }
                    lastSegmentReaderProvider.close();
                    this.lastFlushedSegmentInfo = segmentToFlush;
            }               
        }
    }
    
    private void checkConsistency() throws CorruptIndexException {
        int maxDoc = maxDoc();
        for (Slave slave : this.slaves) {
            if (maxDoc != slave.slaveIndexWriter.maxDoc()) {
                throw new CorruptIndexException("The parallel index is out of sync.");
            }
        }
    }
    
    @Override
    public void rollback() throws IOException {
        for (Slave s : this.slaves) {
            s.slaveIndexWriter.rollback();
        }
        this.inRollback = true;  // prevent doAfterFlush code being executed
        try {
            super.rollback();
        } finally {
            this.inRollback = false;
        }
    }

    @Override
    public void close(boolean waitForMerges) throws IOException {
        // We need to call close on the master first, because this triggers a flush in all slaves.
        super.close(waitForMerges);
        
        // It is save to close the slaves later, because the close will not flush anything.
        try {
            for (Slave s : this.slaves) {
                s.slaveIndexWriter.close();
            }
        } catch (Throwable t) {
            t.printStackTrace();
            // ignore this exception; the master close() call has taken care of any pending flushes and
            // merges
        }
    }
    
}
