package org.apache.lucene.index;

import java.io.IOException;

public class FilterLogMergePolicy extends LogMergePolicy {
    private LogMergePolicy logMergePolicy;

    public FilterLogMergePolicy(LogMergePolicy in) {
        this.logMergePolicy = in;
    }

    @Override
    protected long size(SegmentInfo info) throws IOException {
        return this.logMergePolicy.size(info);
    }

}
