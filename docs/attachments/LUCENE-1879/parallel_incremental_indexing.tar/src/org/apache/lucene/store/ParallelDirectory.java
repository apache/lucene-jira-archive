package org.apache.lucene.store;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ParallelDirectory extends Directory {
    public static interface DirectorySelector {
        public Directory select(String name);
    }
    
    public static interface FileNameMapper {
        public String to(String from);
        public String from(String to);
    }
    
    public static interface FileNameAcceptor {
        public boolean accept(String name);
    }
    
    private Directory[] directories;
    private DirectorySelector selector;
    private FileNameMapper mapper;
    private FileNameAcceptor fileDeleteAcceptor;
    
    public ParallelDirectory(Directory[] dirs, DirectorySelector selector) {
        this.directories = dirs;
        this.selector = selector;
    }
    
    public void setFileNameMapper(FileNameMapper mapper) {
        this.mapper = mapper;
    }
    
    public void setFileDeleteAcceptor(FileNameAcceptor fileDeleteAcceptor) {
        this.fileDeleteAcceptor = fileDeleteAcceptor;
    }
    
    public Lock makeLock(String name) {
        return this.directories[0].getLockFactory().makeLock(name);
    }

    public void clearLock(String name) throws IOException {
        LockFactory f = this.directories[0].getLockFactory();
        if (f != null) {
            f.clearLock(name);
        }
    }
    
    public void setInMemoryFileAcceptor(DirectorySelector s) {
        this.selector = s;
    }
    
    private int getDirectoryIndex(String name, boolean throwFileNotFoundException) throws IOException {
        for (int i = 0; i < this.directories.length; i++) {
            if (this.directories[i].fileExists(name)) {
                return i;
            }
        }
        
        if (throwFileNotFoundException) {
            throw new FileNotFoundException(name);
        }
        return -1;
    }

    public IndexInput openInput(String name) throws IOException {
        if (this.mapper != null) {
            name = this.mapper.to(name);
        }
        return this.directories[getDirectoryIndex(name, true)].openInput(name);
    }

    public IndexOutput createOutput(String name) throws IOException {
        if (this.mapper != null) {
            name = this.mapper.to(name);
        }
        return this.selector.select(name).createOutput(name);
    }
    
    public void touchFile(String name) throws IOException {
        if (this.mapper != null) {
            name = this.mapper.to(name);
        }
        this.selector.select(name).touchFile(name);
    }

    public void close() throws IOException {
        for (int i = 0; i < this.directories.length; i++) {
            this.directories[i].close();
        }
    }
    
    public void deleteFile(String name) throws IOException {
        if (this.mapper != null) {
            name = this.mapper.to(name);
        }
        if (this.fileDeleteAcceptor != null 
                && !this.fileDeleteAcceptor.accept(name)) {
            return;
        }
        this.directories[getDirectoryIndex(name, true)].deleteFile(name);
    }

    public boolean fileExists(String name) throws IOException {
        if (this.mapper != null) {
            name = this.mapper.to(name);
        }
        return getDirectoryIndex(name, false) != -1;
    }

    public long fileLength(String name) throws IOException {
        if (this.mapper != null) {
            name = this.mapper.to(name);
        }
        return this.directories[getDirectoryIndex(name, true)].fileLength(name);
    }

    public long fileModified(String name) throws IOException {
        if (this.mapper != null) {
            name = this.mapper.to(name);
        }
        return this.directories[getDirectoryIndex(name, true)].fileModified(name);
    }


    public String[] list() throws IOException {
        List<String> names = new ArrayList<String>();
        for (int i = 0; i < this.directories.length; i++) {
            String[] l = this.directories[i].list();
            if (this.mapper != null) {
                for (int j = 0; j < l.length; j++) {
                    names.add(this.mapper.from(l[j]));
                }
                
            } else {
                for (int j = 0; j < l.length; j++) {
                    names.add(l[j]);
                }
            }
        }
        return names.toArray(new String[names.size()]);
    }
    
    public void renameFile(String from, String to) throws IOException {
        if (this.mapper != null) {
            from = this.mapper.to(from);
            to = this.mapper.to(to);
        }
        this.directories[getDirectoryIndex(from, true)].renameFile(from, to);
    }

    public static void copyFile(Directory src, Directory dest, String fileName) throws IOException {
        byte[] buf = new byte[BufferedIndexOutput.BUFFER_SIZE];
        IndexOutput os = null;
        IndexInput is = null;
        try {
          // create file in dest directory
          os = dest.createOutput(fileName);
          // read current file
          is = src.openInput(fileName);
          // and copy to dest directory
          long len = is.length();
          long readCount = 0;
          while (readCount < len) {
            int toRead = readCount + BufferedIndexOutput.BUFFER_SIZE > len ? (int)(len - readCount) : BufferedIndexOutput.BUFFER_SIZE;
            is.readBytes(buf, 0, toRead);
            os.writeBytes(buf, toRead);
            readCount += toRead;
          }
        } finally {
          // graceful cleanup
          try {
            if (os != null)
              os.close();
          } finally {
            if (is != null)
              is.close();
          }
        }
    }

}
