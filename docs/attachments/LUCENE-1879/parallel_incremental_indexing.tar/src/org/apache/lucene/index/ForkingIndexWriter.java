package org.apache.lucene.index;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Fieldable;
import org.apache.lucene.store.Directory;

public class ForkingIndexWriter extends IndexWriter {
    
    public static abstract class IndexSelector {
        public Document getDocumentForIndex(String targetIndexName, Document baseDocument) {
            Document d = new Document();
            Iterator<?> fieldsIterator = baseDocument.getFields().iterator();
            while (fieldsIterator.hasNext()) {
                Fieldable field = (Fieldable) fieldsIterator.next();
                if (this.getIndexNameForField(field).equals(targetIndexName)) {
                    d.add(field);
                }
            }
            return d;
        }
        
        public abstract String getIndexNameForField(Fieldable field);
    }
    
    private Map<String, IndexWriter> writers;
    private String masterIndexName;
    private IndexSelector indexSelector;
    
    public ForkingIndexWriter(Directory dir, Analyzer analyzer, boolean create, 
            IndexDeletionPolicy deletionPolicy, MaxFieldLength mfl,
    		IndexSelector indexSelector, String masterIndexName) throws IOException {
    	super(dir, analyzer, create, deletionPolicy, mfl);
        this.writers = new LinkedHashMap<String, IndexWriter>();
        this.masterIndexName = masterIndexName;
        this.indexSelector = indexSelector;
    }
    
    public void addIndexWriter(String indexName, IndexWriter writer) {
        this.writers.put(indexName, writer);
    }

    public void addDocument(Document doc, Analyzer a) throws IOException {
        Throwable firstException = null;

        int maxDoc = super.maxDoc();
        
        try {
            super.addDocument(this.indexSelector.getDocumentForIndex(this.masterIndexName, doc), a);
        } catch (CorruptIndexException cie) {
            throw cie;
        } catch (Throwable e) {
            // check if the max doc id changed; if yes, then lucene added this document
            // partially and marked it as deleted
            if (super.maxDoc() == maxDoc) {
                // max doc id did not change, so we can just throw this IOException to the caller
                throwThrowable(e);
            }
            
            // we have to try to also increase the max doc id of the parallel indexes to keep them in sync,
            // so we have to keep going
            firstException = e;
        }

        // update the now valid max doc id
        maxDoc = super.maxDoc();
        
        try {
            addDocumentToParallelIndexes(doc, a, maxDoc);
        } catch (CorruptIndexException cie) {
            throw cie;
        } catch (Throwable e) {
            if (firstException == null) {
                firstException = e;
            }
        }
        
        
        if (firstException != null) {
            throwThrowable(firstException);
        }
    }
    
    public void updateDocument(Term term, Document doc, Analyzer a)
            throws IOException {
        Throwable firstException = null;
        int maxDoc = super.maxDoc();
        
        try {
            super.updateDocument(term, this.indexSelector.getDocumentForIndex(this.masterIndexName, doc), a);
        } catch (CorruptIndexException cie) {
            throw cie;
        } catch (Throwable e) {
            // check if the max doc id changed; if yes, then lucene added this document
            // partially and marked it as deleted
            if (super.maxDoc() == maxDoc) {
                // max doc id did not change, so we can just throw this IOException to the caller
                throwThrowable(e);
            }
            
            // we have to try to also increase the max doc id of the parallel indexes to keep them in sync,
            // so we have to keep going
            firstException = e;
        }

        // update the now valid max doc id
        maxDoc = super.maxDoc();
        
        try {
            addDocumentToParallelIndexes(doc, a, maxDoc);
        } catch (CorruptIndexException cie) {
            throw cie;
        } catch (Throwable e) {
            if (firstException == null) {
                firstException = e;
            }
        }
        
        if (firstException != null) {
            throwThrowable(firstException);
        }
    }
    
    private void addDocumentToParallelIndexes(Document doc, Analyzer a, int masterMaxDocAfterAdd) throws IOException {
        Throwable firstException = null;
        
        for (Entry<String, IndexWriter> entry : this.writers.entrySet()) {
            IndexWriter w = entry.getValue();
            try {
                w.addDocument(this.indexSelector.getDocumentForIndex(entry.getKey(), doc), a);
            } catch (CorruptIndexException cie) {
                throw cie;
            } catch (Throwable e) {
                if (w.maxDoc() != masterMaxDocAfterAdd) {
                    // if we're here, then something went wrong and the indexes are out of sync;
                    // so we throw an exception indicating that the index is corrupted, which will
                    // cause a rollback
                    throw new CorruptIndexException(e.getMessage());
                }
                if (firstException == null) {
                    // even though we saw an error here we the parallel indexes are still in sync in terms of 
                    // doc ids. So we keep going and throw the first exception we encountered at the end of this call
                    firstException = e;
                }
            }
        }
        
        if (firstException != null) {
            throwThrowable(firstException);
        }

    }

    private void throwThrowable(Throwable t) throws IOException {
        if (t instanceof IOException) {
            throw (IOException) t;
        }
        if (t instanceof RuntimeException) {
            throw (RuntimeException) t;
        }
        if (t instanceof Error) {
            throw (Error) t;
        }
        
        throw new RuntimeException(t);
    }
}
