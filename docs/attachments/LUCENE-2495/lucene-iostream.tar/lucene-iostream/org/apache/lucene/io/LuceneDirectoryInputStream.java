package org.apache.lucene.io;

import java.io.IOException;
import java.io.InputStream;

import org.apache.lucene.store.IndexInput;

public class LuceneDirectoryInputStream extends InputStream {
	private IndexInput _indexInput;
	private long _available;
	
	public LuceneDirectoryInputStream(IndexInput indexInput){
		_indexInput = indexInput;
		_available = indexInput.length();
	}
	
	@Override
	public int available() throws IOException {
		return (int)_available;
	}

	@Override
	public int read() throws IOException {
		_available--;
		return _indexInput.readByte();
	}

	@Override
	public synchronized void reset() throws IOException {
		_indexInput.seek(0L);
		_available = _indexInput.length();
	}

	@Override
	public int read(byte[] b, int off, int len) throws IOException {
		if (len>_available){
			len = (int)_available;
		}
		_available -= len;
		_indexInput.readBytes(b, off, len);
		return len;
	}

	@Override
	public void close() throws IOException {
		_indexInput.close();
	}

	@Override
	public boolean markSupported() {
		return false;
	}
}
