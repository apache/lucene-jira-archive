package org.apache.lucene.io;

import java.io.IOException;
import java.io.OutputStream;

import org.apache.lucene.store.IndexOutput;

public class LuceneDirectoryOutputStream extends OutputStream {

	private final IndexOutput _idxOutput;
	
	public LuceneDirectoryOutputStream(IndexOutput idxOutput){
		_idxOutput = idxOutput;
	}
	
	@Override
	public void write(int b) throws IOException {
		_idxOutput.writeByte((byte)b);
	}

	@Override
	public void close() throws IOException {
		_idxOutput.close();
	}

	@Override
	public void flush() throws IOException {
		_idxOutput.flush();
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		_idxOutput.writeBytes(b, off, len);
	}

	@Override
	public void write(byte[] b) throws IOException {
		_idxOutput.writeBytes(b, b.length);
	}	
}
