package org.apache.lucene.search;

import java.io.IOException;
import java.util.Date;
import java.util.Set;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermEnum;
import org.apache.lucene.store.FSDirectory;

/**
 * Example of creating a fuzzy index based upon another index.
 * @author robertm
 *
 */
public class FuzzyIndexer {

	/**
	 * Create a fuzzy index based on the values in the provided field in the provided index
	 * @param indexDirectory index to read values from
	 * @param field specific field containing the values to be indexed
	 * @return
	 * @throws CorruptIndexException
	 * @throws IOException
	 */
	static int createIndex(String indexDirectory, String field) throws CorruptIndexException, IOException {
		IndexReader index = IndexReader.open(FSDirectory.getDirectory(indexDirectory), true);
		Analyzer analyzer = new WhitespaceAnalyzer();
		IndexWriter writer = new IndexWriter(FSDirectory.getDirectory(indexDirectory + "/fuzzy"), analyzer, IndexWriter.MaxFieldLength.LIMITED);
		writer.setUseCompoundFile(false);

		Document doc = null;
		Field termField = null;
		Field neighborhoodField = null;

		// just a running count of the terms that were indexed
		int termCount = 0;
		// complete list of terms from source index
		TermEnum termEnum = index.terms();

		// iterate the complete list
		while (termEnum.next()) {
			Term term = termEnum.term();
			// only index the provided field
			if (term.field().equals(field)) {
				String value = term.text();
				// form a deletion neighborhood of deletions
				Set<String> deletions = FastSSwC.getNeighborhoodSet(value);
				String nbString = FastSSwC.getNeighborhoodString(deletions);

				// ok this is the first doc, must create document and field objects
				if (doc == null) {
					doc = new Document();
					// we don't need to search on this field, only retrieve it
					termField = new Field("term", value, Field.Store.YES, Field.Index.NO);
					// dont need Norms or TF
					termField.setOmitNorms(true);
					termField.setOmitTf(true);
					// don't need to retrieve this field, only search on it
					neighborhoodField = new Field("nb", nbString, Field.Store.NO, Field.Index.ANALYZED_NO_NORMS);
					// again don't need Norms or TF
					neighborhoodField.setOmitNorms(true);
					neighborhoodField.setOmitTf(true);
					doc.add(termField);
					doc.add(neighborhoodField);					

				} else {
					// not the first document, reuse existing document and field objects, simply replace the value
					termField.setValue(value);
					neighborhoodField.setValue(nbString);						
				}
				// add the document to the index
				writer.addDocument(doc);
				termCount++;
			}
		}


		// optimize and close the index
		writer.optimize();
		writer.close();
		termEnum.close();
		index.close();

		return termCount;
	}


	public static void main(String args[]) throws Exception {

		if (args.length < 2) {
			System.err.println("FuzzyIndexer <indexDirectory> <fieldToIndex>");
			System.exit(1);
		}

		Date d1 = new Date();

		int termCount = createIndex(args[0], args[1]);

		System.out.println("terms indexed: " + termCount);
		long diff = new Date().getTime() - d1.getTime();
		System.out.println("time: " + (diff / 1000));

	}
}

