package org.apache.lucene.search;

import java.util.HashSet;
import java.util.Set;

/**
 * This class implements the FastSSwC algorithm (http://fastss.csg.uzh.ch/ifi-2007.02.pdf).
 * This is FastSS with candidates with an edit distance of 1.
 * It can be shown that all words with an edit distance <= 1 will be returned by this method.
 * However, some words with an edit distance of 2 will also be returned, because delete positions are not stored.
 * Therefore, results must be verified by dynamic programming.
 *
 */
public class FastSSwC {
	
	/**
	 * Generate deletion neighborhood (K=1) for term
	 * @param set Input deletion neighborhood
	 * @return String containing deletion neighborhood, space-separated.
	 */
	public static String getNeighborhoodString(Set<String> set) {
		StringBuilder text = new StringBuilder();
		
		for (String w : set) {
			text.append(w);
			text.append(' ');
		}
		
		return text.toString().trim();
	}
	
	/**
	 * Generate deletion neighborhood (K=1) for term
	 * @param term Input Term
	 * @return Set containing deletion neighborhood for term
	 */
	public static Set<String> getNeighborhoodSet(String term) {
		HashSet<String> neighborhood = new HashSet<String>();
		neighborhood.add(term);
		
		for (int i = 0; i < term.length(); i++) 
			neighborhood.add(term.substring(0, i) + term.substring(i+1));
		
		return neighborhood;
	}
	
}
