package org.apache.lucene.search;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.HitCollector;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.FuzzyQuery.ScoreTerm;

/**
 * A Hit collector for fast fuzzy searches.
 * this verifies the candidates returned by fastssWC.
 * 
 * @author robertm
 *
 */
class FuzzyHitCollector extends HitCollector {
	protected Term queryTerm;
	protected IndexSearcher searcher;
	protected float minimumSimilarity;
	protected List<ScoreTerm> termList;
	
	FuzzyHitCollector(Term queryTerm, IndexSearcher searcher, float minimumSimilarity) {
		this.queryTerm = queryTerm;
		this.searcher = searcher;
		this.minimumSimilarity = minimumSimilarity;
		this.termList = new ArrayList<ScoreTerm>();
	}
	
	@Override
	public void collect(int doc, float score) {
		Document d;
		try {
			d = searcher.doc(doc);
			String candidate = d.getField("term").stringValue();
			String queryTermText = queryTerm.text();
			int distance = StringUtils.getLevenshteinDistance(queryTermText, candidate);
			float maxLen = candidate.length();
        	if (maxLen < queryTermText.length()) {
            	maxLen = queryTermText.length();
        	}	
			float normalizedScore = 1.0f - ((float)distance / maxLen);
			if (normalizedScore <= minimumSimilarity) {
				termList.add(new ScoreTerm(new Term(queryTerm.field(), candidate), normalizedScore));
			}
	        	
		} catch (CorruptIndexException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	public List<ScoreTerm> getTermList() {
		return termList;
	}

}
