package org.apache.lucene.search;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.FuzzyQuery.ScoreTerm;
import org.apache.lucene.util.ToStringUtils;


/**
 * A fast Fuzzy query that uses FastSSwC algorithm
 *
 */
public final class FastFuzzyQuery extends Query {
	private static final long serialVersionUID = 1L;

	protected Term term;
	protected IndexSearcher searcher;

	/**
	 * Default minimum similarity for fuzzy searches.
	 */
	public final static float defaultMinSimilarity = 0.5f; 
	private float minimumSimilarity;

	/**
	 * Create a FastFuzzyQuery 
	 * @param term Term to expand
	 * @param searcher IndexSearcher for the fuzzy index to expand queries against
	 */
	public FastFuzzyQuery(Term term, IndexSearcher searcher) {
		this(term, defaultMinSimilarity, searcher);
	}

	/**
	 * Create a FastFuzzy Query
	 * @param term term to expand
	 * @param minimumSimilarity minimum similarity required for a match
	 * @param searcher IndexSearcher for the fuzzy index to expand terms against
	 * @throws IllegalArgumentException
	 */
	public FastFuzzyQuery(Term term, float minimumSimilarity, IndexSearcher searcher) throws IllegalArgumentException {

		if (minimumSimilarity >= 1.0f)
			throw new IllegalArgumentException("minimumSimilarity >= 1");
		else if (minimumSimilarity < 0.0f)
			throw new IllegalArgumentException("minimumSimilarity < 0");

		this.term = term;
		this.minimumSimilarity = minimumSimilarity;
		this.searcher = searcher;
	}

	/**
	 * Returns the minimum similarity that is required for this query to match.
	 * @return float value between 0.0 and 1.0
	 */
	public float getMinSimilarity() {
		return minimumSimilarity;
	}


	/* (non-Javadoc)
	 * @see org.apache.lucene.search.Query#rewrite(org.apache.lucene.index.IndexReader)
	 */
	public Query rewrite(IndexReader reader) throws IOException {
		BooleanQuery query = new BooleanQuery(false);
		List<ScoreTerm> scoreTermList = expandTerm(term, minimumSimilarity);
		for(ScoreTerm t : scoreTermList){
			TermQuery tq = new TermQuery(t.term);      // found a match
			tq.setBoost(getBoost() * t.score); // set the boost
			query.add(tq, BooleanClause.Occur.SHOULD);          // add to query
		}
		return query;
	}

	/**
	 * Expand a term against the fuzzy index
	 * @param t Term to expand
	 * @return List of Terms with their associated scores (weights)
	 * @throws IOException
	 */
	public List<ScoreTerm> expandTerm(Term t, float minimumSimilarity) throws IOException {

		Query query = buildFastFilter(t.text());
		FuzzyHitCollector collector = new FuzzyHitCollector(t, searcher, minimumSimilarity);
		searcher.search(query, collector);
		return collector.getTermList();
	}

	/**
	 * Build a query to get a candidate list of terms
	 * @param term
	 * @return
	 */
	protected Query buildFastFilter(String term) {
		BooleanQuery query = new BooleanQuery();
		Set<String> neighborhood = FastSSwC.getNeighborhoodSet(term);
		Term base = new Term("nb");
		for (String w : neighborhood)
			query.add(new BooleanClause(new TermQuery(base.createTerm(w)), BooleanClause.Occur.SHOULD));
		return query;
	}

	/* (non-Javadoc)
	 * @see org.apache.lucene.search.Query#toString(java.lang.String)
	 */
	public String toString(String field) {
		StringBuffer buffer = new StringBuffer();
		if (!term.field().equals(field)) {
			buffer.append(term.field());
			buffer.append(":");
		}
		buffer.append(term.text());
		buffer.append('~');
		buffer.append(Float.toString(minimumSimilarity));
		buffer.append(ToStringUtils.boost(getBoost()));
		return buffer.toString();
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof FastFuzzyQuery)) return false;

		final FastFuzzyQuery fuzzyQuery = (FastFuzzyQuery) o;
		if (term != fuzzyQuery.term) return false;
		if (minimumSimilarity != fuzzyQuery.minimumSimilarity) return false;

		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	public int hashCode() {
		int result = term.hashCode() + Float.floatToRawIntBits(getBoost());
		result = 29 * result + minimumSimilarity != +0.0f ? Float.floatToIntBits(minimumSimilarity) : 0;
		return result;
	}
}
