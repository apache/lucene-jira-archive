package org.apache.lucene.search;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.xmlparser.CorePlusExtensionsParser;
import org.apache.lucene.xmlparser.builders.NestedDocumentQueryBuilder;
import org.apache.lucene.xmlparser.builders.PerParentLimitedQueryBuilder;

//Extends the core XML query parser with additional tags 
public class ExtendedXMLQueryParser extends CorePlusExtensionsParser
{
	public ExtendedXMLQueryParser(String defaultField, Analyzer analyzer)
	{
		super(defaultField, analyzer);
		addQueryBuilder("NestedQuery", new NestedDocumentQueryBuilder(filterFactory, queryFactory));
		addQueryBuilder("PerParentLimitedQuery", new PerParentLimitedQueryBuilder(filterFactory, queryFactory));
	}		
}
