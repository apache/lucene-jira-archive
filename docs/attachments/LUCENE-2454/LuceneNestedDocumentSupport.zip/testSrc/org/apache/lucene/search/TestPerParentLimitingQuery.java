package org.apache.lucene.search;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.HashSet;

import junit.framework.TestCase;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;

/**
 * Tests another aspect of nested documents - the ability to quickly
 * roll-up matching children in order to summarise matches on large
 * collections e.g. websites or, in this test case, books
 *  
 * @author MAHarwood
 *
 */
public class TestPerParentLimitingQuery extends TestCase
{
	
	
	private static Directory dir;
	private static IndexSearcher searcher;
	private int numBooksInIndex;
	private QueryParser queryParser;
	private StandardAnalyzer analyzer;

	/*
	 * Query all books for "London" returning only the best chapter from each book 
	 */
	public void testPerParentLimit() throws Exception
	{
		assertTrue(numBooksInIndex>0);
		assertTrue("More chapters than books", searcher.maxDoc()>numBooksInIndex);
		
		Query q=queryParser.parse("London");
		int maxNumChaptersPerBook=1;
		
		//Create a filter that defines "parent" documents in the index - in this test case, books
		Filter parentsFilter=new QueryWrapperFilter(new TermQuery(new Term("docType", "book")));
		
		PerParentLimitedQuery perParentLimitQuery=new PerParentLimitedQuery(q, parentsFilter, maxNumChaptersPerBook);
		HashSet<String>matchedBooks=new HashSet<String>();
		TopDocs topResults = searcher.search(perParentLimitQuery, 5);
		assertEquals("Should only return 2 chapters because we have only 2 books and 1 chapter per book restriction",
				2,topResults.totalHits);
		ScoreDoc[] scoreDocs = topResults.scoreDocs;
		for (int i = 0; i < scoreDocs.length; i++)
		{
			Document chapterDoc=searcher.doc(scoreDocs[i].doc);
			String bookName=chapterDoc.get("bookName");
			assertEquals("Should be returning child docs (chapters) not parent doc (book)", "chapter", 
					chapterDoc.get("docType"));
			assertFalse("Should only have one (best match) chapter per book", 
					matchedBooks.contains(bookName));
			matchedBooks.add(bookName);
			
//			System.out.println(chapterDoc);
			//Ordinarily an app could show highlighted snippets from this chapter - this
			// provides an efficient highlighting strategy for longer documents when they are
			// divided into sections as in this example
		}
		
		System.out.println(searcher.maxDoc());
	}

	/*
	 * Query all books for "London" returning only the best chapter from each book using XML Query Parser
	 */
	public void testXMLQueryParser() throws Exception
	{
		ExtendedXMLQueryParser parser=new ExtendedXMLQueryParser("text",analyzer);
		Query perParentLimitQuery = parser.parse(TestNestedDocumentQuery.class.getResourceAsStream("xmlQuery2.xml"));
		assertTrue(numBooksInIndex>0);
		assertTrue("More chapters than books", searcher.maxDoc()>numBooksInIndex);
		
		HashSet<String>matchedBooks=new HashSet<String>();
		TopDocs topResults = searcher.search(perParentLimitQuery, 5);
		assertEquals("Should only return 2 chapters because we have only 2 books and 1 chapter per book restriction",
				2,topResults.totalHits);
		ScoreDoc[] scoreDocs = topResults.scoreDocs;
		for (int i = 0; i < scoreDocs.length; i++)
		{
			Document chapterDoc=searcher.doc(scoreDocs[i].doc);
			String bookName=chapterDoc.get("bookName");
			assertEquals("Should be returning child docs (chapters) not parent doc (book)", "chapter", 
					chapterDoc.get("docType"));
			assertFalse("Should only have one (best match) chapter per book", 
					matchedBooks.contains(bookName));
			matchedBooks.add(bookName);
			
//			System.out.println(chapterDoc);
			//Ordinarily an app could show highlighted snippets from this chapter - this
			// provides an efficient highlighting strategy for longer documents when they are
			// divided into sections as in this example
		}
		
		System.out.println(searcher.maxDoc());
		
	}	

	@Override
	protected void setUp() throws Exception
	{
		//Load the 2 Gutenburg books found in the testData directory
		
		File gutDir=new File("testData");
		File[] files=gutDir.listFiles(new FilenameFilter(){
			public boolean accept(File dir, String name)
			{
				return name.endsWith("txt");
			}});
		dir = new RAMDirectory();
		analyzer = new StandardAnalyzer(Version.LUCENE_29);
		IndexWriter w=new IndexWriter(dir, analyzer,true,MaxFieldLength.UNLIMITED);
		numBooksInIndex=0;
		for (int i = 0; i < files.length; i++)
		{
			numBooksInIndex++;
			indexGutenbergBook(files[i],w);
		}
		w.close();	
		queryParser=new QueryParser(Version.LUCENE_29,"text",analyzer);
		searcher=new IndexSearcher(dir);		
	}

	@Override
	protected void tearDown() throws Exception
	{
		searcher.close();
		dir.close();
	}
	
	/**
	 * Indexes the contents of a Project Gutenberg book, breaking the book into a Lucene
	 * document per chapter.
	 * @param file
	 * @param writer
	 * @throws Exception
	 */
	private static void indexGutenbergBook(File file, IndexWriter writer) throws Exception
	{
		System.out.println(file.getName());
		//Add parent document to represent book (TODO could extract author/title etc from Gutenburg text)
		 Document doc=new Document();
		 doc.add(new Field("bookName",file.getName(),Field.Store.YES,Field.Index.NOT_ANALYZED_NO_NORMS));
		 doc.add(new Field("docType","book",Field.Store.YES,Field.Index.NOT_ANALYZED_NO_NORMS));
		 writer.addDocument(doc);
		 BufferedReader br=new BufferedReader(new FileReader(file)); 
		 String line=br.readLine();
		 StringBuilder sb=new StringBuilder();
		 while(line!=null)
		 {			 
			 if	(line.startsWith("CHAPTER "))
			 {				 
				 addChapterDoc(file.getName(), writer, sb);
				 sb=new StringBuilder();				 
			 }
			 sb.append(line);
			 sb.append("\n");
			 line=br.readLine();
		 }
		 addChapterDoc(file.getName(), writer, sb);
		 br.close();		
	}

	private static void addChapterDoc(String bookName, IndexWriter writer,
			StringBuilder sb) throws CorruptIndexException, IOException
	{
		Document doc;
		doc=new Document();
		 doc.add(new Field("text",sb.toString(),Field.Store.YES,Field.Index.ANALYZED));
		 //These fields are not strictly necessary for parent/child querying logic but used for test purposes 
		 doc.add(new Field("docType","chapter",Field.Store.YES,Field.Index.ANALYZED_NO_NORMS));
		 doc.add(new Field("bookName",bookName,Field.Store.YES,Field.Index.NOT_ANALYZED_NO_NORMS));
		 writer.addDocument(doc);
	}

}
