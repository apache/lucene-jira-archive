package org.apache.lucene.search;
/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import junit.framework.TestCase;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Index;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexWriter.MaxFieldLength;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;
import org.apache.lucene.xmlparser.CorePlusExtensionsParser;
import org.apache.lucene.xmlparser.builders.NestedDocumentQueryBuilder;
import org.apache.lucene.xmlparser.builders.PerParentLimitedQueryBuilder;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * An example of creating nested documents and accompanying test queries.
 * The example content used here is resumes where a person's resume can 
 * describe experience with multiple employers. This is a good example of 
 * content which has complex structure with nested, repeating sections.
 * 
 * The content for a single resume is represented as multiple Lucene 
 * documents which then enables powerful queries that test multiple properties
 * of child documents without merging all content into a single Lucene document
 * and getting "cross-matching" issues. 
 * 
 * 
 * @author Mark
 *
 */
public class TestNestedDocumentQuery extends TestCase
{
	static TransformerFactory tFactory = TransformerFactory.newInstance();
	static DocumentBuilderFactory dbf=DocumentBuilderFactory.newInstance();
	private Directory dir;
	private IndexWriter writer;
	private PerFieldAnalyzerWrapper analyzer;
	private IndexSearcher searcher;
	QueryParser qp;
	

	/**
	 *  Look for a UK-based candidate with recent java project experience
	 *  using nested document queries
	 * @throws Exception
	 */
	public void testQueryResumeIndex1() throws Exception
	{		
		//Create a filter that defines "parent" documents in the index - in this case resumes
		Filter parentsFilter=new QueryWrapperFilter(new TermQuery(new Term("docType", "resume")));
		
		//Define child document criteria (finds an example of relevant work experience)
		Query childExperienceQuery=qp.parse("java AND dtend:[2007 TO 3000]");
		
		//Define parent document criteria (find a person resident in the UK)
		Query parentQuery=qp.parse("countryName:(UK OR \"United Kingdom\")");
		
		//Wrap the child document query to attribute any matches to the containing parent
		NestedDocumentQuery childQuery=new NestedDocumentQuery(childExperienceQuery, parentsFilter);

		//Combine the parent and nested child queries into a single query for a candidate
		BooleanQuery parentPlusChildQuery=new BooleanQuery();
		parentPlusChildQuery.add(new BooleanClause(parentQuery,Occur.MUST));
		parentPlusChildQuery.add(new BooleanClause(childQuery,Occur.MUST));
		
		TopDocs results = searcher.search(parentPlusChildQuery, 5);
		assertEquals(1, results.totalHits);
		
		Document topDoc = searcher.doc(results.scoreDocs[0].doc);
		
		//Matching document should be the candidate called John
		assertEquals("John", topDoc.get("givenName"));		
	}
	


	/**
	 *  Look for a UK-based candidate with recent java project experience using the XML query parser
	 *  using nested document queries
	 * @throws Exception
	 */
	public void testXMLQueryParser() throws Exception
	{
		ExtendedXMLQueryParser parser=new ExtendedXMLQueryParser("description",analyzer);
		Query parentPlusChildQuery = parser.parse(TestNestedDocumentQuery.class.getResourceAsStream("xmlQuery1.xml"));
		TopDocs results = searcher.search(parentPlusChildQuery, 5);
		assertEquals(1, results.totalHits);
		
		Document topDoc = searcher.doc(results.scoreDocs[0].doc);
		
		//Matching document should be the candidate called John
		assertEquals("John", topDoc.get("givenName"));		
		
		
	}
	
	@Override
	protected void setUp() throws Exception
	{
		dbf.setNamespaceAware(true);		
		dir=new RAMDirectory();
		
		analyzer=new PerFieldAnalyzerWrapper(new StandardAnalyzer(Version.LUCENE_29));
		analyzer.addAnalyzer("skillTags", new WhitespaceAnalyzer());
		analyzer.addAnalyzer("dtend", new WhitespaceAnalyzer());
		analyzer.addAnalyzer("dtstart", new WhitespaceAnalyzer());
		qp=new QueryParser(Version.LUCENE_29,"description",analyzer);
		
		writer=new IndexWriter(dir,analyzer,true,MaxFieldLength.UNLIMITED);

		//Index example resumes (hand generated by http://hresume.weblogswork.com/hresumecreator/ ) 
		indexHResume(TestNestedDocumentQuery.class.getResource("hResume1.html"));
		indexHResume(TestNestedDocumentQuery.class.getResource("hResume2.html"));
		
		//Some example hresumes in the wild to try
//		indexHResume(new URL("http://steve.ganz.name/hresume/")); 
//		indexHResume(new URL("http://uncrease.com/qualifications/Jason.Erb.html")); 
//		indexHResume(new URL("http://mattwilliamsnyc.com/resume/")); 
//		indexHResume(new URL("http://www.niallkennedy.com/about/resume.html")); 
//		indexHResume(new URL("http://eric.ferraiuolo.name/resume/")); 
//		indexHResume(new URL("http://www.jciti.com/cv/cv.php")); 
//		indexHResume(new URL("http://www.mrgaetan.eu/cv/gaetan-riou-cv.html")); 
//		indexHResume(new URL("http://swy.me/resume/")); 
//		indexHResume(new URL("http://cv.antix.co.uk/ant")); 
//		indexHResume(new URL("http://www.ivanbustos.com/resume/")); 
//		indexHResume(new URL("http://k-create.com/resume/")); 
//		indexHResume(new URL("http://brad.hawidu.com/")); 

		writer.close();
		
		//Create searcher artefacts
		searcher=new IndexSearcher(dir);
		
		
	}
	

	@Override
	protected void tearDown() throws Exception
	{
		searcher.close();
		dir.close();
	}	
	

	/**
	 * Loads HTML content from a URL that is marked up using "hResume" standard into a series of
	 * Lucene documents - one for the root Resume, followed by one for each "Experience" 
	 * section. 
	 * 
	 * @param url
	 * @throws Exception
	 */
	private void indexHResume(URL url) throws Exception
	{
		Node xmlRootNode = getHResumeAsNestedDocDataXml(url);
		Element rootDocNode = (Element) xmlRootNode.getFirstChild();
		indexDocument(rootDocNode);		
	}
	
		
	private void indexDocument(Element rootDocNode) throws CorruptIndexException, IOException
	{
		Document luceneDoc=new Document();		
		NodeList fields = rootDocNode.getChildNodes();
		for (int i = 0; i < fields.getLength(); i++)
		{
			Node child=fields.item(i);
			if(child instanceof Element)
			{
				Element childElement = (Element) fields.item(i);
				if("Field".equals(childElement.getNodeName()))
				{
					String fieldName=childElement.getAttribute("name");
					String fieldValue=getText(childElement);
					if(fieldValue!=null)
					{
						luceneDoc.add(new Field(fieldName,fieldValue.trim(), Store.YES,Index.ANALYZED_NO_NORMS));
					}
				}
				
			}
		}
		//Add parent doc to index.
		writer.addDocument(luceneDoc);
		
		//Now recurse to add any child documents
		for (int i = 0; i < fields.getLength(); i++)
		{
			Node child=fields.item(i);
			if(child instanceof Element)
			{
				Element childElement = (Element) fields.item(i);
				if("Document".equals(childElement.getNodeName()))
				{
					indexDocument(childElement);
				}				
			}
		}
	}

	/**
	 *  Uses XSL to convert hResume XHTML document into a simpler data-only XML document
	 *  designed generically for indexing that has the following form:
	 *  <Document>
	 *      <Field name=""></Field>
	 *      <Field name=""></Field>
	 *      <Document>      
	 *      	<Field name=""></Field>
	 *      	<Field name=""></Field>
	 *      </Document>
	 *  </Document>
	 *  
	 * @param url The url of the XHTML marked up with hResume tags
	 * @return The root node of a DOM structure with "Document" and "Field" tags (Documents may also 
	 * contain other Documents)
	 * @throws Exception
	 */
	private Node getHResumeAsNestedDocDataXml(URL url) throws Exception
	{
  		InputStream xslIs=TestNestedDocumentQuery.class.getResourceAsStream("hResumeToLuceneDocs.xsl");
		DocumentBuilder builder = dbf.newDocumentBuilder();
		
		//Avoid loading any referenced DTDs from internet
	    builder.setEntityResolver(new EntityResolver() {
			public InputSource resolveEntity(String publicId, String systemId)
					throws SAXException, IOException
			{
                return new InputSource(new StringReader(""));
			}
	        });
	       
		org.w3c.dom.Document xslDoc = builder.parse(xslIs);
		DOMSource ds = new DOMSource(xslDoc);
		
		Transformer transformer = tFactory.newTransformer(ds);
								
		InputStream xmlIs=url.openStream();
		org.w3c.dom.Document luceneXmlDoc = builder.parse(xmlIs);
		DOMSource xmlDs = new DOMSource(luceneXmlDoc);
		DOMResult xmlResult=new DOMResult();
		transformer.transform(xmlDs, xmlResult);
		return xmlResult.getNode();
		
	}
	
	//==============================================================
	// XML parsing helper routines
	//==============================================================
		
	/* Returns text of node and all child nodes - without markup */
	public static String getText(Node e)
	{
		StringBuilder sb=new StringBuilder();
		getTextBuffer(e, sb);
		return sb.toString();
	}

	private static void getTextBuffer(Node e, StringBuilder sb)
	{
	    for (Node kid = e.getFirstChild(); kid != null; kid = kid.getNextSibling())
		{
			switch(kid.getNodeType())
			{
				case Node.TEXT_NODE:
				{
					sb.append(kid.getNodeValue());
					break;
				}
				case Node.ELEMENT_NODE:
				{
					getTextBuffer(kid, sb);
					break;
				}
				case Node.ENTITY_REFERENCE_NODE:
				{
					getTextBuffer(kid, sb);
					break;
				}
			}
		}
	}
}
