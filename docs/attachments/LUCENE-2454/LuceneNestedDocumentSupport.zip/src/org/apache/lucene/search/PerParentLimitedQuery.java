package org.apache.lucene.search;
/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.IOException;
import java.util.Arrays;
import java.util.Set;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.util.OpenBitSet;
import org.apache.lucene.util.OpenBitSetDISI;

/**
 * Limits the number of matches for any one parent to the best n child matches
 * (e.g. useful for limiting the number of pages returned for any one website) 
 * 
 * @author Mark
 *
 */
@SuppressWarnings("serial")
public class PerParentLimitedQuery extends Query 
{
	Filter parentsFilter;
	Query childQuery;
	private OpenBitSet parentBits;
	int maxDocsPerParent;
	int currentDoc=-1;
	float currentScore=0;

	

	public PerParentLimitedQuery(Query query, Filter filter, int maxDocsPerParent)
	{
		super();
		childQuery = query;
		parentsFilter = filter;
		this.maxDocsPerParent=maxDocsPerParent;
	}
	

	public Weight createWeight(Searcher searcher) throws IOException
	{
		return new PerParentLimitedQueryWeight(childQuery.weight(searcher));
	}

	class PerParentLimitedQueryWeight extends Weight
	{
		Weight delegateWeight;
		
		public PerParentLimitedQueryWeight(Weight weight)
		{
			super();
			delegateWeight = weight;
		}
		@Override
		public Query getQuery()
		{
			return delegateWeight.getQuery();
		}

		@Override
		public float getValue()
		{
			return delegateWeight.getValue();
		}

		@Override
		public float sumOfSquaredWeights() throws IOException
		{
			return delegateWeight.sumOfSquaredWeights();
		}

		@Override
		public void normalize(float norm)
		{
			delegateWeight.normalize(norm);			
		}

		@Override
		public Scorer scorer(IndexReader reader, boolean scoreDocsInOrder,boolean topScorer) throws IOException
		{
			Scorer delegateScorer=delegateWeight.scorer(reader, scoreDocsInOrder, topScorer);
			return new PerParentLimitedScorer(delegateScorer.getSimilarity(),delegateScorer);
		}

		@Override
		public Explanation explain(IndexReader reader, int doc) throws IOException
		{
			throw new UnsupportedOperationException(getClass().getName()+
					" cannot explain match on parent document");
		}		
	}
	
	class PerParentLimitedScorer extends Scorer
	{
		Scorer childScorer;
		int currentParentDoc=-1;
		int nextParentDoc=-1;
		int nextChildDoc=-1;
		float nextChildScore=0;
		
		static final int NO_MORE_DOCS=Integer.MAX_VALUE;

		int childDocs[];
		float childScores[];
		int numCachedChildren=0;
		int maxNumCachedChildrenForThisParent=0;
		

		public PerParentLimitedScorer(Similarity similarity, Scorer scorer)
		{
			super(similarity);
			childScorer = scorer;
			childDocs=new int[maxDocsPerParent];
			childScores=new float[maxDocsPerParent];
			initCachedChildren();
		}

		private void initCachedChildren()
		{
			Arrays.fill(childDocs,0);
			Arrays.fill(childScores,0);
			numCachedChildren=0;
		}

		@Override
		public int nextDoc() throws IOException
		{
			if(numCachedChildren>0)
			{
				//return from our buffer of collected siblings - must be in docID order
				float lowestDoc=Float.MAX_VALUE;
				int lowestIndex=0;
				for (int i = 0; i < maxNumCachedChildrenForThisParent; i++)
				{
					if( (childDocs[i]>0) 
							&&
						(childDocs[i]<lowestDoc)
						)
					{
						lowestIndex=i;
						lowestDoc=childDocs[lowestIndex];
					}
				}
				currentScore=childScores[lowestIndex];
				currentDoc=childDocs[lowestIndex];


				
				numCachedChildren--;
				childDocs[lowestIndex]=0;
				childScores[lowestIndex]=0;
				return currentDoc;
			}
			
			if(nextParentDoc==NO_MORE_DOCS) //no more docs to be had
			{
				currentDoc=NO_MORE_DOCS;
				currentScore=0;
				return NO_MORE_DOCS;
			}
			//start new batch of siblings
			initCachedChildren();
			if (nextParentDoc == -1) // first time in
			{
				int nd=childScorer.nextDoc();
				if (nd==NO_MORE_DOCS)
				{
					currentDoc=NO_MORE_DOCS;
					currentScore=0;
					numCachedChildren=0;
					return NO_MORE_DOCS;
				}
				nextParentDoc = getParentDoc(nd);
				nextChildDoc=nd;
				nextChildScore=childScorer.score();
			}			
			//add the first sibling we already read from last call to childScorer.next
			currentParentDoc=nextParentDoc;
			addChild(nextChildDoc,nextChildScore);

			// now wind forward through any remaining "sibling" docs to cache the
			// best n children for the current parent
			while (nextParentDoc == currentParentDoc)
			{
				int nd=childScorer.nextDoc();
				if (nd==NO_MORE_DOCS)
				{
					nextParentDoc=NO_MORE_DOCS;
					break;
				}
				nextParentDoc = getParentDoc(nd);
				nextChildScore = childScorer.score();
				nextChildDoc = nd;
				
				if (nextParentDoc == currentParentDoc) //if still on same parent
				{ 
					addChild(nextChildDoc,nextChildScore);
				}
			}
			maxNumCachedChildrenForThisParent=numCachedChildren;
			//called recursively here to set up the current score/doc.
			return nextDoc();
		}
		
		private void addChild(int childDocId, float score)
		{
			if(numCachedChildren<maxDocsPerParent)
			{
				//add to array of cached siblings
				childDocs[numCachedChildren]=childDocId;
				childScores[numCachedChildren]=score;
				
				numCachedChildren++;
			}
			else
			{
				//squeeze out any cached sibling scoring lower than current child doc
				float lowestCachedScore=Float.MAX_VALUE;
				int lowestCachedIndex=0;
				for (int i = 0; i < childDocs.length; i++)
				{
					if(childScores[i]<score)
					{
						if(childScores[i]<lowestCachedScore)
						{
							lowestCachedIndex=i;
							lowestCachedScore=childScores[lowestCachedIndex];
						}
					}
				}
				if(lowestCachedScore<score)
				{
					//swap out
					childScores[lowestCachedIndex]=score;
					childDocs[lowestCachedIndex]=childDocId;
				}
			}
		}

		public int getParentDoc(int possibleChildDoc)
		{
			int result=possibleChildDoc;
			while(!parentBits.fastGet(result))
			{
				result--;
				if(result<0)
				{
					throw new IllegalArgumentException(getClass().getName()+" Parent filter " +
							"produced a bitset with no parent doc for child doc #"+possibleChildDoc);					
				}
			}
			return result;
			//TODO - optimal implementation would use a reversed BitSet so could use BitSet.nexSetBit
			//rather than scanning backwards repeatedly with Bitset.get() method.
		}

		@Override
		public int docID()
		{			
			return currentDoc;
		}

		@Override
		public float score() throws IOException
		{
			return currentScore;
		}

		@Override
		public int advance(int target) throws IOException
		{
			if(numCachedChildren>0)
			{
				//return from our buffer of collected siblings - must be in docID order
				float lowestDoc=Float.MAX_VALUE;
				int lowestIndex=0;
				for (int i = 0; i < maxNumCachedChildrenForThisParent; i++)
				{
					if( (childDocs[i]>0) 
							&&
						(childDocs[i]<lowestDoc)
						)
					{
						lowestIndex=i;
						lowestDoc=childDocs[lowestIndex];
					}
				}
				currentScore=childScores[lowestIndex];
				currentDoc=childDocs[lowestIndex];

				
				numCachedChildren--;
				childDocs[lowestIndex]=0;
				childScores[lowestIndex]=0;			
				return currentDoc;
			}
			
			if(nextParentDoc==NO_MORE_DOCS) //no more docs to be had
			{
				currentDoc=NO_MORE_DOCS;
				currentScore=0;
				return NO_MORE_DOCS;
			}
			//start new batch of siblings
			initCachedChildren();
			if (nextParentDoc <target) 
			{
				int nextParent=parentBits.nextSetBit(target);
				if((nextParent<0)|| (childScorer.advance(nextParent)==NO_MORE_DOCS)){
					currentDoc=NO_MORE_DOCS;
					currentScore=0;
					numCachedChildren=0;
					return NO_MORE_DOCS;
				}
				nextParentDoc = getParentDoc(childScorer.docID());
				nextChildDoc=childScorer.docID();
				nextChildScore=childScorer.score();
			}			
			//add the first sibling we already read from last call to childScorer.next
			currentParentDoc=nextParentDoc;
			addChild(nextChildDoc,nextChildScore);

			// now wind forward through any remaining "sibling" docs to cache the
			// best n children for the current parent
			while (nextParentDoc == currentParentDoc)
			{
				int nd=childScorer.nextDoc();
				if (nd==NO_MORE_DOCS)
				{
					nextParentDoc=NO_MORE_DOCS;
					break;
				}
//				nextParentDoc = getParentDoc(childScorer.docID());
				nextParentDoc = getParentDoc(nd);
				nextChildScore = childScorer.score();
//				nextChildDoc = childScorer.docID();
				nextChildDoc = nd;
				
				if (nextParentDoc == currentParentDoc) //if still on same parent
				{ 
					addChild(nextChildDoc,nextChildScore);
				}
			}
			maxNumCachedChildrenForThisParent=numCachedChildren;
			//called recursively here to set up the current score/doc.
			return nextDoc();		
		}

	}


	@Override
//3.0	public void extractTerms(Set<Term> terms)
	public void extractTerms(Set terms) //2.9
	{
		childQuery.extractTerms(terms);
	}



	@Override
	public Query rewrite(IndexReader reader) throws IOException
	{
		childQuery=childQuery.rewrite(reader);
		DocIdSet pset=parentsFilter.getDocIdSet(reader);
		if(pset instanceof OpenBitSet)
		{
			parentBits=(OpenBitSet)pset;
		}
		else
		{
			parentBits=new OpenBitSetDISI(pset.iterator(), reader.maxDoc());
		}
		return this;
	}


	public String toString(String field)
	{	
		return "PerParentLimitedQuery ("+childQuery.toString()+", "+maxDocsPerParent+" )";
	}



}
