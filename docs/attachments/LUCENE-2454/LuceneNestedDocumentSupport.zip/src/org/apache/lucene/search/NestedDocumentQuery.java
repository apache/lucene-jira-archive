package org.apache.lucene.search;
/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.IOException;
import java.util.Set;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.util.OpenBitSet;
import org.apache.lucene.util.OpenBitSetDISI;

/**
 * Remaps matches on "child" documents to their preceding "parent" document.
 * Parents' locations in the index are defined using a Filter.
 * 
 * See http://www.slideshare.net/MarkHarwood/proposal-for-nested-document-support-in-lucene
 * 
 * @author Mark
 *
 */
public class NestedDocumentQuery extends Query 
{
	Filter parentsFilter;
	Query childQuery;
	private OpenBitSet parentBits;
	public static final int SCORE_MODE_AVG=1;
	public static final int SCORE_MODE_MAX=2;
	public static final int SCORE_MODE_TOTAL=3;
	int scoreMode=SCORE_MODE_AVG;
	
	
	public NestedDocumentQuery(Query query, Filter filter)
	{
		super();
		childQuery = query;
		parentsFilter = filter;
	}


	/**
	 * @return the scoreMode
	 */
	public int getScoreMode()
	{
		return scoreMode;
	}


	/**
	 * @param scoreMode the scoreMode to set
	 */
	public void setScoreMode(int scoreMode)
	{
		this.scoreMode = scoreMode;
	}

	

	public Weight createWeight(Searcher searcher) throws IOException
	{
		return new NestedDocumentQueryWeight(childQuery.weight(searcher));
	}

	class NestedDocumentQueryWeight extends Weight
	{
		Weight delegateWeight;
		
		public NestedDocumentQueryWeight(Weight weight)
		{
			super();
			delegateWeight = weight;
		}

		@Override
		public Query getQuery()
		{
			return delegateWeight.getQuery();
		}

		@Override
		public float getValue()
		{
			return delegateWeight.getValue();
		}

		@Override
		public float sumOfSquaredWeights() throws IOException
		{
			return delegateWeight.sumOfSquaredWeights();
		}

		@Override
		public void normalize(float norm)
		{
			delegateWeight.normalize(norm);			
		}

		@Override
		public Scorer scorer(IndexReader reader,boolean scoreDocsInOrder,boolean topScorer) throws IOException
		{
			Scorer delegateScorer=delegateWeight.scorer(reader, scoreDocsInOrder, topScorer);
			return new NestedDocumentScorer(delegateScorer.getSimilarity(),delegateScorer);
		}

		@Override
		public Explanation explain(IndexReader reader, int doc)
				throws IOException
		{
			throw new UnsupportedOperationException(getClass().getName()+
			" cannot explain match on parent document");
		}
		
	}
	
	class NestedDocumentScorer extends Scorer
	{
		Scorer childScorer;
		int currentDoc=-1;
		float currentScore=0;
		int nextDoc=-1;
		int currentChild=-1;
		float nextScore=0;
		static final int NO_MORE_DOCS=Integer.MAX_VALUE;
		

		public NestedDocumentScorer(Similarity similarity, Scorer scorer)
		{
			super(similarity);
			childScorer = scorer;
		}

		@Override
		public int nextDoc() throws IOException
		{
			if(nextDoc==NO_MORE_DOCS) //no more docs to be had
			{
				currentDoc=NO_MORE_DOCS;
				currentScore=0;
				return NO_MORE_DOCS;
			}
			if (nextDoc == -1) // first time in
			{
				int nd=childScorer.nextDoc();
				if (nd==NO_MORE_DOCS)
				{
					return NO_MORE_DOCS;
				}
				currentChild=nd;
				
				nextDoc = getParentDoc(currentChild);
				nextScore = childScorer.score();
			}
			return analyseChildren();
		}
		
		private int analyseChildren() throws IOException
		{
			// assume that in each call to next() we have already previewed the first child
			// in nextDoc
			currentDoc = nextDoc;
			currentScore = nextScore;
						
			int numSiblingsOrParents=1;
			float totalScore=currentScore;
			float maxScore=currentScore;

			// now wind forward through any potential "sibling" docs to find the
			// best child score for the current parent
			while (nextDoc == currentDoc)
			{
				int nd=childScorer.nextDoc();
				if (nd==NO_MORE_DOCS)
				{
					nextDoc=NO_MORE_DOCS;
					break;
				}
				currentChild=nd;
				nextDoc = getParentDoc(currentChild);
				nextScore = childScorer.score();
				if (nextDoc == currentDoc) //if still on same parent
				{ // take the best score for all children encountered
					maxScore = Math.max(nextScore, maxScore);
					numSiblingsOrParents++;
					totalScore+=nextScore;
				}
			}
			//finished evaluating current parent's children - determine choice of score
			
			if(scoreMode==SCORE_MODE_AVG)
			{
				currentScore=totalScore/(float)numSiblingsOrParents;
			}
			if(scoreMode==SCORE_MODE_TOTAL)
			{
				currentScore=totalScore;
			}
			if(scoreMode==SCORE_MODE_MAX)
			{
				currentScore=maxScore;
			}
			return currentDoc;
		}
		
		public int getParentDoc(int possibleChildDoc)
		{
			int result=possibleChildDoc;
			while(!parentBits.fastGet(result))
			{
				result--;
				if(result<0)
				{
					throw new IllegalArgumentException(getClass().getName()+" Parent filter " +
							"identified  no parent doc for child doc #"+possibleChildDoc);					
				}
			}
			return result;
			//TODO - optimal implementation would use a reversed BitSet so could use BitSet.nexSetBit
			//rather than scanning backwards repeatedly with Bitset.get() method.
		}

		@Override
		public int docID()
		{			
			return currentDoc;
		}

		@Override
		public float score() throws IOException
		{
			return currentScore;
		}

		@Override
		public int advance(int target) throws IOException
		{
			if(nextDoc==NO_MORE_DOCS) //no more docs to be had
			{
				currentDoc=NO_MORE_DOCS;
				currentScore=0;
				return NO_MORE_DOCS;
			}
			if (nextDoc <target) // first time in
			{
				int nextParent=parentBits.nextSetBit(target);
				if((nextParent<0)|| (childScorer.advance(nextParent)==NO_MORE_DOCS))
				{
					return NO_MORE_DOCS;
				}
				currentChild=childScorer.docID();
				nextDoc = getParentDoc(currentChild);
				nextScore = childScorer.score();
			}
			return analyseChildren();
		}

	}



	@Override
//3.0	public void extractTerms(Set<Term> terms) 
	public void extractTerms(Set terms) //2.9 
	{
		childQuery.extractTerms(terms);
	}


	@Override
	public Query rewrite(IndexReader reader) throws IOException
	{
		//TODO clone so NestedQuery is rewritable
		childQuery=childQuery.rewrite(reader);
		DocIdSet pset=parentsFilter.getDocIdSet(reader);
		if(pset instanceof OpenBitSet)
		{
			parentBits=(OpenBitSet)pset;
		}
		else
		{
			parentBits=new OpenBitSetDISI(pset.iterator(), reader.maxDoc());
		}
		return this;
	}	

	@Override
	public String toString(String field)
	{	
		return "NestedDocumentQuery ("+childQuery.toString()+")";
	}

}
