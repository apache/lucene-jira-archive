

DESCRIPTION
============

This package contains code and demonstrations of the NestedDocumentQuery feature outlined here: 
   http://www.slideshare.net/MarkHarwood/proposal-for-nested-document-support-in-lucene
   
KNOWN ISSUES
============
Compound documents added to the index MUST be held in the same segment. Currently the "flush" operation on 
IndexWriter is package-protected so applications must subclass IndexWriter and take control over flush calls
to avoid any compound documents being flushed before all child documents have been added. This can be done by
setting IndexWriter.setRAMBufferSizeMB() to a high value and periodically checking IndexWriter.ramSizeInBytes()
after every compound document is fully added to see if the RAM usage has exceeded a maximum value. The IndexWriter
flush method should then be called manually from the IndexWriter subclass. 
NOTE: in tests with trunk versions of Lucene rather than 3.0.1 it was found that ramSizeInBytes did not shrink after
calls to flush - more investigation required. 

It is hoped that if the concept of nested documents is adopted then a slicker way of controlling segment flushes will be
made available.

  
