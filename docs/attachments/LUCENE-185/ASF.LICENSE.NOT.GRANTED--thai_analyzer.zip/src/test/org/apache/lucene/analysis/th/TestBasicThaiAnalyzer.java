package org.apache.lucene.analysis.th;
/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2004 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Lucene" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Lucene", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.io.StringWriter;
import java.net.URL;
import java.util.Hashtable;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenStream;

import junit.framework.*;

/**
 * This class tests BasicThaiAnalyzer on the ability to tokenize thai text. 
 * @author Pichai Ongvasith
 * Created on 2/22/2004
 *
 */
public class TestBasicThaiAnalyzer extends TestCase {
    Analyzer analyzer;
    Hashtable stopwords = new Hashtable();
    Hashtable dictionary = new Hashtable();
    StringReader textReader;
    String text;
    private static final char MIN_THAI_CHAR = '\u0e01';
    private static final char MAX_THAI_CHAR = '\u0e4f';

    /**
     * Read files required for the test, which include stop word list (stopword_th.txt),
     * Thai text to be tested (thaitxt.txt), and a dictionary (rtword.txt)<p><ul>
     * <li> <b>stopword_th.txt</b> contains stop words, one word per line.</li>
     * <li> <b>thaitxt.txt</b> is just a plain text file.</li>
     * <li> <b>rtword.txt</b> contains thai words, one word per line. This file is used to
     * verify the tokens. It may not contain the same words as the dictionary used by JDK.
     * 
     */
    public void setUp() {

        // Read stopword file. Not required.
        readWord("stopword_th.txt", stopwords);

        // create analyzer based on the stopwords
        analyzer = new BasicThaiAnalyzer(stopwords);

        // read Thai text to be parsed. This will be used to test against the result too.
        BufferedReader reader = null;
        URL url = this.getClass().getResource("thaitxt.txt");
        try {
            reader =
                new BufferedReader(new InputStreamReader(url.openStream()));
            StringWriter sw = new StringWriter();
            char[] buffer = new char[1024];
            int readed = 0;
            while ((readed = reader.read(buffer)) != -1) {
                sw.write(buffer, 0, readed);
            }
            text = sw.getBuffer().toString();
            textReader = new StringReader(text);
            // Since we use lowercasefilter, we have to convert here too.
            text = text.toLowerCase();
        } catch (IOException e1) {
            fail(
                "Can't load Thai Text file thaitxt.txt. Please put the file "
                    + "in the directory where the binary of this "
                    + this.getClass()
                    + " is located");
        } finally {
            try {
                reader.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }

        // read a dictionary. Not necesarily the same dictionary JDK uses.
        // this is for testing the parsed tokens.
        readWord("riwords.txt", dictionary);
    }

    private void readWord(String fileName, Hashtable table) {
        URL url = this.getClass().getResource(fileName);
        BufferedReader reader = null;
        try {
            reader =
                new BufferedReader(new InputStreamReader(url.openStream()));
            String line = null;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.length() > 0 && line.charAt(0) != '#')
                    table.put(line, line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                reader.close();
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }
    }

    /**
     * Test the tokenStream method. The test verifies token offsets, tokenized words
     * against supplied rtword.txt, unicode value of chars in tokens with THAI type, 
     * and stop word filtering. The dictionary test allows 10% of tokens not to be
     * in the dictionary.
     */
    public void testTokenStream() {
        TokenStream result = null;
        result = analyzer.tokenStream("NONE", textReader);
        Token token = null;
        try {
            int txtIdx = 0;
            int thaiTokenCount = 0;
            int hit = 0;
            // We are not using any stem filter. So the exact word should be
            // there in the text. The offset should match the position of text.
            // This actually tests TokenTokenizer functionality.
            while ((token = result.next()) != null) {
                int startIdx = text.indexOf(token.termText(), txtIdx);
                txtIdx = token.termText().length() + startIdx;
                // Has to find the token in the original text
                assertTrue(startIdx > -1);

                // The offset in the token has to match the position in the text
                assertEquals(startIdx, token.startOffset());

                // then endOffset of the token has to match the end position in text
                assertEquals(
                    token.termText().length() + startIdx,
                    token.endOffset());

                // The token must not be in stop word list
                assertNull(stopwords.get(token.termText()));

                //System.out.println(token.termText());
                if (token.type().equals("<THAI>")) {
                    // Make sure every character is a thai character
                    for (int i = 0; i < token.termText().length(); i++) {
                        assertTrue(token.termText().charAt(i) >= MIN_THAI_CHAR);
                        assertTrue(token.termText().charAt(i) <= MAX_THAI_CHAR);
                    }

                    // Count the hits 
                    if (dictionary.get(token.termText()) != null)
                        hit++;
                    thaiTokenCount++;
                }
            }

            // No Thai tokenizer is perfect. Given the same text, two people may even
            // tokenize it differently. More importantly, dictionary-based tokenizers
            // handle words not in their own dictionary differently. 
            // But at least, the majority of the tokenized words should be in a dictionary.

            assertTrue((float) hit / thaiTokenCount > 0.8);

        } catch (IOException e1) {
            fail(e1.toString());
        }
    }
}
