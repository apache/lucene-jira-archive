package me.torobaev.lucene.taxonomy.cache;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.apache.lucene.facet.FacetsConfig;
import org.apache.lucene.facet.taxonomy.FacetLabel;
import org.apache.lucene.facet.taxonomy.writercache.UTF8TaxonomyWriterCache;
import org.apache.lucene.index.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.ByteBlockPool;
import org.apache.lucene.util.BytesRef;
import org.apache.lucene.util.BytesRefHash;
import org.apache.lucene.util.StringHelper;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;

public class TaxonomyCacheCheck {

	public static void main(String[] args) throws Exception {
		String taxonomyPath = System.getProperty("taxonomyDir", "../taxonomy");
		String taxonomyCache = System.getProperty("cacheDump", "../taxonomy-cache.json");

		FacetLabel facetLabel = new FacetLabel("frametype", "7");
		FacetLabel collisionLabel = new FacetLabel("modification_id", "682");

		// restore my application runtime cache state from json dump
		UTF8TaxonomyWriterCache cacheFromDump = readCacheDump(taxonomyCache);

		// fill cache with taxonomy content
		UTF8TaxonomyWriterCache cache = readFromTaxonomy(taxonomyPath);

		System.out.println(facetLabel + " from cache dump: " + cacheFromDump.get(facetLabel));

		System.out.println(facetLabel + " from brand new cache: " + cache.get(facetLabel));

		System.out.println(collisionLabel + " from cache dump: " + cacheFromDump.get(collisionLabel));
		System.out.println(collisionLabel + " from brand new cache: " + cache.get(collisionLabel));
	}

	private static UTF8TaxonomyWriterCache readCacheDump(String cachePath) throws Exception {
		// we need to restore application state with hash seed to be able to use cache from dump
		Utils.setStatic(StringHelper.class, "GOOD_FAST_HASH_SEED", 1224915255, true);

		ObjectMapper mapper = new ObjectMapper();

		SimpleModule module = new SimpleModule();
		module.addSerializer(BytesRefHash.class, new Utils.BytesRefHashSer(null));
		module.addSerializer(BytesRefHash.DirectBytesStartArray.class, new Utils.DirectBytesStartArraySer(null));
		module.addSerializer(UTF8TaxonomyWriterCache.class, new Utils.UTF8TaxonomyWriterCacheSer(null));
		module.addSerializer(ByteBlockPool.class, new Utils.ByteBlockPoolSer(null));

		module.addDeserializer(UTF8TaxonomyWriterCache.class, new Utils.UTF8TaxonomyWriterCacheDes(null));

		mapper.registerModule(module);

		return mapper.readValue(new File(cachePath), UTF8TaxonomyWriterCache.class);
	}

	// read taxonomy to cache
	// just a copy of org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyWriter.perhapsFillCache
	private static UTF8TaxonomyWriterCache readFromTaxonomy(String path) throws IOException {
		UTF8TaxonomyWriterCache cache = new UTF8TaxonomyWriterCache();

		Directory taxonomyDir = FSDirectory.open(Paths.get(path));
		ReaderManager manager = new ReaderManager(DirectoryReader.open(taxonomyDir));


		try (DirectoryReader reader = manager.acquire()) {

			PostingsEnum postingsEnum = null;
			for (LeafReaderContext ctx : reader.leaves()) {
				Terms terms = ctx.reader().terms("$full_path$");
				if (terms != null) { // cannot really happen, but be on the safe side
					TermsEnum termsEnum = terms.iterator();
					while (termsEnum.next() != null) {
						if (!cache.isFull()) {
							BytesRef t = termsEnum.term();
							FacetLabel cp = new FacetLabel(FacetsConfig.stringToPath(t.utf8ToString()));
							postingsEnum = termsEnum.postings(postingsEnum, PostingsEnum.NONE);
							int ord = postingsEnum.nextDoc() + ctx.docBase;
							boolean res = cache.put(cp, ord);

							assert !res : "entries should not have been evicted from the cache";
						} else {
							break;
						}
					}
				}
			}
		}

		return cache;
	}
}
