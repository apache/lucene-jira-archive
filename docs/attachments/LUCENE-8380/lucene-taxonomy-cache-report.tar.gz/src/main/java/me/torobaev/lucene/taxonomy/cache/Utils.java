package me.torobaev.lucene.taxonomy.cache;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import org.apache.lucene.facet.taxonomy.writercache.UTF8TaxonomyWriterCache;
import org.apache.lucene.util.ByteBlockPool;
import org.apache.lucene.util.BytesRefHash;
import org.apache.lucene.util.Counter;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import static java.util.stream.StreamSupport.stream;

/**
 * Dirty reflection hacks and json read/write helper
 */
class Utils {

	@SuppressWarnings({"unchecked"})
	static <T> T get(Object object, String field, Class<T> type) {
		try {
			Class<?> clazz = object.getClass();
			Field f = clazz.getDeclaredField(field);
			f.setAccessible(true);
			return (T) f.get(object);
		} catch (NoSuchFieldException | IllegalAccessException e) {
			throw new RuntimeException(e);
		}
	}

	@SuppressWarnings({"unchecked"})
	static <T> T getByType(Object object, String field, Class byType, Class<T> type) {
		try {
			Field f = byType.getDeclaredField(field);
			f.setAccessible(true);
			return (T) f.get(object);
		} catch (NoSuchFieldException | IllegalAccessException e) {
			throw new RuntimeException(e);
		}
	}

	static void set(Object object, String field, Object value, boolean isFinal) {
		try {
			Class<?> clazz = object.getClass();
			Field f = clazz.getDeclaredField(field);
			f.setAccessible(true);
			if (isFinal) {
				Field modifiers = Field.class.getDeclaredField("modifiers");
				modifiers.setAccessible(true);
				modifiers.setInt(f, f.getModifiers() & ~Modifier.FINAL);
			}
			f.set(object, value);
		} catch (NoSuchFieldException | IllegalAccessException e) {
			throw new RuntimeException(e);
		}
	}

	static void setStatic(Class clazz, String field, Object value, boolean isFinal) {
		try {
			Field f = clazz.getDeclaredField(field);
			f.setAccessible(true);

			if (isFinal) {
				Field modifiers = f.getClass().getDeclaredField("modifiers");
				modifiers.setAccessible(true);
				modifiers.set(f, f.getModifiers() & ~Modifier.FINAL);
			}

			f.set(null, value);
		} catch (NoSuchFieldException | IllegalAccessException e) {
			throw new RuntimeException(e);
		}
	}

	//<editor-fold desc="UTF8TaxonomyWriterCache Jackson serializer and deserializer">
	static class BytesRefHashSer extends StdSerializer<BytesRefHash> {


		protected BytesRefHashSer(Class<BytesRefHash> t) {
			super(t);
		}

		@Override
		public void serialize(BytesRefHash value, JsonGenerator gen, SerializerProvider provider) throws IOException {
			gen.writeStartObject();

			gen.writeObjectField("pool", get(value, "pool", ByteBlockPool.class));
			int[] bytesStart = get(value, "bytesStart", int[].class);
			gen.writeObjectField("bytesStart", bytesStart);

			gen.writeNumberField("hashSize", get(value, "hashSize", int.class));
			gen.writeNumberField("hashHalfSize", get(value, "hashHalfSize", int.class));
			gen.writeNumberField("hashMask", get(value, "hashMask", int.class));
			gen.writeNumberField("count", get(value, "count", int.class));
			gen.writeNumberField("lastCount", get(value, "lastCount", int.class));


			int[] ids = get(value, "ids", int[].class);
			gen.writeObjectField("ids", ids);

			gen.writeObjectField("bytesStartArray", get(value, "bytesStartArray", BytesRefHash.BytesStartArray.class));

			gen.writeEndObject();
		}
	}

	static class DirectBytesStartArraySer extends StdSerializer<BytesRefHash.DirectBytesStartArray> {

		protected DirectBytesStartArraySer(Class<BytesRefHash.DirectBytesStartArray> t) {
			super(t);
		}

		@Override
		public void serialize(BytesRefHash.DirectBytesStartArray value, JsonGenerator gen, SerializerProvider provider)
			throws IOException {
			gen.writeStartObject();

			gen.writeNumberField("initSize", get(value, "initSize", int.class));
			gen.writeObjectField("bytesStart", get(value, "bytesStart", int[].class));
			gen.writeObjectField("bytesUsed", get(value, "bytesUsed", Counter.class).get());


			gen.writeEndObject();
		}
	}

	static class UTF8TaxonomyWriterCacheSer extends StdSerializer<UTF8TaxonomyWriterCache> {

		protected UTF8TaxonomyWriterCacheSer(Class<UTF8TaxonomyWriterCache> t) {
			super(t);
		}

		@Override
		public void serialize(UTF8TaxonomyWriterCache value, JsonGenerator gen, SerializerProvider provider)
			throws IOException {
			gen.writeStartObject();


			gen.writeNumberField("bytesUsed", get(value, "bytesUsed", Counter.class).get());

			gen.writeObjectField("map", get(value, "map", BytesRefHash.class));

			gen.writeObjectField("ordinals", get(value, "ordinals", int[][].class));

			gen.writeNumberField("count", get(value, "count", int.class));
			gen.writeNumberField("pageCount", get(value, "pageCount", int.class));

			gen.writeEndObject();

		}
	}

	static class ByteBlockPoolSer extends StdSerializer<ByteBlockPool> {


		protected ByteBlockPoolSer(Class<ByteBlockPool> t) {
			super(t);
		}

		@Override
		public void serialize(ByteBlockPool value, JsonGenerator gen, SerializerProvider provider) throws IOException {
			gen.writeStartObject();


			gen.writeObjectField("buffers", value.buffers);
			gen.writeNumberField("bufferUpto", get(value, "bufferUpto", int.class));
			gen.writeNumberField("byteUpto", value.byteUpto);
			gen.writeObjectField("buffer", value.buffer);
			gen.writeNumberField("byteOffset", value.byteOffset);

			gen.writeNumberField("allocator_blockSize", getByType(get(value, "allocator", int.class), "blockSize", ByteBlockPool.Allocator.class, int.class));


			gen.writeEndObject();
		}
	}


	static class UTF8TaxonomyWriterCacheDes extends StdDeserializer<UTF8TaxonomyWriterCache> {

		protected UTF8TaxonomyWriterCacheDes(Class<?> vc) {
			super(vc);
		}

		@Override
		public UTF8TaxonomyWriterCache deserialize(JsonParser p, DeserializationContext ctxt)
			throws IOException, JsonProcessingException {
			ObjectNode node = p.readValueAs(ObjectNode.class);


			long bytesUsed = node.get("bytesUsed").asLong();
			int count = node.get("count").asInt();
			int pageCount = node.get("pageCount").asInt();

			ArrayNode ordinalsNode = (ArrayNode) node.get("ordinals");

			int[][] ordinals = new int[ordinalsNode.size()][];
			for (int i = 0; i < ordinalsNode.size(); i++) {
				JsonNode jsonNode = ordinalsNode.get(i);
				if (jsonNode != null && !jsonNode.isNull()) {
					ArrayNode an = (ArrayNode) jsonNode;
					ordinals[i] = stream(an.spliterator(), false).mapToInt(JsonNode::asInt).toArray();
				}
			}


			// BytesRefHash start
			JsonNode map = node.get("map");


			//bytesStartArray start
			JsonNode bytesStartArrayNode
				= map.get("bytesStartArray");
			int bytesStartArray_initSize = bytesStartArrayNode.get("initSize").intValue();
			ArrayNode bytesStart = (ArrayNode) bytesStartArrayNode.get("bytesStart");
			int[] bytesStartArray_bytesStart = stream(bytesStart.spliterator(), false).mapToInt(JsonNode::asInt).toArray();

			Counter counter = Counter.newCounter();
			counter.addAndGet(bytesStartArrayNode.get("bytesUsed").asLong());

			BytesRefHash.DirectBytesStartArray bytesStartArray =
				new BytesRefHash.DirectBytesStartArray(bytesStartArray_initSize, counter);

			set(bytesStartArray, "bytesStart", bytesStartArray_bytesStart, false);
			//bytesStartArray end


			int[] hash_bytesStart = stream(map.get("bytesStart").spliterator(), false).mapToInt(JsonNode::asInt).toArray();
			int hash_hashSize = map.get("hashSize").asInt();
			int hash_hashHalfSize = map.get("hashHalfSize").asInt();
			int hash_hashMask = map.get("hashMask").asInt();
			int hash_count = map.get("count").asInt();
			int hash_lastCount = map.get("lastCount").asInt();
			int[] hash_ids = stream(map.get("ids").spliterator(), false).mapToInt(JsonNode::asInt).toArray();


			// pool start

			JsonNode poolNode = map.get("pool");
			JsonNode buffersNode = poolNode.get("buffers");

			ArrayNode buffersArrayNode = (ArrayNode) buffersNode;
			byte[][] pool_buffers = new byte[buffersArrayNode.size()][];

			for (int i = 0; i < buffersArrayNode.size(); i++) {
				pool_buffers[i] = buffersArrayNode.get(i).binaryValue();
			}
			int pool_bufferUpto = poolNode.get("bufferUpto").asInt();
			int pool_byteUpto = poolNode.get("byteUpto").asInt();
			int pool_byteOffset = poolNode.get("byteOffset").asInt();
			byte[] pool_buffer = poolNode.get("buffer").binaryValue();
			int allocator_blockSize = poolNode.get("allocator_blockSize").asInt();
			ByteBlockPool.Allocator allocator = new ByteBlockPool.DirectTrackingAllocator(allocator_blockSize, Counter.newCounter());

			ByteBlockPool pool = new ByteBlockPool(allocator);
			set(pool, "buffers", pool_buffers, false);
			set(pool, "bufferUpto", pool_bufferUpto, false);
			set(pool, "byteUpto", pool_byteUpto, false);
			set(pool, "buffer", pool_buffer, false);
			set(pool, "byteOffset", pool_byteOffset, false);


			// pool end

			BytesRefHash bytesRefHash = new BytesRefHash(pool);
			set(bytesRefHash, "bytesStart", hash_bytesStart, false);
			set(bytesRefHash, "hashSize", hash_hashSize, false);
			set(bytesRefHash, "hashHalfSize", hash_hashHalfSize, false);
			set(bytesRefHash, "hashMask", hash_hashMask, false);
			set(bytesRefHash, "count", hash_count, false);
			set(bytesRefHash, "lastCount", hash_lastCount, false);
			set(bytesRefHash, "ids", hash_ids, false);
			set(bytesRefHash, "bytesStartArray", bytesStartArray, true);
			set(bytesRefHash, "bytesUsed", counter, false);

			// BytesRefHash end


			UTF8TaxonomyWriterCache cache = new UTF8TaxonomyWriterCache();
			set(cache, "ordinals", ordinals, true);
			set(cache, "count", count, false);
			set(cache, "pageCount", pageCount, false);
			set(cache, "map", bytesRefHash, true);

			return cache;
		}
	}
	// </editor-fold>
}
