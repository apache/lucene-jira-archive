package org.apache.lucene.store.jcr;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.GregorianCalendar;

import javax.jcr.ItemExistsException;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;
import javax.jcr.lock.LockException;
import javax.jcr.nodetype.ConstraintViolationException;
import javax.jcr.nodetype.NoSuchNodeTypeException;
import javax.jcr.version.VersionException;

import org.apache.lucene.store.BufferedIndexOutput;
import org.apache.lucene.store.IndexOutput;

/**
 * A Java Content Repository (JSR-170) {@link IndexOutput} implementation.
 *
 * @author Nicolas Bélisle - Laval University Library (nicolas.belisle@bibl.ulaval.ca)
 */
class JcrIndexOutput extends BufferedIndexOutput {

	private long startPos = 0;
	private Node fileFolderNode;
	private int bufferCount = 0;
	
	/**
	 * Size of block/buffer for files
	 */
	private int bufferSize;
	
	JcrIndexOutput(Node fileFolderNode1, int bufferSize1) {
		super();
		try {
			if (!fileFolderNode1.isNodeType("nt:folder")) {
				throw new IllegalArgumentException("Node is not of type nt:folder");
			}
			
			this.bufferSize = bufferSize1;
			this.fileFolderNode = fileFolderNode1;

			//Count existing buffers
			for (NodeIterator it = this.fileFolderNode.getNodes(); it.hasNext(); it.next()) {
				this.bufferCount++;
			}	
			
			if (this.bufferCount == 0) {
				createNewEmptyBuffer();
			}
			
			assert(this.bufferCount > 0);
		}
		catch (RepositoryException e) {
			throw new RuntimeException("Datasource error: " + e.getMessage(), e);
		}
	}
	
	/**
	 * Adds a new empty file and increments the buffer counter
	 * 
	 * @throws ItemExistsException
	 * @throws PathNotFoundException
	 * @throws NoSuchNodeTypeException
	 * @throws LockException
	 * @throws VersionException
	 * @throws ConstraintViolationException
	 * @throws RepositoryException
	 */
	private void createNewEmptyBuffer() throws ItemExistsException, PathNotFoundException, NoSuchNodeTypeException, LockException, VersionException, ConstraintViolationException, RepositoryException {
		Node resourceNode = this.fileFolderNode.addNode("" + (++this.bufferCount), "nt:file").addNode("jcr:content", "nt:resource");
		resourceNode.setProperty("jcr:mimeType", "application/octet-stream");
	    resourceNode.setProperty("jcr:lastModified", new GregorianCalendar());
	    resourceNode.setProperty("jcr:data", new ByteArrayInputStream(new byte[0]));
	}

	/**
	 * @see org.apache.lucene.store.IndexOutput#close()
	 */
	public void close() throws IOException {
		super.flush();
		assert(this.length() > 0);
		try {
			//Change the modification date
			this.fileFolderNode.getNode("1").getNode("jcr:content").setProperty("jcr:lastModified", new GregorianCalendar());
			this.fileFolderNode.save();
		} catch (RepositoryException e) {
			throw new IOException("Datasource error: " + e.getMessage());
		}
	}
	
	/**
	 * @see org.apache.lucene.store.IndexOutput#seek(long)
	 */
	public void seek(long pos) throws IOException {
	    super.seek(pos);
	    this.startPos = pos;
	  }

	/**
	 * @see org.apache.lucene.store.BufferedIndexOutput#flushBuffer(byte[], int)
	 */
	protected void flushBuffer(byte[] b, int len) throws IOException {
		
		assert(len > 0);
		assert(b.length > 0);
		assert(len <= b.length);
		
		long currentBufferIndex = 1 + (this.startPos / this.bufferSize);
		try {
			int buffersNeeded = (int) (1 + (len + this.startPos % this.bufferSize) / this.bufferSize);
			while ((buffersNeeded - (this.bufferCount - currentBufferIndex) > 1)) { 
				createNewEmptyBuffer();
			}
			
			long bufferPos = this.startPos % this.bufferSize;
			byte[] bufferArray = null; 
			for (int bytesToWrite = len; bytesToWrite > 0; currentBufferIndex++) {
				
				//Beginning
				if (bytesToWrite == len) {
					//Read file buffer
					InputStream bufferStream = this.fileFolderNode.getNode("" + currentBufferIndex).getNode("jcr:content").getProperty("jcr:data").getStream();	
					int bufferArraySize = bufferStream.available();
					if (bufferArraySize < bufferPos + bytesToWrite && bufferPos + bytesToWrite < this.bufferSize) {
						bufferArraySize = (int) (bufferPos + bytesToWrite);
					} else if (bufferPos + bytesToWrite > this.bufferSize) {
						bufferArraySize = this.bufferSize;
					}
					bufferArray = new byte[bufferArraySize];
					bufferStream.read(bufferArray);
					bufferStream.close();
				} else {
					bufferPos = 0;
				}
				//FIXME
				arrayCopy(b, len - bytesToWrite, bufferArray, (int) bufferPos, (int) (bufferArray.length - bufferPos), bytesToWrite);

				ByteArrayInputStream bis = new ByteArrayInputStream(bufferArray);
				this.fileFolderNode.getNode("" + currentBufferIndex).getNode("jcr:content").setProperty("jcr:data", bis);
				bytesToWrite = (int) (bytesToWrite - bufferArray.length - bufferPos);
				bis.close();
								
				//Prepare last step
				if (bytesToWrite > 0 && bytesToWrite <= this.bufferSize) {
					//Read file buffer
					InputStream bufferStream = this.fileFolderNode.getNode("" + (currentBufferIndex + 1)).getNode("jcr:content").getProperty("jcr:data").getStream();	
					boolean readBuffer = true;
					int bufferArraySize = bufferStream.available();
					if (bufferArraySize <= bytesToWrite) {
						bufferArraySize = (bytesToWrite);
						readBuffer = false;
					}
					bufferArray = new byte[bufferArraySize];
					//Read the end of the buffer
					if (readBuffer) {
						bufferStream.read(bufferArray);
					}
					bufferStream.close();
				} else {
					bufferArray = new byte[this.bufferSize];
				}
			}
		} catch (RepositoryException e) {
			throw new IOException("Datasource error: " + e.getMessage());
		}
	}
	
	/**
	 * Wraps System.arraycoppy to avoid some IndexOutOfBoundsExceptions
	 * 
	 * @param src
	 * @param srcPos
	 * @param dest
	 * @param destPos
	 * @param length
	 * @param max
	 */
	private static void arrayCopy(byte[] src, int srcPos, byte[] dest, int destPos, int length, int max) {
		int correctedLength = length;
		if (length > src.length) {
			correctedLength = src.length;
		}
		if (correctedLength > max) {
			correctedLength = max;
		}
		System.arraycopy(src, srcPos, dest, destPos, correctedLength);
	}

	/**
	 * @see org.apache.lucene.store.IndexOutput#length()
	 */
	public long length() throws IOException {
		try {
			long counter = (this.bufferCount - 1) * this.bufferSize;
			InputStream fileStream = this.fileFolderNode.getNode("" + this.bufferCount).getNode("jcr:content").getProperty("jcr:data").getStream();
			int available = fileStream.available();
			return counter + available;
		} catch (RepositoryException e) {
			throw new IOException("Datasource error: " + e.getMessage());
		}
	}
}
