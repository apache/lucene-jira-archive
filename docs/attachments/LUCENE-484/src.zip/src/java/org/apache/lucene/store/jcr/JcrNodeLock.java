package org.apache.lucene.store.jcr;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.GregorianCalendar;

import javax.jcr.Node;
import javax.jcr.RepositoryException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.store.Lock;

/**
 * A Java Content Repository (JSR-170) {@link Lock} implementation.
 *
 * @author Nicolas Bélisle - Laval University Library (nicolas.belisle@bibl.ulaval.ca)
 */
class JcrNodeLock extends Lock {
	
	private static Log log = LogFactory.getLog(JcrNodeLock.class);
	public static Object THREAD_LOCK = new Object();
	
    private Node folderNode;
    private String name;

    JcrNodeLock(Node folderNode1, String name1) {
    	this.folderNode = folderNode1;
    	this.name = name1;
    }
    
    public boolean obtain() {
    	log.debug("Obtaining lock: " + this.name);
    	try {
    		synchronized (THREAD_LOCK) {
    			if(!this.folderNode.hasNode(this.name)) {
    				Node lockNode = this.folderNode.addNode(this.name, "nt:file").addNode("jcr:content", "nt:resource");
    				lockNode.setProperty("jcr:mimeType", "application/octet-stream");
    				lockNode.setProperty("jcr:lastModified", new GregorianCalendar());
	    		    lockNode.setProperty("jcr:data", new ByteArrayInputStream(new byte[0]));
	                this.folderNode.save();
	    			log.debug("Lock obtained: " + this.name);
	    			return true;
				}
    		 }
		} catch (RepositoryException e) {
			throw new RuntimeException(e);
		}
		log.debug("Lock could not acquired: " + this.name);
        return false;
    }
    
    /*
    public boolean obtain(long lockWaitTimeout) throws IOException {
    	//If one needs to slow lockWaitTimeout
    	return super.obtain(lockWaitTimeout * 100);
    }*/

    public void release() {
    	log.debug("Releasing lock with name: " + this.name);
        try {
        	synchronized(THREAD_LOCK) {
        		Node fileNode = this.folderNode.getNode(this.name);
    			fileNode.remove();
    			this.folderNode.save();
    		}
		} catch (RepositoryException e) {
			throw new RuntimeException(e);
		}
		log.debug("Lock released: + " + this.name);
    }

    public boolean isLocked() {
    	log.trace("Calling isLocked()");
        try {
        	return this.folderNode.hasNode(this.name);
		} catch (RepositoryException e) {
			throw new RuntimeException(e);
		}
    }
}

