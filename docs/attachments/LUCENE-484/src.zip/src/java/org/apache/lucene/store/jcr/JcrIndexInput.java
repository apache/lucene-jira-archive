package org.apache.lucene.store.jcr;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.io.InputStream;

import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.RepositoryException;

import org.apache.lucene.store.BufferedIndexInput;

/**
 * A Java Content Repository (JSR-170) {@link InputStream} implementation.
 *
 * @author Nicolas Bélisle - Laval University Library (nicolas.belisle@bibl.ulaval.ca)
 */
class JcrIndexInput extends BufferedIndexInput {

	private int bufferCount = 0;
	
	private Node fileFolderNode;
	
	/**
	 * Size of block/buffer for files
	 */
	private int bufferSize;
	
	JcrIndexInput(Node fileFolderNode1, int bufferSize1) {
		try {
			if (!fileFolderNode1.isNodeType("nt:folder")) {
				throw new IllegalArgumentException("Node is not of type nt:folder");
			}
			
			this.fileFolderNode = fileFolderNode1;
			this.bufferSize = bufferSize1;
			
			for (NodeIterator it = this.fileFolderNode.getNodes(); it.hasNext(); it.next()) {
				this.bufferCount++;
			}
			assert(this.bufferCount > 0);
			
			
		} catch (RepositoryException e) {
			throw new RuntimeException("Datasource error: " + e.getMessage(), e);
		}
	}
	
	/**
	 * @see org.apache.lucene.store.BufferedIndexInput#readInternal(byte[], int, int)
	 */
	protected void readInternal(byte[] b, int offset, int length) throws IOException {
		long bufferNumber = 1 + (this.getFilePointer() / this.bufferSize);
		try {
			for (int bytesToRead = length; bytesToRead > 0; bufferNumber++) {
				InputStream currentStream = this.fileFolderNode.getNode("" + bufferNumber).getNode("jcr:content").getProperty("jcr:data").getStream();	
				bytesToRead = bytesToRead - currentStream.read(b, offset + length - bytesToRead, bytesToRead);
				currentStream.close();
			}
		} catch (RepositoryException e) {
			throw new IOException("Datasource error: " + e.getMessage());
		}
	}

	/**
	 * @see org.apache.lucene.store.BufferedIndexInput#seekInternal(long)
	 */
	protected void seekInternal(long pos) throws IOException {
		super.seek(pos);
	}

	/**
	 * @see org.apache.lucene.store.IndexInput#close()
	 */
	public void close() throws IOException {
	}
	
	/**
	 * @see org.apache.lucene.store.IndexInput#length()
	 */
	public long length() {
		try {			
			long counter = (this.bufferCount - 1) * this.bufferSize;
			InputStream fileStream = this.fileFolderNode.getNode("" + this.bufferCount).getNode("jcr:content").getProperty("jcr:data").getStream();
			int available = fileStream.available();
			fileStream.close(); 
			return counter + available;
		} catch (RepositoryException e) {
			throw new RuntimeException("Datasource error: " + e.getMessage(), e);
		} catch (IOException e) {
			throw new RuntimeException("Datasource error: " + e.getMessage(), e);
		}
	}

}
