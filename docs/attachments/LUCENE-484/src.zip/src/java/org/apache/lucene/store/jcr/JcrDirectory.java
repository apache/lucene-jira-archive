package org.apache.lucene.store.jcr;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.jcr.ItemExistsException;
import javax.jcr.Node;
import javax.jcr.NodeIterator;
import javax.jcr.PathNotFoundException;
import javax.jcr.RepositoryException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.store.InputStream;
import org.apache.lucene.store.Lock;
import org.apache.lucene.store.OutputStream;

/**
 * A Java Content Repository (JSR-170) {@link Directory} implementation.
 * Stores bytes in blocks of fixed size.
 *
 * @author Nicolas Bélisle - Laval University Library (nicolas.belisle@bibl.ulaval.ca)
 */
public class JcrDirectory extends Directory {

	private static Log log = LogFactory.getLog(JcrDirectory.class);

	/**
	 * Size of block/buffer for files
	 */
	private int bufferSize = 100;
	
	private Node folderNode;

	public JcrDirectory(Node folderNode1) throws RepositoryException {
		super();
		if (!folderNode1.isNodeType("nt:folder")) {
			throw new IllegalArgumentException("Node: " + folderNode1 + " is not of type nt:folder, it is of type: " + folderNode1.getPrimaryNodeType().getName());
		}
		this.folderNode = folderNode1;
	}

	/**
	 * Can be used to override the default block size
	 * 
	 * @param folderNode1
	 * @param bufferSize1
	 * @throws RepositoryException
	 */
	public JcrDirectory(Node folderNode1, int bufferSize1) throws RepositoryException {
		this(folderNode1);
		if (this.bufferSize < 1) {
			throw new IllegalArgumentException("The bufferSize must greater than 0");
		}
		this.bufferSize = bufferSize1;
	}

	public int getBufferSize() {
		return this.bufferSize;
	}

	/**
	 * @see org.apache.lucene.store.Directory#list()
	 */
	public String[] list() throws IOException {
		log.debug("Listing files of folderNode");
		List list = new ArrayList();
		try {
			for (NodeIterator ni = this.folderNode.getNodes(); ni.hasNext();) {
				Node currentNode = ni.nextNode();
				if (currentNode.getPrimaryNodeType().getName().equals("nt:folder")) {
					list.add(currentNode.getName());
				}
			}
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}
		return (String[]) list.toArray(new String[list.size()]);
	}

	/**
	 * @see org.apache.lucene.store.Directory#fileExists(java.lang.String)
	 */
	public boolean fileExists(String name) throws IOException {
		log.debug("Determining existence of: " + name);
		try {
			if (this.folderNode.hasNode(name)) {
				return true;
			}
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}
		return false;
	}

	/**
	 * @see org.apache.lucene.store.Directory#fileModified(java.lang.String)
	 */
	public long fileModified(String name) throws IOException {
		log.debug("Retrieving modified date for: " + name);
		try {
			Node node = this.folderNode.getNode(name);
			return node.getNode("1").getNode("jcr:content").getProperty("jcr:lastModified").getDate().getTimeInMillis();
		} catch (PathNotFoundException e) {
			throw new IOException("File: " + name + " not found. PathNotFoundException: " + e.getMessage());
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}
	}

	/**
	 * @see org.apache.lucene.store.Directory#touchFile(java.lang.String)
	 */
	public void touchFile(String name) throws IOException {
		log.debug("Touching file : " + name);
		try {
			synchronized (JcrNodeLock.THREAD_LOCK) {
				Node node = this.folderNode.getNode(name);
				node.getNode("1").getNode("jcr:content").setProperty("lastModified", new GregorianCalendar());
				node.save();
			}
		} catch (PathNotFoundException e) {
			throw new IOException("File: " + name + " not found. PathNotFoundException: " + e.getMessage());
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}

	}

	/**
	 * @see org.apache.lucene.store.Directory#deleteFile(java.lang.String)
	 */
	public void deleteFile(String name) throws IOException {
		log.debug("Deleting file : " + name);
		try {
			synchronized (JcrNodeLock.THREAD_LOCK) {
				Node node = this.folderNode.getNode(name);
				node.remove();
				this.folderNode.save();
			}
		} catch (PathNotFoundException e) {
			throw new IOException("File: " + name + " not found. PathNotFoundException: " + e.getMessage());
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}
	}

	/**
	 * @see org.apache.lucene.store.Directory#renameFile(java.lang.String, java.lang.String)
	 */
	public void renameFile(String srcName, String destName) throws IOException {
		log.debug("Renaming : " + srcName + " to: " + destName);
		try {
			synchronized (JcrNodeLock.THREAD_LOCK) {
				if (this.folderNode.hasNode(destName)) {
					this.folderNode.getNode(destName).remove();
				}
				this.folderNode.getSession().move(this.folderNode.getPath() + "/" + srcName, this.folderNode.getPath() + "/" + destName);
				this.folderNode.save();
			}
		} catch (PathNotFoundException e) {
			throw new IOException("File: " + srcName + " not found. PathNotFoundException: " + e.getMessage());
		} catch (ItemExistsException e) {
			throw new IOException("File: " + destName + " already exists. ItemExistsException: " + e.getMessage());
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}
	}

	/**
	 * @see org.apache.lucene.store.Directory#fileLength(java.lang.String)
	 */
	public long fileLength(String name) throws IOException {
		log.debug("Calculating fileLength for: " + name);
		try {
			Node node = this.folderNode.getNode(name);
			IndexInput ii = new JcrIndexInput(node, this.bufferSize);
			long length = ii.length();
			ii.close();
			return length;
		} catch (PathNotFoundException e) {
			throw new IOException("File: " + name + " not found. PathNotFoundException: " + e.getMessage());
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}
	}

	/**
	 * @see org.apache.lucene.store.Directory#createFile(java.lang.String)
	 */
	public OutputStream createFile(String name) throws IOException {
		throw new RuntimeException("Method not implemented");
	}

	/**
	 * @see org.apache.lucene.store.Directory#createOutput(java.lang.String)
	 */
	public IndexOutput createOutput(String name) throws IOException {
		log.debug("Creating file: " + name);
		Node fileFolderNode;
		try {
			synchronized (JcrNodeLock.THREAD_LOCK) {
				
				if (this.folderNode.hasNode(name)) {
					this.folderNode.getNode(name).remove();
				} 
				fileFolderNode = this.folderNode.addNode(name, "nt:folder");
				this.folderNode.save();
			}
		} catch (PathNotFoundException e) {
			throw new IOException("File: " + name + " not found. PathNotFoundException: " + e.getMessage());
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}
		return new JcrIndexOutput(fileFolderNode, this.bufferSize);
	}

	/**
	 * @see org.apache.lucene.store.Directory#openFile(java.lang.String)
	 */
	public InputStream openFile(String name) throws IOException {
		throw new RuntimeException("Method not implemented");
	}

	/**
	 * @see org.apache.lucene.store.Directory#openInput(java.lang.String)
	 */
	public IndexInput openInput(String name) throws IOException {
		log.debug("Closing directory");
		try {
			Node fileNode = this.folderNode.getNode(name);
			return new JcrIndexInput(fileNode, this.bufferSize);
		} catch (PathNotFoundException e) {
			throw new FileNotFoundException("File: " + name + " not found. PathNotFoundException: " + e.getMessage());
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}
	}

	/**
	 * @see org.apache.lucene.store.Directory#makeLock(java.lang.String)
	 */
	public Lock makeLock(String name) {
		return new JcrNodeLock(this.folderNode, name);
	}

	/**
	 * @see org.apache.lucene.store.Directory#close()
	 */
	public void close() throws IOException {
		log.debug("Closing directory");
		try {
			//Do not close the session. It should be managed externally.
			this.folderNode.save();
		} catch (RepositoryException e) {
			throw new IOException("Datasource error. RepositoryException: " + e.getMessage());
		}
	}
}
