package org.apache.lucene.store.jcr;

/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;

import javax.jcr.Node;
import javax.jcr.Repository;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.SimpleCredentials;
import javax.naming.Context;
import javax.naming.InitialContext;

import junit.framework.TestCase;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.jackrabbit.core.RepositoryImpl;
import org.apache.jackrabbit.core.jndi.RegistryHelper;
import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Searcher;

import test.FileDocument;

/**
 * Tests {@link JcrDirectory}.
 *
 * Index and search test using Apache Jackrabbit as JCR implementation.
 * Warning: It seems that Jackrabbit holds a lock on some resources even after calling RepositoryImpl.shutdown().
 * This means that some resources could be left in the filesystem after the test. 
 * 
 * @author Nicolas Bélisle - Laval University Library (nicolas.belisle@bibl.ulaval.ca)
 */
public class JcrStoreTest extends TestCase {
    
	private static Log log = LogFactory.getLog(JcrStoreTest.class);
	
	private static final int BUFFER_SIZE = 100;
	
	private Repository repository;
	private Node node;
	
    public void setUp() throws Exception {
    	log.info("Beginning JCRDirectory test");
    	File file = new File("repotest");
    	file.mkdir();
    	String configFile = "repotest/repository.xml";
    	createRepositoryFile(configFile);
    	
    	String repHomeDir = "repotest";
		
		Hashtable env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, "org.apache.jackrabbit.core.jndi.provider.DummyInitialContextFactory");
		env.put(Context.PROVIDER_URL, "localhost");
		InitialContext ctx = new InitialContext(env);

		RegistryHelper.registerRepository(ctx, "repo", configFile, repHomeDir, true);
		this.repository = (Repository) ctx.lookup("repo");
		Session session = this.repository.login(new SimpleCredentials("userid", "".toCharArray()), null);
		Node rn = session.getRootNode();
		
		if (!rn.hasNode("folder")) {
			rn.addNode("folder", "nt:folder");	
			session.save();
		}
		
		this.node = rn.getNode("folder");
    }
    
    private void createRepositoryFile(String configFile) throws IOException {
		InputStream in = null;
		FileOutputStream out = null;

		try {
			out = new FileOutputStream(configFile);
			in = this.getClass().getResourceAsStream("/org/apache/lucene/store/jcr/repository.xml");
			
			byte[] buffer = new byte[2014];
			for (int bytesRead = -1; (bytesRead = in.read(buffer)) != -1; out.write(buffer, 0, bytesRead));
			out.flush();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			}
			catch (IOException ex) {
				log.debug("Could not close InputStream", ex);
			} 
			try {
				if (out != null) {
					out.close();
				}
			}
			catch (IOException ex) {
				log.debug("Could not close OutputStream", ex);
			} 
		}   
    }

    public void tearDown() throws Exception {
    	this.node.getSession().logout();
    	this.node = null;
    	if (this.repository instanceof RepositoryImpl) {
			((RepositoryImpl) this.repository).shutdown();
		}
    	this.repository = null;
    	deleteDir(new File("repotest"));
    	log.info("JCRDirectory test done!");
    }

    public void testIndexAndSearch() throws Exception {
    	int docCount = 5;
    	for (int i = 0; i < docCount; i++) {
    		indexNode();
    	}
    	log.info(docCount + " document(s) has been successfully indexed in JcrDirectory");
    	int docFound = searchNode();
    	assertEquals(docFound, docCount);
    	log.info(docFound + " document(s) has been successfully found in JcrDirectory");
    }
    
    private void indexNode() throws IOException {		
		IndexWriter writer = null;
		try {
			boolean create = true;
			if (this.node.hasNode("segments")) {
				create = false;
			}
			writer = new IndexWriter(new JcrDirectory(this.node, BUFFER_SIZE), new SimpleAnalyzer(), create);
			writer.setMergeFactor(20);
			writer.addDocument(FileDocument.createDocument());
			writer.optimize();
		} catch (Exception e) {
			throw new RuntimeException("Unable to index document.", e);
		} finally {
			if (writer != null) {
				writer.close();
			}
		}
	}
    
    private int searchNode() throws RepositoryException, IOException, ParseException {
	    Searcher searcher = null;
	    searcher = new IndexSearcher(new JcrDirectory(this.node, BUFFER_SIZE)); 
	    Query query = new QueryParser("content", new SimpleAnalyzer()).parse("aContent");
	    Hits hits = searcher.search(query);
	    searcher.close();
	    return hits.length();
    }
    
    private static void deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            for (int i=0; i < children.length; i++) {
                deleteDir(new File(dir, children[i]));
            }
        }
        dir.delete();
    }
}