package org.apache.lucene.analysis;

/**
 * Created by IntelliJ IDEA.
 * User: grantingersoll
 * Date: Apr 3, 2004
 * Time: 4:01:10 PM
 * To change this template use Options | File Templates.
 *
 *  $Id:$
 */

import junit.framework.TestCase;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 **/
public class TestBaseAnalyzer extends TestCase {

    private Tokenizer tokenizer = new WhitespaceTokenizer();
    private List filters = new ArrayList(2);
    private Set stopWords = null;

    private String testString = "the quick brown fox was tokenized and filtered using the BaseAnalyzer";
    private String[] goldString = {"quick", "brown", "fox", "was",
                                   "tokenized", "filtered", "using", "baseanalyzer"};

    public TestBaseAnalyzer(String testName) {
        super(testName);
    }

    public TestBaseAnalyzer() {
    }

    public void setUp() {
        stopWords = new HashSet();
        stopWords.add("the");
        stopWords.add("a");
        stopWords.add("an");
        stopWords.add("and");
        filters.add(new LowerCaseFilter());
        filters.add(new StopFilter(stopWords));

    }

    public void tearDown() {

    }

    public void test() {
        assertTrue(stopWords.size() == 4);
        assertTrue(filters.size() == 2);
        assertTrue(tokenizer != null);
    }

    public void testAnalyzer() {
        BaseAnalyzer analyzer = new BaseAnalyzer();
        analyzer.setTokenizer(tokenizer);
        analyzer.setFilters(filters);
        assertTrue(analyzer != null);
        TokenStream ts = analyzer.tokenStream("dummy", new StringReader(testString));
        try {
            for (int i = 0; i < goldString.length; i++) {
                Token t = ts.next();
                assertNotNull(t);
                assertEquals(t.termText(), goldString[i]);
            }
            assertNull(ts.next());
            ts.close();
        } catch (IOException e) {
            e.printStackTrace();
            assertTrue(false);
        }

    }
}