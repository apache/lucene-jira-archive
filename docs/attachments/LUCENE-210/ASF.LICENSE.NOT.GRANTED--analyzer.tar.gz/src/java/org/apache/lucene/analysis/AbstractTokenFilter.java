package org.apache.lucene.analysis;

/**
 * Created by IntelliJ IDEA.
 * User: grantingersoll
 * Date: Apr 3, 2004
 * Time: 2:37:51 PM
 * To change this template use Options | File Templates.
 *
 *  $Id:$
 */


import java.io.IOException;

/**
 *
 **/
public abstract class AbstractTokenFilter implements TokenFilter {
    protected TokenStream input = null;

    public void init() {
        //do nothing
    }

    public void setTokenStream(TokenStream previousTokenStream) {
        input = previousTokenStream;
    }

    public void close() throws IOException {
        input.close();
    }

}