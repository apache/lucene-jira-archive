package org.apache.lucene.analysis;

/**
 * Created by IntelliJ IDEA.
 * User: grantingersoll
 * Date: Apr 3, 2004
 * Time: 2:40:05 PM
 * To change this template use Options | File Templates.
 *
 *  $Id:$
 */


import java.io.Reader;
import java.io.IOException;

/**
 *
 **/
public abstract class AbstractTokenizer implements Tokenizer {
    /**
     * The text source for this Tokenizer.
     */
    protected Reader reader;

    public void init() {
        //do nothing
    }

    public void setReader(Reader reader) {
        this.reader = reader;
    }

    /**
     * By default, closes the input Reader.
     */
    public void close() throws IOException {
        reader.close();
    }


}