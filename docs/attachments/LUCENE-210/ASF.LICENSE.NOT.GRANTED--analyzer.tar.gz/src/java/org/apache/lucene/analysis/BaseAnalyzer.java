package org.apache.lucene.analysis;

/**
 * Created by IntelliJ IDEA.
 * User: grantingersoll
 * Date: Apr 3, 2004
 * Time: 2:23:25 PM
 * To change this template use Options | File Templates.
 *
 *  $Id:$
 */

import java.io.Reader;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 **/
public class BaseAnalyzer extends Analyzer {

    private List filters = new ArrayList();
    private Tokenizer tokenizer = null;


    public BaseAnalyzer() {
    }

    public BaseAnalyzer(List filters, Tokenizer tokenizer) {
        this.filters = filters;
        this.tokenizer = tokenizer;
    }

    public Tokenizer getTokenizer() {
        return tokenizer;
    }

    public void setTokenizer(Tokenizer tokenizer) {
        this.tokenizer = tokenizer;
    }


    public boolean removeFilter(TokenFilter filter){
        return filters.remove(filter);
    }


    public void addFilter(TokenFilter filter) {
        filters.add(filter);
    }

    public List getFilters() {
        return filters;
    }

    public void setFilters(List filters) {
        this.filters = filters;
    }

    public TokenStream tokenStream(String fieldName, Reader reader) {
        TokenStream result = null;
        if (tokenizer != null)
        {
            tokenizer.init();
            tokenizer.setReader(reader);
            result = tokenizer;
        }
        if (filters != null && filters.size() > 0)
        {

            for (Iterator iterator = filters.iterator(); iterator.hasNext();) {
                TokenFilter filter = (TokenFilter) iterator.next();
                filter.init();
                filter.setTokenStream(result);
                result = filter;
            }
        }
        return result;
    }

}