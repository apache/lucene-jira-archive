package org.apache.lucene.search;

import java.io.IOException;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;
import java.util.WeakHashMap;

import org.apache.lucene.index.IndexReader;
import org.apache.solr.util.OpenBitSet;

/**
 * Caches numeric field values in memory to improve range filter performance.  During a warmup phase, which happens
 * once for every field this Filter is applied to, numeric values are read from the index, sorted, and stored in 
 * a SortedFieldCache.  When the filter is used, binary searches are used to find where the upper and lower
 * bounds values are indexed within the SortedFieldCache.
 * 
 * MemoryCachedRangeFilter can be used where range filter performance is critical and memory consumption is not
 * an issue.  Memory requirements: (sizeof(int) + sizeof(long)) * numDocs.  Warmup requires creation of FieldCache
 * as well.
 * 
 * @author Andy Liu
  */
public class MemoryCachedRangeFilter extends Filter {
    public static final int DEFAULT_NUM_PARTITIONS = 50;
    
    private static WeakHashMap cache = new WeakHashMap();

    private String field;
    private long lower;
    private long upper;
    private boolean includeLower;
    private boolean includeUpper;
    
    private ValueParser parser = new ValueParser() {
        public long parse(String str) {
            return Long.parseLong(str);
        }
    };
    
    /**
     * Constructs a MemoryCachedRangeFilter
     * 
     * @param field The field this range applies to
     * @param lower The lower bound on this range
     * @param upper The upper bound on this range
     * @param includeLower Is the lower bound value inclusive?
     * @param includeUpper Is the upper bound value inclusive?
     */
    public MemoryCachedRangeFilter(String field, long lower, long upper, boolean includeLower, boolean includeUpper) {
        super();
        this.field = field;
        this.lower = lower;
        this.upper = upper;
        this.includeLower = includeLower;
        this.includeUpper = includeUpper;
    }

    /**
     * Reads all values of a given field and creates a SortedFieldCache.  Stores SortedFieldCache
     * in memory.  Public method, so that warmup can be performed during application intialization.
     * This can take a while for large document sets.
     * 
     * @param reader
     * @throws IOException
     */
    public synchronized void warmup(IndexReader reader) throws IOException {
        warmup(reader, DEFAULT_NUM_PARTITIONS);
    }

    public synchronized void warmup(IndexReader reader, int numPartitions) throws IOException {
        // Check to see if warmup was already performed.  If so, then return.
        if (getFromCache(reader) != null)
            return;
        
        String[] fieldCache = FieldCache.DEFAULT.getStrings(reader, field);
        Tuple[] tuples = new Tuple[fieldCache.length];
        for (int docId=0; docId<fieldCache.length; docId++) {
            Tuple tuple = new Tuple(parser.parse(fieldCache[docId]), docId);
            tuples[docId] = tuple;
        }
        SortedFieldCache sfCache = new SortedFieldCache(tuples, numPartitions);
        
        Map innerCache = (Map) cache.get(reader);
        if (innerCache == null) {
            innerCache = new HashMap();
            cache.put(reader, innerCache);
        }

        innerCache.put(field, sfCache);
    }
    
    private SortedFieldCache getFromCache(IndexReader reader) {
        Map innerCache = (Map) cache.get(reader);

        if (innerCache == null) {
            return null;
        }

        return (SortedFieldCache) innerCache.get(field);        
    }
    
    private void setBitsForRange(IndexReader reader, SortedFieldCache sfCache, long lower, long upper, OpenBitSet bitset) {
        int lowerIndex = sfCache.getLowerIndexForValue(lower, includeLower);
        int upperIndex = sfCache.getUpperIndexForValue(upper, includeUpper);
        
        // Construct bitset.  The complete range of documents is all docId values
        // between lowerIndex and upperIndex.
        long start = System.currentTimeMillis();
        for (int i=lowerIndex; i<=upperIndex; i++) {
            for (int j=0; j<sfCache.docId[i].length; j++) {
                bitset.fastSet(sfCache.docId[i][j]);
            }
        }
    }
    
    public BitSet bits(IndexReader reader) throws IOException {
        SortedFieldCache sfCache = null;
        
        synchronized (this) {
            sfCache = getFromCache(reader);

            if (sfCache == null) {
                warmup(reader);
                sfCache = getFromCache(reader);
            }
        }
        
        //
        // Search bitset cache
        //
        OpenBitSet bitset = new OpenBitSet(reader.maxDoc());
        long cacheStart = Long.MAX_VALUE;
        long cacheEnd = Long.MIN_VALUE;
        
        boolean hit = false;
        for (int i=0; i<sfCache.range.length; i++) {
            if ( (lower < sfCache.rangeStart[i]) &&
                    ( upper > sfCache.rangeEnd[i]) ) {
                bitset.or(sfCache.range[i]);
                cacheStart = Math.min(cacheStart, sfCache.rangeStart[i]);
                cacheEnd = Math.max(cacheEnd, sfCache.rangeEnd[i]);
                hit = true;
            }
        }
        
        if (hit) {
            setBitsForRange(reader, sfCache, lower, cacheStart, bitset);
            setBitsForRange(reader, sfCache, cacheEnd, upper, bitset);
        } else {
            setBitsForRange(reader, sfCache, lower, upper, bitset);   
        }
        
        return new OpenBitSetWrapper(bitset);
    }
    
    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append(field);
        buffer.append(":");
        buffer.append(includeLower ? "[" : "{");
        buffer.append(lower);
        buffer.append("-");
        buffer.append(upper);
        buffer.append(includeUpper ? "]" : "}");
        return buffer.toString();
    }

    public ValueParser getParser() {
        return parser;
    }

    public void setParser(ValueParser parser) {
        this.parser = parser;
    }

    /**
     * Parallel arrays to stare [value, docId] pairs.  Sorted by value 
     */
    static class SortedFieldCache {
        long[] values; // every unique value in field
        int[][] docId; // 2d ragged array of docId's corresponding to each unique value in values[]
        
        long[] rangeStart;
        long[] rangeEnd;
        OpenBitSet[] range;
        
        public SortedFieldCache(Tuple[] tuples, int numRanges) {
            Arrays.sort(tuples);
            
            // One pass over sorted array to count # of unique values
            // Necessary to know allocate array size.  Could use ArrayList, but
            // I want to avoid array resizing.
            int numUnique = 1;
            long currentValue = tuples[0].value;
            for (int i=1; i<tuples.length; i++) {
                if (currentValue != tuples[i].value) {
                    numUnique++;
                    currentValue = tuples[i].value;
                }
            }

//            System.out.println("Found " + numUnique + " unique values.");
            
            values = new long[numUnique];
            docId = new int[numUnique][];

            //
            // Construct array of docId's for each unique value
            //
            currentValue = tuples[0].value;
            int first = 0, last = 1, count = 0;
            for (int i=1; i<tuples.length; i++) {
                if (tuples[i].value != currentValue) {
                    values[count] = currentValue;
                    int[] docsForValue = new int[last-first];
                    for (int j=0; j<docsForValue.length; j++) {
                        docsForValue[j] = tuples[first + j].docId;
                    }
                    docId[count] = docsForValue;
                    
                    count++;
                    
                    currentValue = tuples[i].value;
                    first = i;
                    last = i;
                }
                last++;
            }
            
            //
            // Add last one
            //
            values[count] = currentValue;
            int[] docsForValue = new int[last-first];
            for (int j=0; j<docsForValue.length; j++) {
                docsForValue[j] = tuples[first + j].docId;
            }
            docId[count] = docsForValue;
            
            
            //
            // Create cached bitset ranges
            //
            rangeStart = new long[numRanges];
            rangeEnd = new long[numRanges];
            range = new OpenBitSet[numRanges];

//            System.out.println("Initializing bitsets.");
            
            int interval = Math.round(values.length / (float) numRanges);
            int curLow = 0;
            int curRange = 0;
            while (curLow < values.length) {
                int high = Math.min(curLow + interval, values.length-1);

                OpenBitSet bitset = new OpenBitSet();
                for (int i=curLow; i<=high; i++) {
                    for (int j=0; j<docId[i].length; j++) {
                        bitset.set(docId[i][j]);
                    }
                }
                
                rangeStart[curRange] = values[curLow];
                rangeEnd[curRange] = values[high];
                range[curRange] = bitset;
                
                curRange++;
                
//                System.out.println(" * " + values[curLow] + "(" + curLow + ") / " + values[high] + "(" + high + ") with " + bitset.cardinality() + " docs");
                
                curLow = high + 1;
            }
        }
        
        public int getUpperIndexForValue(long upper, boolean inclusive) {
            int upperIndex = 0;
            
            // If we're asking for a value higher than the maximum value, set index to length-1        
            if (upper > values[values.length-1]) {
                upperIndex = values.length-1;
            } else {
                upperIndex = Arrays.binarySearch(values, upper);
                
                if ( (!inclusive) && (upperIndex >= 0) ) {
                    upperIndex--;
                } else {
                    upperIndex = Math.abs(upperIndex);

                    // binarySearch returns where the value *should* be.  It will be pointing to a
                    // value in the array greater than the value that we're looking for.  Rewind.
                    upperIndex--;
                }
            }
            
            // Special case handling may cause pointer to run off the array.  Adjust.
            if (upperIndex >= values.length)
                upperIndex = values.length-1;
            
            return upperIndex;
        }
        
        public int getLowerIndexForValue(long lower, boolean inclusive) {
            int lowerIndex = 0;

            // If we're asking for a value lower than the minimum value, set index to 0
            if (lower < values[0]) {
                lowerIndex = 0;
            } else {                
                // Otherwise, use binary search to look for index of lower
                lowerIndex = Arrays.binarySearch(values, lower);
                
                // Binary search doesn't take in account series of repeated values.  So the index
                // returned can be in the middle of a series.  Depending on whether or not this
                // bound is inclusive, we will have to adjust to point to the first of the series
                // or the last of the series.
                if ( (!inclusive) && (lowerIndex >= 0) ) {
                    lowerIndex++;
                } else {
                    lowerIndex = Math.abs(lowerIndex);
                }
            }

            if (lowerIndex < 0)
                lowerIndex = 0;
            
            return lowerIndex;
        }
        
    }

    static class Tuple implements Comparable {
        long value;
        int docId;

        public Tuple(long value, int docId) {
            super();
            this.value = value;
            this.docId = docId;
        }

        public int compareTo(Object o) {
            Tuple other = (Tuple) o;
            int val = (this.value < other.value ? -1 : (this.value == other.value ? 0 : 1));

            if (val == 0)
                return (this.docId < other.docId ? -1 : (this.docId == other.docId ? 0 : 1)); 
            return val;
        }

    }
    
    /**
     * Encapsulates how each value should be parsed
     */
    public interface ValueParser {
        public long parse(String str);
    }

    public static class OpenBitSetWrapper extends BitSet {
        OpenBitSet delegee;

        public OpenBitSetWrapper() {
            delegee = new OpenBitSet();
        }

        public OpenBitSetWrapper(OpenBitSet bitset) {
            delegee = bitset;
        }
        
        public OpenBitSetWrapper(long size) {
            delegee = new OpenBitSet(size);
        }

        public int cardinality() {
            return (int) delegee.cardinality();
        }

        public void clear() {
            delegee = new OpenBitSet();
        }

        public void clear(int fromIndex, int toIndex) {
            throw new UnsupportedOperationException("not supported.");
        }

        public void clear(int bitIndex) {
            delegee.clear(bitIndex);
        }

        public Object clone() {
            // Not so pretty.  Is there a better way to do this?  BitSet's bits[] is private.
            BitSet cloned = new BitSet((int) delegee.size());
            for(int i=delegee.nextSetBit(0); i>=0; i=delegee.nextSetBit(i+1)) {
                cloned.set(i);
            }
            
            return cloned;
        }

        public boolean equals(Object obj) {
            return delegee.equals(obj);
        }

        public void flip(int fromIndex, int toIndex) {
            delegee.flip(fromIndex, toIndex);
        }

        public void flip(int bitIndex) {
            delegee.flip(bitIndex);
        }

        public BitSet get(int fromIndex, int toIndex) {
            throw new UnsupportedOperationException("not supported.");
        }

        public boolean get(int bitIndex) {
            return delegee.fastGet(bitIndex);
        }

        public int hashCode() {
            return delegee.hashCode();
        }

        public boolean intersects(BitSet set) {
            throw new UnsupportedOperationException("not supported.");
        }

        public boolean isEmpty() {
            return delegee.isEmpty();
        }

        public int length() {
            throw new UnsupportedOperationException("not supported.");
        }

        public int nextClearBit(int fromIndex) {
            throw new UnsupportedOperationException("not supported.");
        }

        public int nextSetBit(int fromIndex) {
            return delegee.nextSetBit(fromIndex);
        }

        public void or(BitSet set) {
            throw new UnsupportedOperationException("not supported.");
        }

        public void set(int bitIndex, boolean value) {
            throw new UnsupportedOperationException("not supported.");
        }

        public void set(int fromIndex, int toIndex, boolean value) {
            throw new UnsupportedOperationException("not supported.");
        }

        public void set(int fromIndex, int toIndex) {
            throw new UnsupportedOperationException("not supported.");
        }

        public void set(int bitIndex) {
            delegee.fastSet(bitIndex);
        }

        public int size() {
            return (int) delegee.size();
        }

        public String toString() {
            return delegee.toString();
        }

        public void xor(BitSet set) {
            throw new UnsupportedOperationException("not supported.");
        }
    }
}
