package org.apache.lucene.util;
/**
 * Copyright 2006 Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.util.BitSet;
import java.util.Random;

import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.apache.lucene.search.Matcher;
import org.apache.lucene.util.BitsMatcher;
import org.apache.lucene.util.SortedVIntList;
import org.apache.solr.util.OpenBitSet;

public class TestMatchers extends TestCase {
    
  final static int BITS_MATCHER = 0;  
  final static int DENSE_OPEN_BITS_MATCHER = 1;
  final static int OPEN_BITS_MATCHER = 2;
  final static int VINT_MATCHER = 3;
  
  
  final static double[] densityMeasurmentPoints = {0.002,0.01, 0.03, 0.05, 0.07, 0.1, 0.3, 0.5, 0.7, 0.8, 0.9, 0.95};
  final static int MAX_TEST_SIZE = 2048*4096;
  final static int[] matchersUnderTest = {BITS_MATCHER,DENSE_OPEN_BITS_MATCHER,OPEN_BITS_MATCHER,VINT_MATCHER};
  final static String[] matchersUnderTestNames = {"\"BitSet Matcher\"","\"BitSetIterator Matcher\"","\"OpenBitSet Matcher\"","\"SortedVIntList Matcher\""};
  final static Matcher NULL_MATCHER = new  Matcher() {

    @Override
    public int doc() {
        return -1;
    }

    @Override
    public boolean next() throws IOException {
        return false;
    }

    @Override
    public boolean skipTo(int target) throws IOException {
        return false;
    }   
  };
  
  final static Random RANDOM_GENERATOR = new Random();
  
  /** Main for running test case by itself. */
  public static void main(String args[]) {
    TestRunner.run(new TestSuite(TestMatchers.class));
  }
  
  
  
  public void testEmpty() throws IOException{
      BitSet template = buildTemplate(0,0,0);
      Matcher m;
      
      m = buildMatcher(BITS_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
      
      m = buildMatcher(DENSE_OPEN_BITS_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
      
      m = buildMatcher(OPEN_BITS_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
      
      m = buildMatcher(VINT_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
      
      m = NULL_MATCHER;
      tstMatcherAgainstTemplate(m , template);
  }
  
  public void testNonEmpty() throws IOException{
      BitSet template = buildTemplate(1024 * 10, 0.8, 87);
      Matcher m;
      
      m = buildMatcher(BITS_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
      
      m = buildMatcher(DENSE_OPEN_BITS_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
      
      m = buildMatcher(OPEN_BITS_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
      
      m = buildMatcher(VINT_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
    
  }
  
  public void testIterationSpeed() throws IOException{
      BitSet template = null;
      long start, end;
      
      Matcher m;
      System.out.println("#BitSet size: " + MAX_TEST_SIZE);
      System.out.println("#Density" + '\t' + "Milliseconds per full next() scan" + '\t' + "Matcher");
      
      for(int j=0; j < matchersUnderTest.length; j++){
      System.out.println("\n");
          for(int i = 0; i < densityMeasurmentPoints.length; i++){
              template = buildTemplate(MAX_TEST_SIZE, densityMeasurmentPoints[i], 87);    
              System.out.print("\n" + densityMeasurmentPoints[i] + "\t");
              
              m = buildMatcher(matchersUnderTest[j], template);

              System.gc();
              try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                //who cares
            }
            
              start = System.nanoTime();
              iterate(m);   
              end = System.nanoTime();
              
              
              long timeMillisPerIteration = (end-start) / 1000;
              
              System.out.print(timeMillisPerIteration + "\t" + matchersUnderTestNames[j]);
              
          }
          
      }
      
      
      
      m = buildMatcher(BITS_MATCHER, template);
      start = System.nanoTime();
      iterate(m);
      end = System.nanoTime();
      
      
      m = buildMatcher(DENSE_OPEN_BITS_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
      
      m = buildMatcher(OPEN_BITS_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
      
      m = buildMatcher(VINT_MATCHER, template);
      tstMatcherAgainstTemplate(m , template);
    
  }
  
  
  
  
  void tstMatcherAgainstTemplate(Matcher m, BitSet template) throws IOException{
    
      for (int i = template.nextSetBit(0); i >= 0; i = template.nextSetBit(i+1)) {
          assertTrue("No end of Matcher at: " + i, m.next());
          assertEquals(i , m.doc());
      }
      assertTrue("End of Matcher", (! m.next())); 
      
  }


  Matcher buildMatcher(int type, BitSet template){
      OpenBitSet tmp;
      switch(type){
          case TestMatchers.BITS_MATCHER:
              return new BitsMatcher(template);
          case TestMatchers.DENSE_OPEN_BITS_MATCHER:
              tmp = new OpenBitSet(template.size());
              for (int i = template.nextSetBit(0); i >= 0; i = template.nextSetBit(i+1)) {
                  tmp.set(i);
              }
              tmp.trimTrailingZeros();
              return new DenseOpenBitsMatcher(tmp);
              
              
          case TestMatchers.OPEN_BITS_MATCHER:
              tmp = new OpenBitSet(template.size());
              for (int i = template.nextSetBit(0); i >= 0; i = template.nextSetBit(i+1)) {
                  tmp.set(i);
              }
              tmp.trimTrailingZeros();
              return new OpenBitsMatcher(tmp);
         
          case TestMatchers.VINT_MATCHER:
              return new SortedVIntList(template).getMatcher();
              
          default:
              return NULL_MATCHER;
      }
      
      
  }
  
  
  BitSet buildTemplate(int size, double density, long seed){
      BitSet bs = new BitSet(size);
      
      RANDOM_GENERATOR.setSeed(seed);
      
      for(int i = 0; i<size; i++){          
          if(RANDOM_GENERATOR.nextFloat() < density){
              bs.set(i);
          }
      }
      
      return bs;
  }
  
  
  void iterate(Matcher m) throws IOException{
      while(m.next()){
         m.doc(); 
      }
  }
  
}

