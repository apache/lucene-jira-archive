package org.apache.lucene.util;
/**
 * Copyright 2006 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.search.Matcher;
import org.apache.solr.util.OpenBitSet;

/** A Matcher constructed from a BitSet */
public class OpenBitsMatcher extends Matcher {
  private OpenBitSet bitset;
  private int docNr = -1;
  private boolean exhausted = false; // Redundant, avoid cycling, allow assert.
  
  public OpenBitsMatcher(OpenBitSet bitset) {
    this.bitset = bitset;
  }

  public int doc() {
    assert (docNr != -1) && (! exhausted);
    return docNr;
  }
  
  public boolean next() {
    // (docNr + 1) requires -1 initial value for docNr:
    return (! exhausted) && checkNextDocNr(bitset.nextSetBit(docNr + 1));
  }

  public boolean skipTo(int skipDocNr) {
    return (! exhausted) && checkNextDocNr( bitset.nextSetBit(skipDocNr));
  }

  private boolean checkNextDocNr(int d) {
    if (d == -1) {
      exhausted = true;
      return false;
    } else {
      docNr = d;
      return true;
    }
  }
}