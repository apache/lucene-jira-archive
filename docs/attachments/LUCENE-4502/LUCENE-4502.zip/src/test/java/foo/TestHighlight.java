package foo;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.highlight.*;
import org.apache.lucene.util.Version;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: nlabrot
 * Date: 24/10/12
 * Time: 09:33
 */
public class TestHighlight {

    private String text = "The text which appears before and after a highlighted term when using the simple formatter This parameter accepts per-field overrides.";

    @Test
    public void englishTest() throws ParseException, IOException, InvalidTokenOffsetsException {
        EnglishAnalyzer analyzer = new EnglishAnalyzer(Version.LUCENE_40);
        String fragment = highlight("\"which appears before and after a highlighted term when using the simple formatter\"" , analyzer);
        Assert.assertNotNull(fragment);
        Assert.assertNotNull(fragment , "The text <B>which</B> <B>appears</B> <B>before</B> and <B>after</B> a <B>highlighted</B> <B>term</B> <B>when</B> <B>using</B> the <B>simple</B> <B>formatter</B> This parameter accepts per-field overrides.");
    }

    @Test
    public void englishTest2() throws ParseException, IOException, InvalidTokenOffsetsException {
        EnglishAnalyzer analyzer = new EnglishAnalyzer(Version.LUCENE_40);
        String fragment = highlight("\"which appears before and after a highlighted term when using the\"" , analyzer);
        Assert.assertEquals(fragment , "The text <B>which</B> <B>appears</B> <B>before</B> and <B>after</B> a <B>highlighted</B> <B>term</B> <B>when</B> <B>using</B> the simple formatter This parameter accepts per-field overrides.");
    }

    @Test
    public void whitespaceTest() throws ParseException, IOException, InvalidTokenOffsetsException {
        WhitespaceAnalyzer analyzer = new WhitespaceAnalyzer(Version.LUCENE_40);
        String fragment = highlight("\"which appears before and after a highlighted term when using the simple formatter\"" , analyzer);
        Assert.assertEquals(fragment , "The text <B>which</B> <B>appears</B> <B>before</B> <B>and</B> <B>after</B> <B>a</B> <B>highlighted</B> <B>term</B> <B>when</B> <B>using</B> <B>the</B> <B>simple</B> <B>formatter</B> This parameter accepts per-field overrides.");
    }


    private String highlight(String strQuery , Analyzer analyzer) throws ParseException, IOException, InvalidTokenOffsetsException {
        QueryParser queryParser = new QueryParser(Version.LUCENE_40 , "text" , analyzer);

        Query query = queryParser.parse(strQuery);

        QueryScorer queryTermScorer = new QueryScorer(query , "text");
        queryTermScorer.setMaxDocCharsToAnalyze(1024);

        Highlighter highlighter = new Highlighter(queryTermScorer);
        highlighter.setTextFragmenter(new SimpleFragmenter(10000));

        return highlighter.getBestFragment(analyzer , "text" , text);
    }


}
