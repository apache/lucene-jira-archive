package org.audenaerde;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.LongField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.facet.index.FacetFields;
import org.apache.lucene.facet.params.FacetSearchParams;
import org.apache.lucene.facet.search.CountFacetRequest;
import org.apache.lucene.facet.search.FacetRequest;
import org.apache.lucene.facet.search.FacetResult;
import org.apache.lucene.facet.search.FacetsAccumulator;
import org.apache.lucene.facet.search.FacetsCollector;
import org.apache.lucene.facet.taxonomy.CategoryPath;
import org.apache.lucene.facet.taxonomy.TaxonomyReader;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyReader;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyWriter;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.SearcherFactory;
import org.apache.lucene.search.SearcherManager;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.testng.annotations.Test;

import com.google.common.collect.Lists;
import com.google.common.io.Files;

public class FacetSearchWhileIndexingLuceneTest
{
	TaxonomyReader taxoReader;

	FSDirectory taxoDirectory;

	FSDirectory indexDirectory;

	SearcherManager searcherManager;

	boolean running = true;

	private DirectoryTaxonomyWriter taxonomyWriter;

	private IndexWriter indexWriter;

	class Writer extends Thread
	{

		@Override
		public void run()
		{
			int doccount = 0;
			while ( FacetSearchWhileIndexingLuceneTest.this.running )
			{
				try
				{
					doccount++;
					if ( doccount % 1000 == 0 )
					{
						System.out.println( "Added 1000 docs.. Committing!" );
						FacetSearchWhileIndexingLuceneTest.this.indexWriter.commit();
						FacetSearchWhileIndexingLuceneTest.this.taxonomyWriter.commit();

					}
					String facet1Value = String.valueOf( (int) ( Math.random() * 10000.0 ) );
					Document doc = new Document();
					doc.add( new LongField( "doccount", doccount, Store.YES ) );
					doc.add( new StringField( "facet1", facet1Value, Store.YES ) );
					FacetFields ff = new FacetFields( FacetSearchWhileIndexingLuceneTest.this.taxonomyWriter );
					List<CategoryPath> cpList = Lists.newArrayList();
					cpList.add( new CategoryPath( "facet1", facet1Value ) );
					cpList.add( new CategoryPath( "facet2", String.valueOf( (int) ( Math.random() * 10000.0 ) ) ) );
					ff.addFields( doc, cpList );

					FacetSearchWhileIndexingLuceneTest.this.indexWriter.addDocument( doc );

				}
				catch ( IOException e )
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	class Searcher extends Thread
	{
		@Override
		public void run()
		{
			while ( FacetSearchWhileIndexingLuceneTest.this.running )
			{
				try
				{
					IndexSearcher searcher = FacetSearchWhileIndexingLuceneTest.this.searcherManager.acquire();
					TaxonomyReader taxo;
					//DirectoryTaxonomyReader tr = TaxonomyReader.openIfChanged(ref.taxonomyReader);
					if ( FacetSearchWhileIndexingLuceneTest.this.taxoReader == null )
					{
						FacetSearchWhileIndexingLuceneTest.this.refresh();
					}
					taxo = FacetSearchWhileIndexingLuceneTest.this.taxoReader;

					final List<FacetRequest> facetRequests = new ArrayList<FacetRequest>();

					//we request one extra.
					final CountFacetRequest facetRequest = new CountFacetRequest( new CategoryPath( "facet1" ), 10 );
					facetRequests.add( facetRequest );

					final FacetSearchParams facetSearchParams = new FacetSearchParams( facetRequests );

					FacetsCollector facetsCollector =
						FacetsCollector.create( FacetsAccumulator.create( facetSearchParams, searcher.getIndexReader(), taxo ) );

					searcher.search( new MatchAllDocsQuery(), facetsCollector );

					final List<FacetResult> collectedFacets = facetsCollector.getFacetResults();
					FacetSearchWhileIndexingLuceneTest.this.searcherManager.release( searcher );
					System.out.println( collectedFacets.get( 0 ).getFacetResultNode() );
					Thread.sleep( 1000 );

				}
				catch ( InterruptedException e )
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				catch ( Throwable e )
				{
					e.printStackTrace();
					System.exit( 1 );
				}

			}
		}
	}

	class Refresher extends Thread
	{
		@Override
		public void run()
		{
			while ( FacetSearchWhileIndexingLuceneTest.this.running )
			{
				FacetSearchWhileIndexingLuceneTest.this.refresh();
				try
				{
					FacetSearchWhileIndexingLuceneTest.this.refresh();
					Thread.sleep( 1000 );
				}
				catch ( InterruptedException e )
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

	}

	public void refresh()
	{
		System.out.println( "Start refreshing!" );
		try
		{
			FacetSearchWhileIndexingLuceneTest.this.searcherManager.maybeRefresh();
			if ( FacetSearchWhileIndexingLuceneTest.this.taxoReader == null )
			{
				FacetSearchWhileIndexingLuceneTest.this.taxoReader =
					new DirectoryTaxonomyReader( FacetSearchWhileIndexingLuceneTest.this.taxoDirectory );
			}
			else
			{
				TaxonomyReader newReader = TaxonomyReader.openIfChanged( FacetSearchWhileIndexingLuceneTest.this.taxoReader );
				if ( newReader != null )
				{
					FacetSearchWhileIndexingLuceneTest.this.taxoReader.close();
					FacetSearchWhileIndexingLuceneTest.this.taxoReader = newReader;
				}
			}

		}

		catch ( IOException e )
		{
			e.printStackTrace();
		}
		System.out.println( "Done refreshing!" );
	}

	@Test
	public void doit() throws IOException, InterruptedException
	{
		File tempdir = Files.createTempDir();
		String indexLocation = tempdir.getAbsolutePath();

		System.out.println( indexLocation );

		this.indexDirectory = FSDirectory.open( new File( indexLocation, "index" ) );
		this.taxoDirectory = FSDirectory.open( new File( indexLocation, "taxo" ) );

		this.indexWriter =
			new IndexWriter( this.indexDirectory, new IndexWriterConfig( Version.LUCENE_44, new StandardAnalyzer( Version.LUCENE_44 ) ) );
		this.taxonomyWriter = new DirectoryTaxonomyWriter( this.taxoDirectory, OpenMode.CREATE_OR_APPEND );

		this.indexWriter.commit();
		this.taxonomyWriter.commit();
		this.taxonomyWriter.close();
		this.indexWriter.close();
		this.taxoDirectory.close();
		this.indexDirectory.close();

		//reopen
		this.indexDirectory = FSDirectory.open( new File( indexLocation, "index" ) );
		this.taxoDirectory = FSDirectory.open( new File( indexLocation, "taxo" ) );
		this.indexWriter =
			new IndexWriter( this.indexDirectory, new IndexWriterConfig( Version.LUCENE_44 , new StandardAnalyzer( Version.LUCENE_44 ) ) );
		this.taxonomyWriter = new DirectoryTaxonomyWriter( this.taxoDirectory, OpenMode.CREATE_OR_APPEND );

		this.searcherManager = new SearcherManager( this.indexDirectory, new SearcherFactory() );

		Refresher r = new Refresher();
		Writer w = new Writer();
		Searcher s = new Searcher();
		r.start();
		w.start();
		s.start();
		r.join();
	}
}
