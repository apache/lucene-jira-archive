/* MonitorIndexDirSize.java
 *
 * (C) Copyright IBM Corporation 2010
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of the IBM Corporation, ("Confidential Information"). Redistribution
 * of the source code or binary form is not permitted without prior
 * authorization from IBM Corporation.
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */

package com.search;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;



/**
 * One-sentence description of MonitorIndexDirSize goes here.
 * <p>
 * More detailed explanation of MonitorIndexDirSize goes here.
 * <p>
 * @author Created by %created_by% %date_created%
 * @author Modified by %derived_by: %date_created: %
 * @version %version: %
 */
public class MonitorIndexDirSize
{
	public static void main(String[] args)
	{
		String indexDir = args[0];
		System.out.println("Index Dir is : " + indexDir);
		File dir = new File(indexDir);
		File dataFile = new File("data_log.txt");
		int sleepTime = Integer.parseInt(args[1]);
		System.out.println("Sleeping time is - " + sleepTime + " seconds");
		long redZone = 500 * 1024 * 1024;
		long orangeZone = 1000 * 1024 * 1024;
		String redIndicator = "#########";
		String orangeIndicator = "*******";
		String indicator = "";
		
		if (!dataFile.exists())
		{
			try
			{
				dataFile.createNewFile();
			}
			catch (IOException ioe)
			{
				ioe.printStackTrace();
			}
		}
		
		while(true)
		{
			try
			{
				
				FileWriter fstream = new FileWriter("data_log.txt", true);
		        BufferedWriter out = new BufferedWriter(fstream);
		        
		        long dirSize = getDirSize(dir);
		        
		        if (dirSize >= orangeZone && dirSize < redZone)
		        {
		        	indicator = orangeIndicator;
		        }
		        else if (dirSize >= redZone)
		        {
		        	indicator = redIndicator;
		        }
		        
		        out.write(indicator + "Index directory size at : " + new Date() + " - " + (dirSize/1024)/1024 + " MB");
		        out.write(System.getProperty("line.separator"));
		        out.close();
		        Thread.sleep(sleepTime * 1000);
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
	
	public static long getDirSize(File directory)
	{
		File[] files = directory.listFiles();
		long size = 0;
		
		for (File file : files)
		{
			if (file.isFile())
			{
				size+=file.length();
			}
			else
			{
				size+=getDirSize(file);
			}
		}
		
		return size;
	}
}
