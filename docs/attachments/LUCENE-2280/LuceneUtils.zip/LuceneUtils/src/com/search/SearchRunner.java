/* SearchRunner.java
 *
 * (C) Copyright IBM Corporation 2010
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of the IBM Corporation, ("Confidential Information"). Redistribution
 * of the source code or binary form is not permitted without prior
 * authorization from IBM Corporation.
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */

package com.search;



/**
 * One-sentence description of SearchRunner goes here.
 * <p>
 * More detailed explanation of SearchRunner goes here.
 * <p>
 * @author Created by %created_by% %date_created%
 * @author Modified by %derived_by: %date_created: %
 * @version %version: %
 */
public class SearchRunner extends Thread
{
	
	public void run()
	{
		while (true)
		{
			try
			{
				SearchUtils.index();
				//SearchUtils.takeBackup();
				//sleep(5000);
				SearchUtils.optimize();
				System.out.println("");
				System.out.println("");
				System.out.println("");
				System.out.println("");
				System.out.println("Sleeping now, can stop indexer....");
				System.out.println("");
				sleep(5000);
			}
			catch (InterruptedException e)
			{
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
			catch (Exception e)
			{
				System.out.println("**************Exception thrown by optimizer");
				System.out.println("");
				e.printStackTrace();
			}
		}
	}

}
