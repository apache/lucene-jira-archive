/* RunSearchOp.java
 *
 * (C) Copyright IBM Corporation 2010
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of the IBM Corporation, ("Confidential Information"). Redistribution
 * of the source code or binary form is not permitted without prior
 * authorization from IBM Corporation.
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */

package com.search;



/**
 * One-sentence description of RunSearchOp goes here.
 * <p>
 * More detailed explanation of RunSearchOp goes here.
 * <p>
 * @author Created by %created_by% %date_created%
 * @author Modified by %derived_by: %date_created: %
 * @version %version: %
 */
public class RunSearchOp
{
	public static void main(String[] args)
	{
		/*try
		{
			while(true)
			{
				for(int i = 0; i <=100; i++)
				{
					SearchUtils.index();
					SearchUtils.optimize();
				}
				
				Thread.sleep(3000);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}*/
		
		SearchRunner sr = new SearchRunner();
		sr.start();
		
		//SearchUtils.takeBackup();
	}
}
