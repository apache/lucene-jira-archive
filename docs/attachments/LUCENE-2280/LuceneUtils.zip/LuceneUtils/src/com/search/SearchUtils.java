/* SearchUtils.java
 *
 * (C) Copyright IBM Corporation 2010
 * All Rights Reserved.
 *
 * This software is the confidential and proprietary information
 * of the IBM Corporation, ("Confidential Information"). Redistribution
 * of the source code or binary form is not permitted without prior
 * authorization from IBM Corporation.
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has
 * been deposited with the U.S. Copyright Office.
 */

package com.search;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.nio.channels.FileChannel;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;




/**
 * One-sentence description of SearchUtils goes here.
 * <p>
 * More detailed explanation of SearchUtils goes here.
 * <p>
 * @author Created by %created_by% %date_created%
 * @author Modified by %derived_by: %date_created: %
 * @version %version: %
 */
public class SearchUtils
{
	private static String indexFilePath = "D:\\eclipse_WASCE\\eclipse\\workspace\\LuceneUtils\\search_index";
	private static String bkpFilePath = "D:\\eclipse_WASCE\\eclipse\\workspace\\LuceneUtils\\bkp";
	private static String[] stopWords = null;
	private static boolean loggedStopWordError = false;
	public static String backupFile = null;
	
	public static void index()
	{
		IndexWriter writer = null;
		
		try
		{
			// Now create an index writer and go through the directory structure starting with
			// pathToIndex and indexing everything that is found.
			try
			{
				writer = new IndexWriter(indexFilePath, getAnalyzer(), false);
				//writer.setSimilarity(new ChangeSimilarity());
			}
			catch (IOException e)
			{
				//create the index if it didn't exist.
				writer = new IndexWriter(indexFilePath, getAnalyzer(), true);
			}
		
			writer.setMergeFactor(100);
			writer.setMaxBufferedDocs(100);
			
			Document doc = null;
			int i = 0;
			System.out.println("Start indexing...");
			while (i <= 10000)
			{
				doc = new Document();
				doc.add(new Field("some_text", "Some text to serach goes here " + i, Field.Store.NO, Field.Index.TOKENIZED));
				writer.addDocument(doc);
				i++;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		finally
		{
			try
			{
				if(writer != null) 
				{
					writer.close(false);
				}
			}
			catch (CorruptIndexException e)
			{
				e.printStackTrace();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}
	
	public static void optimize()
	{
		IndexWriter writer = null;
		System.out.println("**Start optimizing..");
		try
		{
			File index = new File(indexFilePath);
			
			writer = new IndexWriter(index, getAnalyzer(), !index.exists());
			//SearchUtils.takeBackup();
			writer.optimize();
		}
		catch(Exception e)
		{
			//restoreBackup();
			System.out.println( e);
		}
		finally
		{
			if(writer != null)
			{
				try{writer.close(false);}
				catch(IOException e){/* Do Nothing */}
			}
		}
		
	}
	
	public static Analyzer getAnalyzer() throws InstantiationException, ClassNotFoundException, IllegalAccessException, InvocationTargetException
	{
		return setupAnalyzer();
	}
	
	private static Analyzer setupAnalyzer()
	throws InstantiationException, ClassNotFoundException, IllegalAccessException, InvocationTargetException 
	{
		loadStopWords();
			
		if(stopWords == null)
		{
			System.out.println("Unable to load stopword list, using default.");
			return((Analyzer) Class.forName("org.apache.lucene.analysis.standard.StandardAnalyzer").newInstance());
		}
		
		Constructor constructors[] = Class.forName("org.apache.lucene.analysis.standard.StandardAnalyzer").getConstructors();
		
		for(int i=0;i<constructors.length;i++)
		{
			Class paramTypes[] = constructors[i].getParameterTypes();

			// if the analyzer has a constructor that takes stop words as parameter
			if((paramTypes.length == 1)&&(paramTypes[0].isInstance(stopWords)))
				return((Analyzer) constructors[i].newInstance(new Object[] {stopWords}));																				
		}
			
		if (!loggedStopWordError)
		{
			System.out.println("The Search Analyzer does not accept stop words.");
			System.out.println("The stop words specified in stopwords.txt file would not be considered while indexing.");
			loggedStopWordError = true;
		}

		return((Analyzer) Class.forName("org.apache.lucene.analysis.standard.StandardAnalyzer").newInstance());
	}
	
	// Returns a String array of stopwords
	private static void loadStopWords()
	{
		if(stopWords != null)
			return;
			
		String stopwordFile = "stopwords.txt";
		
		// If the stop word list doesn't exist, return null
		if(!(new File(stopwordFile)).exists())
			return;
		
		BufferedReader pInputStream  = null;
		StringBuilder   stopwordList  = new StringBuilder();
		String         CurrentBuffer = null;
		
		try
		{
			try
			{
				pInputStream = new BufferedReader(new InputStreamReader((new FileInputStream(stopwordFile)),"UTF-8"));
			}
			catch(FileNotFoundException e)
			{
				System.out.println("Read file not found: " + stopwordFile);
				return;
			}
			catch(SecurityException e)
			{
				System.out.println("Read file security error: " + stopwordFile);
				return;
			}
			catch(UnsupportedEncodingException e)
			{
				System.out.println("Unsupported encoding of stop word list");
				return;
			}
		
			while((CurrentBuffer = pInputStream.readLine()) != null)
			{
				stopwordList.append(CurrentBuffer);
			}
		}
		catch(IOException e)
		{
			System.out.println("Error reading from stop word list file");
			return;
		}
		catch(Exception e)
		{
			System.out.println(e);
			return;
		}
		finally
		{
			if(pInputStream != null)
			{
				try{pInputStream.close();}
				catch(IOException e){/* Do Nothing */}
			}
		}
		
		StringTokenizer st = new StringTokenizer(stopwordList.toString(), ",");
		Vector          v  = new Vector();
		
		while(st.hasMoreTokens())
		{
			v.add(st.nextToken().trim());
		}
		
		stopWords = new String[v.size()];
		v.copyInto(stopWords);
	}
	
	public static void takeBackup()
	{
		File indexDir = new File(indexFilePath);
		System.out.println("file1");
		if (indexDir.isDirectory())
		{
			System.out.println("file");
			String[] files = indexDir.list();
			
			for (String file : files)
			{
				System.out.println("file : " + file);
				if (file.startsWith("segments_"))
				{
					System.out.println("Taking backup of file : " + file);
					File source = new File (indexFilePath + "\\" + file);
					File dest = new File (bkpFilePath + "\\" + file);
					backupFile = file;
					
					try
					{
						copyFile(source, dest);
					}
					catch (IOException e)
					{
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	public static void copyFile(File fromFile, final File toFile) throws IOException
	{
		FileChannel source = null;
		FileChannel destination = null;

		toFile.createNewFile();

		try
		{
			source = new FileInputStream(fromFile).getChannel();
			destination = new FileOutputStream(toFile).getChannel();

			source.transferTo(0, Long.MAX_VALUE, destination);
		}
		finally
		{
			closeQuietly(source);
			closeQuietly(destination);
		}


	}
	
	public static void closeQuietly(Closeable closeable)
	{
		if (null == closeable) return;
		
		try
		{
			closeable.close();
		}
		catch (IOException e)
		{
			// ignore. There is almost never a way to handle this
		}
	}
	
	public static void restoreBackup()
	{
		try
		{
			copyFile(new File(bkpFilePath, backupFile), new File(indexFilePath, backupFile));
		}
		catch (IOException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}
