import org.apache.lucene.util.*;
import org.apache.lucene.store.*;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.search.*;
import org.apache.lucene.analysis.core.*;
import org.apache.lucene.queryParser.*;
import java.util.*;
import java.io.*;

// commits: single, multi, delsingle, delmulti

// trunk:
//   javac -cp build/classes/java:../modules/analysis/build/common/classes/java  SearchPerfTest.java; java -cp .:build/classes/java:../modules/analysis/build/common/classes/java SearchPerfTest /x/lucene/trunkwiki/index 2 10000 >& out.x

// 3x:
//   javac -cp build/classes/java  SearchPerfTest.java; java -cp .:build/classes/java SearchPerfTest /x/lucene/3xwiki/index 2 10000 >& out.x

public class SearchPerfTest {

  private static class Result {
    QueryAndSort qs;
    int colType;
    long t;
    int totHits;
    long check;
  }

  private static class SearchThread extends Thread {

    private final IndexSearcher s;
    private final QueryAndSort[] queries;
    private final int numIter;
    public final List<Result> results = new ArrayList<Result>();

    public SearchThread(Random r, IndexSearcher s, List<QueryAndSort> queriesList, int numIter) {
      this.s = s;
      List<QueryAndSort> queries = new ArrayList<QueryAndSort>(queriesList);
      Collections.shuffle(queries, r);
      this.queries = queries.toArray(new QueryAndSort[queries.size()]);
      this.numIter = numIter;
    }

    public void run() {
      try {

        final IndexSearcher s = this.s;
        final QueryAndSort[] queries = this.queries;

        int queryUpto = 0;
        long totSum = 0;

        for(int iter=0;iter<numIter;iter++) {
          for(int q=0;q<queries.length;q++) {
            final QueryAndSort qs = queries[q];

            long t0 = System.nanoTime();
            final TopDocs hits;
            if (qs.s == null) {
              hits = s.search(qs.q, 10);
            } else {
              hits = s.search(qs.q, null, 10, qs.s);
            }
            final long delay = System.nanoTime()-t0;
            totSum += hits.totalHits;
            long check = 0;
            for(int i=0;i<hits.scoreDocs.length;i++) {
              totSum += hits.scoreDocs[i].doc;
              check += hits.scoreDocs[i].doc;
            }
            // discard first 3 -- warmup
            if (iter >= 3) {
              Result r = new Result();
              r.t = delay;
              r.qs = qs;
              r.totHits = hits.totalHits;
              r.check = check;
              results.add(r);
            }
          }
        }
        System.out.println("checksum=" + totSum);
      } catch (IOException ioe) {
        throw new RuntimeException(ioe);
      }
    }
  }

  private static String[] queryStrings = {
    "*:*",
    "states",
    "unite*",
    "united OR states",
    "united AND states",
    "\"united states\"",
  };

  private static class QueryAndSort {
    final Query q;
    final Sort s;

    public QueryAndSort(Query q, Sort s) {
      this.q = q;
      this.s = s;
    }
  }

  private static IndexCommit findCommitPoint(String commit, Directory dir) throws IOException {
    Collection<IndexCommit> commits = IndexReader.listCommits(dir);
    for (final IndexCommit ic : commits) {
      Map<String,String> map = ic.getUserData();
      String ud = null;
      if (map != null) {
        ud = map.get("userData");
        if (ud != null && ud.equals(commit)) {
          return ic;
        }
      }
    }
    throw new RuntimeException("could not find commit '" + commit + "'");
  }

  public static void main(String[] args) throws Exception {

    // args: indexPath numThread numIterPerThread

    // eg java SearchPerfTest /path/to/index 4 100

    final Directory dir = FSDirectory.open(new File(args[0]));
    final long t0 = System.currentTimeMillis();
    final IndexSearcher s;
    if (args.length == 4) {
      final String commit = args[3];
      System.out.println("open commit=" + commit);
      s = new IndexSearcher(IndexReader.open(findCommitPoint(commit, dir), true));
    } else {
      // open last commit
      s = new IndexSearcher(dir);
    }

    System.out.println("reader=" + s.getIndexReader());

    s.search(new TermQuery(new Term("body", "bar")), null, 10, new Sort(new SortField("unique1000000", SortField.STRING)));
    final long t1 = System.currentTimeMillis();
    System.out.println("warm time = " + (t1-t0)/1000.0);

    //System.gc();
    //System.out.println("RAM: " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()));

    final int threadCount = Integer.parseInt(args[1]);
    final int numIterPerThread = Integer.parseInt(args[2]);

    final List<QueryAndSort> queries = new ArrayList<QueryAndSort>();
    QueryParser p = new QueryParser(Version.LUCENE_31, "body", new SimpleAnalyzer(Version.LUCENE_31));

    for(int i=0;i<queryStrings.length;i++) {
      Query q = p.parse(queryStrings[i]);

      // sort by score:
      queries.add(new QueryAndSort(q, null));

      for(int j=0;j<7;j++) {
        final String sortField;
        switch(j) {
        case 0:
          sortField = "country";
          break;
        case 1:
          sortField = "unique10";
          break;
        case 2:
          sortField = "unique100";
          break;
        case 3:
          sortField = "unique1000";
          break;
        case 4:
          sortField = "unique10000";
          break;
        case 5:
          sortField = "unique100000";
          break;
        case 6:
          sortField = "unique1000000";
          break;
        // not necessary, but compiler disagrees:
        default:
          sortField = null;
          break;
        }
        queries.add(new QueryAndSort(q, new Sort(new SortField(sortField, SortField.STRING))));
      }
    }

    final Random rand = new Random(17);

    final SearchThread[] threads = new SearchThread[threadCount];
    for(int i=0;i<threadCount-1;i++) {
      threads[i] = new SearchThread(rand, s, queries, numIterPerThread);
      threads[i].start();
    }

    // I run one thread:
    threads[threadCount-1] = new SearchThread(rand, s, queries, numIterPerThread);
    threads[threadCount-1].run();

    for(int i=0;i<threadCount-1;i++) {
      threads[i].join();
    }

    System.out.println("ns by query/coll:");
    for(QueryAndSort qs : queries) {
      boolean pr = false;
      for(int t=0;t<threadCount;t++) {
        for(Result r : threads[t].results) {
          if (r.qs == qs) {
            if (!pr) {
              System.out.println("  q=" + qs.q + " s=" + qs.s + " h=" + r.totHits);
              pr = true;
            }
            System.out.println("    " + r.t + " c=" + r.check);
          }
        }
      }
    }
  }
}