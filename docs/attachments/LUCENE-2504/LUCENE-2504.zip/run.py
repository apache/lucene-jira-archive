import cPickle
import os
import re

def run(cmd):
  if os.system(cmd):
    raise RuntimeError('failed: %s' % cmd)

reQuery = re.compile('^q=(.*?) s=(.*?) h=(.*?)$')
reResult = re.compile(r'^(\d+) c=(.*?)$')

TEST = 'trunk'
BASE = '3x'

def getResults(fname):
  all = {}

  start = False
  best = None
  for l in open(fname).readlines():

    l = l.strip()
    if not start:
      if l == 'ns by query/coll:':
        start = True
      continue
      
    if l.startswith('q='):
      if best is not None:
        all[(query, sort)] = best, hitCount, check
        best = None
      query, sort, hitCount = reQuery.match(l).groups()
    else:
      m = reResult.match(l)
      t = long(m.group(1))
      check = long(m.group(2))
      if best is None or t < best:
        best = t

  all[(query, sort)] = best, hitCount, check
  return all

iters = 23
threadCount = 2

def save(results):
  open('/root/src/clean/lucene/results2.pk', 'wb').write(cPickle.dumps(results))  

def runTests(test, results):

  print '%s...' % test

  if test == 'trunk':
    os.chdir('/root/src/clean/lucene')
    cp = '.:build/classes/java:../modules/analysis/build/common/classes/java'
  else:
    os.chdir('/root/src/%s/lucene' % test)
    cp = '.:build/classes/java'

  if os.system('/usr/local/src/apache-ant-1.7.1/bin/ant compile'):
    raise RuntimeError('compile failed')
  
  run('javac -cp %s SearchPerfTest.java' % cp)

  #for commit in ('single', 'multi', 'delsingle', 'delmulti'):
  for commit in ('single', 'delmulti'):
    print '  %s...' % commit
    run('java -server -Xmx1g -Xms1g -cp %s SearchPerfTest /x/lucene/%swiki/index 2 %s %s >& res-%s.txt' % (cp, test, iters, commit, commit))
    results[(test, commit)] = getResults('res-%s.txt' % commit)
    save(results)

results = {}

runTests(TEST, results)
runTests(BASE, results)
