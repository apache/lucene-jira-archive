import sys
import re
import cPickle

all = cPickle.loads(open('/root/src/clean/lucene/results2.pk').read())

allQueries = set()
allSorts = set()

TEST = 'trunk'
BASE = '3x'

#for cp in ('single', 'multi', 'delsingle', 'delmulti'):

cp = 'delmulti'

for (q, s), t in all[(TEST, cp)].items():
  allQueries.add(q)
  allSorts.add(s)

print '||Query',

l = list(allSorts)
l.sort()

reSort = re.compile('<string: "(.*?)">')

w = sys.stdout.write

for s in l:
  if s == 'null':
    s = 'score'
  else:
    s = reSort.match(s).group(1)
  s = s.replace('unique1000000', 'unique1M')
  s = s.replace('unique100000', 'unique100K')
  s = s.replace('unique10000', 'unique10K')
  s = s.replace('unique1000', 'unique1K')
  w('||%s' % s)

w('||\n')

l2 = list(allQueries)
l2.sort()

# TODO: assert checksums agree across versions

for q in l2:
  w('|%s' % q.replace('body:', '').replace('*:*', '<all>'))
  for s in l:
    trunk, hitCount, check = all[(TEST, cp)][(q, s)]
    base, hitCount2, check2 = all[(BASE, cp)][(q, s)]
    trunk /= 1000000.0
    base /= 1000000.0
    if hitCount != hitCount2:
      raise RuntimeError('hit counts differ: %s vs %s' % (hitCount, hitCount2))
    if check != check2:
      raise RuntimeError('check counts differ: %s vs %s' % (check, check2))
    if trunk < base:
      color = 'green'
      sign = -1
    else:
      color = 'red'
      sign = 1
    w('|{color:%s}%.1f%%{color}' % (color, 100.0*sign*(trunk - base)/base))
  w('|\n')
