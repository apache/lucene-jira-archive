package org.apache.lucene.seed_issue;

import org.apache.lucene.util.StringHelper;

public class SomeClassUsingStringHelper {
	public Integer doStuffWithStringHelper() {
		return StringHelper.GOOD_FAST_HASH_SEED;
	}
}
