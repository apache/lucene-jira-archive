package org.apache.lucene.seed_issue;

import org.junit.Test;

import static org.junit.Assert.*;

public class SomeClassUsingStringHelperTest {
	@Test
	public void breakingTest() {
		assertNotNull(new SomeClassUsingStringHelper().doStuffWithStringHelper());
	}
}