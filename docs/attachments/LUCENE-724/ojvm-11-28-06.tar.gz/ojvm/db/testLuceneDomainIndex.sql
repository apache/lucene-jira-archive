set long 10000 lines 140 pages 50 timing on echo on
set serveroutput on

begin
  dbms_java.set_output(32000);
end;
/


create table t1 (f1 number, f2 varchar2(200));
insert into t1 values (1, 'ravi');
insert into t1 values (3, 'murthy');
commit;

create index it1 on t1(f2) indextype is LuceneIndex parameters('analyzer:org.apache.lucene.WhitespaceAnalyzer,query:org.apache.lucene.search.FuzzyQuery');

-- query
explain plan for
select * from t1 where contains(f2, 'ravi') > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where contains(f2, 'ravi') > 0;

explain plan for
select * from t1 where contains(f2, 'aaa') > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where contains(f2, 'aaa') > 0;

-- INSERT TESTS
INSERT INTO t1 VALUES (6, 'cheuk');
INSERT INTO t1 VALUES (7, 'chau');

-- query from index table
SELECT prefix,name FROM lucene_index;

-- UPDATE TEST
UPDATE t1 SET f2 = 'Nipun' WHERE f1 = 3;

INSERT INTO t1 VALUES (16, 'ravi marcelo');
INSERT INTO t1 VALUES (17, 'marcelo');

select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;

explain plan for
select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where contains(f2, 'Nipun') > 0;

explain plan for
select * from t1 where contains(f2, 'Nipun') > 0;
set echo off
@@explainPlan
set echo on

select contains(f2,'ravi') from t1;

explain plan for
select contains(f2,'ravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST
DELETE FROM t1 WHERE f2 = 'ravi';

explain plan for
select * from t1 where contains(f2, 'ravi') > 0;
set echo off
@@explainPlan
set echo on

-- DROP TEST
drop table t1;

create table t1 (f1 number, f2 CLOB);
insert into t1 values (1, 'ravi');
insert into t1 values (3, 'murthy');
commit;

create index it1 on t1(f2) indextype is LuceneIndex parameters('analyzer:org.apache.lucene.WhitespaceAnalyzer,query:org.apache.lucene.search.FuzzyQuery');

-- query
select * from t1 where contains(f2, 'ravi') > 0;

explain plan for
select * from t1 where contains(f2, 'ravi') > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where contains(f2, 'aaa') > 0;

explain plan for
select * from t1 where contains(f2, 'aaa') > 0;
set echo off
@@explainPlan
set echo on

-- INSERT TESTS
INSERT INTO t1 VALUES (6, 'cheuk');
INSERT INTO t1 VALUES (7, 'chau');

-- query from index table
SELECT prefix,name FROM lucene_index;

-- UPDATE TEST
UPDATE t1 SET f2 = 'Nipun' WHERE f1 = 3;

INSERT INTO t1 VALUES (16, 'ravi marcelo');
INSERT INTO t1 VALUES (17, 'marcelo');

select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;

explain plan for
select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where contains(f2, 'Nipun') > 0;

explain plan for
select * from t1 where contains(f2, 'Nipun') > 0;
set echo off
@@explainPlan
set echo on

select contains(f2,'ravi') from t1;

explain plan for
select contains(f2,'ravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST
DELETE FROM t1 WHERE f1 = 1;

select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;

explain plan for
select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

-- DROP TEST
drop table t1;

create table t1 (f1 number, f2 XMLType);
insert into t1 values (1, XMLType('<emp id="1"><name>ravi</name></emp>'));
insert into t1 values (3, XMLType('<emp id="3"><name>murthy</name></emp>'));
commit;

create index it1 on t1(f2) indextype is LuceneIndex parameters('analyzer:org.apache.lucene.WhitespaceAnalyzer,query:org.apache.lucene.search.FuzzyQuery');

-- query
select * from t1 where contains(f2, 'ravi') > 0;

explain plan for
select * from t1 where contains(f2, 'ravi') > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where contains(f2, 'aaa') > 0;

explain plan for
select * from t1 where contains(f2, 'aaa') > 0;
set echo off
@@explainPlan
set echo on

-- INSERT TESTS
INSERT INTO t1 VALUES (6, XMLType('<emp id="6"><name>cheuk</name></emp>'));
INSERT INTO t1 VALUES (7, XMLType('<emp id="7"><name>chau</name></emp>'));

-- query from index table
SELECT prefix,name FROM lucene_index;

-- UPDATE TEST
UPDATE t1 SET f2 = XMLType('<emp id="3"><name>Nipun</name></emp>') WHERE f1 = 3;

INSERT INTO t1 VALUES (16, XMLType('<emp id="10"><name>ravi marcelo</name></emp>'));
INSERT INTO t1 VALUES (17, XMLType('<emp id="16"><name>marcelo</name></emp>'));

select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;

explain plan for
select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where contains(f2, 'Nipun') > 0;

explain plan for
select * from t1 where contains(f2, 'Nipun') > 0;
set echo off
@@explainPlan
set echo on

select contains(f2,'ravi') from t1;

explain plan for
select contains(f2,'ravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST
DELETE FROM t1 WHERE f1 = 1;

select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;

explain plan for
select score(1),f2 from t1 where contains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

-- DROP TEST
drop table t1;
