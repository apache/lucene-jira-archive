rem usage notes:
rem sqlplus sys/change_on_install@orcl @db/create-user.sql lucene
rem run on the server machine, because it use dbms_java.loadjava

set define '&';
define lucene_owner=&1;

drop user &lucene_owner cascade;

create user LUCENE identified by &lucene_owner
default tablespace users
temporary tablespace temp
quota unlimited on users;

grant connect,resource to &lucene_owner;
grant create public synonym to &lucene_owner;
grant create library to &lucene_owner;
grant create any directory to &lucene_owner;
grant create any operator,  create indextype, create table to &lucene_owner;

begin
  dbms_java.grant_permission( UPPER('&lucene_owner'),'SYS:java.io.FilePermission', '/junit.properties', 'read' );
  dbms_java.grant_permission( UPPER('&lucene_owner'),'SYS:java.lang.RuntimePermission', 'getClassLoader', '' );
  dbms_java.grant_permission( UPPER('&lucene_owner'),'SYS:java.lang.RuntimePermission', 'accessDeclaredMembers', '' );
end;
/

exit
