
---------------------------------------------------------------------
--    LUCENE Index Method  Implemented as Trusted Callouts  --
---------------------------------------------------------------------
-- Drops
drop indextype LuceneIndex;
drop operator Score;
drop operator Contains;
drop type LuceneDomainIndex force;

-- CREATE INDEXTYPE IMPLEMENTATION TYPE
create type LuceneDomainIndex authid current_user as object
(
  scanctx integer,
  STATIC FUNCTION TextContains(Text IN VARCHAR2, Key IN VARCHAR2,
                               indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextContains(
                java.lang.String, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
  STATIC FUNCTION TextContains(Text IN CLOB, Key IN VARCHAR2,
                               indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextContains(
                oracle.sql.CLOB, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
  STATIC FUNCTION TextContains(Text IN XMLTYPE, Key IN VARCHAR2,
                               indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextContains(
                oracle.xdb.XMLType, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',

  STATIC FUNCTION TextScore(Text IN VARCHAR2, Key IN VARCHAR2,
                            indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextScore(
                java.lang.String, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
  STATIC FUNCTION TextScore(Text IN CLOB, Key IN VARCHAR2,
                            indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextScore(
                oracle.sql.CLOB, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
                
  STATIC FUNCTION TextScore(Text IN XMLTYPE, Key IN VARCHAR2,
                            indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextScore(
                oracle.xdb.XMLType, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',

  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList) RETURN NUMBER,
  
  STATIC FUNCTION ODCIIndexCreate (ia sys.ODCIIndexInfo, parms VARCHAR2,
                                   env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexCreate(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  STATIC FUNCTION ODCIIndexDrop(ia sys.ODCIIndexInfo, env sys.ODCIEnv) RETURN NUMBER,

  STATIC FUNCTION ODCIIndexTruncate(ia SYS.ODCIIndexInfo, env SYS.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexTruncate(oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
                
  STATIC FUNCTION ODCIIndexInsert(ia sys.ODCIIndexInfo, rid VARCHAR2, newval sys.XMLType, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME 
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIInsert(oracle.ODCI.ODCIIndexInfo, java.lang.String,
                oracle.xdb.XMLType, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  STATIC FUNCTION ODCIIndexInsert(ia sys.ODCIIndexInfo, rid VARCHAR2, newval VARCHAR2, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME 
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIInsert(oracle.ODCI.ODCIIndexInfo, java.lang.String,
                java.lang.String, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexDelete(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval sys.XMLType, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIDelete(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		oracle.xdb.XMLType, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexDelete(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval VARCHAR2, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIDelete(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		java.lang.String, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexUpdate(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval sys.XMLType, newval sys.XMLType, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIUpdate(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		oracle.xdb.XMLType, oracle.xdb.XMLType, oracle.ODCI.ODCIEnv) return 
		java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexUpdate(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval VARCHAR2, newval VARCHAR2, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIUpdate(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		java.lang.String, java.lang.String, oracle.ODCI.ODCIEnv) return 
		java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexStart(sctx IN OUT LuceneDomainIndex,
        ia SYS.ODCIIndexInfo, op SYS.ODCIPredInfo, qi sys.ODCIQueryInfo,
        strt number, stop number,
        cmpval VARCHAR2, env SYS.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIStart(org.apache.lucene.indexer.LuceneDomainIndex[],
                oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIPredInfo, 
		oracle.ODCI.ODCIQueryInfo,
                java.math.BigDecimal, java.math.BigDecimal, 
                java.lang.String, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  MEMBER FUNCTION ODCIIndexFetch(nrows NUMBER, rids OUT SYS.ODCIridlist, env SYS.ODCIEnv) RETURN NUMBER as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIFetch(java.math.BigDecimal, 
	oracle.ODCI.ODCIRidList[], oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  MEMBER FUNCTION ODCIIndexClose(env SYS.ODCIEnv) RETURN NUMBER as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIClose(oracle.ODCI.ODCIEnv) return java.math.BigDecimal'
  
);
/
show errors

ALTER JAVA CLASS "org.apache.lucene.indexer.LuceneDomainContext" RESOLVE;
show errors
ALTER JAVA CLASS "org.apache.lucene.indexer.LuceneDomainIndex"  RESOLVE;
show errors



---------------------------------
--  CREATE IMPLEMENTATION UNIT --
---------------------------------

-- CREATE TYPE BODY
create type body LuceneDomainIndex
is
  -- The ODCIGetInterfaces function is invoked when an INDEXTYPE is created by a
  -- CREATE INDEXTYPE... statement or is altered.
  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList) RETURN NUMBER IS
  BEGIN
   ifclist := sys.ODCIObjectList(sys.ODCIObject('SYS','ODCIINDEX2'));
   return ODCIConst.Success;
  END ODCIGetInterfaces;

  -- When a user destroys an index of your indextype by issuing a DROP INDEX statement,
  -- Oracle calls your ODCIIndexDrop() method.
  STATIC FUNCTION ODCIIndexDrop(ia sys.ODCIIndexInfo, env sys.ODCIEnv) RETURN NUMBER is
   stmt varchar2(1000);
   cnum integer;
   junk integer;
  begin
    -- construct the sql statement
   stmt := '';
   IF ((env.CallProperty IS NULL) and (ia.IndexPartition IS NULL) ) THEN
       stmt := 'delete from lucene_index where prefix =''' || ia.IndexSchema || '.' || ia.IndexName || '''';
   ELSE
     IF (ia.IndexPartition IS NOT NULL) THEN
       stmt := 'delete from lucene_index where prefix =''' || ia.IndexSchema || '.' || ia.IndexName || '.' || ia.IndexPartition || '''';
     END IF;
   END IF;
   -- dbms_output.put_line('DROP');
   -- dbms_output.put_line(stmt);
   -- execute the statement
   cnum := dbms_sql.open_cursor;
   dbms_sql.parse(cnum, stmt, dbms_sql.native);
   junk := dbms_sql.execute(cnum);
   dbms_sql.close_cursor(cnum);

   return ODCIConst.Success;
  end;
end;
/
show errors

CREATE OPERATOR Contains
  BINDING (VARCHAR2, VARCHAR2) RETURN NUMBER
  WITH INDEX CONTEXT, SCAN CONTEXT LuceneDomainIndex COMPUTE ANCILLARY DATA
  without column data USING LuceneDomainIndex.TextContains,
  (sys.XMLType, VARCHAR2) RETURN NUMBER
  WITH INDEX CONTEXT, SCAN CONTEXT LuceneDomainIndex COMPUTE ANCILLARY DATA
  without column data USING LuceneDomainIndex.TextContains;

show errors

CREATE OPERATOR Score BINDING 
  (NUMBER) RETURN NUMBER
    ANCILLARY TO Contains(VARCHAR2, VARCHAR2),
                 Contains(sys.XMLType, VARCHAR2)
    without column data USING LuceneDomainIndex.TextScore;

show errors

-- CREATE INDEXTYPE
create indextype LuceneIndex
for
contains(varchar2, varchar2),
contains(sys.XMLType, varchar2)
using LuceneDomainIndex;

show errors

-- GRANTS
grant execute on  LuceneIndex to public;
grant execute on  Contains to public;
grant execute on  Score to public;
grant execute on  LuceneDomainIndex to public;

exit
