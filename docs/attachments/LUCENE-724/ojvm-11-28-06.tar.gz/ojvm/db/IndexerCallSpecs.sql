rem run this file as sys, after loading
rem loadjava -r -v -s -g public -user sys/change_on_install@dev lucene-core-2.0.1-dev.jar

create or replace package luceneIndexer as
   PROCEDURE indexColumn(schemaName VARCHAR2, tableName VARCHAR2, partitionName VARCHAR2, colName VARCHAR2);
   PROCEDURE indexColumn(schemaName VARCHAR2, tableName VARCHAR2, colName VARCHAR2);
   PROCEDURE indexColumn(tableName VARCHAR2, colName VARCHAR2);
   PROCEDURE indexTable(schemaName VARCHAR2, tableName VARCHAR2, partitionName VARCHAR2);
   PROCEDURE indexTable(schemaName VARCHAR2, tableName VARCHAR2);
   PROCEDURE indexTable(tableName VARCHAR2);
end luceneIndexer;
/

create or replace package body luceneIndexer as 

  PROCEDURE indexColumn(tableName VARCHAR2, colName VARCHAR2) is
  begin
     indexColumn(user,tableName,null,colName);
  end indexColumn;
  PROCEDURE indexColumn(schemaName VARCHAR2, tableName VARCHAR2, colName VARCHAR2) is
  begin
     indexColumn(schemaName,tableName,null,colName);
  end indexColumn;
  PROCEDURE indexColumn(schemaName VARCHAR2, tableName VARCHAR2, partitionName VARCHAR2, colName VARCHAR2)
        AS LANGUAGE JAVA
        NAME 'org.apache.lucene.indexer.TableIndexer.indexTable(java.lang.String, java.lang.String, java.lang.String, java.lang.String)';
  PROCEDURE indexTable(tableName VARCHAR2) is
  begin
     indexTable(user,tableName,null);
  end indexTable;
  PROCEDURE indexTable(tableName VARCHAR2, partitionName VARCHAR2) is
  begin
     indexTable(user,tableName,partitionName);
  end indexTable;
  PROCEDURE indexTable(schemaName VARCHAR2, tableName VARCHAR2, partitionName VARCHAR2)
        AS LANGUAGE JAVA
        NAME 'org.apache.lucene.indexer.XMLTypeIndexer.indexTable(java.lang.String, java.lang.String, java.lang.String)';
end luceneIndexer;
/

grant execute on luceneIndexer to public;
create public synonym luceneIndexer for lucene.luceneIndexer;