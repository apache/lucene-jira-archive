rem output the content of an explain plan command
select plan_table_output from table(dbms_xplan.display('plan_table',null,'serial'));

rem SELECT  operation operations,
rem          decode(options, 'BY INDEX ROWID', 'BY ROWID',
rem          'BY USER ROWID', 'BY ROWID',
rem          options) options,
rem          object_name
rem FROM    plan_table
rem ORDER BY id;

TRUNCATE TABLE plan_table;
