package org.apache.lucene.store;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * A database utility methods.
 *
 * @version $Id: $
 * @author Marcelo F. Ochoa
 */
public class OJVMUtil {
    static public void closeDbResources(PreparedStatement stmt, ResultSet rs) {
        try {
            if (rs != null)
                rs.close();
            if (stmt != null)
                stmt.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    static public Connection getConnection() throws SQLException {
        Connection dconn = null;
        try {
            if(System.getProperty("java.vm.name").equals("JServer VM"))
              dconn = DriverManager.getConnection("jdbc:default:connection:");
            else { // only for testing purpose, it supose to be uses inside the OJVM
              DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
              dconn = DriverManager.getConnection("jdbc:oracle:oci:@"+
                                System.getProperty("db.str","dev"),
                                System.getProperty("db.usr","scott"),
                                System.getProperty("db.pwd","tiger"));
            }
            dconn.setAutoCommit(false);
        } catch(SQLException s) {
          s.printStackTrace(System.err);
          throw new InternalError(
             ".getConnection: Can't get defaultConnection "+s.getMessage());
        }
        return dconn;
    }

} 
