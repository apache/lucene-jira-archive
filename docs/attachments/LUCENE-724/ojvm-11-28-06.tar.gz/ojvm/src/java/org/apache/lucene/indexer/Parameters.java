package org.apache.lucene.indexer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import java.sql.SQLException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Parameters implements Serializable {
    private HashMap parms = new HashMap();
    public Parameters() {
    }

    public Parameters(byte[] st) throws SQLException {
        try {
            ByteArrayInputStream i = new ByteArrayInputStream(st);
            ObjectInputStream in = new ObjectInputStream(i);
            int size_t = in.readInt();
            for (int j = 0; j < size_t; j++) {
                String name = (String)in.readObject();
                String value = (String)in.readObject();
                parms.put(name,value);
            }
        } catch (Exception e) {
            throw new SQLException(e.getMessage());
        }
    }
    
    public void setParameter(String name, String value) {
        parms.put(name,value);
    }
    
    public String getParameter(String name) {
        return (String)parms.get(name);
    }
    
    public byte[] getBytes() throws SQLException {
        try {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(o);
            int size = parms.size();
            out.writeInt(size);
            Set keys = parms.keySet();
            Iterator ite = keys.iterator();
            while(ite.hasNext()) {
                String name = (String)ite.next();
                String value = (String)parms.get(name);
                out.writeObject(name);
                out.writeObject(value);
            }
            out.flush();
            return o.toByteArray();
        } catch (Exception e) {
            throw new SQLException(e.getMessage());
        }
    }
    
    public String toString() {
        StringBuffer result = new StringBuffer();
        Set keys = parms.keySet();
        Iterator ite = keys.iterator();
        while(ite.hasNext()) {
            String name = (String)ite.next();
            String value = (String)parms.get(name);
            result.append("parameter '").append(name).append("' ");
            result.append("value '").append(value).append("'\n");
        }
        return result.toString();
    }
}
