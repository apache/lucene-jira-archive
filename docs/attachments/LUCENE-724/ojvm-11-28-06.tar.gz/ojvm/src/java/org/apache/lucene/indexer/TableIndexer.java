package org.apache.lucene.indexer;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import oracle.sql.CLOB;

import oracle.xdb.XMLType;

import oracle.xml.parser.v2.SAXParser;

import oracle.xml.parser.v2.XMLParseException;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Hit;
import org.apache.lucene.search.HitIterator;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.store.OJVMUtil;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public class TableIndexer {
    protected Connection conn;

    protected String schemaName;

    protected String tableName;

    protected String partitionName;

    public TableIndexer() {
    }

    public TableIndexer(String tableName) {
        try {
            this.conn = OJVMUtil.getConnection();
            this.tableName = tableName;
            this.schemaName =
                    this.conn.getMetaData().getUserName().toUpperCase();
            this.partitionName = null;
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
    }

    public TableIndexer(String schemaName, String tableName) {
        try {
            this.conn = OJVMUtil.getConnection();
            this.tableName = tableName;
            this.schemaName = schemaName;
            this.partitionName = null;
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
    }

    public TableIndexer(Connection conn, String tableName) {
        try {
            this.conn = conn;
            this.tableName = tableName;
            this.schemaName =
                    this.conn.getMetaData().getUserName().toUpperCase();
            this.partitionName = null;
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
    }

    public TableIndexer(Connection conn, String schemaName, String tableName) {
        this.conn = conn;
        this.schemaName = schemaName;
        this.tableName = tableName;
        this.partitionName = null;
    }

    public TableIndexer(Connection conn, String schemaName, String tableName,
                        String partitionName) {
        this.conn = conn;
        this.schemaName = schemaName;
        this.tableName = tableName;
        this.partitionName = partitionName;
    }

    public static StringBuffer textExtractor(XMLType obj) throws IOException,
                                                                 SQLException {
        if (obj==null) // Sanity checks
          return new StringBuffer("");
        SAXParser saxParser = new SAXParser();
        MyContentHandler myHandler = new MyContentHandler();
        saxParser.setContentHandler(myHandler);
        try {
            saxParser.parse(obj.getInputStream());
        } catch (XMLParseException e) {
            e.printStackTrace();
            throw new SQLException("XMLParseException: " + e.getMessage());
        } catch (SAXException e) {
            e.printStackTrace();
            throw new SQLException("SAXException: " + e.getMessage());
        }
        return myHandler.getTextResult();
    }

    public void index(IndexWriter writer, String col) throws IOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            if (partitionName != null && partitionName.length() > 0)
                stmt =
this.conn.prepareStatement("SELECT rowid," + col + " FROM " + schemaName +
                           "." + tableName + " PARTITION (" + partitionName +
                           ")");
            else
                stmt =
this.conn.prepareStatement("SELECT rowid," + col + " FROM " + schemaName +
                           "." + tableName);
            rs = stmt.executeQuery();
            while (rs.next()) {
                String rowid = rs.getString(1);
                Document doc = new Document();
                doc.add(new Field("rowid", rowid, Field.Store.YES,
                                  Field.Index.UN_TOKENIZED));
                Object value = rs.getObject(2);
                String valueStr = null;
                if (value != null) { // Sanity checks
                    if (value instanceof CLOB)
                        valueStr =
                                ((CLOB)value).getSubString(1, (int)((CLOB)value)
                                                           .length());
                    else if (value instanceof XMLType)
                        valueStr = textExtractor(((XMLType)value)).toString();
                    else
                        valueStr = value.toString();
                    doc.add(new Field(col, valueStr, Field.Store.NO,
                                      Field.Index.TOKENIZED));
                    writer.addDocument(doc);
                    //System.out.println(".index rowid='"+rowid+
                    //                   "' coltype='"+rs.getObject(2).getClass()+
                    //                   "' value='"+valueStr+"'");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } finally {
            OJVMUtil.closeDbResources(stmt, rs);
        }
    }

    public void sync(IndexWriter writer) throws IOException {

    }

    public static void indexTable(String schema, String table,
                                  String partitionName,
                                  String col) throws IOException {
        OJVMDirectory dir;
        dir =
 OJVMDirectory.getDirectory("LN$" + schema + "." + table + "$IDX");
        IndexWriter writer =
            new IndexWriter(dir, new WhitespaceAnalyzer(), true);
        TableIndexer index =
            new TableIndexer(dir.getConnection(), schema, table,
                             partitionName);
        index.index(writer, col);
        writer.close();
        dir.close();
    }

    public static String[] query(String schema, String table, String col,
                                 String queryStr) throws IOException {
        OJVMDirectory dir;
        dir =
 OJVMDirectory.getDirectory("LN$" + schema + "." + table + "$IDX");
        IndexSearcher searcher = null;
        HitIterator iterator = null;
        searcher = new IndexSearcher(dir);
        Hits hits = searcher.search(new TermQuery(new Term(col, queryStr)));
        iterator = (HitIterator)hits.iterator();
        String rows[] = new String[iterator.length()];
        for (int i = 0; iterator.hasNext(); i++) {
            Hit hit = (Hit)iterator.next();
            rows[i] = hit.get("rowid");
        }
        searcher.close();
        dir.close();
        return rows;
    }

    public static class MyContentHandler extends DefaultHandler {
        StringBuffer textResult = new StringBuffer();

        public void startElement(String uri, String localName, String qName,
                                 Attributes atts) {
            int i = atts.getLength();
            for (int j = 0; j < i; j++) {
                textResult.append(atts.getValue(j)).append(' ');
                //System.out.println(".adding: "+atts.getValue(j));
            }
        }

        public void endElement(String uri, String localName, String qName) {
        }

        public void characters(char[] chars, int start, int length) {
            String strPart = new String(chars, start, length);
            textResult.append(strPart).append(' ');
            //System.out.println(".adding: "+strPart);
        }

        public StringBuffer getTextResult() {
            return this.textResult;
        }

    }
}
