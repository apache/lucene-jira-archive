package org.apache.lucene.indexer;

import java.util.Hashtable;

import org.apache.lucene.search.HitIterator;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class LuceneDomainContext 
{
  Directory dir = null;
  IndexSearcher searcher = null;
  HitIterator iterator = null;
  Hashtable scoreList = null;
  
  public LuceneDomainContext(Directory d, IndexSearcher s, HitIterator i) {
	dir = d;
	searcher = s;
        iterator = i;
        scoreList = null;
  }

    public void setDir(Directory dir) {
        this.dir = dir;
    }

    public Directory getDir() {
        return dir;
    }

    public void setSearcher(IndexSearcher searcher) {
        this.searcher = searcher;
    }

    public IndexSearcher getSearcher() {
        return searcher;
    }

    public void setIterator(HitIterator iterator) {
        this.iterator = iterator;
    }

    public HitIterator getIterator() {
        return iterator;
    }

    public void setScoreList(Hashtable scoreList) {
        this.scoreList = scoreList;
    }

    public Hashtable getScoreList() {
        return scoreList;
    }
}

