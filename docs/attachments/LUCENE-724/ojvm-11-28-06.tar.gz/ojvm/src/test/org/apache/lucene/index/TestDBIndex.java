package org.apache.lucene.index;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.OJVMDirectory;

/**
 * @author mochoa
 * @author Marcelo F. Ochoa
 * @version $Id: $
 */
public class TestDBIndex extends TestCase {
    public void setUp() throws IOException {
    }

    public void testDocCount() throws IOException {
        Directory dir = null;
        IndexWriter writer = null;
        IndexReader reader = null;
        int i;
        try {
            dir = OJVMDirectory.getDirectory("myindex");
            writer = new IndexWriter(dir, new WhitespaceAnalyzer(), true);

            // add 100 documents
            for (i = 0; i < 100; i++) {
                addDoc(writer);
            }
            assertEquals(100, writer.docCount());
            writer.close();
            writer = null;

            // delete 40 documents
            reader = IndexReader.open(dir);
            for (i = 0; i < 40; i++) {
                reader.deleteDocument(i);
            }
            reader.close();
            reader = null;
            
            // test doc count before segments are merged/index is optimized
            writer = new IndexWriter(dir, new WhitespaceAnalyzer(), false);
            assertEquals(100, writer.docCount());
            writer.close();
            writer = null;
            
            reader = IndexReader.open(dir);
            assertEquals(100, reader.maxDoc());
            assertEquals(60, reader.numDocs());
            reader.close();
            reader = null;
            
            // optimize the index and check that the new doc count is correct
            writer = new IndexWriter(dir, new WhitespaceAnalyzer(), false);
            writer.optimize();
            assertEquals(60, writer.docCount());
            writer.close();
            writer = null;
            
            // check that the index reader gives the same numbers.
            reader = IndexReader.open(dir);
            assertEquals(60, reader.maxDoc());
            assertEquals(60, reader.numDocs());
            reader.close();
            reader = null;
        } catch (IOException e) {
            throw e;
        } finally {
            if (reader != null)
                reader.close();
            if (writer != null)
                writer.close();
            if (dir != null)
                dir.close();
        }
    }

    private void addDoc(IndexWriter writer) throws IOException {
        Document doc = new Document();
        doc.add(new Field("content", "aaa", Field.Store.NO,
                          Field.Index.TOKENIZED));
        writer.addDocument(doc);
    }

    public void tearDown() {
    }
}


