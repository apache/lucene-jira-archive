package org.apache.lucene.index;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.OJVMDirectory;


/**
 * @author mochoa
 * @author Marcelo F. Ochoa
 * @version $Id: $
 */
public class TestDBIndexDelDoc extends TestCase {
    public void setUp () throws IOException {
    }

    public void testDelDoc() throws IOException {
        Directory dir = null;
        IndexWriter writer=null;
        IndexReader reader=null;
        try {
          dir = OJVMDirectory.getDirectory("myindex");
          // delete 1 documents
          reader=IndexReader.open(dir);
          reader.deleteDocument(0);
          assertEquals(61,reader.numDocs());
          reader.close();
          reader = null;
          // test doc count before deletion
          writer=new IndexWriter(dir,new WhitespaceAnalyzer(),false);
          assertEquals(62,writer.docCount());
          writer.close();
          writer = null;
        } catch (IOException e) {
            throw e;  
        } finally {
            if (reader!=null)
              reader.close();
            if (writer!=null)
              writer.close();
            if (dir!=null)
              dir.close();
        }
    }

    public void tearDown() {
    }
}









