package org.apache.lucene.indexer;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.lucene.analysis.StopAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Hit;
import org.apache.lucene.search.HitIterator;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.OJVMDirectory;

public class TestTableIndexer extends TestCase {
    OJVMDirectory dir = null;
    public TestTableIndexer() {
    }

    public void setUp () throws IOException {
       Parameters parameters = new Parameters();
       dir = OJVMDirectory.getDirectory("LUCENE.SOURCE_BIG_LIDX");
       parameters.setParameter("ColName","TEXT");
       parameters.setParameter("MergeFactor",""+IndexWriter.DEFAULT_MERGE_FACTOR);
       parameters.setParameter("MaxBufferedDocs",""+IndexWriter.DEFAULT_MAX_BUFFERED_DOCS);
       parameters.setParameter("MaxMergeDocs",""+IndexWriter.DEFAULT_MAX_MERGE_DOCS);
       dir.setParameters(parameters);
       IndexWriter writer  = new IndexWriter(dir, new StopAnalyzer(), true);
       TableIndexer index = new TableIndexer(dir.getConnection(),"TEST_SOURCE_BIG");
       writer.setMergeFactor(1500);
       writer.setMaxBufferedDocs(1500);
       index.index(writer,"TEXT");
       writer.close();
   }


    public void testTestTableIndexer() throws IOException {
        IndexSearcher searcher = null;
        HitIterator iterator = null;
        searcher = new IndexSearcher(dir);
        Hits hits = searcher.search(new TermQuery(new Term("TEXT", "type")));
        iterator = (HitIterator) hits.iterator();
        assertEquals(3593, iterator.length());
        assertTrue(iterator.hasNext());
        Hit hit = (Hit) iterator.next();
        assertEquals("AAAPyTAAEAAAASaABb", hit.get("rowid"));
        searcher.close();
    }
    
    public void tearDown() throws IOException {
        dir.close();
    }
}
