package org.apache.lucene.indexer;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.HashMap;

import java.util.Iterator;
import java.util.Set;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

import oracle.sql.CLOB;

import oracle.xdb.XMLType;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.store.OJVMUtil;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public class LuceneQueue {
    static final java.math.BigDecimal SUCCESS = new java.math.BigDecimal("0");

    static final java.math.BigDecimal ERROR = new java.math.BigDecimal("1");

    static final int NO_WAIT = 0;
    static final int FIRST_MESSAGE = 1;
    static final int LOCKED = 2;
    static final int NEXT_MESSAGE = 3;
    static final String cond1 = "tab.user_data.prefix='";

    static final String enqueueStmt =
    "declare\n" +
    "    enqueue_options     dbms_aq.enqueue_options_t;\n" + 
    "    message_properties  dbms_aq.message_properties_t;\n" + 
    "    message_handle      RAW(16);\n" + 
    "    message             lucene_msg_typ;\n" +
    "begin\n" +
    "    message := lucene_msg_typ(?,?,?,?,?,?);\n" + 
    "    dbms_aq.enqueue(queue_name         => 'LUCENE.lucene_msg_queue',\n" + 
    "                    enqueue_options    => enqueue_options,\n" + 
    "                    message_properties => message_properties,\n" + 
    "                    payload            => message,\n" + 
    "                    msgid              => message_handle);\n" +
    "end;";
    
    static final String dequeueStmt = 
    "declare" +
    "    dequeue_options          dbms_aq.dequeue_options_t;\n" + 
    "    message_properties       dbms_aq.message_properties_t;\n" + 
    "    message_handle           RAW(16);\n" + 
    "    message                  lucene_msg_typ;\n" + 
    "    message_no_data          lucene_msg_typ;\n" +
    "begin\n" +
    "    dequeue_options.wait := ?;\n" + 
    "    dequeue_options.navigation := ?;\n" + 
    "    dequeue_options.dequeue_mode := ?;\n" + 
    "    dequeue_options.deq_condition := ?;\n" +
    "    dbms_aq.dequeue(\n" + 
    "                queue_name         => 'LUCENE.lucene_msg_queue',\n" + 
    "                dequeue_options    => dequeue_options,\n" + 
    "                message_properties => message_properties,\n" + 
    "                payload            => message,\n" + 
    "                msgid              => message_handle);\n" +
    "    ? := message.rid;\n" +
    "    ? := message.operation;\n" +
    "    ? := message.newval;\n" +
    "    ? := message.newval_xml;\n" +
    "    ? := message.newval_clob;\n" +
    "    dequeue_options.dequeue_mode := dbms_aq.REMOVE_NODATA;\n" + 
    "    dequeue_options.msgid := message_handle;\n" + 
    "    dequeue_options.deq_condition := '';\n" + 
    "    dbms_aq.dequeue(\n" + 
    "                queue_name         => 'LUCENE.lucene_msg_queue',\n" + 
    "                dequeue_options    => dequeue_options,\n" + 
    "                message_properties => message_properties,\n" + 
    "                payload            => message_no_data,\n" + 
    "                msgid              => message_handle);\n" + 
    "    commit;\n" +
    "end;";
    
    public LuceneQueue() {
    }

    public static void sync(String prefix) throws IOException,SQLException {
        HashMap scheduledDeleteForUpdate = new HashMap();
        HashMap scheduledAdd = new HashMap();
        OracleCallableStatement cs = null;
        Connection conn = null;
        OJVMDirectory dir = null;
        IndexReader reader = null;
        IndexWriter writer = null;
        try {
            conn = OJVMUtil.getConnection();
            cs =
              (OracleCallableStatement)conn.prepareCall(dequeueStmt);
            cs.setInt(1,NO_WAIT);
            cs.setInt(2,FIRST_MESSAGE);
            cs.setInt(3,LOCKED);
            cs.setString(4,cond1+prefix+"'");
            cs.registerOutParameter(5,OracleTypes.VARCHAR);
            cs.registerOutParameter(6,OracleTypes.VARCHAR);
            cs.registerOutParameter(7,OracleTypes.VARCHAR);
            cs.registerOutParameter(8,OracleTypes.OPAQUE,"SYS.XMLTYPE");
            cs.registerOutParameter(9,OracleTypes.CLOB);
            try {
                cs.execute(); // first message
                String  rid = cs.getString(5);
                String  operation = cs.getString(6);
                String  retval = cs.getString(7);
                XMLType retval_xml = (XMLType)cs.getObject(8);
                CLOB    retval_clob = cs.getCLOB(9);
                //System.out.println("rid: "+rid+" ("+operation+")");
                if ("delete".equals(operation)) {
                    scheduledDeleteForUpdate.remove(rid);
                    scheduledAdd.remove(rid);
                } else if ("update".equals(operation)) {
                    scheduledDeleteForUpdate.put(rid,"");
                    scheduledAdd.put(rid,"");
                } else { // insert
                    if (retval != null)
                      scheduledAdd.put(rid,retval);
                    if (retval_xml != null)
                      scheduledAdd.put(rid,TableIndexer.textExtractor(retval_xml).toString());
                    if (retval_clob != null)
                      scheduledAdd.put(rid,retval_clob.getSubString(1,(int)retval_clob.length()));
                }
                while(true) {
                    cs.setInt(1,NO_WAIT);
                    cs.setInt(2,NEXT_MESSAGE);
                    cs.setInt(3,LOCKED);
                    cs.setString(4,cond1+prefix+"'");
                    cs.execute(); // next message
                    rid = cs.getString(5);
                    operation = cs.getString(6);
                    retval = cs.getString(7);
                    retval_xml = (XMLType)cs.getObject(8);
                    retval_clob = cs.getCLOB(9);
                    //System.out.println("rid: "+rid+" ("+operation+")");
                    if ("delete".equals(operation)) {
                        scheduledDeleteForUpdate.remove(rid);
                        scheduledAdd.remove(rid);
                    } else {
                      if ("update".equals(operation)) // require deletion first
                        scheduledDeleteForUpdate.put(rid,"");
                      // insert
                      if (retval != null)
                        scheduledAdd.put(rid,retval);
                      if (retval_xml != null)
                        scheduledAdd.put(rid,TableIndexer.textExtractor(retval_xml).toString());
                      if (retval_clob != null)
                        scheduledAdd.put(rid,retval_clob.getSubString(1,(int)retval_clob.length()));
                    }
                }
            } catch (SQLException sqe) {
                if (sqe.getErrorCode() != 25228) {
                    sqe.printStackTrace();
                    throw sqe;
                }// else {
                //    System.out.println("No more lucene update msg to dequeue.");
                //}
            }
            dir = OJVMDirectory.getDirectory(prefix);
            Parameters par = dir.getParameters();
            String col = par.getParameter("ColName");
            reader = IndexReader.open(dir);
            Set deleted = scheduledDeleteForUpdate.keySet();
            Iterator ite = deleted.iterator();
            while(ite.hasNext()) {
                String rowid = (String)ite.next();
                //System.out.println("Deleting: "+rowid);
                reader.deleteDocuments(new Term("rowid", rowid));
            }
            reader.close();
            reader = null;
            String analizerStr = par.getParameter("Analyzer","org.apache.lucene.analysis.SimpleAnalyzer");
            int mergeFactor = Integer.parseInt(par.getParameter("MergeFactor",""+IndexWriter.DEFAULT_MERGE_FACTOR));
            int maxBufferedDocs = Integer.parseInt(par.getParameter("MaxBufferedDocs",""+IndexWriter.DEFAULT_MAX_BUFFERED_DOCS));
            int maxMergeDocs = Integer.parseInt(par.getParameter("MaxMergeDocs",""+IndexWriter.DEFAULT_MAX_MERGE_DOCS));
            Analyzer analyzer = null;
            try {
                Class clazz = analizerStr.getClass().forName(analizerStr);
                analyzer = (Analyzer)clazz.newInstance();
            } catch (ClassNotFoundException c) {
                c.printStackTrace();
                throw new SQLException(c.getMessage());
            } catch (InstantiationException i) {
                i.printStackTrace();
                throw new SQLException(i.getMessage());
            } catch (IllegalAccessException e) {
                e.printStackTrace();
                throw new SQLException(e.getMessage());
            }
            writer = new IndexWriter(dir, analyzer, false);
            writer.setMergeFactor(mergeFactor);
            writer.setMaxMergeDocs(maxMergeDocs);
            writer.setMaxBufferedDocs(maxBufferedDocs);
            Set inserted = scheduledAdd.keySet();
            ite = inserted.iterator();
            while(ite.hasNext()) {
                String rowid = (String)ite.next();
                String value = (String)scheduledAdd.get(rowid);
                //System.out.println("Inserting: "+rowid+" "+col+": "+value);
                Document doc = new Document();
                doc.add(new Field("rowid", rowid, Field.Store.YES,
                                  Field.Index.UN_TOKENIZED));
                doc.add(new Field(col,
                                  value, Field.Store.NO, Field.Index.TOKENIZED));
                writer.addDocument(doc);
            }
            writer.close();
            writer = null;
            dir.close();
            dir = null;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error syncing the index: "+prefix+" - "+e.getMessage());
        } finally {
            if (cs != null)
              cs.close();
            cs = null;
            if (reader != null)
                reader.close();
            if (writer != null)
                writer.close();
            if (dir != null)
                dir.close();
            scheduledDeleteForUpdate.clear();
            scheduledDeleteForUpdate = null;
            scheduledAdd.clear();
            scheduledAdd = null;
        }
    }
    
    public static void purge(String prefix) throws SQLException {
        PreparedStatement stmt = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            // Purge deleted documents.
            stmt = conn.prepareStatement("DELETE FROM LUCENE_INDEX WHERE PREFIX = ? AND DELETED = 'Y'");
            stmt.setString(1,prefix);
            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error in purge index: "+prefix+" - "+e.getMessage());
        } finally {
            if (stmt != null)
              stmt.close();
            stmt = null;
        }
    }
    
    public static void discard(Connection conn, String prefix) throws SQLException {
        OracleCallableStatement cs = null;
        try {
            cs =
              (OracleCallableStatement)conn.prepareCall(dequeueStmt);
            cs.setInt(1,NO_WAIT);
            cs.setInt(2,FIRST_MESSAGE);
            cs.setInt(3,LOCKED);
            cs.setString(4,cond1+prefix+"'");
            cs.registerOutParameter(5,OracleTypes.VARCHAR);
            cs.registerOutParameter(6,OracleTypes.VARCHAR);
            cs.registerOutParameter(7,OracleTypes.VARCHAR);
            cs.registerOutParameter(8,OracleTypes.OPAQUE,"SYS.XMLTYPE");
            cs.registerOutParameter(9,OracleTypes.CLOB);
            try {
                cs.execute(); // first message
                String  rid = cs.getString(5);
                String  operation = cs.getString(6);
                String  retval = cs.getString(7);
                XMLType retval_xml = (XMLType)cs.getObject(8);
                CLOB    retval_clob = cs.getCLOB(9);
                //System.out.println("discarding rid: "+rid+" ("+operation+")");
                while(true) {
                    cs.setInt(1,NO_WAIT);
                    cs.setInt(2,NEXT_MESSAGE);
                    cs.setInt(3,LOCKED);
                    cs.setString(4,cond1+prefix+"'");
                    cs.execute(); // next message
                    rid = cs.getString(5);
                    operation = cs.getString(6);
                    retval = cs.getString(7);
                    retval_xml = (XMLType)cs.getObject(8);
                    retval_clob = cs.getCLOB(9);
                    //System.out.println("discarding rid: "+rid+" ("+operation+")");
                }
            } catch (SQLException sqe) {
                if (sqe.getErrorCode() != 25228) {
                    sqe.printStackTrace();
                    throw sqe;
                }
            }
            } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException("Error syncing the index: "+prefix+" - "+e.getMessage());
            } finally {
                if (cs != null)
                  cs.close();
                cs = null;
            }
    }
    
    public static java.math.BigDecimal enqueue(String prefix, String rid, String operation, Object newval) throws SQLException {
        OracleCallableStatement cs = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            cs =
              (OracleCallableStatement)conn.prepareCall(enqueueStmt);
            cs.setString(1,prefix);
            cs.setString(2,rid);
            if (newval instanceof String) {
              cs.setString(3,(String)newval);
              cs.setNull(4,OracleTypes.OPAQUE,"SYS.XMLTYPE");
              cs.setNull(5,OracleTypes.CLOB);
            } else if (newval instanceof XMLType) {
                cs.setNull(3,OracleTypes.VARCHAR);
                cs.setObject(4,newval);
                cs.setNull(5,OracleTypes.CLOB);
            } else if (newval instanceof CLOB) {
                cs.setNull(3,OracleTypes.VARCHAR);
                cs.setNull(4,OracleTypes.OPAQUE,"SYS.XMLTYPE");
                cs.setCLOB(5,(CLOB)newval);
            } else
              throw new RuntimeException("Unsuported data type for newval "+newval.getClass());
            cs.setString(6,operation);
            cs.execute();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
            return ERROR;
        } finally {
            if (cs != null)
              cs.close();
            cs = null;
        }
        return SUCCESS;
    }
}
