package org.apache.lucene.store;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import java.util.Iterator;
import java.util.Vector;

import oracle.jdbc.OracleResultSet;

import oracle.sql.BLOB;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * a pseudo file that represents a database entry.
 *  This class encapsulate the concept of File, but reading and storing the content
 *  in a BLOB column of the table lucene_files.
 *  To improve the direct access to the content a file opened in read mode must be
 *  loaded by calling the method loadData(), this operation is automatically called
 *  by OJVMIndexInput class which implements the stream interface.
 * @version $Id: $
 * @author Marcelo F. Ochoa
 */
public class OJVMFile {    
    private Vector data = new Vector();

    private Timestamp lastModified;

    private boolean loaded = false;

    private String name;

    private String prefix;

    private long size;
    
    private Connection conn;

    /**
     * @param conn an opened database connection
     * @param prefix is the directory name where the inverted index files are stored
     * @param name of the file to be opened in read or write mode.
     * If you call to @see loadData() the file is openend in read only mode
     * otherwise you can write the data into the Vector() data.
     */
    public OJVMFile(Connection conn, String prefix, String name) {
        this.conn = conn;
        this.prefix = prefix;
        this.name = name;
    }

    /**
     * loadData() read the Blob in chunks of BufferedIndexInput.BUFFER_SIZE size
     * and create an in memory Vector() representation of this data.
     */
    public void loadData() {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt =
              conn.prepareStatement("SELECT LAST_MODIFIED,FILE_SIZE,DATA FROM LUCENE_INDEX WHERE PREFIX=? AND NAME=? AND DELETED='N'");
            stmt.setString(1, this.prefix);
            stmt.setString(2, this.name);
            rs = stmt.executeQuery();
            if (rs.next()) {
                this.setLastModified(rs.getTimestamp(1));
                this.setLoaded(true);
                this.setSize(rs.getLong(2));
                this.clearData();

                Blob blob = rs.getBlob(3);
                InputStream byte_stream = blob.getBinaryStream();
                long totalReaded = 0;
                int bytesReaded = 0;
                byte[] buffer = new byte[(int)(((totalReaded+BufferedIndexInput.BUFFER_SIZE)<this.size) ? BufferedIndexInput.BUFFER_SIZE : this.size-totalReaded)];
                while((bytesReaded = byte_stream.read(buffer))>0) {
                    this.addData(buffer);
                    totalReaded += bytesReaded;
                    //System.out.println("loadData reading "+buffer.length+" bytes of "+this.size);
                    buffer = new byte[(int)(((totalReaded+BufferedIndexInput.BUFFER_SIZE)<this.size) ? BufferedIndexInput.BUFFER_SIZE : this.size-totalReaded)];
                }
                byte_stream.close();
            } else
                throw new RuntimeException("Failed to get lucene index prefix='" +
                                           this.prefix + "' name='" + this.name + "'");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            OJVMUtil.closeDbResources(stmt, rs);
        }
    }

    /** add new chunks of data to the Vector()
     * @param buffer to be added
     */
    public void addData(byte[] buffer) {
        data.add(buffer);
    }

    public void clearData() {
        data = new Vector();
    }

    public Vector getData() {
        return data;
    }

    /**
     * @return Timestamp with the lastModified information about the file
     */
    public Timestamp getLastModified() {
        return lastModified;
    }

    /**
     * @return an String with the name of the file
     */
    public String getName() {
        return name;
    }

    /**
     * @return an String with the prefix of the file (directory)
     */
    public String getPrefix() {
        return prefix;
    }

    /**
     * @return long value with the size of the file
     */
    public long getSize() {
        return size;
    }

    public boolean isLoaded() {
        return loaded;
    }

    public void setData(Vector data) {
        this.data = data;
    }

    public void setLastModified(Timestamp lastModified) {
        this.lastModified = lastModified;
    }

    public void setLoaded(boolean loaded) {
        this.loaded = loaded;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public void setSize(long size) {
        this.size = size;
    }
    
    public byte[] toByteArray() throws IOException {
            ByteArrayOutputStream bout =
                       new ByteArrayOutputStream();
            DataOutputStream dout = new DataOutputStream( bout );
            byte[] buffer = null;
            dout.writeInt( this.data.size() );

            for (Iterator i = this.getData().iterator(); i.hasNext(); ) {
              buffer = (byte[])i.next();
              dout.write(buffer,0,buffer.length);
            }
            dout.flush();
            dout.close();
            return bout.toByteArray();
        }
        
    /**
     *  Write operations are doing in one call too, when this method is called
     *  and if the file was not opened in read mode (loadData never called) the close
     *  operation creates a temporary BLOB and insert the entire row into the
     *  lucene_index table.
     *  To optimize the creation of empty files (0 bytes lenght) if this is true the
     *  empty_blob() function is used instead of the temporary blob creation step. 
     * @throws IOException
     */
    public void close() throws IOException {
        //System.out.println("OJVMFile.close "+this.prefix+"/"+this.name);
        if (this.loaded) // if was open for reading, do nothing
          return;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt =
              conn.prepareStatement("INSERT INTO LUCENE_INDEX (PREFIX,NAME,LAST_MODIFIED,FILE_SIZE,DATA,DELETED) " +
                  "VALUES (?,?,sysdate,?,empty_blob(),'N')");
            stmt.setString(1, this.getPrefix());
            stmt.setString(2, this.getName());
            stmt.setLong(3, this.getSize());
            stmt.execute();
            stmt.close();
            stmt = null;
            if (this.getSize()>0) {
                stmt =
                    conn.prepareStatement("SELECT DATA FROM LUCENE_INDEX WHERE PREFIX = ? AND NAME = ? AND DELETED='N' FOR UPDATE");
                stmt.setString(1, this.getPrefix());
                stmt.setString(2, this.getName());
                rs = stmt.executeQuery();
                if (rs.next()) {
                    BLOB blob = ((OracleResultSet)rs).getBLOB(1);
                    OutputStream outstream = blob.setBinaryStream(1L);
                    byte[] buffer = null;
                    for (Iterator i = this.getData().iterator(); i.hasNext(); ) {
                        buffer = (byte[])i.next();
                        outstream.write(buffer,0,buffer.length);
                    }
                    outstream.close();
                } else
                    throw new IOException("Close() - Can't select for update the new BLOB");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new IOException("Unable to flush file " + this.getPrefix() + "/" +this.getName() +
                                  ". Reason: " + e.getMessage());
        } catch (IndexOutOfBoundsException e) {
            e.printStackTrace();
            throw new IOException("Ooops, there where errors during close: "+e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(stmt, rs);
        }
    }
} 
