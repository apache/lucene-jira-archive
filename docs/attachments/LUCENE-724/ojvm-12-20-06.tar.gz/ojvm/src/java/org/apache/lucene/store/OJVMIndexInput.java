package org.apache.lucene.store;

import java.io.IOException;

import java.sql.Connection;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * A database BufferedIndexInput implementation.
 *
 * @version $Id: $
 * @author Marcelo F. Ochoa
 */
public class OJVMIndexInput extends BufferedIndexInput {
    private OJVMFile file;

    private int pointer;

    private Connection conn;

    public OJVMIndexInput(Connection conn, String prefix, String name) {
        this(conn, new OJVMFile(conn,prefix, name));
    }

    public OJVMIndexInput(Connection conn, OJVMFile file) {
        this.file = file;
        this.conn = conn;
        // populate the vector with BLOB from the database
        this.file.loadData();
    }

    public void close() throws IOException {
        // nothing to do
        this.file.close();
    }

    public long length() {
        return file.getSize();
    }

    protected void readInternal(byte[] dest, int offset,
                                int length) throws IOException {
        int remainder = length;
        int start = pointer;
        while (remainder != 0) {
            int bufferNumber = start / BUFFER_SIZE;
            int bufferOffset = start % BUFFER_SIZE;
            int bytesInBuffer = BUFFER_SIZE - bufferOffset;
            int bytesToCopy =
                bytesInBuffer >= remainder ? remainder : bytesInBuffer;
            byte[] buffer = (byte[])file.getData().elementAt(bufferNumber);
            System.arraycopy(buffer, bufferOffset, dest, offset, bytesToCopy);
            offset += bytesToCopy;
            start += bytesToCopy;
            remainder -= bytesToCopy;
        }
        pointer += length;
    }

    protected void seekInternal(long pos) throws IOException {
        pointer = (int)pos;
    }
} 
