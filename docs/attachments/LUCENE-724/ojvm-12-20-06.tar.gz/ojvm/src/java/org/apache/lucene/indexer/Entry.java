package org.apache.lucene.indexer;

import java.io.IOException;

import java.util.HashMap;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.store.OJVMDirectory;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class Entry {
        private OJVMDirectory dir; // which dir

        private Searcher search; // which search

        private long updateCount;
        
        private HashMap activeFilters;
        
        private Analyzer analyzer;

        /** Creates one of these objects. */
        public Entry(OJVMDirectory dir, Searcher search, Analyzer analyzer, long updateCount) {
            this.dir = dir;
            this.search = search;
            this.updateCount = updateCount;
            this.activeFilters = new HashMap();
            this.analyzer = analyzer;
        }

        /** Two of these are equal iff they reference the same field and type. */
        public boolean equals(Object o) {
            if (o instanceof Entry) {
                Entry other = (Entry)o;
                if (other.dir == dir && other.search == search)
                    return true;
            }
            return false;
        }

        /** Composes a hashcode based on the field and type. */
        public int hashCode() {
            return (search == null ? 0 : search.hashCode()) ^
                (dir == null ? 0 : dir.hashCode());
        }

        public OJVMDirectory getDirectory() {
            return this.dir;
        }

        public Searcher getSeacher() {
            return this.search;
        }
        
        public long getUpdateCount() {
            return this.updateCount;
        }
        
        public void addFilter(String qry, Filter f) {
            this.activeFilters.put(qry,f);
        }
        
        public Filter getFilter(String qry) {
            return (Filter)this.activeFilters.get(qry);    
        }
        
        public void setAnalyzer(Analyzer analyzer) {
            this.analyzer = analyzer;
        }
        
        public Analyzer getAnalyzer() {
            return this.analyzer;    
        }
        
        public void close() throws IOException {
            //System.out.println("Closing cachedSearcher entry "+this);
            this.search.close();
            this.search = null;
            this.dir.close();
            this.dir = null;
            this.activeFilters.clear();
            this.activeFilters = null;
        }
        
        public String toString() {
            StringBuffer result = new StringBuffer("Entry: ");
            result.append("dir: ").
              append(dir.toString()).
              append(" searcher: ").
              append(search.toString()).append(" updateCount: ").append(updateCount);
              return result.toString();
        }
    }

