package org.apache.lucene.indexer;

import java.io.IOException;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.Hashtable;

import oracle.ODCI.ODCIEnv;
import oracle.ODCI.ODCIIndexCtx;
import oracle.ODCI.ODCIIndexInfo;
import oracle.ODCI.ODCIObject;
import oracle.ODCI.ODCIObjectList;
import oracle.ODCI.ODCIPredInfo;
import oracle.ODCI.ODCIQueryInfo;
import oracle.ODCI.ODCIRidList;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.driver.OracleConnection;

import oracle.jpub.runtime.MutableStruct;

import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;

import oracle.xdb.XMLType;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.indexer.ContextManager;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Hit;
import org.apache.lucene.search.HitIterator;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryFilter;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.store.OJVMUtil;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public class LuceneDomainIndex implements CustomDatum, CustomDatumFactory {
    public static final String _SQL_NAME = "LUCENE.LUCENEDOMAININDEX";

    public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

    static final java.math.BigDecimal SUCCESS = new java.math.BigDecimal("0");

    static final java.math.BigDecimal ERROR = new java.math.BigDecimal("1");

    static final int TRUE = 1;

    static final int FALSE = 0;

    static int[] _sqlType = { 4 };

    static CustomDatumFactory[] _factory = new CustomDatumFactory[1];

    MutableStruct _struct;

    static final LuceneDomainIndex _LuceneDomainIndexFactory =
        new LuceneDomainIndex();

    public static CustomDatumFactory getFactory() {
        return _LuceneDomainIndexFactory;
    }

    /* constructor */

    public LuceneDomainIndex() {
        _struct = new MutableStruct(new Object[1], _sqlType, _factory);
    }

    /* CustomDatum interface */

    public Datum toDatum(OracleConnection c) throws SQLException {
        return _struct.toDatum((Connection)c, _SQL_NAME);
    }

    /* CustomDatumFactory interface */

    public CustomDatum create(Datum d, int sqlType) throws SQLException {
        if (d == null)
            return null;
        LuceneDomainIndex o = new LuceneDomainIndex();
        o._struct = new MutableStruct((STRUCT)d, _sqlType, _factory);
        return o;
    }

    /* shallow copy method: give object same attributes as argument */

    void shallowCopy(LuceneDomainIndex d) throws SQLException {
        _struct = d._struct;
    }

    /* accessor methods */

    public Integer getScanctx() throws SQLException {
        return (Integer)_struct.getAttribute(0);
    }

    public void setScanctx(Integer scanctx) throws SQLException {
        _struct.setAttribute(0, scanctx);
    }

    /**
     * @param ia
     * @param env
     * @return an string with the indexschema.indexname[.partitionname]
     * @throws SQLException
     */
    public static String getIndexPrefix(ODCIIndexInfo ia,
                                           ODCIEnv env) throws SQLException {
        String indexPrefix;
        if (ia.getIndexPartition() != null && env.getCallProperty() != null)
            indexPrefix =
                    ia.getIndexSchema() + "." + ia.getIndexName() + "." + ia.getIndexPartition();
        else
            indexPrefix = ia.getIndexSchema() + "." + ia.getIndexName();
        return indexPrefix;
    }

    /**
     * The ODCIGetInterfaces function is invoked when an INDEXTYPE is created by a
     * CREATE INDEXTYPE... statement or is altered.
     * @param ifclist OUT parameter with the type of the interface supported
     * @return SUCESS or ERROR
     */
    public static java.math.BigDecimal ODCIGetInterfaces(ODCIObjectList [] ifclist)
                                       throws SQLException {
        try {
            ODCIObject obj = new ODCIObject();
            obj.setObjectName("ODCIINDEX2");
            obj.setObjectSchema("SYS");
            ODCIObject []list = new ODCIObject[1];
            list[0] = obj;
            ifclist[0] = new ODCIObjectList(list);
        } catch (SQLException sqe) {
            sqe.printStackTrace();
            return ERROR;
        }
        return SUCCESS;
    }

    /**
     * Invoked when a domain index or a domain index partition is altered using 
     * an ALTERINDEX or an ALTER INDEX PARTITION statement.
     * @param ia Contains information about the index and the indexed column
     * @param parms Parameter string,
     *              IN: With ALTER INDEX PARAMETERS or ALTER INDEX REBUILD,
     *              contains the user specified parameter string With ALTER INDEX RENAME,
     *              contains the new name of the domain index
     *              OUT: Valid only with ALTER INDEX PARAMETERS or ALTER INDEX REBUILD;
     *              Contains the resultant string to be stored in system catalogs
     * @param option Specifies one of the following options:
     *              - AlterIndexNone if ALTER INDEX [PARTITION] PARAMETERS
     *              - AlterIndexRename if ALTER INDEX RENAME [PARTITION]
     *              - AlterIndexRebuild if ALTER INDEX REBUILD [PARTITION] 
     *                [PARALLEL (DEGREE deg)] [PARAMETERS]
     *              - AlterIndexUpdBlockRefs if ALTER INDEX [schema.]index UPDATE BLOCK REFERENCES
     * @param env The environment handle passed to the routine
     * @return ODCIConst.Success on success, ODCIConst.Error on error,
     *         or ODCIConst.Warning otherwise.
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIIndexAlter(ODCIIndexInfo ia,
                                                       String[] parms,
                                                       java.math.BigDecimal option,
                                                       ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        Parameters parameters = new Parameters();
        /*System.out.println("Alter parms: '" + parms[0] + "' option = "+option);
        System.out.println("ODCIIndexInfo.getIndexName: " + ia.getIndexName() +
                           " ODCIIndexInfo.getIndexSchema: " +
                           ia.getIndexSchema() +
                           " ODCIIndexInfo.getIndexPartition: " +
                           ia.getIndexPartition());
        System.out.println("getIndexCols.length: "+ia.getIndexCols().length());*/
        String directoryPrefix = getIndexPrefix(ia, env);
        try {
            if (parms != null && parms[0] != null && option.equals(BigDecimal.valueOf(0))) {
              String paramstr = parms[0];
              String [] parmList = paramstr.split(",");
              for (int i=0;i<parmList.length;i++) {
                String []nameValue = parmList[i].split(":");
                parameters.setParameter(nameValue[0],nameValue[1]);
              }
            } else
                throw new SQLException("ODCIIndexAlter error parameter is null or option not implemented.");
            String columnName = ia.getIndexCols().getElement(0).getColName().replaceAll("\"","");
            parameters.setParameter("ColName",columnName);
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            dir.setParameters(parameters);
            parms[0] = parameters.toString();
            //System.out.println("parameters.toString(): "+parameters.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
                if (dir != null)
                    dir.close();
                dir = null;
            } catch (IOException e) {
                e.printStackTrace();
                return ERROR;
            }
        }
        return SUCCESS;
    }
                                                       
    /**
     * When a user issues a CREATE INDEX statement that references the indextype,
     * Oracle calls your ODCIIndexCreate() method, passing it any parameters specified
     * as part of the CREATE INDEX... PARAMETERS (...) statement, plus the description
     * of the index.
     * Typically, this method creates the tables or files in which you plan to store
     * index data. Unless the base table is empty, the method should also build the index.
     * @param ia Contains information about the index and the indexed column
     * @param parms Parameter string,
     *              IN: With ALTER INDEX PARAMETERS or ALTER INDEX REBUILD,
     *              contains the user specified parameter string With ALTER INDEX RENAME,
     *              contains the new name of the domain index
     *              OUT: Valid only with ALTER INDEX PARAMETERS or ALTER INDEX REBUILD;
     *              Contains the resultant string to be stored in system catalogs
     * @param env The environment handle passed to the routine
     * @return ODCIConst.Success on success, ODCIConst.Error on error,
     *         or ODCIConst.Warning otherwise.
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIIndexCreate(ODCIIndexInfo ia,
                                                       String parms,
                                                       ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexWriter writer = null;
        Parameters parameters = new Parameters();
        /*System.out.println("Create parms: '" + parms + "'");
        System.out.println("ODCIIndexInfo.getIndexName: " + ia.getIndexName() +
                           " ODCIIndexInfo.getIndexSchema: " +
                           ia.getIndexSchema() +
                           " ODCIIndexInfo.getIndexPartition: " +
                           ia.getIndexPartition());
        System.out.println("getIndexCols.length: "+ia.getIndexCols().length());*/
        String directoryPrefix = getIndexPrefix(ia, env);
        try {
            if (parms!=null) {
              String [] parmList = parms.split(",");
              for (int i=0;i<parmList.length;i++) {
                String []nameValue = parmList[i].split(":");
                parameters.setParameter(nameValue[0],nameValue[1]);
              }
            }
            String columnName = ia.getIndexCols().getElement(0).getColName().replaceAll("\"","");
            parameters.setParameter("ColName",columnName);
            String analyzerStr = parameters.getParameter("Analyzer","org.apache.lucene.analysis.SimpleAnalyzer");
            int mergeFactor = Integer.parseInt(parameters.getParameter("MergeFactor",""+IndexWriter.DEFAULT_MERGE_FACTOR));
            int maxBufferedDocs = Integer.parseInt(parameters.getParameter("MaxBufferedDocs",""+IndexWriter.DEFAULT_MAX_BUFFERED_DOCS));
            int maxMergeDocs = Integer.parseInt(parameters.getParameter("MaxMergeDocs",""+IndexWriter.DEFAULT_MAX_MERGE_DOCS));
            Analyzer analyzer = null;
            try {
                Class clazz = analyzerStr.getClass().forName(analyzerStr);
                analyzer = (Analyzer)clazz.newInstance();
            } catch (ClassNotFoundException c) {
                c.printStackTrace();
                return ERROR;
            } catch (InstantiationException i) {
                i.printStackTrace();
                return ERROR;
            } catch (IllegalAccessException e) {
                e.printStackTrace();
                return ERROR;
            }
            /*
            System.out.println("Indexing column: '"+columnName+"'");
            System.out.println("Analyzer: '"+analyzerStr+"'");
            System.out.println("MergeFactor: "+mergeFactor);
            System.out.println("MaxBufferedDocs: "+maxBufferedDocs);
            System.out.println("MaxMergeDocs: "+maxMergeDocs);
            */
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            writer = new IndexWriter(dir, analyzer, true);
            writer.setMergeFactor(mergeFactor);
            writer.setMaxMergeDocs(maxMergeDocs);
            writer.setMaxBufferedDocs(maxBufferedDocs);
            TableIndexer index =
                new TableIndexer(OJVMUtil.getConnection(),
                                 ia.getIndexCols().getElement(0).getTableSchema(),
                                 ia.getIndexCols().getElement(0).getTableName(),
                                 ((ia.getIndexPartition() != null &&
                                   env.getCallProperty() != null) ?
                                  ia.getIndexCols().getElement(0)
                                  .getTablePartition() : null));
            index.index(writer, columnName);
            dir.setParameters(parameters);
            dir.removeCachedSearcher();
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
                if (writer != null)
                    writer.close();
                //if (tmpDir != null)
                //    tmpDir.close();
                if (dir != null)
                    dir.close();
            } catch (IOException e) {
                e.printStackTrace();
                return ERROR;
            }
        }
        return SUCCESS;
    }

    /**
     * When a user issues a DROP statement against a table that contains a
     * column or object type attribute indexed by your indextype, Oracle calls your
     * ODCIIndexDrop() method. This method should leave the domain index empty.
     * @param ia
     * @param env
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIIndexDrop(ODCIIndexInfo ia,
                                                     ODCIEnv env) throws SQLException {
        String directoryPrefix = getIndexPrefix(ia, env);
        Connection conn = null;
        PreparedStatement stmt = null;
        //System.out.println("Drop index: " + directoryPrefix);
        try {
            conn = OJVMUtil.getConnection();
            LuceneQueue.discard(conn,directoryPrefix);
            stmt = conn.prepareStatement("DELETE FROM LUCENE_INDEX WHERE PREFIX = ?");
            stmt.setString(1,directoryPrefix);
            stmt.execute();
        } catch (SQLException s) {
            s.printStackTrace();
            return ERROR;
        } finally {
            OJVMUtil.closeDbResources(stmt,null);
        }
        return SUCCESS;
    }
    
    /**
     * When a user issues a TRUNCATE statement against a table that contains a
     * column or object type attribute indexed by your indextype, Oracle calls your
     * ODCIIndexTruncate() method. This method should leave the domain index empty.
     * @param ia
     * @param env
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIIndexTruncate(ODCIIndexInfo ia,
                                                         ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexWriter writer = null;
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Truncate. on index: " + directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            Parameters parameters = dir.getParameters();
            String analizerStr = parameters.getParameter("Analyzer","org.apache.lucene.analysis.SimpleAnalyzer");
            Analyzer analyzer = null;
            try {
                Class clazz = analizerStr.getClass().forName(analizerStr);
                analyzer = (Analyzer)clazz.newInstance();
            } catch (ClassNotFoundException c) {
                c.printStackTrace();
                return ERROR;
            } catch (InstantiationException i) {
                i.printStackTrace();
                return ERROR;
            } catch (IllegalAccessException e) {
                e.printStackTrace();
                return ERROR;
            }
            // Discard pending changes and purge deleted documents
            LuceneQueue.discard(dir.getConnection(),directoryPrefix);
            //System.out.println("Analyzer: '"+analizerStr+"'");
            // open a writer object with last argument to true cause truncation on lucene index
            writer = new IndexWriter(dir, analyzer, true);
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
                if (writer != null)
                    writer.close();
                writer = null;
                if (dir != null)
                    dir.close();
                dir = null;
            } catch (IOException e) {
                e.printStackTrace();
                return ERROR;
            }
        }
        return SUCCESS;
    }

    /**
     * Overloading version for XMLType columns
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal TextContains(XMLType text,
                                                    String keyStr,
                                                    ODCIIndexCtx ctx,
                                                    LuceneDomainIndex[] sctx,
                                                    java.math.BigDecimal scanflg) throws SQLException,
                                                                                         IOException,
                                                                                         ParseException {
        return TextContains(((text!=null) ? TableIndexer.textExtractor(text).toString() : ""),
                            keyStr, ctx, sctx,
                            scanflg); // column value is not used
    }

    /**
     * Overloading version for CLOB columns data type
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal TextContains(CLOB text,
                                                    String keyStr,
                                                    ODCIIndexCtx ctx,
                                                    LuceneDomainIndex[] sctx,
                                                    java.math.BigDecimal scanflg) throws SQLException,
                                                                                         IOException,
                                                                                         ParseException {
        return TextContains(((text!=null) ? text.getSubString(1, (int)text.length()) : ""),
                            keyStr, ctx, sctx,
                            scanflg); // column value is not used
    }

    /**
     * Functional implementation for the SQL Operator lcontains(colum,'text to search')>0
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal TextContains(String text, String keyStr,
                                                    ODCIIndexCtx ctx,
                                                    LuceneDomainIndex[] sctx,
                                                    java.math.BigDecimal scanflg) throws SQLException,
                                                                                         IOException,
                                                                                         ParseException {

        int flag = scanflg.intValue();
        //System.out.println("TextContains. Operator rowid='" + ((ctx!=null) ? ctx.getRid() : "null") +
        //                   "' text='"+text+"' key= '"+keyStr+"' scanflg='"+flag+"'");
        ODCIIndexInfo ia = (ctx != null) ? ctx.getIndexInfo() : null;
        //System.out.println("TextContains. ODCIIndexInfo="+ia);
        if (flag == 1 && sctx!=null && sctx[0]!=null) { // close index operation
            return new BigDecimal("1");
        }
        if (ia == null &&
            flag > 0) { // no Domain Index is bound to a particular column
            if (flag == 2 && text.matches(keyStr)) // note that here is not lucene query syntas, is regexp!!
                return new BigDecimal("1");
            else
                return new BigDecimal("0");
        }
        String directoryPrefix =
            (ia.getIndexPartition() != null) ? ia.getIndexSchema() + "." +
            ia.getIndexName() + "." + ia.getIndexPartition() :
            ia.getIndexSchema() + "." + ia.getIndexName();
        Entry entry = OJVMDirectory.getCachedSearcher(directoryPrefix);
        TermQuery tq = new TermQuery(new Term("rowid",
                                              ctx.getRid()));
        Searcher searcher = entry.getSeacher();
        Filter docsFilter = null;
        docsFilter = entry.getFilter(keyStr);
        String columnName = ia.getIndexCols().getElement(0).getColName().replaceAll("\"","");
        if (docsFilter == null) {
            QueryParser parser = new QueryParser(columnName,entry.getAnalyzer());
            Query qry = parser.parse(keyStr);
            docsFilter = new QueryFilter(qry);
            entry.addFilter(keyStr,docsFilter);
            //System.out.println("TextContains: storing cachingFilter: "+docsFilter.hashCode()+" and searcher: "+searcher.hashCode());
        }
        if (sctx == null || sctx[0] == null) {
            sctx[0] = new LuceneDomainIndex();
            sctx[0].setScanctx(new Integer(1));
        } 
        Hits hits =
                searcher.search(tq,docsFilter);
        //System.out.println("TextContains: using cachingFilter: "+docsFilter.hashCode()+" and searcher: "+searcher.hashCode());
        return BigDecimal.valueOf(hits.length());
    }

    /**
     * Overloading version for XMLType column data type
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal TextScore(XMLType text, String keyStr,
                                                 ODCIIndexCtx ctx,
                                                 LuceneDomainIndex[] sctx,
                                                 java.math.BigDecimal scanflg) throws SQLException {
        return TextScore("", "", ctx, sctx, scanflg);
    }

    /**
     * Overloading version for CLOB column data type
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal TextScore(CLOB text, String keyStr,
                                                 ODCIIndexCtx ctx,
                                                 LuceneDomainIndex[] sctx,
                                                 java.math.BigDecimal scanflg) throws SQLException {
        return TextScore("", "", ctx, sctx, scanflg);
    }

    /**
     * Return a pre-computed value of the score() value for a particular rowid.
     * We assume that OCIFetch function was called first and store the score for
     * each rowid visited.
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal TextScore(String text, String keyStr,
                                                 ODCIIndexCtx ctx,
                                                 LuceneDomainIndex[] sctx,
                                                 java.math.BigDecimal scanflg) throws SQLException {
        LuceneDomainContext sbtctx;
        //System.out.println("TextScore. Operator rowid='" + ctx.getRid() +
        //                   "' text='"+text+"' key= '"+keyStr+"' scanflg='"+scanflg+"'");
        int key;
        if (sctx == null || sctx[0] == null) // Sanity checks
            throw new SQLException("LuceneDomainIndex parameter is null.");
        key = sctx[0].getScanctx().intValue();
        //System.out.println("ContextManager key=" + key);

        // Get the resultSet back from the ContextManager using the key
        sbtctx = (LuceneDomainContext)ContextManager.getContext(key);
        Hashtable cachedRowids = sbtctx.getScoreList();
        //System.out.println("TextScore getting slist: "+cachedRowids.hashCode());
        Float scoreValue = (Float)cachedRowids.get(ctx.getRid());
        if (scoreValue == null)
            throw new SQLException("Ooops, I can't find a pre-cached score with this rowid= '" +
                                   ctx.getRid() + "'");
        return new java.math.BigDecimal(scoreValue.doubleValue());
    }

    /**
     * Oracle calls your ODCIStart() method at the beginning of an index scan,
     * passing it information on the index and the operator. Typically, this method:
     * - Initializes data structures used in the scan
     * - Parses and executes SQL statements that query the tables storing the index data
     * - Saves any state information required by the fetch and cleanup methods, and
     *   returns the state or a handle to it
     * - Sometimes generates a set of result rows to be returned at the first invocation of
     *   ODCIFetch()
     * The information on the index and the operator is not passed to the fetch and cleanup
     * methods. Thus, ODCIStart() must save state data that needs to be shared
     * among the index scan routines and return it through an output sctx parameter. To
     * share large amounts of state data, allocate cursor-duration memory and return a
     * handle to the memory in the sctx parameter.
     * As member methods, ODCIFetch() and ODCIClose() are passed the
     * built-in SELF parameter, through which they can access the state data.
     * @param sctx IN: The value of the scan context returned by some previous related
     *                 query-time call (such as the corresponding ancillary operator, if
     *                 invoked before the primary operator); NULL otherwise
     *             OUT: The context that is passed to the next query-time call; the next
     *                  query-time call will be to ODCIIndexFetch
     * @param ia Contains information about the index and the indexed column
     * @param op Contains information about the operator predicate
     * @param qi Contains query information (hints plus list of ancillary operators referenced)
     * @param strt The start value of the bounds on the operator return value.
     *             The datatype is the same as that of the operator's return value
     * @param stop The stop value of the bounds on the operator return value.
     *             The datatype is the same as that of the operator's return value.
     * @param cmpval The value arguments of the operator invocation. The number and
     *               datatypes of these arguments are the same as those of the value
     *               arguments to the operator.
     * @param env The environment handle passed to the routine
     * @return ODCIConst.Success on success, or ODCIConst.Error on error
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIStart(LuceneDomainIndex[] sctx,
                                                 ODCIIndexInfo ia,
                                                 ODCIPredInfo op,
                                                 ODCIQueryInfo qi,
                                                 java.math.BigDecimal strt,
                                                 java.math.BigDecimal stop,
                                                 String cmpval,
                                                 ODCIEnv env) throws java.sql.SQLException {
        //System.out.println("ODCIStart. Operator '" + op.getObjectName() +
        //                   "' cmpval='" + cmpval + "' strt= '" + strt +
        //                   "' stop='" + stop + "'");
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Saved parameters.\n"+parms.toString());
        int key;
        LuceneDomainContext sbtctx; // cntxt obj that holds the ResultSet and Statement
        //Directory dir = OJVMDirectory.getDirectory(directoryPrefix);
        Searcher searcher = null;
        HitIterator iterator = null;
        if (!op.getObjectName().equalsIgnoreCase("lcontains"))
            throw new SQLException("Expected lcontains operator, use lcontains(column,'text to search')>0");
        if (strt==null || stop!=null)
            throw new SQLException("NOT functionality is not implemented, use lcontains(column,'text to search')>0");
        int strtValue = strt.intValue();
        if (strtValue!=0)
            throw new SQLException("Incorrect value for the operator, use lcontains(column,'text to search')>0");
        try {
            Entry entry = OJVMDirectory.getCachedSearcher(directoryPrefix);
            String columnName = ia.getIndexCols().getElement(0).getColName().replaceAll("\"","");
            //System.out.println("Indexing column: '"+columnName+"'");
            //System.out.println("Analyzer: "+entry.getAnalyzer());
            searcher = entry.getSeacher();
            QueryParser parser = new QueryParser(columnName,entry.getAnalyzer());
            Query qry = parser.parse(cmpval);
            Filter docsFilter = null;
            docsFilter = entry.getFilter(cmpval);
            if (docsFilter == null) {
                docsFilter = new QueryFilter(qry);
                entry.addFilter(cmpval,docsFilter);
                //System.out.println("ODCIStart: storing cachingFilter: "+docsFilter.hashCode()+" and searcher: "+searcher.hashCode());
            }
            Hits hits =
                searcher.search(qry,docsFilter);
            iterator = (HitIterator)hits.iterator();
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } catch (ParseException p) {
            p.printStackTrace();
            return ERROR;
        }
        sbtctx = new LuceneDomainContext(iterator);
        sctx[0] = new LuceneDomainIndex();
        key = ContextManager.setContext((Object)sbtctx);

        //System.out.println("ContextManager key=" + key);

        // set the key into the self argument so that we can retrieve the
        // context with this key later.
        sctx[0].setScanctx(new Integer(key));

        return SUCCESS;
    }

    /**
     * Oracle calls your ODCIFetch() method to return the row identifiers of
     * the next batch of rows that satisfies the operator predicate, passing it
     * the state data returned by ODCIStart() or the previous ODCIFetch() call.
     * The operator predicate is specified in terms of the operator expression
     * (name and arguments) and a lower and upper bound on the operator return values.
     * Thus, ODCIFetch() must return the row identifiers of the rows for which
     * the operator return value falls within the specified bounds. To indicate
     * the end of index scan, return a NULL.
     * @param nrows Is the maximum number of result rows that can be returned to
     *              Oracle in this call
     * @param rids  Is the array of row identifiers for the result rows being
     *              returned by this call
     * @param env   The environment handle passed to the routine
     * @return ODCIConst.Success on success, or ODCIConst.Error on error
     * @throws SQLException
     */
    public java.math.BigDecimal ODCIFetch(java.math.BigDecimal nrows,
                                          ODCIRidList[] rids,
                                          ODCIEnv env) throws java.sql.SQLException {
        LuceneDomainContext sbtctx; // cntxt obj that holds the ResultSet and Statement
        String rid;
        float score;
        HitIterator iterator = null;
        int idx = 1;
        int done = FALSE;
        int nRows = nrows.intValue();
        String[] rlist = new String[nRows];
        Hashtable slist = new Hashtable(nRows);
        int key = getScanctx().intValue();
        //System.out.println("Fetch nrows : " + nRows);
        //System.out.println("ContextManager key=" + key);

        // Get the resultSet back from the ContextManager using the key
        sbtctx = (LuceneDomainContext)ContextManager.getContext(key);
        iterator = sbtctx.getIterator();

        //***************
        // Fetch rowids *
        //***************
        for (int i = 0; done != TRUE; i++) {
            if (idx > nRows) {
                done = TRUE;
            } else {
                if (iterator.hasNext()) {
                    // append rowid to collection
                    Hit hit = (Hit)iterator.next();
                    try {
                        rid = hit.get("rowid");
                        score = hit.getScore();
                    } catch (IOException e) {
                        e.printStackTrace();
                        throw new SQLException(e.getMessage());
                    }
                    rlist[i] = new String(rid);
                    slist.put(rid, new Float(score));
                    idx++;
                } else {
                    // append null r࡯wid to collection
                    rlist[i] = null;
                    done = TRUE;
                }
            }
        }

        // Store last fetch of score List to be used by score() ancillary operator
        //System.out.println("ODCIFetch storing slist: "+slist.hashCode());
        sbtctx.setScoreList(slist);

        // Since rids is an out parameter we need to set the ODCIRidList
        // object into the first position to be passed out.
        rids[0] = new ODCIRidList(rlist);

        return SUCCESS;
    }

    /**
     * Oracle calls your ODCIIndexClose() method when the cursor is closed or reused,
     * passing it the current state. ODCIIndexClose() should perform whatever cleanup
     * or closure operations your indextype requires.
     * @param env The environment handle passed to the routine
     * @return ODCIConst.Success on success, ODCIConst.Error on error
     * @throws SQLException
     */
    public java.math.BigDecimal ODCIClose(ODCIEnv env) throws java.sql.SQLException {
        LuceneDomainContext sbtctx; // contxt obj that holds the ResultSet and Statement
        //Directory dir = null;
        //IndexSearcher searcher = null;
        int key = getScanctx().intValue();
        //System.out.println("ODCIClose key=" + key);

        // Get the resultSet and statement back from the ContextManager
        // so that we can close them.
        sbtctx = (LuceneDomainContext)ContextManager.clearContext(key);
        return SUCCESS;
    }

    /**
     * Overloaded version for CLOB columns
     * @param ia
     * @param rid
     * @param newval
     * @param env
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal ODCIInsert(ODCIIndexInfo ia, String rid,
                                                  CLOB newval,
                                                  ODCIEnv env) throws SQLException,
                                                                      IOException {
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Insert. newval: '" + newval + "' rowid: '" + rid +
        //                   "' on index: " + directoryPrefix);
        LuceneQueue.enqueue(directoryPrefix,rid,"insert",newval);
        return SUCCESS;
    }

    /**
     * Overloaded version for XMLType columns
     * @param ia
     * @param rid
     * @param newval
     * @param env
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal ODCIInsert(ODCIIndexInfo ia, String rid,
                                                  XMLType newval,
                                                  ODCIEnv env) throws SQLException,
                                                                      IOException {
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Insert. newval: '" + newval + "' rowid: '" + rid +
        //                   "' on index: " + directoryPrefix);
        LuceneQueue.enqueue(directoryPrefix,rid,"insert",newval);
        return SUCCESS;
    }

    /**
     * When a user inserts a record, Oracle calls your ODCIIndexInsert() method,
     * passing it the new values in the indexed columns and the corresponding row
     * identifier.
     * @param ia
     * @param rid
     * @param newval
     * @param env
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal ODCIInsert(ODCIIndexInfo ia, String rid,
                                                  String newval,
                                                  ODCIEnv env) throws SQLException {
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Insert. newval: '" + newval + "' rowid: '" + rid +
        //                   "' on index: " + directoryPrefix);
        LuceneQueue.enqueue(directoryPrefix,rid,"insert",newval);
        return SUCCESS;
    }

    /**
     * Overloaded version for CLOB columns
     * @param ia
     * @param rid
     * @param oldval
     * @param env
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIDelete(ODCIIndexInfo ia, String rid,
                                                  CLOB oldval,
                                                  ODCIEnv env) throws SQLException {
        return ODCIDelete(ia, rid, "",
                          env); // val is not required by delete operations
    }

    /**
     * Overloaded version for XMLType columns
     * @param ia
     * @param rid
     * @param oldval
     * @param env
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIDelete(ODCIIndexInfo ia, String rid,
                                                  XMLType oldval,
                                                  ODCIEnv env) throws SQLException {
        return ODCIDelete(ia, rid, "",
                          env); // val is not required by delete operations
    }

    /**
     * When a user deletes a record, Oracle calls your ODCIIndexDelete() method,
     * passing it the old values in the indexed columns and the corresponding
     * row identifier.
     * @param ia
     * @param rid
     * @param oldval
     * @param env
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIDelete(ODCIIndexInfo ia, String rid,
                                                  String oldval,
                                                  ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexReader reader = null;
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Delete. oldval: '" + oldval + "' rowid: '" + rid +
        //                   "' on index: " + directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            reader = IndexReader.open(dir);
            reader.deleteDocuments(new Term("rowid", rid));
            LuceneQueue.enqueue(directoryPrefix,rid,"delete","-");
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
                if (reader != null)
                    reader.close();
                if (dir != null)
                    dir.close();
            } catch (IOException e) {
                e.printStackTrace();
                return ERROR;
            }
        }
        return SUCCESS;
    }

    /**
     * Overloaded version for CLOB columns
     * @param ia
     * @param rid
     * @param oldval
     * @param newval
     * @param env
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal ODCIUpdate(ODCIIndexInfo ia, String rid,
                                                  CLOB oldval,
                                                  CLOB newval,
                                                  ODCIEnv env) throws SQLException,
                                                                      IOException {
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Insert. newval: '" + newval + "' rowid: '" + rid +
        //                   "' on index: " + directoryPrefix);
        LuceneQueue.enqueue(directoryPrefix,rid,"update",newval);
        return SUCCESS;
    }

    /**
     * Overloaded version for XMLType columns
     * @param ia
     * @param rid
     * @param oldval
     * @param newval
     * @param env
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal ODCIUpdate(ODCIIndexInfo ia, String rid,
                                                  XMLType oldval,
                                                  XMLType newval,
                                                  ODCIEnv env) throws SQLException,
                                                                      IOException {
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Insert. newval: '" + newval + "' rowid: '" + rid +
        //                   "' on index: " + directoryPrefix);
        LuceneQueue.enqueue(directoryPrefix,rid,"update",newval);
        return SUCCESS;
    }

    /**
     * When a user updates a record, Oracle calls your ODCIIndexUpdate() method,
     * passing it the old and new values in the indexed columns and the corresponding
     * row identifier.
     * @param ia
     * @param rid
     * @param oldval
     * @param newval
     * @param env
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIUpdate(ODCIIndexInfo ia, String rid,
                                                  String oldval, String newval,
                                                  ODCIEnv env) throws SQLException {
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Insert. newval: '" + newval + "' rowid: '" + rid +
        //                   "' on index: " + directoryPrefix);
        LuceneQueue.enqueue(directoryPrefix,rid,"update",newval);
        return SUCCESS;
    }

    /**
     * Process pending changes on the index (delete,update,insert DML operations)
     * delete operations are allways synced because the index can not return invalid rowid
     * but the delete operation is queued too.
     * @param directoryPrefix
     * @throws IOException
     * @throws SQLException
     */
    public static void sync(String directoryPrefix) throws IOException,
                                                           SQLException {
        LuceneQueue.sync(directoryPrefix);
        LuceneQueue.purge(directoryPrefix);
    }

    public static void optimize(String directoryPrefix) throws IOException,
                                                           SQLException {
        OJVMDirectory dir = null;
        IndexWriter writer = null;
        //System.out.println("Truncate. optimize index: " + directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            Parameters parameters = dir.getParameters();
            String analizerStr = parameters.getParameter("Analyzer","org.apache.lucene.analysis.SimpleAnalyzer");
            int mergeFactor = Integer.parseInt(parameters.getParameter("MergeFactor",""+IndexWriter.DEFAULT_MERGE_FACTOR));
            int maxBufferedDocs = Integer.parseInt(parameters.getParameter("MaxBufferedDocs",""+IndexWriter.DEFAULT_MAX_BUFFERED_DOCS));
            int maxMergeDocs = Integer.parseInt(parameters.getParameter("MaxMergeDocs",""+IndexWriter.DEFAULT_MAX_MERGE_DOCS));
            Analyzer analyzer = null;
            try {
                Class clazz = analizerStr.getClass().forName(analizerStr);
                analyzer = (Analyzer)clazz.newInstance();
            } catch (ClassNotFoundException c) {
                c.printStackTrace();
                throw new SQLException(c.getMessage());
            } catch (InstantiationException i) {
                i.printStackTrace();
                throw new SQLException(i.getMessage());
            } catch (IllegalAccessException e) {
                e.printStackTrace();
                throw new SQLException(e.getMessage());
            }
            //System.out.println("Analyzer: '"+analizerStr+"'");
            // open a writer object with last argument to true cause truncation on lucene index
            writer = new IndexWriter(dir, analyzer, false);
            writer.setMergeFactor(mergeFactor);
            writer.setMaxMergeDocs(maxMergeDocs);
            writer.setMaxBufferedDocs(maxBufferedDocs);
            writer.optimize();
            // after optimize purge deleted documents
            LuceneQueue.purge(directoryPrefix);
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                if (writer != null)
                    writer.close();
                if (dir != null)
                    dir.close();
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            }
        }
    }
}
