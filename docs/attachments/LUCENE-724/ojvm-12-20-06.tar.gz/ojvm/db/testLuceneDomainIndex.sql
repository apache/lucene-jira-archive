set long 10000 lines 140 pages 50 timing on echo on
set serveroutput on size 1000000 

begin
  dbms_java.set_output(1000000);
end;
/

/*
declare
  c NUMBER;
begin
  for i in 1..32000 loop
  -- dbms_output.put_line('iteration '||i);
  select count(*) into c from t1 where lcontains(f2, 'ravi') > 0;
  -- dbms_output.put_line('count '||c);
  end loop;
end;

-- as SYS
SELECT a.sql_text,a.USERS_OPENING,a.EXECUTIONS FROM sys.v_$sqlarea a,sys.all_users b 
WHERE a.parsing_user_id = b.user_id and b.username = 'LUCENE'
order by a.executions desc;
*/

/*
-- Demo indexing a big table (96k rows)
create table test_source_big as (select text from all_source);
-- MergeFactor,MaxBufferedDocs and MaxMergeDocs reduce IO over the BLOB storage
-- but you can get a java.lang.OutOfMemoryError with bigger values.
create index source_big_lidx on test_source_big(text) 
indextype is lucene.LuceneIndex 
parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer,MergeFactor:1000,MaxBufferedDocs:1000');
create index source_big_idx on test_source_big(text) 
indextype is ctxsys.context; 

insert into test_source_big
select TEXT from (select rownum as ntop_pos,q.* from
(select text from all_source) q)
where ntop_pos>=0 and ntop_pos<10000;
begin
   LuceneDomainIndex.sync(USER||'.SOURCE_BIG_LIDX');
   commit;
end;
/
select count(TEXT) from (select rownum as ntop_pos,q.* from
(select text from test_source_big where lcontains(text,'function')>0) q)
where ntop_pos>=0 and ntop_pos<10;

insert into test_source_big
select TEXT from (select rownum as ntop_pos,q.* from
(select text from all_source) q)
where ntop_pos>=10000 and ntop_pos<20000;
begin
   LuceneDomainIndex.sync(USER||'.SOURCE_BIG_LIDX');
   commit;
end;
/
select count(TEXT) from (select rownum as ntop_pos,q.* from
(select text from test_source_big where lcontains(text,'function')>0) q)
where ntop_pos>=0 and ntop_pos<10;

insert into test_source_big
select TEXT from (select rownum as ntop_pos,q.* from
(select text from all_source) q)
where ntop_pos>=20000 and ntop_pos<40000;
begin
   LuceneDomainIndex.sync(USER||'.SOURCE_BIG_LIDX');
   commit;
end;
/
select count(TEXT) from (select rownum as ntop_pos,q.* from
(select text from test_source_big where lcontains(text,'function')>0) q)
where ntop_pos>=0 and ntop_pos<10;

*/
-- Demo indexing an small table (487 rows)
-- test sync(index),optimize(index) procedures and deferred, massive batch inserts
create table test_source_small as 
(
select NAME,TYPE,LINE,TEXT from 
(select rownum as ntop_pos,q.* from (select * from user_source) q)
where ntop_pos>=0 and ntop_pos<100
);
create index source_small_lidx on test_source_small(text) 
indextype is lucene.LuceneIndex 
parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer,MaxBufferedDocs:500');
-- create index source_small_idx on test_source_small(text) 
-- indextype is ctxsys.context;
begin
   LuceneDomainIndex.optimize(USER||'.SOURCE_SMALL_LIDX');
   commit;
end;
/
select count(*) from test_source_small where lcontains(text,'type')>0;

insert into test_source_small
select NAME,TYPE,LINE,TEXT from (select rownum as ntop_pos,q.* from
(select * from user_source) q)
where ntop_pos>=100 and ntop_pos<200;
begin
   LuceneDomainIndex.sync(USER||'.SOURCE_SMALL_LIDX');
   commit;
end;
/
select count(*) from test_source_small where lcontains(text,'type')>0;

insert into test_source_small
select NAME,TYPE,LINE,TEXT from (select rownum as ntop_pos,q.* from
(select * from user_source) q)
where ntop_pos>=200 and ntop_pos<500;
begin
   LuceneDomainIndex.sync(USER||'.SOURCE_SMALL_LIDX');
   commit;
end;
/
select count(*) from test_source_small where lcontains(text,'type')>0;
begin
   LuceneDomainIndex.optimize(USER||'.SOURCE_SMALL_LIDX');
   commit;
end;
/
select count(*) from test_source_small where lcontains(text,'type')>0;
drop table test_source_small;

create table t1 (f1 number, f2 varchar2(200));
insert into t1 values (1, 'ravi');
insert into t1 values (3, 'murthy');
commit;

create index it1 on t1(f2) indextype is lucene.LuceneIndex parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer');

-- query
select * from t1 where lcontains(f2, 'ravi') > 0;

explain plan for
select * from t1 where lcontains(f2, 'ravi') > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f2, 'aaa') > 0;

explain plan for
select * from t1 where lcontains(f2, 'aaa') > 0;
set echo off
@@explainPlan
set echo on

alter index it1 parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer,MaxBufferedDocs:500');

-- INSERT TESTS
INSERT INTO t1 VALUES (6, 'cheuk');
INSERT INTO t1 VALUES (7, 'chau');

-- UPDATE TEST
UPDATE t1 SET f2 = 'Nipun' WHERE f1 = 3;

-- INSERT TESTS
INSERT INTO t1 VALUES (16, 'ravi marcelo');
INSERT INTO t1 VALUES (17, 'marcelo');

-- query from index table
-- SELECT name,file_size FROM lucene_index;

begin
  LuceneDomainIndex.sync(USER||'.IT1');
end;
/

begin
  LuceneDomainIndex.optimize(USER||'.IT1');
end;
/

-- query from index table
-- SELECT name,file_size FROM lucene_index;

select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f2, 'Nipun') > 0;

explain plan for
select * from t1 where lcontains(f2, 'Nipun') > 0;
set echo off
@@explainPlan
set echo on

select lcontains(f2,'ravi') from t1;

explain plan for
select lcontains(f2,'ravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST, this operation is never enqueued!!!
DELETE FROM t1 WHERE f2 = 'ravi';

-- query from index table
-- SELECT name,file_size FROM lucene_index;

select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

-- DROP TEST
drop table t1;

create table t1 (f1 number, f2 CLOB);
insert into t1 values (1, 'ravi');
insert into t1 values (3, 'murthy');
commit;

create index it1 on t1(f2) indextype is lucene.LuceneIndex parameters('Analyzer:org.apache.lucene.analysis.SimpleAnalyzer');

-- query
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f2, 'aaa') > 0;

explain plan for
select * from t1 where lcontains(f2, 'aaa') > 0;
set echo off
@@explainPlan
set echo on

alter index it1 parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer,MaxBufferedDocs:500');

-- INSERT TESTS
INSERT INTO t1 VALUES (6, 'cheuk');
INSERT INTO t1 VALUES (7, 'chau');

-- UPDATE TEST
UPDATE t1 SET f2 = 'Nipun' WHERE f1 = 3;

-- INSERT TESTS
INSERT INTO t1 VALUES (16, 'ravi marcelo');
INSERT INTO t1 VALUES (17, 'marcelo');

-- query from index table
-- SELECT name,file_size FROM lucene_index;

begin
  LuceneDomainIndex.sync(USER||'.IT1');
end;
/

-- SELECT name,file_size FROM lucene_index;

select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f2, 'Nipun') > 0;

explain plan for
select * from t1 where lcontains(f2, 'Nipun') > 0;
set echo off
@@explainPlan
set echo on

select lcontains(f2,'ravi') from t1;

explain plan for
select lcontains(f2,'ravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST
DELETE FROM t1 WHERE f1 = 1;

-- query from index table
-- SELECT name,file_size FROM lucene_index;

select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

-- DROP TEST
drop table t1;


create table t1 (f1 number, f2 XMLType);
insert into t1 values (1, XMLType('<emp id="1"><name>ravi</name></emp>'));
insert into t1 values (3, XMLType('<emp id="3"><name>murthy</name></emp>'));
commit;

create index it1 on t1(f2) indextype is lucene.LuceneIndex parameters('Analyzer:org.apache.lucene.analysis.WhitespaceAnalyzer');

commit;

-- query
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f2, 'aaa') > 0;

explain plan for
select * from t1 where lcontains(f2, 'aaa') > 0;
set echo off
@@explainPlan
set echo on

alter index it1 parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer,MaxBufferedDocs:500');

-- INSERT TESTS
INSERT INTO t1 VALUES (6, XMLType('<emp id="6"><name>cheuk</name></emp>'));
INSERT INTO t1 VALUES (7, XMLType('<emp id="7"><name>chau</name></emp>'));

-- UPDATE TEST
UPDATE t1 SET f2 = XMLType('<emp id="3"><name>Nipun</name></emp>') WHERE f1 = 3;

-- INSERT TESTS
INSERT INTO t1 VALUES (16, XMLType('<emp id="10"><name>ravi marcelo</name></emp>'));
INSERT INTO t1 VALUES (17, XMLType('<emp id="16"><name>marcelo</name></emp>'));

-- query from index table
-- SELECT name,file_size FROM lucene_index;

begin
  LuceneDomainIndex.sync(USER||'.IT1');
end;
/

-- SELECT name,file_size FROM lucene_index;

select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f2, 'Nipun') > 0;

explain plan for
select * from t1 where lcontains(f2, 'Nipun') > 0;
set echo off
@@explainPlan
set echo on

select lcontains(f2,'ravi') from t1;

explain plan for
select lcontains(f2,'ravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST
DELETE FROM t1 WHERE f1 = 1;

-- query from index table
-- SELECT name,file_size FROM lucene_index;

select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

-- DROP TEST
drop table t1;