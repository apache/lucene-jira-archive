
---------------------------------------------------------------------
--    LUCENE Index Method  Implemented as Trusted Callouts  --
---------------------------------------------------------------------
-- Drops
drop public synonym LContains;
drop public synonym LScore;
drop public synonym LuceneDomainIndex;
drop indextype LuceneIndex force;
drop operator LScore force;
drop operator LContains force;
drop type LuceneDomainIndex force;
drop table LUCENE_INDEX;

create table LUCENE_INDEX (
    PREFIX        VARCHAR2(100),
    NAME          VARCHAR2(30),
    LAST_MODIFIED TIMESTAMP,
    FILE_SIZE     INTEGER,
    DATA          BLOB,
    DELETED       CHAR(1)
    )
/

ALTER TABLE LUCENE_INDEX MODIFY LOB (DATA) (PCTVERSION 0 CACHE READS NOLOGGING);

ALTER TABLE LUCENE_INDEX ADD CONSTRAINT LUCENE_INDEX_PK PRIMARY KEY (PREFIX,NAME);

/* Droping a object type queue table and queue: */
begin 
  DBMS_AQADM.STOP_QUEUE (queue_name         => 'LUCENE.lucene_msg_queue');
  DBMS_AQADM.DROP_QUEUE (queue_name         => 'LUCENE.lucene_msg_queue');
  DBMS_AQADM.DROP_QUEUE_TABLE (queue_table  => 'LUCENE.lucene_msg_qtab');
  exception when others then
    null;
end;
/

CREATE or replace type lucene_msg_typ as object (
  prefix      VARCHAR2(4000),
  rid         VARCHAR2(18),
  newval      VARCHAR2(4000),
  newval_xml  sys.XMLType,
  newval_clob CLOB,
  operation   VARCHAR2(32)
);
/
show errors

/* Creating a object type queue table and queue: */
declare
  reginfo             sys.aq$_reg_info;
  reginfolist         sys.aq$_reg_info_list;
begin 
  DBMS_AQADM.CREATE_QUEUE_TABLE (queue_table        => 'LUCENE.lucene_msg_qtab',
                                 queue_payload_type => 'LUCENE.lucene_msg_typ');
  DBMS_AQADM.CREATE_QUEUE (queue_name         => 'LUCENE.lucene_msg_queue',
                           queue_table        => 'LUCENE.lucene_msg_qtab');
  DBMS_AQADM.START_QUEUE (queue_name          => 'LUCENE.lucene_msg_queue');
  commit;
end;
/

-- CREATE INDEXTYPE IMPLEMENTATION TYPE
create type LuceneDomainIndex authid definer as object
(
  scanctx integer,
  STATIC FUNCTION getIndexPrefix(ia SYS.ODCIIndexInfo, env SYS.ODCIEnv) RETURN VARCHAR2 AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.getIndexPrefix(oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIEnv) return java.lang.String',
  STATIC FUNCTION TextContains(Text IN VARCHAR2, Key IN VARCHAR2,
                               indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextContains(
                java.lang.String, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
  STATIC FUNCTION TextContains(Text IN CLOB, Key IN VARCHAR2,
                               indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextContains(
                oracle.sql.CLOB, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
  STATIC FUNCTION TextContains(Text IN XMLTYPE, Key IN VARCHAR2,
                               indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextContains(
                oracle.xdb.XMLType, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',

  STATIC FUNCTION TextScore(Text IN VARCHAR2, Key IN VARCHAR2,
                            indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextScore(
                java.lang.String, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
  STATIC FUNCTION TextScore(Text IN CLOB, Key IN VARCHAR2,
                            indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextScore(
                oracle.sql.CLOB, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
                
  STATIC FUNCTION TextScore(Text IN XMLTYPE, Key IN VARCHAR2,
                            indexctx IN sys.ODCIIndexCtx, sctx IN OUT LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextScore(
                oracle.xdb.XMLType, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',

  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIGetInterfaces(oracle.ODCI.ODCIObjectList[]) return java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexCreate(ia sys.ODCIIndexInfo, parms VARCHAR2,
                                  env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexCreate(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  STATIC FUNCTION ODCIIndexAlter(ia sys.ODCIIndexInfo, parms IN OUT VARCHAR2, alter_option NUMBER, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexAlter(oracle.ODCI.ODCIIndexInfo, java.lang.String[], java.math.BigDecimal,
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
                
  STATIC FUNCTION ODCIIndexDrop(ia sys.ODCIIndexInfo, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexDrop(oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
                
  STATIC FUNCTION ODCIIndexTruncate(ia SYS.ODCIIndexInfo, env SYS.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexTruncate(oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
                
  STATIC FUNCTION ODCIIndexInsert(ia sys.ODCIIndexInfo, rid VARCHAR2, newval CLOB, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME 
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIInsert(oracle.ODCI.ODCIIndexInfo, java.lang.String,
                oracle.sql.CLOB, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  STATIC FUNCTION ODCIIndexInsert(ia sys.ODCIIndexInfo, rid VARCHAR2, newval sys.XMLType, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME 
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIInsert(oracle.ODCI.ODCIIndexInfo, java.lang.String,
                oracle.xdb.XMLType, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  STATIC FUNCTION ODCIIndexInsert(ia sys.ODCIIndexInfo, rid VARCHAR2, newval VARCHAR2, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME 
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIInsert(oracle.ODCI.ODCIIndexInfo, java.lang.String,
                java.lang.String, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexDelete(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval CLOB, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIDelete(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		oracle.sql.CLOB, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexDelete(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval sys.XMLType, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIDelete(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		oracle.xdb.XMLType, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexDelete(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval VARCHAR2, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIDelete(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		java.lang.String, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexUpdate(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval CLOB, newval CLOB, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIUpdate(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		oracle.sql.CLOB, oracle.sql.CLOB, oracle.ODCI.ODCIEnv) return 
		java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexUpdate(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval sys.XMLType, newval sys.XMLType, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIUpdate(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		oracle.xdb.XMLType, oracle.xdb.XMLType, oracle.ODCI.ODCIEnv) return 
		java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexUpdate(ia sys.ODCIIndexInfo, rid VARCHAR2, oldval VARCHAR2, newval VARCHAR2, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIUpdate(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		java.lang.String, java.lang.String, oracle.ODCI.ODCIEnv) return 
		java.math.BigDecimal',
  
  STATIC FUNCTION ODCIIndexStart(sctx IN OUT LuceneDomainIndex,
        ia SYS.ODCIIndexInfo, op SYS.ODCIPredInfo, qi sys.ODCIQueryInfo,
        strt number, stop number,
        cmpval VARCHAR2, env SYS.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIStart(org.apache.lucene.indexer.LuceneDomainIndex[],
                oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIPredInfo, 
		oracle.ODCI.ODCIQueryInfo,
                java.math.BigDecimal, java.math.BigDecimal, 
                java.lang.String, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  MEMBER FUNCTION ODCIIndexFetch(nrows NUMBER, rids OUT SYS.ODCIridlist, env SYS.ODCIEnv) RETURN NUMBER as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIFetch(java.math.BigDecimal, 
	oracle.ODCI.ODCIRidList[], oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  MEMBER FUNCTION ODCIIndexClose(env SYS.ODCIEnv) RETURN NUMBER as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIClose(oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  STATIC PROCEDURE sync(prefix VARCHAR2) as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.sync(java.lang.String)',

  STATIC PROCEDURE optimize(prefix VARCHAR2) as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.optimize(java.lang.String)'
);
/
show errors

ALTER JAVA CLASS "org.apache.lucene.indexer.LuceneDomainContext" RESOLVE;
show errors
ALTER JAVA CLASS "org.apache.lucene.indexer.LuceneDomainIndex"  RESOLVE;
show errors

CREATE OPERATOR LContains
  BINDING (VARCHAR2, VARCHAR2) RETURN NUMBER
  WITH INDEX CONTEXT, SCAN CONTEXT LuceneDomainIndex COMPUTE ANCILLARY DATA
  without column data USING LuceneDomainIndex.TextContains,
  (sys.XMLType, VARCHAR2) RETURN NUMBER
  WITH INDEX CONTEXT, SCAN CONTEXT LuceneDomainIndex COMPUTE ANCILLARY DATA
  without column data USING LuceneDomainIndex.TextContains;

show errors

CREATE OPERATOR LScore BINDING 
  (NUMBER) RETURN NUMBER
    ANCILLARY TO LContains(VARCHAR2, VARCHAR2),
                 LContains(sys.XMLType, VARCHAR2)
    without column data USING LuceneDomainIndex.TextScore;

show errors

-- CREATE INDEXTYPE
create indextype LuceneIndex
for
lcontains(varchar2, varchar2),
lcontains(sys.XMLType, varchar2)
using LuceneDomainIndex;

show errors

-- GRANTS
grant execute on  LuceneIndex to public;
grant execute on  LContains to public;
grant execute on  LScore to public;
grant execute on  LuceneDomainIndex to public;

create public synonym LContains for lucene.LContains;
create public synonym LScore for lucene.LScore;
create public synonym LuceneDomainIndex for lucene.LuceneDomainIndex;
exit
