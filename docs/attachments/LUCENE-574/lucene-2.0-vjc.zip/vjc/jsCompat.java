// name: jsCompat.jsl
// purpose: missing functions from Microsoft J# runtime needed by Lucene
// created: 14-FEB-2006 George J. Carrette
//
//
// In the lucene 1.9.1 src/java code, apply the following "macro-transformations" manually.
//
// #define Float.intBitsToFloat(_x)    jsCompat.initBitsToFloat(_x)
// #define Float.floatToRawIntBits(_x) jsCompat.floatToRawIntBits(_x)
// #define _x.nextSetBit(_y)           jsCompat.nextSetBit(_x,_y)
// #define _x.matches(_y)              jsCompat.matches(_x,_y)
//

package java.lang;

import java.util.BitSet;
import System.BitConverter;
import System.Text.RegularExpressions.*;
import java.io.File;

public class jsCompat
{

    public static int floatToRawIntBits(float x) {
	// You would expect the compiler to optimize this at some point.
	return(BitConverter.ToInt32(BitConverter.GetBytes(x),0));
    }

    public static float intBitsToFloat(int x) {
	// same as above.
	return(BitConverter.ToSingle(BitConverter.GetBytes(x),0));
    }

    public static boolean matches(String input,String pattern) {
	Regex rx = new Regex(pattern);
	return(rx.IsMatch(input));
    }

    public static int nextSetBit(BitSet bits,int i) {
	// The crypto people must have asked for this one.
	// Often available as a hardware instruction.
	int n = bits.length();
	for (int j = i; j < n; ++j) if (bits.get(j)) return(j);
	return(-1);
    }

    /* The built-in J# File class leaves the file opened
       by the process when it creates the file. This causes
       the delete to fail silently. To avoid silent failures
       we also avoid calling the J# File Delete method. */

    public static boolean FilecreateNewFile(File f)
    {
	String fn = f.ToString();
	// System.Console.WriteLine("LockFile Create: " + fn);
	System.IO.FileStream fs = null;
	try
	    {
		fs = new System.IO.FileStream(fn,
					      System.IO.FileMode.CreateNew);
		return(true);
	    }
	catch (Exception e)
	    {
		return(false);
	    }
	finally
	    {
		if (fs != null)
		    {
			fs.Close();
		    }
	    }
    }

    public static void FileDelete(File f)
    {
	String fn = f.ToString();
	// System.Console.WriteLine("LockFile Delete: " + fn);
	
	System.IO.FileInfo fi = new System.IO.FileInfo(fn);
	fi.Delete();
    }
}







