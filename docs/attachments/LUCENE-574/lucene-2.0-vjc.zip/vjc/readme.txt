8-MAY-2006 George J. Carrette, gjc@alum.mit.edu

For lucene 2.0, see the note at the end of this file.

The folder containing this readme can be placed
right into the Lucene Java 1.9.1 source code release,
into the folder lucene-1.9.1/src/vjc
For convenience you can combine this with the pre-build binary
tree for the same release of Lucene Java in order to have
access to the documentation tree and files.

The lucene.sln is a "Solution" file for Visual Studio 2005.
It should be sufficient to use the free "Visual J# 2005 Express Edition"
from http://msdn.microsoft.com/vstudio/express/visualj/

Or you can just run the BUILD.BAT, calling the vjc.exe compiler
through the MSBUILD.EXE.  This requires the .NET 2.0 runtime
downloaded from http://update.microsoft.com/ or
or http://www.microsoft.com/downloads/details.aspx?FamilyID=0856EACB-4362-4B0D-8EDD-AAB15C5E04F5

It is hoped that this will not be significantly more difficult
conceptually than dealing with the Gnu native compiler for the Java
language, gcj.

One minor glitch here is that vjsproj files refer to source code
via a relative path using ".."
 <ItemGroup>
  <Compile Include="../java/org/apache/lucene/analysis/Analyzer.java" />
 </ItemGroup>
and this relative path gives the GUI some reason to complain.
You can ignore these warnings. The only way to avoid them that I have
found is to copy the sln and vjsproj files into the toplevel lucene-1.9.1
folder and avoid the use of ".."

Some files in the Lucne Java 1.9.1 sources needed to be patched.
The file lucene-1.9.1-patch.txt contains a patch that can be
applied using the http://www.cygwin.com/ gnu patch command.

This is what it looked like in cygwin shell to make the patch,
with the current working directory being the src folder.

$ patch -b -p1 < vjc/lucene-1.9.1-patch.txt
patching file demo/org/apache/lucene/demo/SearchFiles.java
patching file java/org/apache/lucene/index/IndexFileNameFilter.java
patching file java/org/apache/lucene/search/ConstantScoreQuery.java
patching file java/org/apache/lucene/search/MultiTermQuery.java
patching file java/org/apache/lucene/search/Searchable.java
patching file java/org/apache/lucene/search/spans/SpanFirstQuery.java
patching file java/org/apache/lucene/search/spans/SpanNearQuery.java
patching file java/org/apache/lucene/search/spans/SpanNotQuery.java
patching file java/org/apache/lucene/search/spans/SpanOrQuery.java
patching file java/org/apache/lucene/store/FSDirectory.java
patching file java/org/apache/lucene/util/SmallFloat.java


Or you can make the changes manually. I hope it is obvious that all I am
doing here is changing some built-in method calls into static method
calls defined in the jsCompat.java file.

The J# compiler seems to be generally quite good, handling all of
the language constructs required by Lucene Java, but there are some
weaknesses in the runtime.

Here is how to read the patch file.

Lines starting with "---" refer to the "original" source file,
and lines starting with "+++" refer to the modified source file.
After that a line starting with "-" is the "before patching"
line of code, and a line starting with "+" is the line "after patching".

All other lines provide a meaningful context to the patch.

---

diff --unified --strip-trailing-cr --recursive --ignore-file-name-case ref src > src/vjc/lucene-1.9.1-patch.txt


---------------

Lucene 2.0. The work here was done around 11-MAY-2006.
From sources taken from the trunk at revision 405803.

svn co http://svn.apache.org/repos/asf/lucene/java/trunk

The patch from 1.9.1. was applied. Some files needed to be removed
from the lucene.vjsproj. The indexfiles-test-vjc.bat did not work
on the src/java folder because of any array copying/index problem
in org.apache.lucene.analysis.standard.FastCharStream.refill
when it encountered the .svn\empty-file.

This problem does not happen with the Lucene Java sources compiled
using jdk1.5.0_06 from Sun. So this could point to problem with the
microsoft J# compiler and/or runtime. For some reason the variable
newPosition gets set to -1. In order to allow the demo to work

The resulting patch you should apply to the trunk sources is
this instead: lucene-2.0-patch.txt

This is what it looked like in cygwin shell to make the patch,
with the current working directory being the src folder.

$ patch -b -p0 < vjc/lucene-2.0-patch.txt

After that cd to the vjc and run the BUILD.BAT file.

$ cmd /c build.bat

You can then run test test indexing:

$ cmd /c indexfiles-test-vjc.bat

Then the test searching

$ cmd /c searchfiles-test-vjc.bat




-------------------------------------------------------------------------

svn diff > vjc/lucene-2.0-patch.txt
