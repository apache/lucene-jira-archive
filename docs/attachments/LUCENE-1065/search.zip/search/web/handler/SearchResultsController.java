package com.mgh.sps.search.web.handler;

import java.util.Map;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mgh.sps.search.business.facade.Search;
import com.mgh.sps.common.dto.ResourceDTO;
import com.mgh.sps.common.util.SessionAttributeKey;
import com.mgh.sps.common.util.SessionManager;
import com.mgh.sps.fileusage.web.constants.FileUsageWebConstants;

public class SearchResultsController extends SimpleFormController {

	/**
	 * SearchResults Controller 
	 * @author Muralikrishna.s
	 * @Codedondate DD-MM-YY=26-07-07
	 * @Usecase/s associated =UC504
	 */
	private static final Logger logger = Logger
			.getLogger(SearchResultsController.class.getName());

	private final static String REG_EXP = "^[A-Za-z0-9]*$";

	private final static Pattern EMAIL_PATTERN_REG = Pattern.compile(REG_EXP);
	/**
	 * Spring framework method used to hold reference data
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param command
	 *            Object
	 * @param arg2
	 *            Errors
	 * @return Map
	 * @throws Exception
	 */
	@Override
	protected Map referenceData(HttpServletRequest request, Object command,
			Errors errors) throws Exception {
		logger.debug("SearchResultsController.referenceData() method entered:"
				+ request + "," + command + "," + errors);
		 
		SessionManager.setSessionAttribute(SessionAttributeKey.tabIndex,
				FileUsageWebConstants.TAB_SEARCH, request);
		Search search = (Search) super.getWebApplicationContext().getBean(
				"searchfacade");
		ResourceDTO resourceDto = (ResourceDTO) command;
		String[] allValues = new String[7];
		if (null != (String[]) SessionManager.getSessionAttribute(
				SessionAttributeKey.allValues, request)) {
			allValues = (String[]) SessionManager.getSessionAttribute(
					SessionAttributeKey.allValues, request);
			resourceDto.setKeywords(allValues[0]);
			resourceDto.setCountry(allValues[1]);
			resourceDto.setUniversityName(allValues[2]);
			resourceDto.setSubjectArea(allValues[3]);
			resourceDto.setQualification(allValues[4]);
			resourceDto.setYearLevel(allValues[5]);
			resourceDto.setSpecificType(allValues[6]);
		}
		logger.debug("%%%%%%%%%%%%%%%%%qualification%%%%%%%%%%%%%%%"
				+ resourceDto.getQualification());
		String flag = (String) request.getParameter("id");
		resourceDto.setFlag(flag);
		logger.debug("SearchResultsController.referenceData() method exited:");
		return search.retrieveReferenceData(resourceDto);
		 
	}

	/**
	 * Spring framework method used to hold OnSubmit
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param response
	 *            HttpServletResponse
	 * @param command
	 *            Object
	 * @param arg3
	 *            BindException
	 * @return ModelAndView
	 * @throws Exception
	 */
	@Override
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		SessionManager.cleanup(request);
		logger.debug("SearchResultsController.onSubmit() method entered:"
				+ request + "," + command + "," + response + "," + errors);
		Search search = (Search) super.getWebApplicationContext().getBean(
				"searchfacade");
		Map dynamic = (Map) getServletContext().getAttribute("config");
		ResourceDTO resourceDto = (ResourceDTO) command;
		SessionManager.removeSessionAttribute(SessionAttributeKey.allValues,
				request);
		//changed by sreelatha on sep21
		//resourceDto.setKeywords(request.getParameter("keywords"));
		//String key = request.getParameter("keywords");
		//logger.debug("&&&&&&&&&&&&&  key &&&&&&&&&&&&" + key);
		String keywords = (request.getParameter("keywords"));
		if(null!=keywords) {
			keywords = keywords.trim();
		}
		resourceDto.setKeywords(keywords);
//		 changes end
		resourceDto.setUniversityName(request.getParameter("universityName"));
		resourceDto.setSubjectArea(request.getParameter("subjectArea"));
		resourceDto.setCountry(request.getParameter("country"));
		resourceDto.setQualification(request.getParameter("qualification"));
		resourceDto.setYearLevel(request.getParameter("yearLevel"));
		resourceDto.setSpecificType(request.getParameter("specificType"));
		String[] allValues = new String[7];
		//changed by sreelatha on sep21
		//allValues[0] = request.getParameter("keywords");
		allValues[0] = resourceDto.getKeywords();
		//changes end
		allValues[1] = request.getParameter("country");
		allValues[2] = request.getParameter("universityName");
		allValues[3] = request.getParameter("subjectArea");
		allValues[4] = request.getParameter("qualification");
		allValues[5] = request.getParameter("yearLevel");
		allValues[6] = request.getParameter("specificType");
		SessionManager.setSessionAttribute(SessionAttributeKey.allValues,
				allValues, request);
			if(null!=keywords) {
			keywords = keywords.trim();
			String words="";
			for(int i=0;i<keywords.length();i++) {			
				String key=String.valueOf(keywords.charAt(i));
				 if(key.contains("*")) {
						key = key.replace("*"," ");
					} else if(key.contains("?")) {
						key = key.replace("?"," ");
					} else if(key.contains("[")) {
						key = key.replace("["," ");
					} else if(key.contains("{")) {
						key = key.replace("{"," ");
					} else if(key.contains("(")) {
						key = key.replace("("," ");
					} else if(key.contains(")")) {
						key = key.replace(")"," ");
					} else if(key.contains("+")) {
						key = key.replace("+"," ");
					} else if(key.contains("\\")) {
						key = key.replace("\\"," ");
					} else if(key.contains(" ")) {
						key = key.replace(" "," ");
					} else if(key.contains("_")) {
						key = key.replace("_","_");
					}  else if(!EMAIL_PATTERN_REG.matcher(key).matches()) {
						key = key.replaceAll(key," ");
					} 
				words = words + key;
				}
			keywords = words;
			resourceDto.setKeywords(keywords);
		}
		
		SessionManager.setSessionAttribute(SessionAttributeKey.test, search.setInputValues(resourceDto, dynamic), request);
		String name = (String) SessionManager.getSessionAttribute(SessionAttributeKey.tempName, request);
		String flag1 = request.getParameter("id");
		String status="";
		if (flag1 !=null && flag1.equals("loggedInUser"))
		{			
		if(name==null)
			{
				return new ModelAndView();
			}
		}
		if (flag1 !=null && flag1.equals("loggedInUser")){
			status = "redirect:SearchResults.htm?id=loggedInUser";
		}else if(flag1 !=null && flag1.equals("nonLoggedInUser"))
		{
			status = "redirect:SearchResultsnlu.htm?id=nonLoggedInUser";	
		}
		//}
		super.setSuccessView(status);
		ModelAndView mav = new ModelAndView(super.getSuccessView());
		logger.debug("SearchResultsController.onSubmit() method exited:");
		return mav;
	 
	}
	
}