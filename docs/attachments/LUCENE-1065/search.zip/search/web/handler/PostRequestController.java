package com.mgh.sps.search.web.handler;


import org.springframework.web.servlet.mvc.SimpleFormController;

public class PostRequestController extends SimpleFormController {

	/**
	 * Post a File Request
	 * 
	 * @author Muralikrishna.s
	 * @date DD-MM-YY=26-07-07
	 * @Usecase/s associated =UC504,UC505
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	private static final Logger logger = Logger
			.getLogger(PostRequestController.class.getName());

	private final static String REG_EXP = "^[A-Za-z0-9]*$";

	private final static Pattern EMAIL_PATTERN_REG = Pattern.compile(REG_EXP);
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	/**
	 * Spring framework method used to hold show form
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param response
	 *            HttpServletResponse
	 * @param arg2
	 *            BindException
	 * @return ModelAndView
	 * @throws Exception
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	@Override
	protected ModelAndView showForm(HttpServletRequest request,
			HttpServletResponse response, BindException bindException)
			throws Exception {
		return super.showForm(request, response, bindException);
	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	/**
	 * Spring framework method used to hold form backing object
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @return ModelAndView
	 * @throws Exception
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	@Override
	protected Object formBackingObject(HttpServletRequest arg0)
			throws Exception {
		return super.formBackingObject(arg0);
	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	
	/**
	 * Spring framework method used to hold reference data
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param command
	 *            Object
	 * @param arg2
	 *            Errors
	 * @return Map
	 * @throws Exception
	 */
	
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	@Override
	protected Map referenceData(HttpServletRequest request, Object command,
			Errors bindException) throws Exception {
		logger.debug("PostRequestController.referenceData() method entered:"
				+ request + "," + command + "," + bindException);
		// declaring the instance of ResourceDTO reference
		ResourceDTO resourceDto = (ResourceDTO) command;
		SessionManager.setSessionAttribute(SessionAttributeKey.tabIndex,
				FileUsageWebConstants.TAB_SEARCH, request);
		Search search = (Search) super.getWebApplicationContext().getBean(
				"searchfacade");
		//changed by sreelatha on sep21
		//String keywords = request.getParameter("keywords");
		String keywords = (request.getParameter("keywords"));		
		if(null!=keywords) {
		keywords = keywords.trim();
		resourceDto.setKeywords(keywords);
		} else {
			resourceDto.setKeywords("Keyword Search");
		}
//		 changes end
		String university = request.getParameter("universityName");
		String subjectArea = request.getParameter("subjectArea");
		String qualification1 = request.getParameter("qualification");
		String country1 = request.getParameter("country");
		String specifictype = request.getParameter("specificType");
		String yearlevel = request.getParameter("yearLevel");
		String comments = request.getParameter("comments");
//
//		if (keywords == null)
//			resourceDto.setKeywords("Keyword Search");
//		else
//			resourceDto.setKeywords(keywords);

		if (university == null) {
			resourceDto.setUniversityName("a specific UNIVERSITY");
			resourceDto.setSubjectArea("a specific SUBJECT AREA");
		} else {
			resourceDto.setUniversityName(university);
			if (subjectArea == null)
				resourceDto.setSubjectArea("a specific SUBJECT AREA");
			else
				resourceDto.setSubjectArea(subjectArea);
		}
		if (qualification1 != null)
			resourceDto.setQualification(qualification1);
		if (country1 != null)
			resourceDto.setCountry(country1);
		if (specifictype != null)
			resourceDto.setSpecificType(specifictype);
		if (yearlevel != null)
			resourceDto.setYearLevel(yearlevel);
		if (comments != null)
			resourceDto.setComments(comments);

		String flag = (String) request.getParameter("id");
		resourceDto.setFlag(flag);
		if (null != (String) SessionManager.getSessionAttribute(
				SessionAttributeKey.tempName, request)) {
			String userName = (String) SessionManager.getSessionAttribute(
					SessionAttributeKey.tempName, request);
			resourceDto.setUserName(userName);
			if (flag == null) {
				logger.debug("**flag value null in PostRequestController**"+ flag);
				resourceDto = search.setCountryValues(resourceDto);
				logger.debug("PostRequestController.referenceData() method exited:");
				return search.retrieveReferenceData(resourceDto);
			} else {
				logger.debug("**flag value not null in PostRequestController**"
						+ flag);
				if (flag.equals("directFileRequest")) {
					resourceDto = search
							.setCountryValues(resourceDto);
					logger
							.debug("PostRequestController.referenceData() method exited:");
					return search.retrieveReferenceData(resourceDto);
				} else if (flag.equals("fileRequest")) {
					String[] allValues = new String[7];
					if (null != (String[]) SessionManager.getSessionAttribute(
							SessionAttributeKey.allValues, request)) {
						allValues = (String[]) SessionManager
								.getSessionAttribute(
										SessionAttributeKey.allValues, request);
						resourceDto.setKeywords(allValues[0]);
						resourceDto.setCountry(allValues[1]);
						resourceDto.setUniversityName(allValues[2]);
						resourceDto.setSubjectArea(allValues[3]);
						resourceDto.setQualification(allValues[4]);
						resourceDto.setYearLevel(allValues[5]);
						resourceDto.setSpecificType(allValues[6]);
					}
					logger
							.debug("PostRequestController.referenceData() method exited:");
					return search.retrieveReferenceData(resourceDto);
				}
			}

			if (flag.equals("searchDetails")) {
				if (SessionManager.getSessionAttribute(
						SessionAttributeKey.searchDetails, request) != null) {
					String UploadDetails = (String) SessionManager
							.getSessionAttribute(
									SessionAttributeKey.searchDetails, request);
					String s1[] = UploadDetails.split("/");
					resourceDto.setCountry(s1[7]);
					resourceDto.setUniversityName(s1[0]);
					if (null != (ArrayList<String>) SessionManager
							.getSessionAttribute(
									SessionAttributeKey.selDisciplinesS, request)) {
						ArrayList<String> disciplines = (ArrayList<String>) SessionManager
								.getSessionAttribute(
										SessionAttributeKey.selDisciplinesS,
										request);
						if (disciplines != null) {
							Iterator itr = disciplines.iterator();
							String str = "";
							while (itr.hasNext()) {
								str = str + (String) itr.next() + ",";
							}
							str = Utilities.trimLastComma(str);
							resourceDto.setSubjectArea(str);
						} else {
							resourceDto.setSubjectArea(s1[1]);
						}
						resourceDto.setQualification(s1[2]);
						resourceDto.setYearLevel(s1[3]);
						resourceDto.setSpecificType((s1[4]));
						resourceDto.setKeywords(s1[5]);
						resourceDto.setComments(s1[6]);
						resourceDto.setCountry(s1[7]);
					}
					logger
							.debug("PostRequestController.referenceData() method exited:");
					return search.retrieveReferenceData(resourceDto);
				}
			}
		}
		logger.debug("PostRequestController.referenceData() method exited:");
		return null;
	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */

	/**
	 * Spring framework method used to hold OnSubmit
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param response
	 *            HttpServletResponse
	 * @param command
	 *            Object
	 * @param arg3
	 *            BindException
	 * @return ModelAndView
	 * @throws Exception
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command,
			BindException bindException) throws Exception {
		String status = null;
		logger.debug("PostRequestController.onSubmit() method entered:"
				+ request + "," + response + "," + command + ","
				+ bindException);
		//added by sreelatha
		SessionManager.removeSessionAttribute(SessionAttributeKey.selDisciplinesS,
				request);
		//end
		ResourceDTO resourceDto = (ResourceDTO) command;
		MailManager mailManager = new MailManager();
		Search search = (Search) super.getWebApplicationContext().getBean(
				"searchfacade");
		Map dynamic = (Map) getServletContext().getAttribute("config");
		if (null != (String) SessionManager.getSessionAttribute(
				SessionAttributeKey.userStatus, request)) {
			String userStatus = (String) SessionManager.getSessionAttribute(
					SessionAttributeKey.userStatus, request);

			if (resourceDto.getFlag() == null) {
				logger
						.debug("***********flag value in submit PostRequestController**********"
								+ resourceDto.getFlag());
			} else if (resourceDto.getFlag() != null) {
				if (resourceDto.getFlag().equals("fileRequest")) {
					//changed by sreelatha on sep21
					//resourceDto.setKeywords(request.getParameter("keywords"));
					//String key = request.getParameter("keywords");
					//logger.debug("&&&&&&&&&&&&& post request controller key &&&&&&&&&&&&"
							//		+ key);
					String keywords = (request.getParameter("keywords"));
					if(keywords!=null) {
					keywords = keywords.trim();
					}
					resourceDto.setKeywords(keywords);
//					 changes end
					String universityName = request
							.getParameter("universityName");
					resourceDto.setSubjectArea(request
							.getParameter("subjectArea"));
					resourceDto.setCountry(request.getParameter("country"));
					resourceDto.setQualification(request
							.getParameter("qualification"));
					resourceDto.setYearLevel(request.getParameter("yearLevel"));
					resourceDto.setSpecificType(request
							.getParameter("specificType"));
					resourceDto.setComments(request.getParameter("comments"));
					if (null != (String) SessionManager.getSessionAttribute(
							SessionAttributeKey.tempName, request)) {
						String userName = (String) SessionManager
								.getSessionAttribute(
										SessionAttributeKey.tempName, request);

						resourceDto.setUniversityName(universityName);
						resourceDto.setUserName(userName);
						resourceDto.setUserStatus(userStatus);
						search.insertpostRequestDetails(resourceDto,dynamic);
						if (userStatus.equals("General")) {
							try {
								mailManager.sendPostRequest(resourceDto,dynamic);
							} catch (Exception e) {
								logger
										.error("Caught exception in while sending the mail: "
												+ e);
								status = "post_request_thank";
							}
						}
						status = "post_request_thank";
					}
					} else if (resourceDto.getFlag()
							.equals("directFileRequest")
							|| resourceDto.getFlag().equals("searchDetails")
							|| resourceDto.getFlag().equals("firstFileRequest")) {
						String[] allValues = new String[7];
						//added by sreelatha
						String keywords = (request.getParameter("keywords"));
						if(keywords!=null) {
						keywords = keywords.trim();	
						}
						resourceDto.setKeywords(keywords);
						allValues[0] = resourceDto.getKeywords();
						//end
						allValues[1] = request.getParameter("country");
						allValues[2] = request.getParameter("universityName");
						allValues[3] = request.getParameter("subjectArea");
						allValues[4] = request.getParameter("qualification");
						resourceDto.setQualificationId(allValues[4]);
						allValues[5] = request.getParameter("yearLevel");
						resourceDto.setYearLevelId(allValues[5]);
						allValues[6] = request.getParameter("specificType");
						resourceDto.setSpecificType(allValues[6]);
						SessionManager.setSessionAttribute(	SessionAttributeKey.allValues, allValues,request);
						keywords = keywords.trim();
						String words="";
						for(int i=0;i<keywords.length();i++) {			
							String key=String.valueOf(keywords.charAt(i));
							 if(key.contains("*")) {
									key = key.replace("*"," ");
								} else if(key.contains("?")) {
									key = key.replace("?"," ");
								} else if(key.contains("[")) {
									key = key.replace("["," ");
								} else if(key.contains("{")) {
									key = key.replace("{"," ");
								} else if(key.contains("(")) {
									key = key.replace("("," ");
								} else if(key.contains(")")) {
									key = key.replace(")"," ");
								} else if(key.contains("+")) {
									key = key.replace("+"," ");
								}else if(key.contains("\\")) {
									key = key.replace("\\"," ");
								} else if(key.contains(" ")) {
									key = key.replace(" "," ");
								} else if(key.contains("_")) {
									key = key.replace("_","_");
								}  else if(!EMAIL_PATTERN_REG.matcher(key).matches()) {
									key = key.replaceAll(key," ");
								} 
							words = words + key;
							}
						keywords = words;
						resourceDto.setKeywords(keywords);
						SessionManager.setSessionAttribute(SessionAttributeKey.test, search.setInputValues(resourceDto, dynamic), request);
						status = "redirect:SearchResultsnlu.htm";
					}
			}
			super.setSuccessView(status);
		}
		ModelAndView mav = new ModelAndView(super.getSuccessView());
		logger.debug("PostRequestController.onSubmit() method exited:");
		return mav;
	}
*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
}