package com.mgh.sps.search.web.handler;

import java.util.Map;
import java.util.*;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mgh.sps.search.business.facade.Search;
//import com.mgh.sps.common.constants.app.AppConstants;
import com.mgh.sps.common.dto.ResourceDTO;
import com.mgh.sps.common.util.SessionAttributeKey;
import com.mgh.sps.common.util.SessionManager;
import com.mgh.sps.fileusage.web.constants.FileUsageWebConstants;

public class SearchController extends SimpleFormController {

	/**
	 * Search Controller 
	 * @author Muralikrishna.s
	 * @date DD-MM-YY=26-07-07
	 * @Usecase/s associated =UC501
	 */
	
	private static final Logger logger = Logger
			.getLogger(SearchController.class.getName());
			
	private final static String REG_EXP = "^[A-Za-z0-9]*$";

	private final static Pattern EMAIL_PATTERN_REG = Pattern.compile(REG_EXP);

	/**
	 * Spring framework method used to hold show form
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param response
	 *            HttpServletResponse
	 * @param arg2
	 *            BindException
	 * @return ModelAndView
	 * @throws Exception
	 */
	@Override
	protected ModelAndView showForm(HttpServletRequest request,
			HttpServletResponse response, BindException bind) throws Exception {
		return super.showForm(request, response, bind);
	}

	/**
	 * Spring framework method used to hold form backing object
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @return ModelAndView
	 * @throws Exception
	 */
	@Override
	protected Object formBackingObject(HttpServletRequest request)
			throws Exception {
		return super.formBackingObject(request);
	}

	/**
	 * Spring framework method used to hold reference data
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param command
	 *            Object
	 * @param arg2
	 *            Errors
	 * @return Map
	 * @throws Exception
	 */
	@Override
	protected Map referenceData(HttpServletRequest request, Object command,
			Errors error) throws Exception {
		SessionManager.cleanup(request);


		logger.debug("SearchController.referenceData() method entered:"
				+ request + "," + command + "," + error);
		ResourceDTO resourceDto = (ResourceDTO) command;
		SessionManager.setSessionAttribute(SessionAttributeKey.tabIndex,
				FileUsageWebConstants.TAB_SEARCH, request);
		String userName = (String) SessionManager.getSessionAttribute(
				SessionAttributeKey.tempName, request);
		resourceDto.setUserName(userName);
		Search search = (Search) super.getWebApplicationContext().getBean(
				"searchfacade");
		resourceDto.setKeywords("Keyword Search");
		String universityName = resourceDto.getUniversityName();
		String subjectArea = resourceDto.getSubjectArea();
		String country = resourceDto.getCountry();
		logger.info("**** universityName****"+universityName);
		logger.info("**** subjectArea****"+subjectArea);
		logger.info("**** country****"+country);
		if(null!=universityName) {
			resourceDto.setUniversityName(universityName);
		} else {
			resourceDto.setUniversityName("a specific UNIVERSITY");
		}
		if(null!=subjectArea) {
			resourceDto.setSubjectArea(subjectArea);
		} else {			
			resourceDto.setSubjectArea("a specific SUBJECT AREA");
		}
		String flag = (String) request.getParameter("id");
		resourceDto.setFlag(flag);
		if(null!=country) { 
			resourceDto.setCountry(country);
		} else {
		if (userName != null) {
		/*	String headerInformation = (String) SessionManager
					.getSessionAttribute(SessionAttributeKey.headerInformation,
							request);
			if (null != headerInformation) {
				if (headerInformation.equals("en-us")) {
					resourceDto.setCountry("2");
				} else {
					resourceDto.setCountry("1");
				}
			}
		} else { */
			resourceDto = search.setCountryValues(resourceDto);
		} else {
			resourceDto.setCountry("select");
		}
		}
		logger.debug("SearchController.referenceData() method exited:");
		return search.retrieveReferenceData(resourceDto);
	}

	/**
	 * Spring framework method used to hold OnSubmit
	 * 
	 * @param request
	 *            HttpServletRequest
	 * @param response
	 *            HttpServletResponse
	 * @param command
	 *            Object
	 * @param arg3
	 *            BindException
	 * @return ModelAndView
	 * @throws Exception
	 */
	@Override
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException bind)
			throws Exception {
		SessionManager.cleanup(request);
		String name = (String) SessionManager.getSessionAttribute(SessionAttributeKey.tempName, request);
		String flag1 = request.getParameter("id");
		if (flag1 !=null && flag1.equals("loggedInUser"))
		{			
		if(name==null)
			{
				return new ModelAndView();
			}

		}
		logger.debug("SearchController.onSubmit() method entered:" + request
				+ "," + command + "," + response + "," + bind);
		ResourceDTO resourceDto = (ResourceDTO) command;
		String status = null;
		
		Search search = (Search) super.getWebApplicationContext().getBean(
				"searchfacade");
		//changed by sreelatha on sep21
		//resourceDto.setKeywords(request.getParameter("keywords"));
		//logger.debug("&&&&&&&&&&&&&  key &&&&&&&&&&&&"
			//	+ resourceDto.getKeywords());
		String keywords = (request.getParameter("keywords"));
		if(null!=keywords) {
			keywords = keywords.trim();
		}
		resourceDto.setKeywords(keywords);
//		 changes end
		Map dynamic = (Map) getServletContext().getAttribute("config");
		resourceDto.setUniversityName(request.getParameter("universityName"));
		resourceDto.setSubjectArea(request.getParameter("subjectArea"));
		resourceDto.setCountry(request.getParameter("country"));
		resourceDto.setQualification(request.getParameter("qualification"));
		resourceDto.setYearLevel(request.getParameter("yearLevel"));
		resourceDto.setSpecificType(request.getParameter("specificType"));
		String[] allValues = new String[7];
		allValues[0] = resourceDto.getKeywords();
		allValues[1] = resourceDto.getCountry();
		allValues[2] = resourceDto.getUniversityName();
		allValues[3] = resourceDto.getSubjectArea();
		allValues[4] = resourceDto.getQualification();
		allValues[5] = resourceDto.getYearLevel();
		allValues[6] = resourceDto.getSpecificType();
		
		SessionManager.setSessionAttribute(SessionAttributeKey.allValues,allValues, request);
		
		if(null!=keywords) {
			keywords = keywords.trim();
			String words="";
			for(int i=0;i<keywords.length();i++) {			
				String key=String.valueOf(keywords.charAt(i));
				 if(key.contains("*")) {
						key = key.replace("*"," ");
					} else if(key.contains("?")) {
						key = key.replace("?"," ");
					} else if(key.contains("[")) {
						key = key.replace("["," ");
					} else if(key.contains("{")) {
						key = key.replace("{"," ");
					} else if(key.contains("(")) {
						key = key.replace("("," ");
					} else if(key.contains(")")) {
						key = key.replace(")"," ");
					} else if(key.contains("+")) {
						key = key.replace("+"," ");
					} else if(key.contains("\\")) {
						key = key.replace("\\"," ");
					} else if(key.contains(" ")) {
						key = key.replace(" "," ");
					} else if(key.contains("_")) {
						key = key.replace("_","_");
					}  else if(!EMAIL_PATTERN_REG.matcher(key).matches()) {
						key = key.replaceAll(key," ");
					} 
				words = words + key;
				}
			keywords = words;
			resourceDto.setKeywords(keywords);
			}			
		SessionManager.setSessionAttribute(SessionAttributeKey.test, search.setInputValues(resourceDto, dynamic), request);
		logger.info("**** onSubmit in SearchController ****");
		if (flag1 !=null && flag1.equals("loggedInUser")){
			status = "redirect:SearchResults.htm?id=loggedInUser";
		}else if(flag1 !=null && flag1.equals("nonLoggedInUser"))
		{
			status = "redirect:SearchResultsnlu.htm?id=nonLoggedInUser";	
		}
		// }
		super.setSuccessView(status);
		ModelAndView mav = new ModelAndView(super.getSuccessView());
		logger.debug("SearchController.onSubmit() method exited:");
		return mav;
		 
	}

}