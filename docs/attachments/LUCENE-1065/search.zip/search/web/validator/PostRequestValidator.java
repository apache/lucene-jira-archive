package com.mgh.sps.search.web.validator;

//import java.util.ArrayList;
//import java.util.LinkedHashMap;
//import java.util.Map;
/*import java.util.StringTokenizer;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;*/
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

//import com.mgh.sps.common.constants.app.AppConstants;
import com.mgh.sps.common.dto.ResourceDTO;
/*import com.mgh.sps.common.util.ResourceBundleReader;
import com.mgh.sps.registration.dao.delegate.ValidaterDao;
import com.mgh.sps.search.business.exception.DisciplineNotFoundException;
import com.mgh.sps.search.business.facade.Search;*/

/* 
 @ Author  = Murali Krishna.S
 @ Coded on  date DD-MM-YY= 22-07-07
 @ Use case/s associated = UC504
 @ Objective = Validatotion for post file request
 */
public class PostRequestValidator implements Validator {
	/*private static final Logger logger = Logger
	.getLogger(PostRequestValidator.class.getName());
	ResourceBundleReader reader = new ResourceBundleReader("search");
	ResourceDTO resourcedto;*/
	
	/*private final static String EMAIL_REG_EXP = "^[A-Za-z]*$";
	
	private final static String REG_EXP = "^[A-Za-z0-9]*$";
	
	private final static Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REG_EXP);
	
	private final static Pattern EMAIL_PATTERN_REG = Pattern.compile(REG_EXP);
	
	ValidaterDao validaterDao = new ValidaterDao();*/
	
	public boolean supports(Class clazz) {
		return clazz.equals(ResourceDTO.class);
	}
	
	public void validate(Object obj, Errors errors)  {
		//--------------------------------code commented for stubbing----------------------
		
		/*
		logger.debug("PostRequestValidator.validate() method entered:" + obj
				+ errors);
		resourcedto = (ResourceDTO) obj;
		validateKeywords(errors, resourcedto.getKeywords());
		validateCountry(errors, resourcedto.getCountry());
		validateUniversityName(errors, resourcedto.getUniversityName());
		try {
			validateSubjectArea(errors, resourcedto.getSubjectArea());
		} catch (DisciplineNotFoundException e) {
			e.printStackTrace();
			logger
			.error("Catch Exception in validateSubjectArea in PostRequestValidator");
		}
		validateQualification(errors, resourcedto.getQualification());
		validateYearLevel(errors, resourcedto.getYearLevel());
		validateSpecificType(errors, resourcedto.getSpecificType());
		logger.debug("PostRequestValidator.validate() method exited:");
		*/
		//-----------------------------End of code Commented for stubbing-----------------------
	}	
	
	
//	--------------------------------code commented for stubbing----------------------
	
	/* private void validateKeywords(Errors errors, String keywords) {
		keywords = keywords.trim();
		logger.debug("PostRequestValidator.validateKeywords() method entered:"
				+ errors + keywords);
//		changed by sreelatha on sep21		
		keywords = keywords.replace(">","");				
		keywords = keywords.replace("<","");
		keywords = keywords.replace("\"","");			
		resourcedto.setKeywords(keywords);
//		 changes end
		if (keywords.equals("Keyword Search") || keywords == ""
			|| keywords == null || keywords.equals("")
			|| keywords.equals(" ") || keywords.equals("KeywordSearch")) {
			// ValidationUtils.rejectIfEmptyOrWhitespace(errors, "keywords",
			// "required", "Please enter TOPICS COVERED field");
			errors.reject("keywords",
					new Object[] { "keywords" },
			reader.getProperty("errors.search.topicscovered"));
		}		
		logger.debug("PostRequestValidator.validateKeywords() method exited:");
	}
	
	private void validateCountry(Errors errors, String country) {
		logger.debug("PostRequestValidator.validateCountry() method entered:"
				+ errors + country);
		if (country.equals("select")) {
			errors.reject("country",
					new Object[] { "country" }, reader.getProperty("errors.search.countryfeild"));
		}
		logger.debug("PostRequestValidator.validateCountry() method exited:");
	}
	
	private void validateUniversityName(Errors errors, String universityName) {
		logger.debug("PostRequestValidator.validateKeywords() method entered:"
				+ errors + universityName);
		if(universityName.contains(">")) {
			universityName = universityName.replaceAll(">","");			
		}
		if (universityName.equalsIgnoreCase("a specific UNIVERSITY")
				|| universityName == "" || universityName == null
				|| universityName.equals("") || universityName.equals(" ")) {
			// ValidationUtils.rejectIfEmptyOrWhitespace(errors,
			// "universityName", "required", "Please enter UNIVERSITY field");
			errors.reject("universityName",
					new Object[] { "universityName" },
					reader.getProperty("errors.search.universityfeild"));
		} else {
			if(universityName.contains(">")) {
				universityName = universityName.replaceAll(">","");
			}
			int countryId = Integer.parseInt(resourcedto.getCountry());
			ArrayList cId = new ArrayList();					
				cId=validaterDao.getUniversityNameDB(countryId,universityName);
				if(cId.isEmpty()) {
				errors
				.reject(
						"universityName",
 						new Object[] { "universityName" },
 						reader.getProperty("errors.post.universitynamenotexist"));
			}
		}
		logger
		.debug("PostRequestValidator.validateUniversityName() method exited:");
	}
	
	private void validateSubjectArea(Errors errors, String subjectArea) throws DisciplineNotFoundException {
		logger
		.debug("PostRequestValidator.validateSubjectArea() method entered:"
				+ errors + subjectArea);
		ApplicationContext ctx = null;
		String[] paths = { AppConstants.APPLICATIONCONTEXT_PATH };
		ctx = new ClassPathXmlApplicationContext(paths);
		Search search = (Search) ctx.getBean("searchfacade");
		if (subjectArea.equalsIgnoreCase("a specific SUBJECT AREA")
				|| subjectArea == "" || subjectArea == null
				|| subjectArea.equals("") || subjectArea.equals(" ")) {
			// ValidationUtils.rejectIfEmptyOrWhitespace(errors, "subjectArea",
			// "required", "Please enter SUBJECT AREA field");
			errors.reject("subjectArea",
					new Object[] { "subjectArea" },
					reader.getProperty("errors.search.subjectareafeild"));
		} else {
			
			// if(!EMAIL_PATTERN.matcher(subjectArea).matches()) {
			// errors.rejectValue("subjectArea","errors.subjectArea.notvalid",new
			// Object[] { "subjectArea" }," Only alphabets are allowed in
			// SUBJECT AREA field");
			// }
			if(subjectArea.contains(">")) {
				subjectArea = subjectArea.replaceAll(">","");			
			}
			String subject = subjectArea;
			ArrayList discipline = new ArrayList();
			discipline = search.retriveDisciplineList(subjectArea);
			int count = 0;
			StringTokenizer stt = new StringTokenizer(subject, ",");
			while (stt.hasMoreTokens()) {
				String sub = stt.nextToken();
				if (!discipline.contains(sub)) {
					count++;
				}
			}
			if (count > 0) {
				errors.reject("subjectArea",
						new Object[] { "subjectArea" },
						reader.getProperty("errors.post.subjectareanotexist"));
			}
		}
		logger
		.debug("PostRequestValidator.validateSubjectArea() method exited:");
		// else
		// {
		// ArrayList sId=new ArrayList();
		// sId=validaterDao.getSubjectNameDB(resourcedto.getUniversityName());
		// if(!sId.contains(subjectArea))
		// {
		// errors.rejectValue("subjectArea","errors.subjectArea.required",new
		// Object[] { "subjectArea" }," Subject Area Field is Invalid");
		// }
		// }
	}
	
	private void validateQualification(Errors errors, String qualification) {
		logger
		.debug("PostRequestValidator.validateQualification() method entered:"
				+ errors + qualification);
		if (qualification.equals("select")) {
			errors.reject("qualification",
					new Object[] { "qualification" },
					reader.getProperty("errors.search.qualificationfeild"));
		}
		logger
		.debug("PostRequestValidator.validateQualification() method exited:");
	}
	
	// No validation for year level and specific type since we are having All
	// Year Levels and All Types
	private void validateYearLevel(Errors errors, String yearLevel) {
		logger.debug("PostRequestValidator.validateYearLevel() method entered:"
				+ errors + yearLevel);
		if (yearLevel.equals("select")) {
			errors.reject("yearLevel",
					new Object[] { "yearLevel" },
					reader.getProperty("errors.search.yearlevelfeild"));
		}
		logger.debug("PostRequestValidator.validateYearLevel() method exited:");
	}
	
	private void validateSpecificType(Errors errors, String specificType) {
		logger
		.debug("PostRequestValidator.validateSpecificType() method entered:"
				+ errors + specificType);
		if (specificType.equals("select")) {
			errors
			.reject("specificType",
					new Object[] { "specificType" },
					reader.getProperty("errors.search.typefeild"));
		}
		logger
		.debug("PostRequestValidator.validateSpecificType() method entered:");
	}
	*/
	//-----------------------------End of code Commented for stubbing-----------------------
	
}