package com.mgh.sps.search.web.validator;

import java.util.ArrayList;
/*import java.util.regex.Pattern;

import com.mgh.sps.registration.dao.delegate.ValidaterDao;*/
import com.mgh.sps.search.business.exception.DisciplineNotFoundException;
import com.mgh.sps.search.business.exception.UserUniversityIdNotFoundException;
import com.mgh.sps.search.business.facade.Search;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.mgh.sps.common.constants.app.AppConstants;
import com.mgh.sps.common.dto.ResourceDTO;
import com.mgh.sps.common.util.ResourceBundleReader;

/* 
 @ Author  = Murali Krishna.S
 @ Coded on  date DD-MM-YY= 22-07-07
 @ Use case/s associated = UC501 & UC503
 @ Objective = Validatotion for search home page and search results page
 */
public class SearchValidator implements Validator {
	private static final Logger logger = Logger.getLogger(SearchValidator.class
			.getName());

	//private final static String REG_EXP = "^[A-Za-z0-9]*$";

	//private final static Pattern EMAIL_PATTERN_REG = Pattern.compile(REG_EXP);

	ResourceDTO resourcedto;
	ResourceBundleReader reader = new ResourceBundleReader("search");
	public boolean supports(Class clazz) {
		return clazz.equals(ResourceDTO.class);
	}

	public void validate(Object object, Errors errors) {
		logger.debug("SearchValidator.validate() method entered:"+object+errors);
		resourcedto = (ResourceDTO) object;
		try {		
			validateAll(errors, resourcedto.getKeywords());
		} catch (UserUniversityIdNotFoundException e) {
			e.printStackTrace();
			logger
			.error("Catch Exception in validateSubjectArea in SearchValidator");
		}
		 catch (DisciplineNotFoundException e) {
			e.printStackTrace();
			logger
			.error("Catch Exception in validateSubjectArea in SearchValidator");
		}
		logger.debug("SearchValidator.validate() method exited:");
	}

	private void validateAll(Errors errors, String keywords) throws DisciplineNotFoundException, UserUniversityIdNotFoundException  {
		keywords = keywords.trim();
		logger.debug("SearchValidator.validate() method entered:"+errors+keywords);
		//ValidaterDao validaterDao = new ValidaterDao();
		String country = resourcedto.getCountry();
		String universityName = resourcedto.getUniversityName();
		String subjectArea = resourcedto.getSubjectArea();
		String qualification = resourcedto.getQualification();
		String yearLevel = resourcedto.getYearLevel();
		String specificType = resourcedto.getSpecificType();
		logger.info("****inside validateAll of search validator****");
		logger.info("***************keywords*******************" + keywords);
		logger.debug("***************country*******************" + country);
		logger.debug("***************qualification*******************"
				+ qualification);
		logger.debug("***************yearLevel*******************" + yearLevel);
		logger.debug("***************specificType*******************"
				+ specificType);
//		changed by sreelatha on sep21		
		keywords = keywords.replace(">","");			
		keywords = keywords.replace("<","");
		keywords = keywords.replace("\"","");
		resourcedto.setKeywords(keywords);		
//		 changes end
		if ((keywords.equals("Keyword Search") || keywords.equals("")) && country.equals("select")
				&& (universityName.equals("a specific UNIVERSITY") || universityName.equals(""))
				&& (subjectArea.equals("a specific SUBJECT AREA") || subjectArea.equals(""))
				&& qualification.equals("select") && yearLevel.equals("select")
				&& specificType.equals("select")) {
			errors.reject("keywords",
					new Object[] { "keywords" },
					reader.getProperty("errors.search.atleastonefile"));
		} 
		
		else if (keywords.contains("<") || keywords.contains(">")
				|| keywords.contains("{") || keywords.contains("}")
				|| keywords.contains("^") || keywords.contains("~")
				|| keywords.contains("[") || keywords.contains("]")
				|| keywords.contains("|")) {
			errors.reject("keywords",
					new Object[] { "keywords" }, reader.getProperty("errors.search.keywordfeild"));
		}
		
		universityName = universityName.replace("\""," ");
		if (universityName.contains("<") || universityName.contains(">")
				|| universityName.contains("{") || universityName.contains("}")
				|| universityName.contains("^") || universityName.contains("~")
				|| universityName.contains("[") || universityName.contains("]")
				|| universityName.contains("|") ) {
			resourcedto.setUniversityName("a specific UNIVERSITY");
			errors.reject("universityName",new Object[] { "universityName" },reader.getProperty("errors.search.universitynameinvalid"));
		} else if(universityName.equals("a specific UNIVERSITY") || universityName=="" || universityName==null || universityName.equals(""))
		{			
			resourcedto.setUniversityName("a specific UNIVERSITY");
		}
		else
		{		
			
			//if(country.equals("select")) {
				ApplicationContext ctx = null;
				String[] paths = { AppConstants.APPLICATIONCONTEXT_PATH };
				ctx = new ClassPathXmlApplicationContext(paths);
				Search search = (Search) ctx.getBean("searchfacade");
				ArrayList universities = new ArrayList();
				universities = search.retriveUniversitiesList(universityName);
				//String countryValue = country.toUpperCase();
				if (!(universities.contains(universityName))) {
					logger.info("SearchValidator.validateAll() method in universityName");
					errors.reject("universityName",new Object[] { "universityName" },reader.getProperty("errors.search.universitynamenotexist"));
				}
			//}
		/*	else {
			//ValidationUtils.rejectIfEmptyOrWhitespace(errors, "universityName", "required", "University Name is Required field");
			int countryId=Integer.parseInt(country);
			ArrayList cId=new ArrayList();
				cId=validaterDao.getUniversityNameDB(countryId,universityName);
				if(cId.size()==0)
				{	
					logger.info("SearchValidator.validateAll() method in else universityName");				
					errors.reject("universityName",new Object[] { "universityName" },reader.getProperty("errors.search.universitynamenotexist"));
				}
			}
			*/
			
		}
		subjectArea = subjectArea.replace("\""," ");
		if (subjectArea.contains("<") || subjectArea.contains(">")
				|| subjectArea.contains("{") || subjectArea.contains("}")
				|| subjectArea.contains("^") || subjectArea.contains("~")
				|| subjectArea.contains("[") || subjectArea.contains("]")
				|| subjectArea.contains("|") ) {
			resourcedto.setSubjectArea("a specific SUBJECT AREA");
			errors.reject("subjectArea",new Object[] { "subjectArea" },reader.getProperty("errors.search.subjectareainvalid"));
		} else if(subjectArea.equals("a specific SUBJECT AREA") || subjectArea=="" || subjectArea==null || subjectArea.equals(""))
		{
			resourcedto.setSubjectArea("a specific SUBJECT AREA");
		}	
		else
		{
			
			
			//if(universityName.equals("a specific UNIVERSITY") || universityName=="" || universityName==null || universityName.equals("")) {
			ApplicationContext ctx = null;
			String[] paths = { AppConstants.APPLICATIONCONTEXT_PATH };
			ctx = new ClassPathXmlApplicationContext(paths);
			Search search = (Search) ctx.getBean("searchfacade");
			ArrayList discipline = new ArrayList();
			discipline = search.retriveDisciplineList(subjectArea);
			//String subject = subjectArea.toUpperCase();
			if (!(discipline.contains(subjectArea))) {				
				errors.reject("subjectArea",new Object[] { "subjectArea" },reader.getProperty("errors.search.subjectareanotexist"));
			}
			//}
		/*	else {
			//ValidationUtils.rejectIfEmptyOrWhitespace(errors, "subjectArea", "required", "Subject Area is Required field");
			ArrayList sId=new ArrayList();
			sId=validaterDao.getSubjectNameDB(subjectArea,universityName);
			if(sId.size()==0)
			{				
				errors.reject("subjectArea",new Object[] { "subjectArea" },reader.getProperty("errors.search.subjectareanotexist"));
			}
			}
			*/		
		}
		logger.debug("***************&&&&&&country*******************"+resourcedto.getCountry());
		logger.debug("***************&&&&&&universityName*******************"+resourcedto.getUniversityName());
		logger.debug("***************&&&&&&subjectArea*******************"+resourcedto.getSubjectArea());
		logger.debug("***************&&&&&&qualification*******************"+resourcedto.getQualification());
		logger.debug("***************&&&&&&yearLevel*******************"+resourcedto.getYearLevel());
		logger.debug("***************&&&&&&specificType*******************"+resourcedto.getSpecificType());
		
		logger.debug("SearchValidator.validateAll() method exited:");
	}		
}