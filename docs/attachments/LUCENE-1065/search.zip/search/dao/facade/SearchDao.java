package com.mgh.sps.search.dao.facade;

import java.util.ArrayList;
//import java.util.Map;

import com.mgh.sps.common.dto.ResourceDTO;

/**
 * @author senthilkumar.devan
 * @Objective SearchDao class contains database related methods that needs to be implemented
 */
public interface SearchDao {
	
	/**
	 * @return
	 */
	public ArrayList getSpecificTypes();

	/**
	 * @return
	 */
	public ArrayList getYearLevel();

	/**
	 * @return
	 */
	public ArrayList getCountryDetails();
	
	/**
	 * @return
	 */
	public ArrayList retriveQualificationList();

	/**
	 * @param userName
	 * @return
	 */
	public int retriveUserID(ResourceDTO resourceDto);

	/**
	 * @param uname
	 * @return
	 */
	public int getCountryValues(ResourceDTO resourceDto);

	/**
	 * @param universityName
	 * @return
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public int retriveUniversityID(ResourceDTO resourceDto);
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	/**
	 * @param countryID
	 * @param aId
	 * @return
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public Map retriveUnvList(int countryID, String aId);
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	/**
	 * @param uName
	 * @param aId
	 * @return
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public Map retriveSubjectList(String uName, String aId);
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	/**
	 * @param universityId
	 * @return
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public Map retriveDegreesList(int universityId);
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	/**
	 * @param resourceDto
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public void insertpostRequestDetails(ResourceDTO resourceDto);
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	/**
	 * @param qualificationId
	 * @return
	 */
	public String getQualificationValue(ResourceDTO resourceDto);

	/**
	 * @param specificTypeId
	 * @return
	 */
	public String getSpecificTypeValue(ResourceDTO resourceDto);

	/**
	 * @param yearLevelId
	 * @return
	 */
	public String getYearLevelValue(ResourceDTO resourcesDto);

	/**
	 * @param userStatus
	 * @return
	 */
//	public int getStatusId(String userStatus);
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public int getStatusId(ResourceDTO resourcesDto);
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	/**
	 * @param tempName
	 * @return
	 */
	public ResourceDTO retriveUserStatus(ResourceDTO resourceDto);

	/**
	 * @param filename
	 * @return
	 
	public int getFileFormatValue(String filename);*/

	/**
	 * @return
	 */
	//public Map getDynamicConfig();

	/**
	 * @return
	 */
	public ArrayList retriveDisciplinesList(String subjectArea);
	
	/**
	 * @param countryId
	 * @return
	 */
	public String getCountryValue(ResourceDTO resourceDto);
	
	/**
	 * @return
	 */
	public ArrayList retriveUniversityList(String universityName);
}