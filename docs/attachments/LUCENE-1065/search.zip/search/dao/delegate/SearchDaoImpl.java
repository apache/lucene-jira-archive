package com.mgh.sps.search.dao.delegate;

import java.util.ArrayList;
/*import java.util.HashMap;
import java.util.Map;*/
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import com.mgh.sps.common.dto.MapDto;
import com.mgh.sps.common.dto.ResourceDTO;
import com.mgh.sps.common.exceptions.GGRuntimeException;
//import com.mgh.sps.common.orm.entity.ConfigValue;
import com.mgh.sps.common.orm.entity.Country;
import com.mgh.sps.common.orm.entity.Degree;
import com.mgh.sps.common.orm.entity.Discipline;
import com.mgh.sps.common.orm.entity.University;
import com.mgh.sps.common.orm.entity.Usefulfor;
import com.mgh.sps.common.orm.entity.UserDetails;
import com.mgh.sps.common.orm.entity.Users;
import com.mgh.sps.common.orm.entity.YearLevelStudy;
import com.mgh.sps.search.dao.facade.SearchDao;

/**
 * @author Murali Krishna.S 
 * @date : 25-07-2007
 * @Objective Implemented Methods are used to retrieve Search module related
 *            values from the database.
 */
public class SearchDaoImpl extends HibernateDaoSupport implements SearchDao {
	/**
	 * Methods related to Search module(SearchDaoImpl class) are implemented in
	 * this class
	 */

	/**
	 * Logger creation for SearchDaoImpl class
	 */
	private static final Logger logger = Logger.getLogger(SearchDaoImpl.class
			.getName());

	/**
	 * Method returns list of files that are of the specific types.
	 * example:'Seminar Notes', 'Lecture Notes'
	 * 
	 * @return ArrayList
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getSpecificTypes()
	 */
	public ArrayList getSpecificTypes() {
		/** Logger creation for getSpecificTypes method */
		logger.debug("SearchDaoImpl.getSpecificTypes() method entered:");
		try {
		ArrayList<MapDto> list = null;
		MapDto usefulFor = null;
		ArrayList<Usefulfor> useful = (ArrayList<Usefulfor>) this
		.getHibernateTemplate().find(
				"from Usefulfor order by usefulFor asc");
		if (!(useful.isEmpty())) {
			list = new ArrayList<MapDto>();
			int sizeOfUseful = useful.size();
			for (int i = 0; i <= (sizeOfUseful - 1); i++) {
				usefulFor = new MapDto();
				usefulFor.setKey(String.valueOf(useful.get(i).getId()));
				usefulFor.setValue(useful.get(i).getUsefulFor());
				list.add(usefulFor);
			}
			logger.debug("SearchDaoImpl.getSpecificTypes() method exited:");
			return list;
		}
	 } catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getSpecificTypes: Specific types not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getSpecificTypes() method exited:");
		return null;
	}

	/**
	 * Method returns the year level of study of that particular user.
	 * 
	 * @return ArrayList
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getYearLevel()
	 */
	public ArrayList getYearLevel() {
		/** Logger creation for getYearLevel method */
		logger.debug("SearchDaoImpl.getYearLevel() method entered:");
		try {
		ArrayList<MapDto> list = null;
		MapDto yearList = null;
		ArrayList<YearLevelStudy> years = (ArrayList<YearLevelStudy>) this
		.getHibernateTemplate().find(
				"from YearLevelStudy order by yearLevel asc");
		if (!(years.isEmpty())) {
			list = new ArrayList<MapDto>();
			int sizeOfYears = years.size();
			for (int i = 0; i <= (sizeOfYears - 1); i++) {
				yearList = new MapDto();
				int id = years.get(i).getId();
				String idValue = String.valueOf(id);
				yearList.setValue(years.get(i).getYearLevel());
				yearList.setKey(idValue);
				list.add(yearList);
			}
			logger.debug("SearchDaoImpl.getYearLevel() method exited:");
			return list;
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getYearLevel: Year level not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getYearLevel() method exited:");
		return null;
	}

	/**
	 * Method returns the List of qualifications.
	 * 
	 * @return ArrayList
	 * @see com.mgh.sps.search.dao.facade.SearchDao#retriveQualificationList()
	 */
	public ArrayList retriveQualificationList() {
		/** Logger creation for retriveQualificationList method */
		logger
		.debug("SearchDaoImpl.retriveQualificationList() method entered:");
		try {
		ArrayList<MapDto> list = null;
		MapDto degreeList = null;
		ArrayList<Degree> degree = (ArrayList<Degree>) this
		.getHibernateTemplate().find("from Degree order by name asc");
		if (!(degree.isEmpty())) {
			list = new ArrayList<MapDto>();
			int sizeOfDegree = degree.size();
			for (int i = 0; i <= (sizeOfDegree - 1); i++) {
				degreeList = new MapDto();
				int id = degree.get(i).getId();
				String idValue = String.valueOf(id);
				degreeList.setValue(degree.get(i).getName());
				degreeList.setKey(idValue);
				list.add(degreeList);
			}
			logger
			.debug("SearchDaoImpl.retriveQualificationList() method exited:");
			return list;
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.retriveQualificationList: Qualification not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.retriveQualificationList() method exited:");
		return null;
	}

	/**
	 * Method returns the list of countries having Universities.
	 * 
	 * @return ArrayList
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getCountryDetails()
	 */
	public ArrayList getCountryDetails() {
		/** Logger creation for getCountryDetails method */
		logger.debug("SearchDaoImpl.getCountryDetails() method entered:");
		try {
		ArrayList<MapDto> list2 = null;
		ArrayList<Country> country = (ArrayList<Country>) this
		.getHibernateTemplate().find("from Country order by name asc");
		if (!(country.isEmpty())) {
			list2 = new ArrayList<MapDto>();
			int sizeOfCountry = country.size();
			for (int i = 0; i < sizeOfCountry; i++) {
				MapDto countries = new MapDto();
				int id = country.get(i).getId();
				String idValue = String.valueOf(id);
				countries.setValue(country.get(i).getName());
				countries.setKey(idValue);
				list2.add(countries);
			}
			logger.debug("SearchDaoImpl.getCountryDetails() method exited:");
			return list2;
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getCountryDetails: Country not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getCountryDetails() method exited:");
		return null;
	}

	/**
	 * @param countryID
	 * @param aId
	 * @return Map
	 * @see com.mgh.sps.search.dao.facade.SearchDao#retriveUnvList(int,
	 *      java.lang.String)
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public Map retriveUnvList(int countryID, String aId) {
		return null;
	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */

	/**
	 * @param uName
	 * @param aId
	 * @return Map
	 * @see com.mgh.sps.search.dao.facade.SearchDao#retriveSubjectList(java.lang.String,
	 *      java.lang.String)
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public Map retriveSubjectList(String uName, String aId) {
		return null;
	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */

	/**
	 * Method retrieves the list of degrees available in a particular
	 * university.
	 * 
	 * @param universityId
	 *            universityId is unique key to find the degrees of that
	 *            particular university
	 * @return Map
	 * @see com.mgh.sps.search.dao.facade.SearchDao#retriveDegreesList(int)
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public Map retriveDegreesList(int universityId) {
		// Logger creation for retriveDegreesList method 
		logger.debug("SearchDaoImpl.retriveDegreesList() method entered:" +universityId);
		try {
		Map degrees = null;
		Map sortedDegreeMap = new LinkedHashMap();
		ArrayList<UniversityDegree> degree = (ArrayList<UniversityDegree>) this
		.getHibernateTemplate()
		.find(
				"from UniversityDegree as ud where ud.universityId=(from University as u where u.id=?)",universityId);
		if (!(degree.isEmpty())) {
			degrees = new TreeMap();
			int sizeOfDegree = degree.size();
			for (int i = 0; i <= (sizeOfDegree - 1); i++) {
				int id = degree.get(i).getDegreeId().getId();
				String idValue = String.valueOf(id);
				degrees.put(degree.get(i).getDegreeId().getName(), idValue);
			}
			// Sorting for degree list...
			Iterator iter = degrees.keySet().iterator();

			while (iter.hasNext()) {
				String key = (String) iter.next();
				sortedDegreeMap.put(degrees.get(key), key);

			}
			logger.debug("SearchDaoImpl.retriveDegreesList() method exited:");
			return sortedDegreeMap;
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.retriveDegreesList: Degrees not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.retriveDegreesList() method exited:");
		return null;

	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */

	/**
	 * Method inserts the request details posted by the user.
	 * 
	 * @param resourceDto
	 *            ResourceDTO to retrieve search related details.
	 * @see com.mgh.sps.search.dao.facade.SearchDao#insertpostRequestDetails(com.mgh.sps.common.dto.ResourceDTO)
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public void insertpostRequestDetails(ResourceDTO resourceDto) {
		// Logger creation for insertpostRequestDetails method 
		logger.debug("SearchDaoImpl.insertpostRequestDetails() method entered:"
				+ resourceDto);

		ResourceRequest rr = new ResourceRequest();
		try {
			ArrayList<University> university = (ArrayList<University>) this
			.getHibernateTemplate().find(
					"from University u where id=?",
					Integer.parseInt(resourceDto.getUniversityId()));
			rr.setUniversityId((University) (university.get(0)));
			ArrayList<Degree> degree = (ArrayList<Degree>) this
			.getHibernateTemplate().find("from Degree d where id=?",
					Integer.parseInt(resourceDto.getQualification()));
			rr.setDegreeId((Degree) (degree.get(0)));
			ArrayList<YearLevelStudy> yearLevelStudy = (ArrayList<YearLevelStudy>) this
			.getHibernateTemplate().find(
					"from YearLevelStudy y where id=?",
					Integer.parseInt(resourceDto.getYearLevel()));
			rr.setYearLevelId((YearLevelStudy) (yearLevelStudy.get(0)));
			rr.setDisciplineList(resourceDto.getSubjectArea());
			ArrayList<Usefulfor> usefulfor = (ArrayList<Usefulfor>) this
			.getHibernateTemplate().find("from Usefulfor u where id=?",
					Integer.parseInt(resourceDto.getSpecificType()));
			rr.setUsefulForTypeId((Usefulfor) (usefulfor.get(0)));
			rr.setComments(resourceDto.getComments());
			ArrayList<Users> userList = (ArrayList<Users>) this
			.getHibernateTemplate().find("from Users u where id=?",
					Integer.parseInt(resourceDto.getUserId()));
			rr.setUserId((Users) (userList.get(0)));
			rr.setTopicsCovered(resourceDto.getKeywords());
			ArrayList<Status> status = (ArrayList<Status>) this
			.getHibernateTemplate().find("from Status u where id=?",
					Integer.parseInt(resourceDto.getUserStatusId()));
			rr.setStatusId((Status) (status.get(0)));
			this.getHibernateTemplate().save(rr);
			this.getHibernateTemplate().flush();
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.insertpostRequestDetails: Post request details not inserted",
					dae);
		}
		logger.debug("SearchDaoImpl.insertpostRequestDetails() method exited:");
	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */

	/**
	 * Method retrieves the country values having userId as the parameter.
	 * 
	 * @param userId
	 *            userId to retrieve the country names.
	 * @return integer
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getCountryValues(int)
	 */
	public int getCountryValues(ResourceDTO resourceDto) {
		/** Logger creation for getCountryValues method */
		logger.debug("SearchDaoImpl.getCountryValues() method entered:"	+ resourceDto.getUserId());
		try {
		ArrayList<UserDetails> userDetails = (ArrayList<UserDetails>) this
		.getHibernateTemplate()
		.find("from UserDetails where usersId=(from Users where id=?)",Integer.parseInt(resourceDto.getUserId()));
		if (!userDetails.isEmpty()) {
			logger.debug("SearchDaoImpl.getCountryValues() method exited:");
			return userDetails.get(0).getCountryId().getId();
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getCountryValues: Country Values not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getCountryValues() method exited:");
		return 0;
	}

	/**
	 * Method retrieves the UserId of that particular tempName of a user.
	 * 
	 * @param tempName
	 *            tempName to retrieve the userId of that user.
	 * @return integer
	 * @see com.mgh.sps.search.dao.facade.SearchDao#retriveUserID(java.lang.String)
	 */
	public int retriveUserID(ResourceDTO resourceDto) {
		/** Logger creation for retriveUserID method */
		logger
		.debug("SearchDaoImpl.retriveUserID() method entered:"+ resourceDto.getUserName());
		try {
		//boolean found = false;
		ArrayList<Users> users = (ArrayList<Users>) this.getHibernateTemplate()
		.find("from Users where uname=?", resourceDto.getUserName());
		if (!users.isEmpty()) {
			logger.debug("SearchDaoImpl.retriveUserID() method exited:");
			return users.get(0).getId();
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.retriveUserID: User ID not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.retriveUserID() method exited:");
		return 0;
	}

	/**
	 * Method returns Qualification of the user.
	 * 
	 * @param qualificationId
	 *            to fetch the qualification.
	 * @return qualification
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getQualificationValue(java.lang.String)
	 */
	public String getQualificationValue(ResourceDTO resourceDto) {
		/** Logger creation for getQualificationValue method */
		logger.debug("SearchDaoImpl.getQualificationValue() method entered:"+ resourceDto.getQualification());
		try {
		ArrayList<Degree> degree = (ArrayList<Degree>) this
		.getHibernateTemplate().find("from Degree where id=?",Integer.parseInt(resourceDto.getQualification()));
		if (!degree.isEmpty()) {
			logger
			.debug("SearchDaoImpl.getQualificationValue() method exited:");
			return degree.get(0).getName();
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getQualificationValue: Qualification not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getQualificationValue() method exited:");
		return null;
	}

	/**
	 * Method returns the specific type of the file.
	 * 
	 * @param specificTypeId
	 *            to fetch the specific type of the file.
	 * @return SpecificType
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getSpecificTypeValue(java.lang.String)
	 */
	public String getSpecificTypeValue(ResourceDTO resourceDto) {
		/** Logger creation for getSpecificTypeValue method */
		logger.debug("SearchDaoImpl.getSpecificTypeValue() method entered:"	+resourceDto.getSpecificType());
		try {
		ArrayList<Usefulfor> usefulfor = (ArrayList<Usefulfor>) this
		.getHibernateTemplate().find("from Usefulfor where id=?",Integer.parseInt(resourceDto.getSpecificType()));
		if (!usefulfor.isEmpty()) {
			logger.debug("SearchDaoImpl.getSpecificTypeValue() method exited:");
			return usefulfor.get(0).getUsefulFor();
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getSpecificTypeValue: Specific Type Value not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getSpecificTypeValue() method exited:");
		return null;
	}

	/**
	 * Method returns the year of study of a user.
	 * 
	 * @param yearLevelId
	 * @return YearLevelValue String
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getYearLevelValue(java.lang.String)
	 */
	public String getYearLevelValue(ResourceDTO resourceDto) {
		/** Logger creation for getYearLevelValue method */
		logger.debug("SearchDaoImpl.getYearLevelValue() method entered:"+ resourceDto.getYearLevel());
		try {
		ArrayList<YearLevelStudy> yearLevel = (ArrayList<YearLevelStudy>) this
		.getHibernateTemplate().find("from YearLevelStudy where id=?",Integer.parseInt(resourceDto.getYearLevel()));
		if (!yearLevel.isEmpty()) {
			logger.debug("SearchDaoImpl.getYearLevelValue() method exited:");
			return yearLevel.get(0).getYearLevel();
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getYearLevelValue: Year Level Value not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getYearLevelValue() method exited:");
		return null;
	}

	/**
	 * Method returns the Status id of a particular user.
	 * 
	 * @param userStatus
	 * @return StatusId
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getStatusId(java.lang.String)
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public int getStatusId(ResourceDTO resourcesDto) {
		// Logger creation for getStatusId method 
		logger
		.debug("SearchDaoImpl.getStatusId() method entered:"+ resourcesDto.getUserStatus());
		try {
		ArrayList<Status> status = (ArrayList<Status>) this
		.getHibernateTemplate().find("from Status where status=?",resourcesDto.getUserStatus());
		if (status.size() != 0) {
			logger.debug("SearchDaoImpl.getStatusId() method exited:");
			return status.get(0).getId();
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getStatusId: Status Id not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getStatusId() method exited:");
		return 0;
	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */

	/**
	 * Method returns the status of the user.
	 * 
	 * @param tempName
	 *            tempName to get the status.
	 * @return user status
	 * @see com.mgh.sps.search.dao.facade.SearchDao#retriveUserStatus(resourceDto)
	 */
	public ResourceDTO retriveUserStatus(ResourceDTO resourceDto) {
		/** Logger creation for retriveUserStatus method */
		logger.debug("SearchDaoImpl.retriveUserStatus() method entered:"
				+ resourceDto.getUserName());
		try {
		String status="";
		ArrayList<UserDetails> userdetails = (ArrayList<UserDetails>) this
		.getHibernateTemplate()
		.find(
				"from UserDetails where usersId=(from Users where uname=?)",
				resourceDto.getUserName());
		if (!userdetails.isEmpty()) {
			logger.debug("SearchDaoImpl.retriveUserStatus() method exited:");
			//return userdetails.get(0).getUserStatusId().getStatus();
		status=userdetails.get(0).getUserStatusId().getStatus();
		resourceDto.setUserStatus(status);
		return resourceDto;
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.retriveUserStatus: User Status not retrived",
					dae);
		}
		resourceDto.setUserStatus(null);
		logger.debug("SearchDaoImpl.retriveUserStatus() method exited:");
		return resourceDto;
	}

	/**
	 * Method returns the format of the file.
	 * 
	 * @param filename
	 *            to retrieve the file format id.
	 * @return file format
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getFileFormatValue(java.lang.String)
	 */
	/*public int getFileFormatValue(String filename) {
		// Logger creation for getFileFormatValue method /
		logger.debug("SearchDaoImpl.getFileFormatValue() method entered:"
				+ filename);
		try {
		ArrayList<Resources> resources = (ArrayList<Resources>) this
		.getHibernateTemplate().find("from Resources where name=?",
				filename);
		if (resources.size() != 0) {
			logger.debug("SearchDaoImpl.getFileFormatValue() method exited:");
			return resources.get(0).getHandwrittenStatus();
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getFileFormatValue: File Format Value not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getFileFormatValue() method exited:");
		return 0;
	}*/

	/**
	 * Method returns the university id of a particular university.
	 * 
	 * @param universityName
	 *            to retrieve the university id of a particular university.
	 * @return university id
	 * @see com.mgh.sps.search.dao.facade.SearchDao#retriveUniversityID(java.lang.String)
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public int retriveUniversityID(ResourceDTO resourceDto) {
		// Logger creation for retriveUniversityID method 
		logger.debug("SearchDaoImpl.retriveUniversityID() method entered:"+resourceDto.getUniversityName());
		try {
		ArrayList<University> university = (ArrayList<University>) this
		.getHibernateTemplate().find("from University where name=?",resourceDto.getUniversityName());
		if (university.size() != 0) {
			logger.debug("SearchDaoImpl.retriveUniversityID() method exited:");
			return university.get(0).getId();
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.retriveUniversityID: University ID not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.retriveUniversityID() method exited:");
		return 0;
	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */

	/**
	 * Method returns the Dynamic configuration settings.
	 * 
	 * @return Dynamic config
	 * @see com.mgh.sps.search.dao.facade.SearchDao#getDynamicConfig()
	 */
	/*public Map getDynamicConfig() {
		*//** Logger creation for getDynamicConfig method *//*
		logger.debug("SearchDaoImpl.getDynamicConfig() method entered:");
		try {
		Map map = null;
		ArrayList<ConfigValue> dynamicConfig = (ArrayList<ConfigValue>) this
		.getHibernateTemplate().find("from DynamicConfig");
		if (dynamicConfig.size() != 0) {
			map = new HashMap();
			int sizeOfDynamicConfig = dynamicConfig.size();
			for (int i = 0; i < sizeOfDynamicConfig; i++) {
				map.put(dynamicConfig.get(i).getKey(), dynamicConfig.get(i)
						.getValue());
			}
			logger.debug("SearchDaoImpl.getDynamicConfig() method exited:");
			return map;
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.getDynamicConfig: Dynamic Config not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.getDynamicConfig() method exited:");
		return null;
	}*/

	/**
	 * Method returns list of disciplines available.
	 * 
	 * @return degree
	 * @see com.mgh.sps.search.dao.facade.SearchDao#retriveDisciplinesList()
	 */
	public ArrayList retriveDisciplinesList(String subjectArea) {
		/** Logger creation for retriveDisciplinesList method */
		logger.debug("SearchDaoImpl.retriveDisciplinesList() method entered:");
		try {
		ArrayList degree = null;
		ArrayList<Discipline> discipline = (ArrayList<Discipline>) this
		.getHibernateTemplate().find(
				"from Discipline");
		if (!discipline.isEmpty()) {
			degree = new ArrayList();
			int sizeOfDiscipline = discipline.size();
			for (int i = 0; i < (sizeOfDiscipline); i++) {				
				//String disc = discipline.get(i).getName().toUpperCase();
				String disc = discipline.get(i).getName();
				degree.add(disc);
			}
			logger
			.debug("SearchDaoImpl.retriveDisciplinesList() method exited:");
			return degree;
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.retriveDisciplinesList: Disciplines List not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.retriveDisciplinesList() method exited:");
		return null;
	}
	
	/**Method returns the country value for a particular country ID.
	 * 
	 * @param CountryId
	 * @return
	 */
	public String getCountryValue(ResourceDTO resourceDto) {
		/** Logger creation for getCountryValue method */
		logger.debug("SearchDaoImpl.getCountryValue() method entered:"
				+ resourceDto.getCountry());
		ArrayList<Country> country = (ArrayList<Country>) this
		.getHibernateTemplate().find("from Country where id=?",
				Integer.parseInt(resourceDto.getCountry()));
		if (!country.isEmpty()) {
			logger.debug("SearchDaoImpl.getCountryValue() method exited:");
			return country.get(0).getName();
		}
		logger.debug("SearchDaoImpl.getCountryValue() method exited:");
		return null;
	}
	
	/**
	 * Method returns list of universities available.
	 * 
	 * @return university
	 * @see com.mgh.sps.search.dao.facade.SearchDao#retriveUniversityList()
	 */
	public ArrayList retriveUniversityList(String universityName) {
		logger.debug("SearchDaoImpl.retriveUniversityList() method entered:");
		try {
		ArrayList uni = null;
		ArrayList<University> university = (ArrayList<University>) this
		.getHibernateTemplate().find(
				"from University");
		if (!university.isEmpty()) {
			uni = new ArrayList();
			int sizeOfUniversity = university.size();
			for (int i = 0; i < (sizeOfUniversity); i++) {
				String disc = university.get(i).getName();
				uni.add(disc);
			}
			logger
			.debug("SearchDaoImpl.retriveUniversityList() method exited:");
			return uni;
		}
		} catch (DataAccessException dae) {
			throw new GGRuntimeException(
					"SearchDaoImpl.retriveUniversityList: Universities List not retrived",
					dae);
		}
		logger.debug("SearchDaoImpl.retriveUniversityList() method exited:");
		return null;
	}
}