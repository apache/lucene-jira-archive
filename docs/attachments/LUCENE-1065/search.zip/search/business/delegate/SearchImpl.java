package com.mgh.sps.search.business.delegate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
/*import java.util.MissingResourceException;
import javax.mail.MessagingException;*/
import org.apache.log4j.Logger;
import com.mgh.sps.common.dto.ResourceDTO;
//import com.mgh.sps.common.exceptions.GGSystemException;
import com.mgh.sps.common.helper.lucene.LuceneProcessor;
//import com.mgh.sps.common.util.MailManager;
import com.mgh.sps.registration.dao.delegate.ValidaterDao;
import com.mgh.sps.search.business.exception.CountryNotFoundException;
import com.mgh.sps.search.business.exception.DisciplineNotFoundException;
//import com.mgh.sps.search.business.exception.ConfigMapNotFoundException;
import com.mgh.sps.search.business.exception.FileFormatIdNotFoundException;
import com.mgh.sps.search.business.exception.QualificationNotFoundException;
//import com.mgh.sps.search.business.exception.SearchResultsNotFoundException;
import com.mgh.sps.search.business.exception.SpecificTypeNotFoundException;
import com.mgh.sps.search.business.exception.StatusNotFoundException;
import com.mgh.sps.search.business.exception.UserIdNotFoundException;
import com.mgh.sps.search.business.exception.UserUniversityIdNotFoundException;
import com.mgh.sps.search.business.exception.YearLevelNotFoundException;
import com.mgh.sps.search.business.facade.Search;
import com.mgh.sps.search.dao.facade.SearchDao;

/**
 * This is a business delegate used for Search Module
 * 
 * @date 26 July 2007
 * @author muralikrishna.s
 * @usecase UC613,UC614,UC615,UC616
 */
public class SearchImpl implements Search {
	/** Methods related to Search module are implemented in this class */

	/** Logger creation for Search class */
	private  static final Logger logger = Logger.getLogger(SearchImpl.class.getName());
	LuceneProcessor lucene = null;
	SearchDao searchDao = null;

	/**
	 * This method is used to set the input values to ResourceDTO
	 * 
	 * @author muralikrishna.s
	 * @date 02 Aug 2007
	 * @usecase UC205 InprocessLogin Login
	 * @param resourceDto
	 *            ResourceDTO
	 * @param dynamic
	 *            ResourceDTO
	 * @return list ArrayList<ResourceDTO>
	 * @throws FileFormatIdNotFoundException
	 */
	public ArrayList<ResourceDTO> setInputValues(ResourceDTO resourceDto,
			Map dynamic) throws FileFormatIdNotFoundException {
		/** Logger creation for setInputValues method */
		logger.debug("SearchImpl.setInputValues() method entered:"+ resourceDto);
		if (resourceDto.getUniversityName().equals("a specific UNIVERSITY")	|| resourceDto.getUniversityName().trim().equals("")) {
			resourceDto.setUniversityName("select");
		}
		if (resourceDto.getSubjectArea().equals("a specific SUBJECT AREA")	|| resourceDto.getSubjectArea().trim().equals("")) {
			resourceDto.setSubjectArea("select");
			logger.debug("**********SearchController subject area***********"+ resourceDto.getSubjectArea());
		}
		if (!resourceDto.getQualification().equals("select")) {
			resourceDto.setQualification(searchDao.getQualificationValue(resourceDto));
		}
		if (!resourceDto.getSpecificType().equals("select")) {
			resourceDto.setSpecificType(searchDao.getSpecificTypeValue(resourceDto));
		}
		if (!resourceDto.getYearLevel().equals("select")) {
			resourceDto.setYearLevel(searchDao.getYearLevelValue(resourceDto));
		}
		if(resourceDto.getKeywords().equals("Keyword Search") || resourceDto.getKeywords().trim().equals("")) {
			logger.info("resourceDto.getKeywords()********"+resourceDto.getKeywords());
			resourceDto.setKeywords("");
		}
		if(!resourceDto.getCountry().equals("select")) {
			resourceDto.setCountry(searchDao.getCountryValue(resourceDto));
			logger.info("resourceDto.getCountry()********"+resourceDto.getCountry());
		}
		logger.debug("SearchImpl.setInputValues() method exited:");
		/*
		if (retriveSearchResults(resourceDto, dynamic) == null) {
			try {
				throw new SearchResultsNotFoundException(
						"SearchImpl.setInputValues: Search results not found");
			} catch (SearchResultsNotFoundException e) {
				e.printStackTrace();
			}
		}*/
		return retriveSearchResults(resourceDto, dynamic);
	}

	/**
	 * This method is used to retrieve the reference data
	 * 
	 * @author muralikrishna.s
	 * @date 02 Aug 2007
	 * @usecase UC205 InprocessLogin Login
	 * @param resourceDto
	 *            ResourceDTO
	 * @return refMap Map
	 * @throws UserUniversityIdNotFoundException
	 * @throws SpecificTypeNotFoundException
	 * @throws QualificationNotFoundException
	 * @throws CountryNotFoundException
	 * @throws YearLevelNotFoundException
	 */

	public Map retrieveReferenceData(ResourceDTO resourceDto)
			throws UserUniversityIdNotFoundException, CountryNotFoundException,
			YearLevelNotFoundException, SpecificTypeNotFoundException,
			QualificationNotFoundException {
		logger.debug("SearchImpl.retrieveReferenceData() method entered:"
				+ resourceDto);
		ValidaterDao validaterDao = new ValidaterDao();
		Map<String, Object> refMap = new HashMap<String, Object>();
		//int universityId = searchDao.retriveUniversityID(resourceDto);
		if (searchDao.getCountryDetails() == null
				|| searchDao.getCountryDetails().equals("")) {
			throw new CountryNotFoundException(
					"SearchImpl.retrieveReferenceData: Country not found");
		}
		if (searchDao.getYearLevel() == null
				|| searchDao.getYearLevel().equals("")) {
			throw new YearLevelNotFoundException(
					"SearchImpl.retrieveReferenceData: Year level not found");
		}
		if (searchDao.getSpecificTypes() == null
				|| searchDao.getSpecificTypes().equals("")) {
			throw new SpecificTypeNotFoundException(
					"SearchImpl.retrieveReferenceData: Specific type not found");
		}
		/*if(universityId>0) {
			if(searchDao.retriveDegreesList(universityId) == null 
					|| searchDao.retriveDegreesList(universityId).equals("")) {
				throw new QualificationNotFoundException(
						"SearchImpl.retriveDegreesList: Degrees not found");
			}
		} else {*/
			if(searchDao.retriveQualificationList() == null 
					|| searchDao.retriveQualificationList().equals("")) {
				throw new QualificationNotFoundException(
				"SearchImpl.retriveQualificationList: Degrees not found");
			}
		//}
		refMap.put("country", validaterDao.getCountryDetails());
		refMap.put("yearLevel", searchDao.getYearLevel());
		refMap.put("specificType", searchDao.getSpecificTypes());
	/*	if (universityId > 0) {
			refMap.put("qualification", searchDao.retriveDegreesList(universityId));
		} else {*/
			// refMap.put("qualification",
			// searchDao.retriveDegreesList(universityId));
			refMap.put("qualification", searchDao.retriveQualificationList());
		//}
		logger.debug("SearchImpl.retrieveReferenceData() method exited:");
		return refMap;
	}

	/**
	 * This method is used to retrieve the search results
	 * 
	 * @author muralikrishna.s
	 * @date 02 Aug 2007
	 * @usecase UC205 InprocessLogin Login
	 * @param resourceDto
	 *            ResourceDTO
	 * @param dynamic
	 *            Map
	 * @return list ArrayList<ResourceDTO>
	 * @throws FileFormatIdNotFoundException
	 */
	private ArrayList<ResourceDTO> retriveSearchResults(
			ResourceDTO resourceDto, Map dynamic)
			throws FileFormatIdNotFoundException {
		logger.debug("SearchImpl.retriveSearchResults() method entered:"
				+ resourceDto);
		ArrayList<ResourceDTO> list = lucene.searchAlgorithm(resourceDto,
				dynamic);
		if (null != list) {
			int sizeofList = list.size();
			for (int i = 0; i <= (sizeofList - 1); i++) {
				String shortdesc = list.get(i).getShortDescription();
				if (shortdesc == null || shortdesc.equals("")) {
					list.get(i).setShortDescription("not provided");
				}
				String[] topics = (list.get(i).getTopicsCovered()).split(" ");
				int topic = (topics.length) - 2;
				if (topic == 1) {
					if (topics[0] == null || topics[0].equals("")) {
						list.get(i).setTopicsCovered("not provided");
					} else {
						list.get(i).setTopicsCovered(topics[0]);
					}
				} else {
					if (topic > 1) {
						String top = topics[0];
						for (int j = 1; j < topic; j++) {
							top = top + " " + topics[j];
						}
						list.get(i).setTopicsCovered(top);
					}
				}
				/*String filename = list.get(i).getFileFormatName();
				list.get(i).setFileFormatId(
						String.valueOf(searchDao.getFileFormatValue(filename)));
				logger
						.info("$$$$$$$$$$$$$$$$$$$$ FileFormatId $$$$$$$$$$$$$$$$$$$$$$"
								+ list.get(i).getFileFormatId());*/
			}
			logger.debug("SearchImpl.retriveSearchResults() method exited:");
			return list;
		}
		logger.debug("SearchImpl.retriveSearchResults() method exited:");
		return null;
	}

	/**
	 * This method is used to set the input values to ResourceDTO
	 * 
	 * @author muralikrishna.s
	 * @date 02 Aug 2007
	 * @usecase UC205 InprocessLogin Login
	 * @param resourceDto
	 *            ResourceDTO
	 * @param userName
	 *            String
	 * @return resourceDto ResourceDTO
	 * @throws UserIdNotFoundException
	 * @throws CountryNotFoundException
	 */

	public ResourceDTO setCountryValues(ResourceDTO resourceDto)
			throws UserIdNotFoundException, CountryNotFoundException {
		logger.debug("SearchImpl.setCountryValues() method entered:"
				+ resourceDto + "," + resourceDto);
		int uname = searchDao.retriveUserID(resourceDto);
		if (uname == 0) {
			throw new UserIdNotFoundException(
					"SearchImpl.setCountryValues: User Id not found");
		}
		resourceDto.setUserId(String.valueOf(uname));
		String cId = String.valueOf(searchDao.getCountryValues(resourceDto));
		if (cId == null || cId.equals("")) {
			throw new CountryNotFoundException(
					"SearchImpl.setCountryValues: Country not found");
		}
		resourceDto.setCountry(cId);
		logger.debug("SearchImpl.setCountryValues() method exited:");
		return resourceDto;
	}

	/**
	 * This method is used to set the input values to ResourceDTO
	 * 
	 * @author muralikrishna.s
	 * @date 02 Aug 2007
	 * @usecase UC205 InprocessLogin Login
	 * @param resourceDto
	 *            ResourceDTO
	 * @param universityName
	 *            String
	 * @param userStatus
	 *            String
	 * @param dynamic
	 *            String
	 * @throws UserUniversityIdNotFoundException,
	 * @throws UserIdNotFoundException
	 * @throws StatusNotFoundException,
	 * @throws GGSystemException
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public void insertpostRequestDetails(ResourceDTO resourceDto,Map dynamic)throws UserUniversityIdNotFoundException, UserIdNotFoundException,
	
	StatusNotFoundException, GGSystemException {
//logger.debug("SearchImpl.insertpostRequestDetails() method entered:"+ resourceDto + "," + universityName + "," + userName + ","	+ userStatus);

		String uniname = String.valueOf(searchDao.retriveUniversityID(resourceDto));
		resourceDto.setUniversityId(uniname);
		if (uniname==null || uniname.equals("")) {
			throw new UserUniversityIdNotFoundException(
					"SearchImpl.insertpostRequestDetails: User universityId not found");
		}
		String uname = String.valueOf(searchDao.retriveUserID(resourceDto));
		resourceDto.setUserId(uname);
		if (uname==null || uname.equals("")) {
			throw new UserIdNotFoundException(
					"SearchImpl.insertpostRequestDetails: User Id not found");
		}
		String statusId = String.valueOf(searchDao.getStatusId(resourceDto));
		resourceDto.setUserStatusId(statusId);
		
		if (statusId==null || statusId.equals("")) {
			throw new StatusNotFoundException(
					"SearchImpl.insertpostRequestDetails: Status not found");
		}
		searchDao.insertpostRequestDetails(resourceDto);
		
		
		if (resourceDto.getUserStatus().equals("General")) {
	try {
		logger.info("message sending");
		MailManager mailManager = new MailManager();
		mailManager.sendPostRequest(resourceDto,dynamic);
	} catch (MissingResourceException resourceException) {
		throw new GGSystemException(
				"SearchImpl.insertpostRequestDetails: Missing Resource Exception",
				resourceException);
	} catch (MessagingException messagingException) {
		throw new GGSystemException(
				"SearchImpl.insertpostRequestDetails: Messaging Exception",
				messagingException);
	}
}
logger.debug("SearchImpl.insertpostRequestDetails() method exited:");
}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	
	
	
	
	
	

	/**
	 * Getters
	 * 
	 * @return
	 */
	public LuceneProcessor getLucene() {
		return lucene;
	}

	/**
	 * Setters
	 * 
	 * @param lucene
	 */
	public void setLucene(LuceneProcessor lucene) {
		this.lucene = lucene;
	}

	/**
	 * Getters
	 * 
	 * @return searchDao
	 */
	public SearchDao getSearchDao() {
		return searchDao;
	}

	/**
	 * Setters
	 * 
	 * @param searchDao
	 */
	public void setSearchDao(SearchDao searchDao) {
		this.searchDao = searchDao;
	}

	/**
	 * Method retrieves the Status of the User
	 * 
	 * @param tempName
	 * @return user status
	 * @throws Exception
	 */
	public ResourceDTO retriveUserStatus(ResourceDTO resourceDto)
			throws StatusNotFoundException {

		return this.searchDao.retriveUserStatus(resourceDto);
	}

	/**
	 * Method retrieves the list of degrees of a particular university.
	 * 
	 * @param universityId
	 * @return Degree List(Map)
	 * @throws QualificationNotFoundException
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public Map retriveDegreesList(int universityId)
			throws QualificationNotFoundException {
		if (searchDao.retriveDegreesList(universityId) == null
				|| searchDao.retriveDegreesList(universityId).equals("")) {
			throw new QualificationNotFoundException(
					"SearchImpl.retriveDegreesList: Qualification not found");
		}
		return this.searchDao.retriveDegreesList(universityId);
	}
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	/**
	 * Method retrieves the Dynamic configuration values.
	 * 
	 * @return Dynamic config values(Map)
	 * @throws ConfigMapNotFoundException
	 */
	/*public Map getDynamicValues() throws ConfigMapNotFoundException {
		if (searchDao.getDynamicConfig() == null
				|| searchDao.getDynamicConfig().equals("")) {
			throw new ConfigMapNotFoundException(
					"SearchImpl.getDynamicValues: Dynamic config not found");
		}
		return searchDao.getDynamicConfig();
	}*/

	/**
	 * Method returns lists of Disciplines available for the courses.
	 * 
	 * @return List of Disciplines
	 * @throws DisciplineNotFoundException
	 */
	public ArrayList retriveDisciplineList(String subjectArea) throws DisciplineNotFoundException {
		if (searchDao.retriveDisciplinesList(subjectArea) == null
				|| searchDao.retriveDisciplinesList(subjectArea).equals("")) {
			throw new DisciplineNotFoundException(
					"SearchImpl.retriveDisciplinesList: Disciplines not found");
		}
		return searchDao.retriveDisciplinesList(subjectArea);
	}
	
	/**
	 * @return
	 * @throws UserUniversityIdNotFoundException
	 */
	public ArrayList retriveUniversitiesList(String universityName) throws UserUniversityIdNotFoundException {
		if (searchDao.retriveUniversityList(universityName) == null
				|| searchDao.retriveUniversityList(universityName).equals("")) {
			throw new UserUniversityIdNotFoundException(
					"SearchImpl.retriveUniversitiesList: Universities not found");
		}
		return searchDao.retriveUniversityList(universityName);
	}





}
