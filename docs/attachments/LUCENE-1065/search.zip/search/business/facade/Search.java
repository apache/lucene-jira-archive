package com.mgh.sps.search.business.facade;

import java.util.ArrayList;
import java.util.Map;

import com.mgh.sps.common.dto.ResourceDTO;
//import com.mgh.sps.common.exceptions.GGSystemException;
//import com.mgh.sps.common.util.MailManager;
import com.mgh.sps.search.business.exception.CountryNotFoundException;
import com.mgh.sps.search.business.exception.DisciplineNotFoundException;
//import com.mgh.sps.search.business.exception.ConfigMapNotFoundException;
import com.mgh.sps.search.business.exception.FileFormatIdNotFoundException;
import com.mgh.sps.search.business.exception.QualificationNotFoundException;
import com.mgh.sps.search.business.exception.SpecificTypeNotFoundException;
import com.mgh.sps.search.business.exception.StatusNotFoundException;
import com.mgh.sps.search.business.exception.UserIdNotFoundException;
import com.mgh.sps.search.business.exception.UserUniversityIdNotFoundException;
import com.mgh.sps.search.business.exception.YearLevelNotFoundException;

/**
 * @author senthilkumar.devan
 * @Objective Search Interface contains search related methods that needs to be
 *            implemented.
 */
public interface Search {

	/**
	 * @param resourceDTO
	 * @param dynamic
	 * @return
	 * @throws FileFormatIdNotFoundException
	 */
	public ArrayList<ResourceDTO> setInputValues(ResourceDTO resourceDTO,
			Map dynamic) throws FileFormatIdNotFoundException;

	/**
	 * @param resourceDTO
	 * @return
	 * @throws UserUniversityIdNotFoundException
	 * @throws CountryNotFoundException
	 * @throws YearLevelNotFoundException
	 * @throws SpecificTypeNotFoundException
	 * @throws QualificationNotFoundException
	 */
	public Map retrieveReferenceData(ResourceDTO resourceDTO)
			throws UserUniversityIdNotFoundException, CountryNotFoundException,
			YearLevelNotFoundException, SpecificTypeNotFoundException,
			QualificationNotFoundException;

	/**
	 * @param resourceDTO
	 * @param userName
	 * @return
	 * @throws UserIdNotFoundException
	 * @throws CountryNotFoundException
	 */
	public ResourceDTO setCountryValues(ResourceDTO resourceDTO)
			throws UserIdNotFoundException, CountryNotFoundException;

	/**
	 * @param resourceDto
	 * @param universityName
	 * @param userName
	 * @param userStatus
	 * @throws UserUniversityIdNotFoundException
	 * @throws UserIdNotFoundException
	 * @throws StatusNotFoundException
	 * @throws GGSystemException
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public void insertpostRequestDetails(ResourceDTO resourceDt,Map dynamic)	throws UserUniversityIdNotFoundException, UserIdNotFoundException,		StatusNotFoundException, GGSystemException;
	*/
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	
	

	/**
	 * @param tempName
	 * @return
	 * @throws StatusNotFoundException
	 */
	public ResourceDTO retriveUserStatus(ResourceDTO resourceDto)
			throws StatusNotFoundException;
		
	/**
	 * @param universityId
	 * @return
	 * @throws QualificationNotFoundException
	 */
	/**
	 * October 24 Stubbed Code for Beta release method started
	 */
	/**
	public Map retriveDegreesList(int universityId)
			throws QualificationNotFoundException;
    */
	/**
	 * October 24 Stubbed Code for Beta release method ended
	 */
	
	/**
	 * @return
	 * @throws ConfigMapNotFoundException
	 */
	//public Map getDynamicValues() throws ConfigMapNotFoundException;

	/**
	 * @return
	 * @throws DisciplineNotFoundException
	 */
	public ArrayList retriveDisciplineList(String subjectArea) throws DisciplineNotFoundException;
	
	/**
	 * @return
	 * @throws UserUniversityIdNotFoundException
	 */
	public ArrayList retriveUniversitiesList(String universityName) throws UserUniversityIdNotFoundException;
}
