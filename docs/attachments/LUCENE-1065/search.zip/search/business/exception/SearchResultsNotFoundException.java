package com.mgh.sps.search.business.exception;

import com.mgh.sps.common.exceptions.GGApplicationException;

/**
 * @author senthilkumar.devan
 * @objective Application related exceptions are caught here.
 * (When search results are not found)
 */
public class SearchResultsNotFoundException extends GGApplicationException {
	
	/**
	 * Class constructor.
	 * @param message
	 * @param code
	 */
	public SearchResultsNotFoundException(String message, long code) {
		super(message, code);
	}
	
	/**
	 * Class constructor.
	 * @param message
	 */
	public SearchResultsNotFoundException(String message) {
		super(message);
	}

}
