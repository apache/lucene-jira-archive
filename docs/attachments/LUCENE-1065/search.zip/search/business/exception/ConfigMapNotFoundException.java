package com.mgh.sps.search.business.exception;

import com.mgh.sps.common.exceptions.GGApplicationException;

/**
 * @author senthilkumar.devan
 * @objective Application related exceptions are caught here.
 */
public class ConfigMapNotFoundException extends GGApplicationException {

	/**
	 * Class constructor.
	 * @param message
	 * @param code
	 */
	public ConfigMapNotFoundException(String message, long code) {
		super(message, code);
	}

	/**
	 * Class constructor.
	 * @param message
	 */
	public ConfigMapNotFoundException(String message) {
		super(message);
	}

}
