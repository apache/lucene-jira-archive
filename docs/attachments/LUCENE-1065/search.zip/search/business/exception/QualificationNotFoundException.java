package com.mgh.sps.search.business.exception;

import com.mgh.sps.common.exceptions.GGApplicationException;

/**
 * @author senthilkumar.devan
 * @objective Application related exceptions are caught here.
 * (When qualification searched for is not found)
 */
public class QualificationNotFoundException extends GGApplicationException {
	
	/**
	 * Class constructor.
	 * @param message
	 * @param code
	 */
	public QualificationNotFoundException(String message, long code) {
		super(message, code);
	}
	
	/**
	 * Class constructor.
	 * @param message
	 */
	public QualificationNotFoundException(String message) {
		super(message);
	}

}
