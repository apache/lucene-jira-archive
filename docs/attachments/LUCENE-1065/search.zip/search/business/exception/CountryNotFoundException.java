package com.mgh.sps.search.business.exception;

import com.mgh.sps.common.exceptions.GGApplicationException;

/**
 * @author senthilkumar.devan
 * @objective Application related exceptions are caught here.
 * (When country searched for is not found)
 */
public class CountryNotFoundException extends GGApplicationException {
	
	/**
	 * Class constructor.
	 * @param message
	 * @param code
	 */
	public CountryNotFoundException(String message, long code) {
		super(message, code);
	}
	
	/**
	 * Class constructor.
	 * @param message
	 */
	public CountryNotFoundException(String message) {
		super(message);
	}

}
