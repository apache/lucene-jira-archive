package com.mgh.sps.search.business.exception;

import com.mgh.sps.common.exceptions.GGApplicationException;

/**
 * @author senthilkumar.devan
 * @objective Application related exceptions are caught here.
 * (When user id is not found)
 */
public class UserIdNotFoundException extends GGApplicationException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4815933231992472745L;

	/**
	 * Class constructor.
	 * @param message
	 * @param code
	 */
	public UserIdNotFoundException(String message, long code) {
		super(message, code);
	}
	
	/**
	 * Class constructor.
	 * @param message
	 */
	public UserIdNotFoundException(String message) {
		super(message);
	}
	

}
