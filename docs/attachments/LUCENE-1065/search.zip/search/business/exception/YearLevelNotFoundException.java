package com.mgh.sps.search.business.exception;

import com.mgh.sps.common.exceptions.GGApplicationException;

/**
 * @author senthilkumar.devan
 * @objective Application related exceptions are caught here.
 * (When year level of study searched is not found)
 */
public class YearLevelNotFoundException extends GGApplicationException {
	
	/**
	 * Class constructor.
	 * @param message
	 * @param code
	 */
	public YearLevelNotFoundException(String message, long code) {
		super(message, code);
	}
	
	/**
	 * Class constructor.
	 * @param message
	 */
	public YearLevelNotFoundException(String message) {
		super(message);
	}

}
