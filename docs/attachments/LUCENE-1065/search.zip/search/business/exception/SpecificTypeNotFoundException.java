package com.mgh.sps.search.business.exception;

import com.mgh.sps.common.exceptions.GGApplicationException;

/**
 * @author senthilkumar.devan
 * @objective Application related exceptions are caught here.
 * (When specific type of a file is not found)
 */
public class SpecificTypeNotFoundException extends GGApplicationException {
	
	/**
	 * Class constructor.
	 * @param message
	 * @param code
	 */
	public SpecificTypeNotFoundException(String message, long code) {
		super(message, code);
	}
	
	/**
	 * Class constructor.
	 * @param message
	 */
	public SpecificTypeNotFoundException(String message) {
		super(message);
	}

}
