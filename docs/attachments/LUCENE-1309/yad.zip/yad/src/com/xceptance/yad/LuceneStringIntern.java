package com.xceptance.yad;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CountDownLatch;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.LockObtainFailedException;
import org.apache.lucene.store.RAMDirectory;
import org.junit.Assert;

/**
 * Tests the concurrent performance of Lucene IndexSearcher
 * for comparison with String.intern() or weak hashmap in Field.java
 *
 * @author  
 * @version 
 */
public class LuceneStringIntern implements Runnable
{
    private final static Directory directory = new RAMDirectory();
    
    private final static String[] creators = {"Rene", "Marc", "Dude", "Unknown", "Helen", "Sue", "Peter", "Wayne"};
    private final static Random random = new Random();
    
    private final static String[] searchWords = 
    {
        "appearance", "silently", "create", "visibility", "directory", "relationship", 
        "Microsoft", "JNI", "managed", "Thinking", "are", "Linux"
    };
    private final static int[] searchWordHitCounts = 
    {
        22, 10, 678, 23, 77, 38, 
        102, 40, 11, 78, 0, 56
    };

    private final static CountDownLatch startSignal = new CountDownLatch(1);
    
    private final IndexSearcher isearcher;
    
    /**
     * 
     */
    public LuceneStringIntern(IndexSearcher isearcher)
    {
        super();
        this.isearcher = isearcher;
    }

    private static void buildIndex() throws Exception
    {
        Analyzer analyzer = new StandardAnalyzer();

        // Store the index in memory use the setup RAMDirectory
        
        // To store an index on disk, use this instead:
        //Directory directory = FSDirectory.getDirectory("/tmp/testindex");
        IndexWriter iwriter = new IndexWriter(directory, analyzer, true);
        iwriter.setMaxFieldLength(25000);

        // get data file
        BufferedReader reader = new BufferedReader(new FileReader("data/sentences.txt"));
        
        String line = null;
        int counter = 0;
        while ( (line = reader.readLine()) != null)
        {
            counter++;
            Document doc = new Document();
        
            doc.add(new Field("text", line, Field.Store.NO, Field.Index.TOKENIZED));
            doc.add(new Field("counter", String.valueOf(counter), Field.Store.YES, Field.Index.UN_TOKENIZED));
            
            String creator = creators[random.nextInt(creators.length)];
            doc.add(new Field("creator", creator, Field.Store.YES, Field.Index.TOKENIZED));
            doc.add(new Field("upper", creator.toUpperCase(), Field.Store.YES, Field.Index.TOKENIZED));
            doc.add(new Field("lower", creator.toLowerCase(), Field.Store.YES, Field.Index.TOKENIZED));
            iwriter.addDocument(doc);
        }
         
        reader.close();
        
        iwriter.optimize();
        iwriter.close();        
    }
    
    private void searchIndex(int iterations, IndexSearcher isearcher) throws CorruptIndexException, IOException, ParseException
    {
        Analyzer analyzer = new StandardAnalyzer();

        for (int i = 0; i < iterations; i++)
        {
            // get search phrase and count
            final int pos = random.nextInt(searchWords.length);
            String searchWord = searchWords[pos];
            int searchWordHitCount = searchWordHitCounts[pos];
            
            // Parse a simple query that searches for "text":
            QueryParser parser = new QueryParser("text", analyzer);
            Query query = parser.parse(searchWord);
    
            Hits hits = isearcher.search(query);
            Assert.assertEquals("Search result count wrong for '" + searchWord + "'", searchWordHitCount, hits.length());
            
            // just an outside ref
            String s = null;
            
            // Iterate through the results:
            for (int h = 0; h < hits.length(); h++) 
            {
                Document hitDoc = hits.doc(h);
                
                // access data
                List<Field> fields = hitDoc.getFields();
                for(int f = 0; f < fields.size(); f++)
                {
                    Field field = fields.get(f);
                    s = field.stringValue();
                }
            }
        }
    }
    
    private void execute(IndexSearcher isearcher) throws Exception
    {
        final int WARMUP1 = 100;
        final int WARMUP2 = 200; 
        final int SEARCH = 5000; 
        
        // warm it up, twice
        long sWarmup1 = System.currentTimeMillis();
        searchIndex(WARMUP1, isearcher);
        long eWarmup1 = System.currentTimeMillis();

        long sWarmup2 = System.currentTimeMillis();
        searchIndex(WARMUP2, isearcher);
        long eWarmup2 = System.currentTimeMillis();

        // search on it
        long sSearch = System.currentTimeMillis();
        searchIndex(SEARCH, isearcher);
        long eSearch = System.currentTimeMillis();

        String tName = Thread.currentThread().getName();
//        System.out.println("[" + tName +  "] Warmup1 took: " + (eWarmup1 - sWarmup1) + "ms");
//        System.out.println("[" + tName +  "] Warmup2 took: " + (eWarmup2 - sWarmup2) + "ms");
        System.out.println("[" + tName +  "] Search  took: " + (eSearch - sSearch) + "ms");
    }

    private static IndexSearcher getIndexSearcher() throws Exception
    {
        // use on index for all 
        return new IndexSearcher(directory);
    }

    private static void tearDown(IndexSearcher isearcher) throws Exception
    {
        isearcher.close();
        directory.close();
    }

    
    /* (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    public void run()
    {
        try
        {
            startSignal.await();
            execute(isearcher);
        }
        catch (Exception ex) 
        {
            ex.printStackTrace();
        }
    }

    /**
     * @param args
     * @throws IOException 
     * @throws LockObtainFailedException 
     * @throws CorruptIndexException 
     */    
    public static void main(String[] args) throws Exception
    {
        // Single run
        buildIndex();
        IndexSearcher isearcher = getIndexSearcher();

        LuceneStringIntern test = new LuceneStringIntern(isearcher);
        test.execute(isearcher);
        
        // multi threading
        final int THREADCOUNT = 4;
        final List<Thread> threads = new ArrayList<Thread>(THREADCOUNT);
        // build
        for (int i = 0; i < THREADCOUNT; i++)
        {
            // YOU CAN ASSIGN an exclusive searcher to the thread here or use the 
            // global one to check concurrency. It seems that the searcher is
            // synchronized and so the run time decreases when using exclusive ones.
            // isearcher = getIndexSearcher();
            threads.add(new Thread(new LuceneStringIntern(isearcher), "Thread-" + i));
        }
        // start threads
        for (int i = 0; i < THREADCOUNT; i++)
        {
            threads.get(i).start();
        }
        // activate all
        startSignal.countDown();
        
        // wait
        for (int i = 0; i < THREADCOUNT; i++)
        {
            threads.get(i).join();
        }
        
        tearDown(isearcher);
    }

}
