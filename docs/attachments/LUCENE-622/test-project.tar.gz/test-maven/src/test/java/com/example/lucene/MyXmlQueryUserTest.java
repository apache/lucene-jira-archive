package com.example.lucene;

import org.apache.lucene.xmlparser.ParserException;

import junit.framework.TestCase;

public class MyXmlQueryUserTest extends TestCase {

  public void testParsing() throws ParserException {
    String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<TermsQuery fieldName=\"contents\">term1</TermsQuery>";
    MyXmlQueryUser u = new MyXmlQueryUser();
    System.out.println("parsed: " + u.parse(xml));

  }
}
