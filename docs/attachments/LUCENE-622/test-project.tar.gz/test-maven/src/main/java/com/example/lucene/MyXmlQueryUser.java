package com.example.lucene;

import java.io.ByteArrayInputStream;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Query;
import org.apache.lucene.xmlparser.CoreParser;
import org.apache.lucene.xmlparser.CorePlusExtensionsParser;
import org.apache.lucene.xmlparser.ParserException;

public class MyXmlQueryUser {

  private CoreParser builder;

  public MyXmlQueryUser() {
    Analyzer analyzer = new StandardAnalyzer();
    builder = new CorePlusExtensionsParser(analyzer, new QueryParser(
        "contents", analyzer));

  }

  public Query parse(String xml) throws ParserException {
    Query result = builder.parse(new ByteArrayInputStream(xml.getBytes()));
    return result;
  }

}
