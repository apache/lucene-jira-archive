package se.snigel.lucene.crud;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;

import java.io.IOException;
import java.util.LinkedList;


public abstract class AbstractCRUD<E extends Tokenized> implements CRUD<E> {

    public LinkedList<Hit<E>> search(Query query, Searcher searcher) throws IOException {        
        Hits hits = searcher.search(query);
        LinkedList<Hit<E>> ret = new LinkedList<Hit<E>>();
        for (int i = 0; i < hits.length(); i++) {
            E tokenized = assembleTokenized(hits.doc(i));
            if (tokenized == null) {
                throw new InconsistnecyException("Index contains references to unknown instances of " + tokenized.getClass().getName() + ". Rebuild the index.");
            }
            ret.addLast(new Hit<E>(tokenized, hits.score(i)));
        }
        return ret;
    }

    public void idFactory(E tokenized) {
        throw new NullPointerException("Id must be set.");
    }

    public final void create(IndexWriter indexWriter, E tokenized) throws IOException, RuntimeException {
        create(indexWriter, indexWriter.getAnalyzer(), tokenized);
    }

    public void create(IndexWriter indexWriter, Analyzer analyzer, E tokenized) throws IOException, RuntimeException {

        if (tokenized.getId() == null) {
            idFactory(tokenized);
        }
        indexWriter.addDocument(assembleDocumentToBeCommitted(tokenized), analyzer);

    }

    public final void delete(IndexReader reader, E tokenized) throws IOException {
        reader.deleteDocuments(new Term(getIdField(), tokenized.getId().toString()));
    }

    /**
     * Creates a document based on a tokenized instance.
     *
     * Override this method to add your sub-class attributes in the lucene document.
     * Usually it is a good thing to avoid using Lucene as your primary object persistency layer. Rather try working the ID as a foregin key.
     *
     * @param tokenized the instance to be stored in the lucene index.
     * @return A lucene document representing the tokenized
     */
    protected Document assembleDocumentToBeCommitted(E tokenized) {
        Document document = new Document();
        document.add(new Field(getIdField(), tokenized.getId().toString(), Field.Store.YES, Field.Index.UN_TOKENIZED, Field.TermVector.NO));
        return document;
    }

}