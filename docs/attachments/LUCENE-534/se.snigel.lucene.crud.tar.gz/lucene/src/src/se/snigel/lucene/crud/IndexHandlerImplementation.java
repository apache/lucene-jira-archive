package se.snigel.lucene.crud;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.File;
import java.io.IOException;

/**
 * User: kalle
 * Date: 2006-mar-11
 * Time: 20:14:10
 */
public class IndexHandlerImplementation implements IndexHandler {

    private boolean inRAM;
    private File path;

    private RAMDirectory indexRAM;
    private FSDirectory indexFS;
    private IndexSearcher searcher;
    private Analyzer analyzer;

    private static final Logger log = LogManager.getLogger(IndexHandlerImplementation.class);

    public IndexHandlerImplementation(File path, boolean inRAM, Analyzer analyzer) throws IOException {
        this.path = path;
        this.inRAM = inRAM;
        this.analyzer = analyzer;

        boolean create = false;
        if (!path.exists()) {
            create = true;
            path.mkdirs();
        }
        indexFS = FSDirectory.getDirectory(path, create);
        if (IndexReader.isLocked(indexFS)) {
            log.warn("File system index is locked! Removing locks in hope it was due to an abnormal server shut down.");
            IndexReader.unlock(indexFS);
        }

        if (create && !create()) {

            IndexWriter indexWriter = new IndexWriter(indexFS, analyzer, true);

            // add stupid data to avoid currput (empty) index TODO: better!
            Document dumb = new Document();
            dumb.add(new Field("_bug", "_fix", Field.Store.YES, Field.Index.NO));
            indexWriter.addDocument(dumb);
            indexWriter.close();

        }

        onIndexFSUpdate();
    }

    /**
     * @return true if something was created;
     * @throws IOException
     */
    public boolean create() throws IOException {
         return false;
    }

    public IndexWriter createIndexWriter() throws IOException {
        return createIndexWriter(false);
    }

    public IndexWriter createIndexWriter(boolean create) throws IOException {
        return createIndexWriter(getAnalyzer(), create);
    }

    public IndexWriter createIndexWriter(Analyzer analyzer, boolean create) throws IOException {
        return new IndexWriter(getIndexFS(), analyzer, create);
    }
    
    public IndexReader createReader() throws IOException {
    		return IndexReader.open(getIndex());
	}

	public Directory getIndex() {
        if (inRAM) {
            return indexRAM;
        } else {
            return indexFS;
        }
    }

    public Analyzer getAnalyzer() {
        return analyzer;
    }


    public final void onIndexFSUpdate() throws IOException {
    	
        final RAMDirectory oldIndexRAM = indexRAM;

        if (inRAM) {
            indexRAM = new RAMDirectory(indexFS);
        }

        if (oldIndexRAM != null) {
            oldIndexRAM.close();
        }

        onIndexUpdate();
    }

    public final void onIndexUpdate() throws IOException {

	    	final IndexSearcher oldSearcher = searcher;
	    
	    	searcher = new IndexSearcher(getIndex());
	
	    	if (oldSearcher != null) {
            try {
                Thread.sleep(5000); // give old searches a chanse to finish.
                oldSearcher.close();
            } catch (Exception e) {
                // ignore
            }
        }


    }

    public void addAll(Directory[] dir) throws IOException {
        IndexWriter indexWriter;
        indexWriter = new IndexWriter(indexFS, analyzer, false);
        indexWriter.addIndexes(dir);
        indexWriter.close();
        if (inRAM) {
            indexWriter = new IndexWriter(indexRAM, analyzer, false);
            indexWriter.addIndexes(dir);
            indexWriter.close();
        }
        onIndexUpdate();

    }

    public void close() throws IOException {
        
        if (getSearcher() != null) {
            getSearcher().close();
        }
        if (getIndexRAM() != null) {
            getIndexRAM().close();
        }
        if (getIndexFS() != null) {
            getIndexFS().close();
        }
    }


    protected void finalize() throws Throwable {
        close();
        super.finalize();
    }

    public boolean isInRAM() {
        return inRAM;
    }

    public File getPath() {
        return path;
    }

    protected RAMDirectory getIndexRAM() {
        return indexRAM;
    }

    protected FSDirectory getIndexFS() {
        return indexFS;
    }

    

    public IndexSearcher getSearcher() {
        return searcher;
    }
}
