package se.snigel.lucene.crud;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;

import java.io.IOException;
import java.io.File;
import java.util.List;
import java.util.Collection;
import java.util.LinkedList;

/**
 * User: kalle
 * Date: 2006-mar-14
 * Time: 19:38:41
 */
public interface IndexHandler {

    Analyzer getAnalyzer();

    /**
     * @return true if something was created;
     * @throws IOException
     */
    public boolean create() throws IOException;


    /**
     *This method should also initialize the
     * @throws IOException
     * @param dir
     * @throws java.io.IOException
     */
    void addAll(Directory[] dir) throws IOException;

    public abstract void onIndexUpdate() throws IOException;
    public abstract void onIndexFSUpdate() throws IOException;

    public abstract IndexWriter createIndexWriter() throws IOException;
    public abstract IndexWriter createIndexWriter(boolean create) throws IOException;
    public abstract IndexWriter createIndexWriter(Analyzer analyzer, boolean create) throws IOException;
    public abstract IndexReader createReader() throws IOException;
    
    public abstract File getPath();

    public abstract Directory getIndex();
    public abstract IndexSearcher getSearcher();

    public abstract void close() throws IOException;


}
