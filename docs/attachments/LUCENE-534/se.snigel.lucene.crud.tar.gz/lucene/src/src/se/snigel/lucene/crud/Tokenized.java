package se.snigel.lucene.crud;

/**
 * User: kalle
 * Date: 2006-mar-14
 * Time: 10:12:33
 */
public interface Tokenized<E> {

    /**
     * @return the safe lucene document identity
     */
    E getId();

    public void setId(E id);

 
}
