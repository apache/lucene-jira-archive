package se.snigel.lucene.crud;

import java.io.IOException;

/**
 * User: kalle
 * Date: 2006-mar-30
 * Time: 05:59:21
 */
public class InconsistnecyException extends IOException {

    public InconsistnecyException() {
    }

    public InconsistnecyException(String string) {
        super(string);
    }
    
}
