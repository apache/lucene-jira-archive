package se.snigel.lucene.crud.example;

import se.snigel.lucene.crud.AbstractTokenized;

public class MyClass extends AbstractTokenized<Long> {

	private Long id;

    public MyClass(Long id, String stringValue) {
        this.id = id;
        this.stringValue = stringValue;
    }

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;		
	}

	private String stringValue;

    public String getStringValue() {
        return stringValue;
    }

    public void setStringValue(String stringValue) {
        this.stringValue = stringValue;
    }


}
