package se.snigel.lucene.crud;

/**
 * User: kalle
 * Date: 2006-mar-14
 * Time: 10:07:05
 */
public abstract class AbstractTokenized<E> implements Tokenized<E> {
 
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        } else if (o == null) {
            return false;
        } else if (o instanceof Tokenized) {
            return getId().equals(((Tokenized) o).getId());
        } else {
            return false;
        }
    }

    public int hashCode() {
        if (getId() != null) {
            return getId().hashCode();
        } else {
            return super.hashCode();
        }
    }
}
