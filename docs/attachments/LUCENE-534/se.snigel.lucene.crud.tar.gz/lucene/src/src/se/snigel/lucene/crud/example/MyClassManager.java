package se.snigel.lucene.crud.example;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.LinkedList;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;

import se.snigel.lucene.crud.*;

public class MyClassManager {

    public static void main(String[] ignored) throws Exception {
        MyClassManager m = new MyClassManager();
        m.registerMyClass(new MyClass(1l, "det var en g�ng en gubbe"));
        m.registerMyClass(new MyClass(2l, "som bodde i en stubbe"));
        m.registerMyClass(new MyClass(3l, "med sina dr�ngar b�da."));
        m.registerMyClass(new MyClass(4l, "de var uppe hela dagen"));
        m.registerMyClass(new MyClass(5l, "tills de fick ont i magen"));
        m.getIndexHandler().create();
        LinkedList<Hit<MyClass>> hits = m.getCRUD().search(new TermQuery(new Term("textValue", "stubbe")), m.getIndexHandler().getSearcher());        
    }

    private Map<Long, MyClass> myClassesById = new HashMap<Long, MyClass>();

    public Map<Long, MyClass> getMyClassesById() {
        return myClassesById;
    }
    public void registerMyClass(MyClass myClass) {
        getMyClassesById().put(myClass.getId(), myClass);
    }

    private IndexHandler ih;
    public IndexHandler getIndexHandler() throws IOException {
        if (ih ==  null) {
            ih = new IndexHandlerImplementation(new File("/tmp/myClassesIndex"), true, new StandardAnalyzer()) {

                @Override
                public boolean create() throws IOException {
                    IndexWriter iw = createIndexWriter(true);
                    for (MyClass instance : myClassesById.values()) {
                        getCRUD().create(iw, getAnalyzer(), instance);
                    }
                    iw.close();
                    return myClassesById.size() > 0;
                }

            };
        }
        return ih;
    }

    private CRUD<MyClass> crud;

    public CRUD<MyClass> getCRUD() {
        if (crud == null) {
            crud = new AbstractCRUD<MyClass>() {
                public MyClass assembleTokenized(Document document) throws IOException {
                    return myClassesById.get(document.getField(getIdField()));
                }
                public String getIdField() {
                    return "MyClass.id";
                }

                @Override
                protected Document assembleDocumentToBeCommitted(MyClass tokenized) {
                    Document ret = super.assembleDocumentToBeCommitted(tokenized);
                    ret.add(new Field("textValue", tokenized.getStringValue(), Field.Store.NO, Field.Index.TOKENIZED, Field.TermVector.WITH_OFFSETS));
                    return ret;
                }
            };
        }
        return crud;
    }
}
