package se.snigel.lucene.crud;

/**
 * User: kalle
 * Date: 2006-mar-21
 * Time: 04:08:53
 */
public class Hit<E extends Tokenized> implements Comparable<Hit> {
    private E tokenized;
    private Float score;

    public Hit(E tokenized, float score) {
        this.tokenized = tokenized;
        this.score = score;
    }

    public int compareTo(Hit hit) {
        return score.compareTo(hit.score);
    }

    public E getTokenized() {
        return tokenized;
    }

    public float getScore() {
        return score;
    }

    public String toString() {
        return getScore() + " " + getTokenized().toString();
    }


    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        final Hit hit = (Hit) o;

        if (Float.compare(hit.score, score) != 0) return false;
        if (tokenized != null ? !tokenized.equals(hit.tokenized) : hit.tokenized != null) return false;

        return true;
    }

    public int hashCode() {
        int result;
        result = (tokenized != null ? tokenized.hashCode() : 0);
        result = 29 * result + score != +0.0f ? Float.floatToIntBits(score) : 0;
        return result;
    }
}