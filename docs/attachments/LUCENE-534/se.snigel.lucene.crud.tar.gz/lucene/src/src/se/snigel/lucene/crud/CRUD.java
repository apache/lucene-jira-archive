package se.snigel.lucene.crud;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.store.Directory;

import java.io.IOException;
import java.util.LinkedList;
import java.util.NoSuchElementException;

/**
 * <p>
 * A simple Create/Read/Update/Delete pattern that with safe identity (a unique term per document) to a document
 * represented as a Tokenized instance.
 * </p>
 * <p>
 * Also comes in handy if you want to try another brand of index.
 * </p>
 * @author kalle
 */
public interface CRUD<E extends Tokenized> {
    /**
     * if no id has been assigned at commit time, this method is called. yoda me.
     * @param tokenized
     */
    void idFactory(E tokenized);


    E assembleTokenized(Document document) throws IOException;

    void create(IndexWriter indexWriter, E tokenized) throws IOException, RuntimeException;

    /**
     * Creates a tokenized instance in the lucene index, but only if the instance is dirty.
     * If the tokenized has no identity, it is created by this method.
     *
     * @param indexWriter persistence pointer.
     * @param tokenized the instance to be persisted.
     * @throws java.io.IOException
     * @throws RuntimeException if the tokenized was assembled from an index document.
     */
    void create(IndexWriter indexWriter, Analyzer analyzer, E tokenized) throws IOException, RuntimeException;

    void delete(IndexReader reader, E tokenized) throws IOException;

    /**
     * @return the lucene document field used to store the tokenized identity in.
     */
    String getIdField();

    public LinkedList<Hit<E>> search(Query query, Searcher searcher) throws IOException;
}
