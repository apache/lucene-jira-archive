
package org.apache.lucene.document;

import junit.framework.TestCase;

import java.util.Calendar;
import java.util.TimeZone;
import java.util.Date;

/**
 * Testcase for DateField and DateFieldDefinition
 * @author Dan Rapp
 */
public class TestDateField extends TestCase {

  public void testDateDefinitions() throws Exception {
    assertTrue("Unexpected result for minimum date string: " + DateField.MIN_DATE_STRING(), DateField.MIN_DATE_STRING().equals("000000000"));
    assertTrue("Unexpected result for maximum date string: " + DateField.MAX_DATE_STRING(), DateField.MAX_DATE_STRING().equals("zzzzzzzzz"));
  }

  public void testFieldDefinition() throws Exception {
    assertTrue("Expected length for definition = 5, instead its: " + DateFieldDefinition.HISTORICAL_DATE_DEF.getDateFieldLength(), DateFieldDefinition.HISTORICAL_DATE_DEF.getDateFieldLength() == 5);
    assertTrue("Too many chars required for translation definition. TestDefinition: " + DateFieldDefinition.HISTORICAL_DATE_DEF.getDateFieldLength() + ", DefaultDefinition: " + DateFieldDefinition.DEFAULT_DATE_DEF.getDateFieldLength(), DateFieldDefinition.HISTORICAL_DATE_DEF.getDateFieldLength() < DateFieldDefinition.DEFAULT_DATE_DEF.getDateFieldLength());
  }

  private void testDateSpread(int year, int month, int day, DateFieldDefinition definition) {
    Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));

    cal.clear();
    cal.set(year, month, day, 0, 0, 0);
    cal.set(Calendar.MILLISECOND, 0);
    java.util.Date date = cal.getTime();
    String dateString = DateField.dateToString(date, definition);
    java.util.Date dateAfter = DateField.stringToDate(dateString, definition);
    assertTrue("Date doesn't remain the same through conversion: Date before: " + date + ", Date After: " + dateAfter, dateAfter.compareTo(date) == 0);

    cal.clear();
    cal.set(year, month, day, 23, 59, 59);
    cal.set(Calendar.MILLISECOND, 999);
    date = cal.getTime();
    String dateString2 = DateField.dateToString(date, definition);
    assertTrue("Date resolution not working properly (strings should be equal). Initial String: " + dateString + ", Subsequent String: " + dateString2, dateString2.equals(dateString));

    cal.clear();
    cal.set(year, month, day+1, 0, 0, 0);
    cal.set(Calendar.MILLISECOND, 0);
    date = cal.getTime();
    dateString2 = DateField.dateToString(date, definition);
    assertTrue("Date resolution not working properly (strings should NOT be equal). Initial String: " + dateString + ", Subsequent String: " + dateString2, !dateString2.equals(dateString));

    cal.clear();
    cal.set(year, month, day-2, 23, 59, 59);
    cal.set(Calendar.MILLISECOND, 999);
    date = cal.getTime();
    long time = date.getTime();
    dateString2 = DateField.timeToString(time, definition);
    assertTrue("Date resolution not working properly (strings should NOT be equal). Initial String: '" + dateString + "', Subsequent String: '" + dateString2 + "'", !dateString2.equals(dateString));
  }

  public void testConversionWithDefinition() throws Exception {
    DateFieldDefinition def = new DateFieldDefinition(0, DateFieldDefinition.DATE, DateFieldDefinition.ONE_WEEK);
    try {
      // testing a date spread on the zero value should work except when
      // we try to back up a second...
      testDateSpread(1970, 0, 1, def);
      ///CLOVER:OFF
      assertTrue("Pre-1970 date was accepted", false);
    }
    catch(RuntimeException e) {
      // this is what we'd expect...
      assertTrue(e.getMessage().equals(DateField.TOO_EARLY_EXCEPTION_MESSAGE));
    }
    testDateSpread(1970, 6, 4, def);

    def = new DateFieldDefinition(200, DateFieldDefinition.DATE, DateFieldDefinition.ONE_WEEK);
    testDateSpread(1970, 6, 4, def);
    testDateSpread(1770, 6, 4, def);

    testDateSpread(2003, 10, 7, DateFieldDefinition.HISTORICAL_DATE_DEF);
    testDateSpread(1776, 6, 4, DateFieldDefinition.HISTORICAL_DATE_DEF);
  }

  public void testDefaultConversion() throws Exception {
    try {
      testDateSpread(1776, 6, 4, DateFieldDefinition.DEFAULT_DATE_DEF);
      ///CLOVER:OFF
      assertTrue("Pre-1970 date accepted.", false);
      ///CLOVER:ON
    }
    catch (RuntimeException e) {
      // this is what we'd expect...
      assertTrue(e.getMessage().equals(DateField.TOO_EARLY_EXCEPTION_MESSAGE));
    }

    Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
    cal.clear();
    cal.set(1970, 6, 4, 0, 0, 0);
    Date date = cal.getTime();
    String dateString = DateField.timeToString(cal.getTimeInMillis());
    Date dateAfter = DateField.stringToDate(dateString);
    long time = DateField.stringToTime(dateString);
    assertTrue("Date doesn't remain the same through conversion: Date before: " + date + ", Date After: " + dateAfter, dateAfter.compareTo(date) == 0);
    assertTrue("Millis doesn't remain the same through conversion: Millis before: " + cal.getTimeInMillis() + ", Millis After: " + time, cal.getTimeInMillis() == time);


    time = DateField.stringToTime(DateField.MAX_DATE_STRING());

    try {
      dateString = DateField.timeToString(time + 1);
      ///CLOVER:OFF
      assertTrue("> MAX_DATE accepted.", false);
      ///CLOVER:ON
    }
    catch (RuntimeException e) {
      // this is what we'd expect...
      assertTrue(e.getMessage().equals(DateField.TOO_LATE_EXCEPTION_MESSAGE));
    }
  }

  // todo: need some test cases for resolutions other than MILLISECOND and DATE
}