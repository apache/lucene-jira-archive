package org.apache.lucene.queryParser;

import org.apache.lucene.document.DateFieldDefinition;

/**
 * FieldStrategy provides a means of determining what is or is not a date field and
 * given a date field, how the date should be treated, e.g. what are the valid ranges
 * for that field, what is the resolution of the field, and how much difference between
 * dates in a fuzzy search.
 * @author Dan Rapp
 */
public interface FieldStrategy {

  public boolean isDateField(String field);

  public DateFieldDefinition getDateFieldDefinition(String field);
}
