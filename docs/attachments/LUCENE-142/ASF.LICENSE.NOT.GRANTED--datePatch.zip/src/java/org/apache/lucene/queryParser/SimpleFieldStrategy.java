package org.apache.lucene.queryParser;

import org.apache.lucene.document.DateFieldDefinition;

/**
 * A very simple implementation of FieldStrategy. It assumes that all fields in which the
 * field name contains the text '.date' is a date field and that the field definition
 * is the {@link DateFieldDefinition#DEFAULT_DATE_DEF DefaultDefinition}.
 * <p>This class is intended primarily for illustrative purposes.
 * @author Dan Rapp
 */
public class SimpleFieldStrategy implements FieldStrategy {

  public boolean isDateField(String field) {
    return (field.toLowerCase().indexOf(".date") != -1);
  }

  public DateFieldDefinition getDateFieldDefinition(String field) {
    return DateFieldDefinition.DEFAULT_DATE_DEF;
  }

}
