package org.apache.lucene.search;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.document.DateField;
import org.apache.lucene.document.DateFieldDefinition;

import java.io.IOException;

/**
 * Subclass of FilteredTermEnum for enumerating all (DateField) terms that are
 * similiar to the specified filter term.
 * <p>
 * Term enumerations are always ordered by Term.compareTo().  Each term in
 * the enumeration is greater than all that precede it.
 * @author Dan Rapp
 */
public class FuzzyDateTermEnum extends FilteredTermEnum {

  boolean fieldMatch = false;
  boolean endEnum = false;

  Term searchTerm = null;
  String field = "";
  String text = "";
  long time = 0L;
  long distance;

  private long fuzzyThreshold;

  public FuzzyDateTermEnum(IndexReader reader, Term term, DateFieldDefinition definition) throws IOException {
    super(reader, term);
    this.fuzzyThreshold = definition.getFuzzyThreshold();
    searchTerm = term;
    field = searchTerm.field();
    text = searchTerm.text();
    time = DateField.stringToTime(text);
    distance = time - fuzzyThreshold;
    setEnum(reader.terms(new Term(searchTerm.field(), DateField.timeToString(distance))));
  }

  /**
   * The termCompare method in FuzzyDateTermEnum simply calculates the
   * distance (in milliseconds) between two date terms to determine if
   * it falls within the fuzzyThreshold
   */
  protected final boolean termCompare(Term term) {
    boolean withinThreshold = false;
    if (field == term.field()) {
      String target = term.text();
      long targetTime = DateField.stringToTime(target);
      distance = Math.abs(time - targetTime);
      if (distance > fuzzyThreshold) {
        endEnum = true;
      }
      else {
        withinThreshold = true;
      }
    }
    else {
      endEnum = true;
    }
    return withinThreshold;
  }

  protected float difference() {
    return (1.0f - (float)distance / (fuzzyThreshold + 1));
  }

  public final boolean endEnum() {
    return endEnum;
  }

  public void close() throws IOException {
    super.close();
    searchTerm = null;
    field = null;
    text = null;
  }
}
