package org.apache.lucene.search;

import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.document.DateFieldDefinition;

import java.io.IOException;

/**
 * A FuzzyQuery class that handles fuzzy queries on Dates simply based on the
 * number of milliseconds seperating two dates rather than on the edit distance.
 * @author Dan Rapp
 */
public class FuzzyDateQuery extends MultiTermQuery {
  DateFieldDefinition definiton;
  public FuzzyDateQuery(Term term, DateFieldDefinition definition) {
    super(term);
    this.definiton = definition;
  }

  protected FilteredTermEnum getEnum(IndexReader reader) throws IOException {
    return new FuzzyDateTermEnum(reader, getTerm(), definiton);
  }
}
