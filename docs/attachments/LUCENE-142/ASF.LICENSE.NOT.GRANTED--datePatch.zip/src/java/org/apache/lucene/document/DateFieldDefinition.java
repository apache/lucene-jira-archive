
package org.apache.lucene.document;

import org.apache.lucene.store.OutputStream;
import org.apache.lucene.store.InputStream;

import java.io.IOException;
import java.text.DateFormat;

/**
 * DateFieldDefinition is used by {@link DateField} to support
 * pre 1970 dates.
 * @author Dan Rapp
 */
public class DateFieldDefinition {
  public static final long ONE_MILLISECOND = 1;
  /** One second, in milliseconds **/
  public static final long ONE_SECOND = 1000;
  /** One minute, in milliseconds **/
  public static final long ONE_MINUTE = 60 * ONE_SECOND;
  /** One hour, in milliseconds **/
  public static final long ONE_HOUR = 60 * ONE_MINUTE;
  /** One day, in milliseconds **/
  public static final long ONE_DAY = 24 * ONE_HOUR;
  /** One week, in milliseconds **/
  public static final long ONE_WEEK = 7 * ONE_DAY;
  /** One year in milliseconds **/
  public static final long ONE_YEAR = (long)(365.2425 * ONE_DAY);

  /**
   * Field number for resolution in DateFieldDefinition constructor indicating the
   * year
   */
  public static final int YEAR = 0;
  /**
   * Field number for resolution in DateFieldDefinition constructor indicating the
   * month
   */
  public static final int MONTH = 1;
  /**
   * Field number for resolution in DateFieldDefinition constructor indicating the
   * date
   */
  public static final int DATE = 2;
  /**
   * Field number for resolution in DateFieldDefinition constructor indicating the
   * hour
   */
  public static final int HOUR = 3;
  /**
   * Field number for resolution in DateFieldDefinition constructor indicating the
   * minute
   */
  public static final int MINUTE = 4;
  /**
   * Field number for resolution in DateFieldDefinition constructor indicating the
   * Second
   */
  public static final int SECOND = 5;
  /**
   * Field number for resolution in DateFieldDefinition constructor indicating the
   * millisecond
   */
  public static final int MILLISECOND = 6;

  private static final long[] RESOLUTION = {
    ONE_YEAR,
    ONE_DAY * 31,
    ONE_DAY,
    ONE_HOUR,
    ONE_MINUTE,
    ONE_SECOND,
    ONE_MILLISECOND
  };

  public static final DateFieldDefinition DEFAULT_DATE_DEF = new DateFieldDefinition(0, MILLISECOND, ONE_DAY);
  public static final DateFieldDefinition HISTORICAL_DATE_DEF = new DateFieldDefinition(5000, DATE, ONE_YEAR); // 1970 +/- 5000 years (approximate span of recorded history)

  private int dateLen;
  // defines the resolution of the time that is stored in the index,
  // e.g. if resloution is millis then its possible to differentiate
  // entries in the index that are 1 millisecond apart, etc.
  private long resolution_divisor;
  // defines the offset from a 1970 date to a new time coordinate to support
  // monotonically increasing positive index values.
  private long offset_addend;
  // defines how far off a date can be and still result in a fuzzy search hit.
  private long fuzzyThreshold;

  // ctor params (stored for serialization)
  private int resolution;
  private int offset;

  private DateFormat dateFormat;

  /**
   * Defines a DateField that can represent dates that are atleast +/- offset
   * from Jan 1, 1970 and are distinguishable from other dates when the
   * time difference exceeds resolution. For example if you do not wish to
   * distinguish between two different date values within a given day, then
   * resolution should be specified as ONE_DAY.
   * @param offset the ammount of time im years +/- Jan 1, 1970 that this
   * DateField supports. An offset of 0 will support dates in the range of Jan 1, 1970
   * to Jan 1, 2970.
   * @param resolution the amount of time two date values may differ to be considered
   * two seperate dates within the index. This value is one of Resolution Fields.
   * @param fuzzyThreshold the ammount of time in which a date may be from the
   * date specified in a fuzzy search and still return a hit
   */
  public DateFieldDefinition(int offset, int resolution, long fuzzyThreshold) {
    this.resolution = resolution;
    this.offset = offset;
    this.fuzzyThreshold = fuzzyThreshold;

    resolution_divisor = RESOLUTION[this.resolution];

    if (this.offset == 0) {
      offset_addend = 0;
      long maxDate = (ONE_YEAR * 1000) / resolution_divisor;
      this.dateLen = Long.toString(maxDate, Character.MAX_RADIX).length();
    }
    else {
      offset_addend = (offset * ONE_YEAR * 2) / resolution_divisor;
      this.dateLen = Long.toString(offset_addend, Character.MAX_RADIX).length();
    }
    dateFormat = DateFormat.getDateInstance(DateFormat.SHORT);
    dateFormat.setLenient(true);
  }

  public int getDateFieldLength() {
    return dateLen;
  }

  public long getFuzzyThreshold() {
    return fuzzyThreshold;
  }

  public DateFormat getDateFormat() {
    return dateFormat;
  }

  public void setDateFormat(DateFormat dateFormat) {
    this.dateFormat = dateFormat;
  }

  public long translate(long time) {
    boolean pre = time < 0;
    // if we are dealing with negative time, then we need to add one
    // to avoid a "fence post" situation on having the very initial
    // millisecond of a day in negative time equate to all of the values
    // of a preceeding day (except for its initial millisecond) when
    // we are working with a day resolution, etc.
    if (pre) time++;
    time /= resolution_divisor;
    // we still need to ensure that we are negative time, even if
    // the resolution division has taken us to 0, this will prevent
    // a true 0 value from being indistinguishable from a slightly
    // negative value
    if (pre) time--;
    time += offset_addend;
    return time;
  }

  public long reverseTranslation(long time) {
    time -= offset_addend;
    boolean pre = time < 0;
    if (pre) time++;
    time *= resolution_divisor;
    // if we are dealing with negative time, then we need to add
    // in a full resolution width of time to resolve back to our
    // original input
    if (pre) time -= resolution_divisor;
    return time;
  }

  public String getMaxString() {
    char[] buffer = new char[dateLen];
    char c = Character.forDigit(Character.MAX_RADIX-1, Character.MAX_RADIX);
    for (int i = 0 ; i < buffer.length; i++)
      buffer[i] = c;
    return new String(buffer);
  }

  public void writeDefinition(OutputStream output) throws IOException {
    output.writeVInt(offset);
    output.writeVInt(resolution);
    output.writeVLong(fuzzyThreshold);
  }

  public static DateFieldDefinition read(InputStream input) throws IOException {
    int offset = input.readVInt();
    int resolution = input.readVInt();
    long fuzzyThreshold = input.readVLong();
    // return the instance of  a "well-known" DateFieldDefinitions, rather than
    // constructing new ones.
    if (offset == 0 && resolution == MILLISECOND && fuzzyThreshold == ONE_DAY) {
      return DEFAULT_DATE_DEF;
    }
    else if (offset == 5000 && resolution == DATE&& fuzzyThreshold == ONE_YEAR) {
      return HISTORICAL_DATE_DEF;
    }
    return new DateFieldDefinition(offset, resolution, fuzzyThreshold);
  }

}
