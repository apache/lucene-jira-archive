/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.io.IOException;
import java.util.Iterator;
import java.util.TreeMap;

/**
 * Replace terms by other terms 
 * @author Nicolas Maisonneuve
 *
 */
public class TermReplacer  implements TermTransformer {

	private final class ReplaceTerm  {
		private Term oldterm;
		private DocumentSelection docs;
		
		/**
		 * @param docs The docs to set.
		 */
		public void setDocs(DocumentSelection docs) {
			this.docs = docs;
		}

		/**
		 * @return Returns the docs.
		 */
		public DocumentSelection getDocs() {
			return docs;
		}
	}

	private final class ReplaceProducter implements TermProducter {
	
		private final class ReplaceTermEnum extends TermEnum {
			private Term term;

			private Iterator iterTerm;

			private ReplaceTerm rt;

			public void close() throws IOException {
				termEnum.close();
			}

			public int docFreq() {
				throw new UnsupportedOperationException(); // return
															// termEnum.docFreq();
			}

			public boolean next() throws IOException {
				if (!iterTerm.hasNext())
					return false;
				else {
					term = (Term) iterTerm.next();

					return true;
				}
			}

			public Term term() {
				return term;
			}

			public ReplaceTermEnum() {
				iterTerm = replacedTerm.keySet().iterator();
			}
		}

		private final class ReplaceTermPositions implements TermPositions {
			private ReplaceTerm rt;

			public int nextPosition() throws IOException {
				return termPositions.nextPosition();
			}

			public int doc() {
				return termPositions.doc();
			}

			public int freq() {
				return termPositions.freq();
			}

			public void seek(Term arg0) throws IOException {
				rt = getReplacedTerm(arg0, false);
				if (rt != null)
					termPositions.seek(rt.oldterm);
			}

			public void seek(TermEnum tenum) throws IOException {
				seek(tenum.term());
			}

			public void close() throws IOException {
				termPositions.close();
			}

			public boolean next() throws IOException {
				if (rt == null)
					return false;
				do {
					if (!termPositions.next()) {
						return false;
					}
				} while (rt.getDocs().isSelected(termPositions.doc()));

				return true;
			}

			public int read(int[] arg0, int[] arg1) throws IOException {
				throw new UnsupportedOperationException();
			}

			public boolean skipTo(int arg0) throws IOException {
				throw new UnsupportedOperationException();
			}
		}
		TermEnum termEnum;
		TermPositions termPositions;
		
		public ReplaceProducter(TermProducter input) throws IOException {
			termEnum = input.terms();
			termPositions = input.termPositions();
		
		}
		public TermEnum terms() throws IOException {
			return new ReplaceTermEnum();
		}

		public TermPositions termPositions() throws IOException {
			return new ReplaceTermPositions();
		}

	}

	TreeMap replacedTerm = new TreeMap();

	public TermReplacer() {
		}

	public TermProducter transform(TermProducter input)
			throws IOException {
		return new ReplaceProducter(input);
	}

	public final ReplaceTerm getReplacedTerm(Term newterm, boolean create) {
		ReplaceTerm replacedterm = (ReplaceTerm) replacedTerm.get(newterm);
		if (replacedterm == null && create) {
			replacedterm = new ReplaceTerm();
			replacedTerm.put(new Term(newterm.field, newterm.text, false),
					replacedterm);
		}
		return replacedterm;
	}

	public void replaceTerm(Term oldTerm, Term newTerm, DocumentSelection docsel) {
		ReplaceTerm replacedterm = getReplacedTerm(newTerm, true);
		replacedterm.oldterm = oldTerm;
		replacedterm.setDocs(docsel);
	}

}
