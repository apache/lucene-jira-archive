package org.apache.lucene.index;

import java.io.IOException;
import java.util.TreeMap;

final public class TermFilter implements TermTransformer {

	private final class FilterProducter implements TermProducter {
		private final class FilterTermEnum extends TermEnum {

			private DocumentSelection deldocs;

			private Term term;

			public void close() throws IOException {
				filteredTermEnum.close();
			}

			public int docFreq() {
				if (deldocs == null) {
					return filteredTermEnum.docFreq();
				} else {
					return (deldocs.allSelected()) ? 0 : filteredTermEnum
							.docFreq()
							- deldocs.size();
				}
			}

			public boolean next() throws IOException {
				do {
					if (!filteredTermEnum.next()) {
						return false;
					}
					term = filteredTermEnum.term();
					deldocs = filter(term);

				} while (deldocs != null && docFreq() == 0);

				return true;
			}

			public Term term() {
				return term;
			}
		}

		private final class FilterTermPositions implements TermPositions {

			private DocumentSelection deldocs;

			private Term term;

			public int nextPosition() throws IOException {

				return filteredTermPositions.nextPosition();
			}

			public int doc() {
				return filteredTermPositions.doc();
			}

			public int freq() {
				return filteredTermPositions.freq();
			}

			public int read(int[] arg0, int[] arg1) throws IOException {
				throw new UnsupportedOperationException();
			}

			public void seek(Term arg0) throws IOException {
				term = arg0;
				// System.out.println("term " + arg0 + " passed!");
				filteredTermPositions.seek(term);
				deldocs = filter(term);
				// PrintableTermTest.printTermPositions(filteredTermPositions);
				// filteredTermPositions.seek(term);
			}

			public void seek(TermEnum tenum) throws IOException {
				seek(tenum.term());

			}

			public boolean skipTo(int arg0) throws IOException {
				throw new UnsupportedOperationException();
			}

			public void close() throws IOException {
				filteredTermEnum.close();
			}

			public boolean next() throws IOException {
				int doc = 0;
				boolean res;
				do {
					if (!filteredTermPositions.next()) {
						// System.out.println("no more docs" + " "+term);
						return false;
					}
					if (deldocs == null)
						return true;
					doc = filteredTermPositions.doc();
					res = deldocs.isSelected(doc);
					// System.out.println("term "+term +" doc:
					// "+filteredTermPositions.doc()+" "+res);

				} while (res);

				return true;
			}

		}

		private TermEnum filteredTermEnum;

		private TermPositions filteredTermPositions;

		private DocumentSelection filter(Term term) {
			DocumentSelection deldocs;
			boolean res;

			// check if term must be deleted
			deldocs = getDeletedDocs(term);
			if (deldocs == null) {
				// no , so check if the field must be deleted
				termBuffer.set(term.field, "");
				return deldocs = getDeletedDocs(termBuffer);
			} else
				return deldocs;
		}

		public FilterProducter(TermProducter input) throws IOException {
			filteredTermEnum = input.terms();
			filteredTermPositions = input.termPositions();
		}

		public TermEnum terms() throws IOException {
			return new FilterTermEnum();
		}

		public TermPositions termPositions() throws IOException {
			return new FilterTermPositions();
		}

	}


	private TreeMap deletedPostings = new TreeMap();
	private Term termBuffer = new Term("", "");

	/**
	 * get the DeletedDocs object associated with the term
	 * 
	 * @param term
	 * @param create
	 *            if the term is no found , create it
	 * @return
	 */
	public final DocumentSelection getDeletedDocs(Term term) {
		return (DocumentSelection) deletedPostings.get(term);
	}

	/**
	 * Delete a search field for some documents
	 * 
	 * @param field
	 *            the field name 
	 * @param docs
	 *            the selected documents
	 */
	public final void deleteField(String field, DocumentSelection docsel) {
		deletedPostings.put(new Term(field, "", false), docsel);
	}

	/**
	 * Delete a term for some documents
	 * 
	 * @param field
	 *            the field of the term
	 * @param value
	 *            the value of the term
	 * @param docs
	 *            the selected documents
	 */
	public final void deleteTerm(Term term, DocumentSelection docsel) {
		deletedPostings.put(term, docsel);
	}

	public final void deleteTerm(String field, String value,
			DocumentSelection docsel) {
		deletedPostings.put(new Term(field, value, false), docsel);
	}

	public TermProducter transform(TermProducter input) throws IOException {
		return new FilterProducter(input);
	}

}
