/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.io.IOException;
import java.util.BitSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.lucene.util.PriorityQueue;
/**
 * Term merger :  merge and sort several termProducters to produce new Term Postings
 *  
 * @author Nicolas Maisonneuve
 *
 */
public final class TermMerger implements TermProducter {

	final class PostingInfos {
		TermEnum te;

		TermPositions tp;

		PostingInfos(TermEnum te, TermPositions tp) {
			this.te = te;
			this.tp = tp;
		}
	}

	private final class MergeTermPositions implements TermPositions {

		private final class TermPositionsQueue extends PriorityQueue {
			TermPositionsQueue(List termPositions) throws IOException {
				initialize(termPositions.size());

				Iterator i = termPositions.iterator();
				while (i.hasNext()) {
					TermPositions tp = (TermPositions) i.next();
					putTP(tp);
				}
			}

			final void putTP(TermPositions tp) throws IOException {
				if (tp.next())
					put(tp);
			}

			final TermPositions peek() {
				return (TermPositions) top();
			}

			public final boolean lessThan(Object a, Object b) {
				return ((TermPositions) a).doc() < ((TermPositions) b).doc();
			}
		}

		private int _doc;

		private int _freq;

		private IntQueue _posList;

		private TermPositionsQueue _termPositionsQueue;

		private List listtermPositions;

		public MergeTermPositions(List termPositions) throws IOException {
			listtermPositions = termPositions;
			_termPositionsQueue = new TermPositionsQueue(termPositions);
			_posList = new IntQueue();
		}

		private Map filter;

		private BitSet deletedDocs;

		public void filter(Map filter) {
			this.filter = filter;
		}

		/**
		 * Be sure that the merged termpositions are pointing the the same term
		 * before to call this method
		 */
		public final boolean next() throws IOException {

			_posList.clear();
			if (_termPositionsQueue.size() == 0)
				return false;

			_doc = _termPositionsQueue.peek().doc();
			TermPositions tp;
			do {
				tp = _termPositionsQueue.peek();

				for (int i = 0; i < tp.freq(); i++)
					_posList.add(tp.nextPosition());

				if (tp.next())
					_termPositionsQueue.adjustTop();
				else {
					_termPositionsQueue.pop();
				}
			} while (_termPositionsQueue.size() > 0
					&& _termPositionsQueue.peek().doc() == _doc);
			// if no position in the doc (maybe a deleted doc) ==> next
			// } while (_posList.size() == 0);

			_posList.sort();
			_freq = _posList.size();

			return true;
		}

		public final int nextPosition() {
			return _posList.next();
		}

		public final boolean skipTo(int target) throws IOException {
			while (target > _termPositionsQueue.peek().doc()) {
				TermPositions tp = (TermPositions) _termPositionsQueue.pop();

				if (tp.skipTo(target))
					_termPositionsQueue.put(tp);
				else
					tp.close();
			}

			return next();
		}

		public final int doc() {
			return _doc;
		}

		public final int freq() {
			return _freq;
		}

		public final void close() throws IOException {
			while (_termPositionsQueue.size() > 0)
				((TermPositions) _termPositionsQueue.pop()).close();
		}

		public void seek(Term term) throws IOException {
			Iterator iter = listtermPositions.iterator();
			_termPositionsQueue.clear();
			while (iter.hasNext()) {
				TermPositions tp = (TermPositions) iter.next();
				tp.seek(term);
				_termPositionsQueue.putTP(tp);

			}
		}

		public void seek(TermEnum termEnum) throws IOException {
			Iterator iter = listtermPositions.iterator();
			_termPositionsQueue.clear();
			while (iter.hasNext()) {
				TermPositions tp = (TermPositions) iter.next();
				tp.seek(termEnum);
				_termPositionsQueue.putTP(tp);
			}
		}

		/**
		 * Not implemented.
		 * 
		 * @throws UnsupportedOperationException
		 */
		public int read(int[] arg0, int[] arg1) throws IOException {
			throw new UnsupportedOperationException();
		}

	}

	private final class MergeTermEnum extends TermEnum {

		private final class TermEnumQueue extends PriorityQueue {
			TermEnumQueue(List postingInfoslist) throws IOException {
				initialize(postingInfoslist.size());

				Iterator i = postingInfoslist.iterator();
				while (i.hasNext()) {
					PostingInfos pi = (PostingInfos) i.next();
					if (pi.te.next())
						put(pi);
				}
			}

			final PostingInfos peek() {
				return (PostingInfos) top();
			}

			public final boolean lessThan(Object a, Object b) {
				int comparison = ((PostingInfos) a).te.term().compareTo(
						((PostingInfos) b).te.term());
				return comparison < 0;
			}
		}

		private Term _term;

		private int _freq;

		private IntQueue _docsList;

		private TermEnumQueue _termEnumQueue;

		public MergeTermEnum(List PostingInfosList) throws IOException {

			_termEnumQueue = new TermEnumQueue(PostingInfosList);
			_docsList = new IntQueue();
		}

		public void close() throws IOException {
			while (_termEnumQueue.size() > 0) {
				PostingInfos pi = (PostingInfos) _termEnumQueue.pop();
				pi.te.close();
				pi.tp.close();
			}
		}

		/**
		 * no supported
		 */
		public int docFreq() {
			// throw new UnsupportedOperationException();
			return _freq;
		}

		public boolean next() throws IOException {

			_docsList.clear();
			do {

				if (_termEnumQueue.size() == 0)
					return false;

				_term = _termEnumQueue.peek().te.term();
				// System.out.println("term "+_term);
				//TermPositions tp;
				TermEnum te;
				//do {
					te = _termEnumQueue.peek().te;
					// System.out.println(" m term "+te.term());
				//	tp = _termEnumQueue.peek().tp;
				//	tp.seek(_term);

				//	while (tp.next()) {
				//		_docsList.add(tp.doc());
				//	}

					if (te.next())
						_termEnumQueue.adjustTop();
					else {
						_termEnumQueue.pop();

					}
				} while (_termEnumQueue.size() > 0
						&& _termEnumQueue.peek().te.term().equals(_term));

				// if no doc -> next
			//} while (_docsList.size() == 0);

			//_docsList.sort();
			//_freq = _docsList.size();

			return true;
		}

		public Term term() {
			return _term;
		}

	}

	List termPositionsList = new LinkedList();

	List termEnumList = new LinkedList();

	List producters = new LinkedList();

	public void addProducter(TermProducter producter) {
		producters.add(producter);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.lucene.index.TermProducter#termPositions()
	 */
	public TermPositions termPositions() throws IOException {
		termPositionsList.clear();
		for (Iterator iter = producters.iterator(); iter.hasNext();) {
			TermProducter tp = (TermProducter) iter.next();
			termPositionsList.add(tp.termPositions());
		}
		return new MergeTermPositions(termPositionsList);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.lucene.index.TermProducter#terms()
	 */
	public TermEnum terms() throws IOException {
		termEnumList.clear();
		for (Iterator iter = producters.iterator(); iter.hasNext();) {
			TermProducter tp = (TermProducter) iter.next();
			termEnumList.add(new PostingInfos(tp.terms(), tp.termPositions()));
		}
		return new MergeTermEnum(termEnumList);
	}

}
