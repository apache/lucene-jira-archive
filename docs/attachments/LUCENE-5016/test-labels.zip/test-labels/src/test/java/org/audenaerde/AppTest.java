package org.audenaerde;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.LongField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.facet.index.FacetFields;
import org.apache.lucene.facet.params.FacetSearchParams;
import org.apache.lucene.facet.sampling.RandomSampler;
import org.apache.lucene.facet.sampling.RepeatableSampler;
import org.apache.lucene.facet.sampling.SamplingAccumulator;
import org.apache.lucene.facet.sampling.SamplingParams;
import org.apache.lucene.facet.search.CountFacetRequest;
import org.apache.lucene.facet.search.FacetRequest;
import org.apache.lucene.facet.search.FacetResult;
import org.apache.lucene.facet.search.FacetResultNode;
import org.apache.lucene.facet.search.FacetsCollector;
import org.apache.lucene.facet.search.StandardFacetsAccumulator;
import org.apache.lucene.facet.taxonomy.CategoryPath;
import org.apache.lucene.facet.taxonomy.TaxonomyReader;
import org.apache.lucene.facet.taxonomy.TaxonomyWriter;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyReader;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyWriter;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Different behavior between labelling of Sampling vs Standard
     * @throws IOException 
     */
    public void testLabelling() throws IOException
    {
    	RAMDirectory index = new RAMDirectory();
    	RAMDirectory taxo  = new RAMDirectory();
    	
    	IndexWriter w = new IndexWriter(index, new IndexWriterConfig(Version.LUCENE_43, new StandardAnalyzer(Version.LUCENE_43)));
    	DirectoryTaxonomyWriter tax = new DirectoryTaxonomyWriter(taxo);
  
    	for (int i=0; i<100_000;i++)
    	{
    		addDocument(w, tax, i,0);
    	}  	
    	for (int i=0; i<1;i++)
    	{
    		addDocument(w,tax,i,1);
    	}
    	tax.commit();
    	w.commit();
    	
    	IndexReader reader = DirectoryReader.open(w, true);
		IndexSearcher searcher = new IndexSearcher(reader);
		TaxonomyReader taxoReader;
		taxoReader = new DirectoryTaxonomyReader(tax);

		final List<FacetRequest> facetRequests = new ArrayList<FacetRequest>();

		facetRequests.add( new CountFacetRequest( new CategoryPath( "A"), 10) );
		facetRequests.add( new CountFacetRequest( new CategoryPath( "B"), 10) );
	

		SamplingParams sampleParams = new SamplingParams();
		sampleParams.setMaxSampleSize( 100 );
		sampleParams.setMinSampleSize( 100 );
		sampleParams.setSamplingThreshold( 100 );
		sampleParams.setOversampleFactor( 1.0d );
		
		FacetSearchParams params = new FacetSearchParams(facetRequests);
		FacetsCollector samplingFacetsCollector = FacetsCollector.create( new SamplingAccumulator( new RepeatableSampler(sampleParams),  params, reader, taxoReader));
		FacetsCollector standardFacetsCollector = FacetsCollector.create( new StandardFacetsAccumulator(params, reader, taxoReader));
		
		searcher.search( new MatchAllDocsQuery(), samplingFacetsCollector );
		searcher.search( new MatchAllDocsQuery(), standardFacetsCollector );
		
		FacetResult standardB = standardFacetsCollector.getFacetResults().get(1);
		FacetResult samplingB = samplingFacetsCollector.getFacetResults().get(1);
		
		CategoryPath labelStandard = standardB.getFacetResultNode().label;
		CategoryPath labelSampling = samplingB.getFacetResultNode().label;
			
		TestCase.assertEquals("Same behavior?",labelStandard, labelSampling);
    }
	
	private void addDocument(IndexWriter w, TaxonomyWriter tax, int i, int j)
			throws IOException {
		FacetFields ff = new FacetFields(tax);
    	
    	final List<CategoryPath> categories = new ArrayList<CategoryPath>();
    	categories.add(new CategoryPath( "A", String.valueOf(i)));
    	
    	//note we do not add B at all! (we have no valid B in our set.)
      	Document doc = new Document();
  		ff.addFields(doc, categories);
       	w.addDocument(doc);
	}
}
