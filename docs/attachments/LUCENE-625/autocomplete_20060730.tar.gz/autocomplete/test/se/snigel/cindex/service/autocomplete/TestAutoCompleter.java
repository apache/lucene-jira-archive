package se.snigel.cindex.service.autocomplete;

import junit.framework.TestCase;

/**
 * @author karl wettin <mailto:karl.wettin@gmail.com>
 *         Date: Jul 30, 2006
 *         Time: 6:29:04 PM
 */
public class TestAutoCompleter extends TestCase {


    public void testAll() throws Exception {
        AutoCompleter autoCompleter = new AutoCompleter();

        assertEquals(autoCompleter.size(), 0);

        autoCompleter.train("heros");
        autoCompleter.train("heroes");
        autoCompleter.train("heroes");
        autoCompleter.train("heroes of might");
        autoCompleter.train("heroes of might");
        autoCompleter.train("heroes of might");
        autoCompleter.train("heroes of might and magic");
        autoCompleter.train("heroes of might and magic");
        autoCompleter.train("heroes of might and magic");
        autoCompleter.train("heroes of might and magic");
        autoCompleter.train("heroes of might and magic");
        autoCompleter.train("alfa");
        autoCompleter.train("beta");

        autoCompleter.flush();
        assertEquals(autoCompleter.size(), 6);

        assertEquals(1, autoCompleter.complete("hero", 1).length);

        assertEquals(4, autoCompleter.complete("hero", 10).length);
        assertEquals("heroes", autoCompleter.complete("hero", 10)[0]);
        assertEquals(null, autoCompleter.complete("heros", 10));
        assertEquals(1, autoCompleter.complete("alf", 10).length);
        assertEquals("alfa", autoCompleter.complete("a", 10)[0]);
        assertEquals(1, autoCompleter.complete("bet", 10).length);
        assertEquals("beta", autoCompleter.complete("be", 10)[0]);

        autoCompleter.remove("heros");
        assertEquals(5, autoCompleter.size());
        assertEquals(3, autoCompleter.complete("hero", 10).length);
        autoCompleter.optimize(10);
        assertFalse(autoCompleter.getTrie().findNode("heros") != null);

        autoCompleter.remove("heroes");
        assertEquals(4, autoCompleter.size());
        assertEquals("heroes of might", autoCompleter.complete("hero", 10)[0]);
        autoCompleter.optimize(10);
        assertFalse(autoCompleter.getTrie().findNode("heroes") == null);

        autoCompleter.train("beta");
        autoCompleter.train("beta");
        autoCompleter.train("beta");

        autoCompleter.train("heroes of night and magic");
        autoCompleter.train("heroes of knight and magic");
        autoCompleter.train("heroes of light and magic");
        autoCompleter.flush();

        autoCompleter.optimize(4);

        assertEquals(null, autoCompleter.complete("a", 10));
        assertEquals(3, autoCompleter.complete("h", 10).length);
        assertEquals(1, autoCompleter.complete("b", 10).length);


    }


}
