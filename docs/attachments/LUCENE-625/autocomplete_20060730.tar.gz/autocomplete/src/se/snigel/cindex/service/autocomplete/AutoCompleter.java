package se.snigel.cindex.service.autocomplete;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import se.snigel.util.trie.Node;
import se.snigel.util.trie.NodeVisitor;
import se.snigel.util.trie.Trie;

import java.io.Serializable;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @author karl wettin <mailto:karl.wettin@gmail.com>
 *         Date: Jul 30, 2006
 *         Time: 4:41:10 PM
 */
public class AutoCompleter implements Serializable {

    private static final long serialVersionUID = 1l;
    private static Log log = LogFactory.getLog(AutoCompleter.class);

    private Trie<TrieNodeData> trie = new Trie<TrieNodeData>();
    private Queue<TrainData> trainDataQue = new ConcurrentLinkedQueue<TrainData>();
    private int size = 0;

    public int size() {
        return size;
    }

    final Trie<TrieNodeData> getTrie() {
        return trie;
    }

    private static final Comparator<TrieNodeData> completeComparator = new Comparator<TrieNodeData>() {
        public int compare(TrieNodeData o1, TrieNodeData o2) {
            int ret = o1.getNodePath().compareTo(o2.getNodePath());
            if (ret == 0) {
                ret = new Long(o2.getActivityFrequency()).compareTo(o1.getActivityFrequency());
            }
            return ret;
        }
    };

    public final String[] complete(String input, int maxResults) {
        Node<TrieNodeData> node = trie.findNode(input);
        if (node == null || node.getData() == null || node.getData().getNodeDataRecursive() == null) {
            return null;
        }
        List<TrieNodeData> items = new ArrayList<TrieNodeData>(maxResults);
        for (int index = 0; index < maxResults && index < node.getData().getNodeDataRecursive().size(); index ++) {
            items.add(node.getData().getNodeDataRecursive().get(index));
        }
        if (items.size() == 0) {
            return null;
        }
        Collections.sort(items, completeComparator);
        String[] ret = new String[items.size()];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = items.get(i).getNodePath();
        }
        return ret;
    }

    public final void train(String text) {
        trainDataQue.add(new TrainData(text));
    }

    public final void flush() {
        Set<TrieNodeData> diryNodeData = new HashSet<TrieNodeData>(trainDataQue.size());

        while (trainDataQue.size() > 0) {
            TrainData trainData = trainDataQue.remove();

            final LinkedList<Node<TrieNodeData>> reversedNodePath = new LinkedList<Node<TrieNodeData>>();
            trie.createPath(trainData.getText(), new NodeVisitor<TrieNodeData>() {
                public void visit(CharSequence path, Node<TrieNodeData> node) {
                    reversedNodePath.addFirst(node);
                }
            });

            Node<TrieNodeData> leafNode = reversedNodePath.removeFirst();
            if (leafNode.getData() == null) {
                leafNode.setData(new TrieNodeData());
                leafNode.getData().setNodePath(trainData.getText());
                size++;
            }
            leafNode.getData().setLastTouched(trainData.getDate());
            leafNode.getData().setActivityFrequency(leafNode.getData().getActivityFrequency() + 1);

            for (Node<TrieNodeData> node : reversedNodePath) {
                if (node.getData() == null) {
                    node.setData(new TrieNodeData());
                }
                if (node.getData().getNodeDataRecursive() == null) {
                    node.getData().setNodeDataRecursive(new ArrayList<TrieNodeData>(25));
                }
                if (!node.getData().getNodeDataRecursive().contains(leafNode.getData())) {
                    node.getData().getNodeDataRecursive().add(leafNode.getData());
                }
                diryNodeData.add(node.getData());
            }

        }

        for (TrieNodeData nodeData : diryNodeData) {
            Collections.sort(nodeData.getNodeDataRecursive(), recursiveNodeDataSortComparator);
        }
    }

    private static final Comparator<TrieNodeData> recursiveNodeDataSortComparator = new Comparator<TrieNodeData>() {
        public int compare(TrieNodeData o1, TrieNodeData o2) {
            int ret = new Long(o2.getActivityFrequency()).compareTo(o1.getActivityFrequency());
            if (ret == 0) {
                ret = new Long(o2.getLastTouched()).compareTo(o1.getLastTouched());
                if (ret == 0) {
                    ret = o1.getNodePath().compareTo(o2.getNodePath());
                }
            }
            return ret;
        }
    };

    public final boolean remove(String text) {
        final LinkedList<Node<TrieNodeData>> reversedNodePath = new LinkedList<Node<TrieNodeData>>();
        trie.createPath(text, new NodeVisitor<TrieNodeData>() {
            public void visit(CharSequence path, Node<TrieNodeData> node) {
                reversedNodePath.addFirst(node);
            }
        });
        if (reversedNodePath.size() == 0) {
            return false;
        }

        Node<TrieNodeData> leafNode = reversedNodePath.removeFirst();
        if (leafNode.getData() == null || leafNode.getData().getNodePath() == null) {
            return false;
        }

        for (Node<TrieNodeData> node : reversedNodePath) {
            node.getData().getNodeDataRecursive().remove(leafNode.getData());
        }

        if (leafNode.getData().getNodeDataRecursive() == null || leafNode.getData().getNodeDataRecursive().size() == 0)
        {
            leafNode.setData(null);
        } else {
            leafNode.getData().setNodePath(null);
        }


        size--;

        return true;
    }

    private static final Comparator<TrieNodeData> optimizationSortComparator = new Comparator<TrieNodeData>() {
        public int compare(TrieNodeData o1, TrieNodeData o2) {
            int ret = new Long(o2.getActivityFrequency()).compareTo(o1.getActivityFrequency());
            if (ret == 0) {
                ret = new Long(o2.getLastTouched()).compareTo(o1.getLastTouched());
                if (ret == 0) {
                    ret = o1.getNodePath().compareTo(o2.getNodePath());
                }
            }
            return ret;
        }
    };

    public final void optimize(int maxSize) {
        if (size <= maxSize) {
            trie.optimize();
            return;
        }
        // gather all
        List<TrieNodeData> allNodeDatas = new ArrayList<TrieNodeData>(size);
        for (Node<TrieNodeData> node : trie.getRoot().getChildren()) {
            allNodeDatas.addAll(node.getData().getNodeDataRecursive());
        }
        // order by last touched
        Collections.sort(allNodeDatas, optimizationSortComparator);
        for (int index = maxSize; index < allNodeDatas.size(); index++) {
            remove(allNodeDatas.get(index).getNodePath());
        }

        trie.optimize();
    }


    private class TrainData {
        private String text;
        private long date;

        public TrainData(String text) {
            this.text = text;
            date = System.currentTimeMillis();
        }

        public String getText() {
            return text;
        }

        public long getDate() {
            return date;
        }
    }
}
