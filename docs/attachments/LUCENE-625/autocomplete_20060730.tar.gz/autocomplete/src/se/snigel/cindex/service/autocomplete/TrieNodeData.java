package se.snigel.cindex.service.autocomplete;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.Serializable;
import java.util.List;

/**
 * @author karl wettin <mailto:karl.wettin@gmail.com>
 *         Date: Jul 30, 2006
 *         Time: 4:41:36 PM
 */
public class TrieNodeData
        implements Serializable {

    private static final long serialVersionUID = 1l;
    private static Log log = LogFactory.getLog(TrieNodeData.class);

    private String nodePath;
    private long lastTouched;
    private long activityFrequency;

    private List<TrieNodeData> nodeDataRecursive;

    public final String getNodePath() {
        return nodePath;
    }

    public final void setNodePath(String nodePath) {
        this.nodePath = nodePath;
    }

    public final long getActivityFrequency() {
        return activityFrequency;
    }

    public final void setActivityFrequency(long activityFrequency) {
        this.activityFrequency = activityFrequency;
    }

    public final List<TrieNodeData> getNodeDataRecursive() {
        return nodeDataRecursive;
    }

    public final void setNodeDataRecursive(List<TrieNodeData> nodeDataRecursive) {
        this.nodeDataRecursive = nodeDataRecursive;
    }

    public final long getLastTouched() {
        return lastTouched;
    }

    public final void setLastTouched(long lastTouched) {
        this.lastTouched = lastTouched;
    }

    public String toString() {
        return getNodePath() + " [" + getActivityFrequency() + "]@" + getLastTouched();
    }

}
