package org.apache.lucene.taskBenchmark.task;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.taskBenchmark.feeds.DocMaker;


/**
 * Basic task: add a document.
 * Other side effects: none.
 */
public class AddDocTask extends PerfTask {

  private static int logStep = -1;

  // volatile data passed between setup(), doLogic(), tearDown().
  Document doc = null;
  
  /* (non-Javadoc)
   * @see taskBenchmark.task.PerfTask#setup()
   */
  public void setup() throws Exception {
    DocMaker docMaker = getRunData().getDocMaker();
    doc = docMaker.makeDocument();
  }

  /* (non-Javadoc)
   * @see taskBenchmark.task.PerfTask#tearDown()
   */
  public void tearDown() {
    DocMaker docMaker = getRunData().getDocMaker();
    log(docMaker.getCount());
    doc = null;
  }

  public int doLogic() throws Exception {
    getRunData().getIndexWriter().addDocument(doc);
    return 1;
  }

  private void log (int count) {
    if (logStep<0) {
      // avoid sync although race possible here
      logStep = getRunData().getConfig().get("doc.add.log.step",500);
    }
    if (logStep>0 && (count%logStep)==0) {
      System.out.println("--> processed "+count+" docs");
    }
  }
}
