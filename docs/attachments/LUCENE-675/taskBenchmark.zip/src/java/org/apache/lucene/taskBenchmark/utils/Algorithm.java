package org.apache.lucene.taskBenchmark.utils;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.File;
import java.io.FileReader;
import java.io.StreamTokenizer;
import java.util.ArrayList;

import org.apache.lucene.taskBenchmark.PerfRunData;
import org.apache.lucene.taskBenchmark.task.PerfTask;
import org.apache.lucene.taskBenchmark.task.RepSumByPrefTask;
import org.apache.lucene.taskBenchmark.task.TaskSequence;

/**
 * Test algorithm, as read from file
 */
public class Algorithm {
  
  private TaskSequence sequence = new TaskSequence(null,false);
  
  /**
   * Read algorithm from file
   * @param algFile file containing perf test instructions
   * @param runData perf-run-data used at running the tasks.
   * @throws Exception if errors while parsing the algorithm 
   */
  public Algorithm (File algFile, PerfRunData runData) throws Exception {
    int maxDepthLogStart = runData.getConfig().get("task.max.depth.log",0);
    TaskSequence currSequence = sequence;
    PerfTask prevTask = null;
    StreamTokenizer stok = new StreamTokenizer(new FileReader(algFile));
    stok.commentChar('#');
    stok.eolIsSignificant(false);
    stok.ordinaryChar('"');
    stok.ordinaryChar('/');
    boolean colonOk = false; 
    currSequence.setDepth(0,maxDepthLogStart);
    String taskPackage = PerfTask.class.getPackage().getName() + ".";
    
    while (stok.nextToken() != StreamTokenizer.TT_EOF) { 
      switch(stok.ttype) {
  
        case StreamTokenizer.TT_WORD:
          String s = stok.sval;
          PerfTask task = (PerfTask) Class.forName(taskPackage+s+"Task").newInstance();
          task.setRunData(runData);
          currSequence.addTask(task);
          if (task instanceof RepSumByPrefTask) {
            stok.nextToken();
            String prefix = stok.sval;
            if (prefix==null || prefix.length()==0) { 
              throw new Exception("named report prefix problem - "+stok.toString()); 
            }
            ((RepSumByPrefTask) task).setPrefix(prefix);
          }
          colonOk = false; prevTask = task;
          break;
  
        default:
          char c = (char)stok.ttype;
          
          switch(c) {
          
            case ':' :
              if (!colonOk) throw new Exception("colon unexpexted: - "+stok.toString());
              colonOk = false;
              // get repetitions number
              stok.nextToken();
              if (stok.ttype!=StreamTokenizer.TT_NUMBER) throw new Exception("expexted repetitions number: - "+stok.toString());
              ((TaskSequence)prevTask).setRepetitions((int)stok.nval); 
              // check for rate specification (ops/min)
              stok.nextToken();
              if (stok.ttype!=':') {
                stok.pushBack();
              } else {
                // get rate number
                stok.nextToken();
                if (stok.ttype!=StreamTokenizer.TT_NUMBER) throw new Exception("expexted rate number: - "+stok.toString());
                // check for unit - min or sec, sec is default
                stok.nextToken();
                if (stok.ttype!='/') {
                  stok.pushBack();
                  ((TaskSequence)prevTask).setRate((int)stok.nval,false); // set rate per sec
                } else {
                  stok.nextToken();
                  if (stok.ttype!=StreamTokenizer.TT_WORD) throw new Exception("expexted rate unit: 'min' or 'sec' - "+stok.toString());
                  String unit = stok.sval.toLowerCase();
                  if ("min".equals(unit)) {
                    ((TaskSequence)prevTask).setRate((int)stok.nval,true); // set rate per min
                  } else if ("sec".equals(unit)) {
                    ((TaskSequence)prevTask).setRate((int)stok.nval,false); // set rate per sec
                  } else {
                    throw new Exception("expexted rate unit: 'min' or 'sec' - "+stok.toString());
                  }
                }
              }
              colonOk = false;
              break;
    
            case '{' : 
            case '[' :  
              // start serial sequence
              TaskSequence seq2 = new TaskSequence(currSequence, c=='[');
              seq2.setRunData(runData);
              currSequence.addTask(seq2);
              currSequence = seq2;
              // check for sequence name
              stok.nextToken();
              if (stok.ttype!='"') {
                stok.pushBack();
              } else {
                stok.nextToken();
                String name = stok.sval;
                seq2.setName(name);
                stok.nextToken();
                if (stok.ttype!='"' || name==null || name.length()==0) { 
                  throw new Exception("sequence name problem - "+stok.toString()); 
                }
              }
              colonOk = false;
              break;
    
            case '>' :
              currSequence.setNoChildReport();
            case '}' : 
            case ']' : 
              // end sequence
              colonOk = true; prevTask = currSequence;
              currSequence = currSequence.getParent();
              break;
          
          } //switch(c)
          break;
          
      } //switch(stok.ttype)
      
    }
    
    if (sequence != currSequence) {
      throw new Exception("Unmatched sequences");
    }
    
    // remove redundant top level enclosing sequences
    while (sequence.getRepetitions()==1 && sequence.getRate()==0) {
      ArrayList t = sequence.getTasks();
      if (t!=null && t.size()==1) {
        PerfTask p = (PerfTask) t.get(0);
        if (p instanceof TaskSequence) {
          sequence = (TaskSequence) p;
          continue;
        }
      }
      break;
    }
  }

  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  public String toString() {
    String newline = System.getProperty("line.separator");
    StringBuffer sb = new StringBuffer();
    sb.append(sequence.toString());
    sb.append(newline);
    return sb.toString();
  }

  /**
   * Execute this algorithm
   * @throws Exception 
   */
  public void execute() throws Exception {
    sequence.doLogic();
  }
  
  
}

