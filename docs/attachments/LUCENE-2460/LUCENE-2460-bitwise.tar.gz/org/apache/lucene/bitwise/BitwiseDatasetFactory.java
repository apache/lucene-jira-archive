
package org.apache.lucene.bitwise;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.FieldCache;

/**
 * BitwiseDatasetFactory
 * 
 * Helper class used to prepare the integer values array retrieved from the Lucene index
 * 
 * The retrieved integer values are stored in a {@link BitwiseDataset} object and returned
 * 
 * @author Israel Ekpo <iekpo@php.net>
 * @version $Id: BitwiseDatasetFactory.java 54 2010-05-14 01:40:52Z iekpo $
 */
public class BitwiseDatasetFactory {

	/**
	 * The name of the integer field we are running the bitwise operation on
	 */
	private final String bitwiseFieldName;
	
	/**
	 * Constructor for BitwiseDatasetFactory
	 * 
	 * @param bitwiseFieldName The name of the integer field in the Lucene index
	 */
	public BitwiseDatasetFactory(String bitwiseFieldName)
	{
		this.bitwiseFieldName = bitwiseFieldName;
	}
	
	/**
	 * Retrieves all the integer values for the target field from the index segment
	 * 
	 * @param indexReader
	 * @return Returns a BitwiseDataset result containing an array of all the values
	 * @throws IOException
	 */
	public BitwiseDataset buildDataSet(IndexReader indexReader) throws IOException
	{
		return new BitwiseDataset(FieldCache.DEFAULT.getInts(indexReader, bitwiseFieldName, FieldCache.NUMERIC_UTILS_INT_PARSER));
	}
}
