
package org.apache.lucene.bitwise;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.util.BitSet;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.DocIdSet;
import org.apache.lucene.search.DocIdSetIterator;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryWrapperFilter;
import org.apache.lucene.util.DocIdBitSet;

/**
 * BitwiseFilter
 * 
 * Used to filter documents returned based on the results of a bitwise operation
 * on a Lucene document field and a specific source value
 * 
 * @see BitwiseOperation
 * @see BitwiseOperation.BITWISE_AND
 * @see BitwiseOperation.BITWISE_OR
 * @see BitwiseOperation.BITWISE_XOR
 * 
 * @author Israel Ekpo <iekpo@php.net>
 * @since Lucene 3.1
 * @version $Id: BitwiseFilter.java 54 2010-05-14 01:40:52Z iekpo $
 */
public class BitwiseFilter extends Filter {

	/**
	 * Universal version identifier for a Serializable class
	 * Deserialization uses this number to ensure that a loaded class 
	 * corresponds exactly to a serialized object
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * The pre constructed org.apache.lucene.search.Query
	 */
	private Query query;
	
	/**
	 * The internal helper filter
	 */
	private BitwiseFilterResult resultFilter;
	
	/**
	 * Class Constructor
	 * 
	 * @see BitwiseOperation
	 * @see BitwiseOperation.BITWISE_AND
	 * @see BitwiseOperation.BITWISE_OR
	 * @see BitwiseOperation.BITWISE_XOR
	 * 
	 * One of BitwiseOperation.BITWISE_AND, BitwiseOperation.BITWISE_OR, or BitwiseOperation.BITWISE_XOR is used
	 * for the operation parameter.
	 * 
	 * @param fieldName Name of the integer field containing the bit values
	 * @param operation The {@link BitwiseOperation} between the sourceValue and the targetValue in the fields
	 * @param sourceValue The source value specified in this filter and used in the bitwise operations
	 * @param negate Whether to negate the result of the operation
	 * @param query A pre constructed org.apache.lucene.search.Query
	 */
	public BitwiseFilter(String fieldName, BitwiseOperation operation, int sourceValue, boolean negate, Query query)
	{		
		this.query = query;
		
		this.resultFilter = new BitwiseFilterResult(fieldName, operation, sourceValue, negate, new BitwiseDatasetFactory(fieldName));
	}
	
	@Override
	public DocIdSet getDocIdSet(IndexReader reader) throws IOException {
		
		/* Constrains search results to only match those which also match a provided by preConstructedQuery */
		QueryWrapperFilter filter = new QueryWrapperFilter(query);
		
		DocIdSet docIdSet = filter.getDocIdSet(reader);
		
		/* Used to prepare the BitSet */
		BitSet bitSet = new BitSet();
		
		int docId = 0;
		
		/* Preparing the Original bitSet */
        for (DocIdSetIterator iterator = docIdSet.iterator(); (docId = iterator.nextDoc()) != DocIdSetIterator.NO_MORE_DOCS;) {
            bitSet.set(docId);
        }
        
        /* Called once for each segment in the index */
        DocIdBitSet docIdBitSet = new DocIdBitSet(resultFilter.getBitSet(reader, bitSet));
		
		return docIdBitSet;
	}
	
	/**
	 * Returns the internal helper filter
	 * 
	 * @return The internal helper used to perform the filtering
	 */
	public BitwiseFilterResult getResultFilter()
	{
		return resultFilter;
	}
}
