
package org.apache.lucene.bitwise;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.index.IndexReader;

/**
 * BitwiseFilterResult
 * 
 * Helper class used by {@link BitwiseFilter} to filter documents returned from a Query
 * 
 * @author Israel Ekpo <iekpo@php.net>
 * @version $Id: BitwiseFilterResult.java 54 2010-05-14 01:40:52Z iekpo $
 */
public class BitwiseFilterResult {

	private BitwiseOperation bitwiseOperation;
	
	private BitwiseDatasetFactory datasetFactory;
	
	private final Map<Integer, Boolean> resultById = new HashMap<Integer, Boolean>();
	
	private int sourceValue;
	
	private boolean negate;
	
	private int nextOffset = 0;
	
	/**
	 * Constructor for BitwiseResultFilter
	 * 
	 * @param fieldName The name of the Integer field in the Lucene Document
	 * @param operation The bitwise operation object
	 * @param sourceValue The source value used in the operation
	 * @param negate Whether or not to negate the result of each operation
	 * @param datasetFactory The dataset factory used in retrieving the values from each segment
	 */
	public BitwiseFilterResult(String fieldName, BitwiseOperation operation, int sourceValue, boolean negate, BitwiseDatasetFactory datasetFactory)
	{
		this.bitwiseOperation = operation;
		
		this.datasetFactory   = datasetFactory;
		
		this.sourceValue  = sourceValue;
		
		this.negate = negate;
	}
	
	/**
	 * Returns the Bitset for documents that pass the check
	 * 
	 * Gets called once for each segment in the Index
	 * 
	 * @param reader The IndexReader for a specific segment
	 * @param bits The original bits from the pre constructed Query
	 * @return The filtered BitSet
	 * @throws IOException
	 */
	public BitSet getBitSet(final IndexReader reader, final BitSet bits) throws IOException
	{
		BitSet bitSet = new BitSet(bits.cardinality());
		
		final BitwiseDataset dataSet = datasetFactory.buildDataSet(reader);
		
		final int start = 0;
		
		int docId = bits.nextSetBit(start);
		
		while (docId != -1) {
			
            if (reader.isDeleted(docId)) {
            	
                docId = bits.nextSetBit(docId + 1);
                
                continue;
            }
            
            int targetValue = dataSet.getBitValue(docId);
            
            boolean operationResult = bitwiseOperation.doOperation(sourceValue, targetValue, negate);
            
            if (operationResult) {
            	
                bitSet.set(docId); 
                
                resultById.put(docId + nextOffset, operationResult);                
            }

            docId = bits.nextSetBit(docId + 1);
        }
		
		// index reader may be from different/new segment
		nextOffset += reader.maxDoc();
	
		return bitSet;
	}
	
	/**
	 * Returns the result for a specific Document Id
	 * 
	 * @param docId
	 * @return A boolean value for the operation
	 */
	public Boolean getResult(int docId)
	{
		Boolean result = resultById.get(docId);
		
		if (null != result)
		{
			return result;
		}
		
		return null;
	}
	
	/**
	 * Returns all the results computed in all the segments
	 * 
	 * @return A map of all the document ids and their results
	 */
	public Map<Integer, Boolean> getResults()
	{
		return resultById;
	}
	
	/**
	 * Returns the operation used in the computation
	 * 
	 * @see  BitwiseOperation
	 * 
	 * @return The BitwiseOperation object
	 */
	public BitwiseOperation getOperation()
	{
		return bitwiseOperation;
	}
}
