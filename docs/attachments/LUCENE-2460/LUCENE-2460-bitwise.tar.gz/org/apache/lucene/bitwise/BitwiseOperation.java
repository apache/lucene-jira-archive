
package org.apache.lucene.bitwise;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * BitwiseOperation
 * 
 * Template for bitwise operation computers.
 * 
 * 
 * @author Israel Ekpo <iekpo@php.net>
 * @since Lucene 3.1
 */
public interface BitwiseOperation {
	
	/**
	 * A bitwise AND operation
	 */
	public static final String OPERATION_TYPE_AND = "AND";
	
	/**
	 * A bitwise OR operation
	 * 
	 */
	public static final String OPERATION_TYPE_OR  = "OR";
	
	/**
	 * A bitwise exclusive OR operation 
	 */
	public static final String OPERATION_TYPE_XOR = "XOR";
	
	/**
	 * Performs the bitwise operation and returns a boolean value
	 * 
	 * {@link BitwiseOperation.BITWISE_AND} has one the performs a bitwise AND operation
	 * {@link BitwiseOperation.BITWISE_XOR} has one the performs a bitwise exclusive OR operation
	 * {@link BitwiseOperation.BITWISE_OR}  has one the performs a bitwise inclusive OR operation
	 * 
	 * @param sourceValue The source value
	 * @param targetValue The target value
	 * @param negate Whether or not to perform a negation
	 * @return Returns true if the result of the operation is greater than 0 and false otherwise
	 */
	public boolean doOperation(int sourceValue, int targetValue, boolean negate);
	
	/**
	 * Retrieves the name of the operation object
	 * 
	 * @return Returns the name of the operation
	 */
	public String getOperationName();
	
	/**
	 * Performs a bitwise AND operation
	 * 
	 * @see BitwiseOperation
	 */
	public static final BitwiseOperation BITWISE_AND = new BitwiseOperation() {
		
		/**
         * {@inheritDoc}
         */
		public boolean doOperation(int sourceValue, int targetValue, boolean negate)
		{
			int bitwiseOperationValue = (sourceValue & targetValue);
			
			if (!negate)
			{
				return (bitwiseOperationValue > 0);
			}
			
			return (bitwiseOperationValue == 0);
		}
		
		/**
         * {@inheritDoc}
         */
		public String getOperationName()
		{
			return OPERATION_TYPE_AND;
		}
	};
	
	/**
	 * Performs a bitwise OR operation
	 * 
	 * @see BitwiseOperation
	 */
	public static final BitwiseOperation BITWISE_OR = new BitwiseOperation() {
		
		/**
         * {@inheritDoc}
         */
		public boolean doOperation(int sourceValue, int targetValue, boolean negate)
		{
			int bitwiseOperationValue = (sourceValue | targetValue);
			
			if (!negate)
			{
				return (bitwiseOperationValue > 0);
			}
			
			return (bitwiseOperationValue == 0);
		}
		
		/**
         * {@inheritDoc}
         */
		public String getOperationName()
		{
			return OPERATION_TYPE_OR;
		}
	};
	
	/**
	 * Performs a bitwise exclusive OR operation
	 * 
	 * @see BitwiseOperation
	 */
	public static final BitwiseOperation BITWISE_XOR = new BitwiseOperation() {
		
		/**
         * {@inheritDoc}
         */
		public boolean doOperation(int sourceValue, int targetValue, boolean negate)
		{
			int bitwiseOperationValue = (sourceValue ^ targetValue);
			
			if (!negate)
			{
				return (bitwiseOperationValue > 0);
			}
			
			return (bitwiseOperationValue == 0);
		}
		
		/**
         * {@inheritDoc}
         */
		public String getOperationName()
		{
			return OPERATION_TYPE_XOR;
		}
	};
}
