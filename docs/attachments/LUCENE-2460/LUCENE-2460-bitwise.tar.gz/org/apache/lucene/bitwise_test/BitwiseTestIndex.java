package org.apache.lucene.bitwise_test;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import static org.apache.lucene.bitwise_test.IndexConfig.*;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.NumericField;
import org.apache.lucene.index.CorruptIndexException;

/**
 * BitwiseTestIndex class
 * 
 * Used for adding documents to the index used in this test
 * 
 * @author Israel Ekpo <iekpo@php.net>
 */
public class BitwiseTestIndex extends BitwiseTestBase {

	public BitwiseTestIndex()
	{
		
	}
	
	public void index(Document doc) throws CorruptIndexException, IOException
	{		
		iwriter.addDocument(doc);
	}
	
	public void close() throws CorruptIndexException, IOException
	{
		iwriter.close();
	    
		shutdown();
	}
	
	public static void main(String[] args) throws Exception 
	{		
		BitwiseTestIndex obj = new BitwiseTestIndex();
		
		obj.setupIndex();
		
		FileInputStream fstream = new FileInputStream(DATA_SOURCE);
	    
		// Get the object of DataInputStream
	    DataInputStream in = new DataInputStream(fstream);
	    
	    BufferedReader br = new BufferedReader(new InputStreamReader(in));
	    
	    String strLine = new String("");
	    
	    int numIndexed = 0;
	    
	    //Read DATA File Line By Line
	    while ((strLine = br.readLine()) != null)   {
	      
	    	String[] data = strLine.split(" ");
	    	
	    	Document doc = new Document();
			
			String firstname   = new String(data[0]);
			
			String lastname    = new String(data[1]);
			
			int active  = Integer.parseInt(new String(data[2]));
			
			int permissions  = Integer.parseInt(new String(data[3]));
		
			String country    = new String(data[4]);
			
			System.out.println(FIRST_NAME_KEY + " : " + firstname);
			System.out.println(LAST_NAME_KEY + " : " + lastname);
			
			System.out.println(ACTIVE_KEY + " : " + active);
			System.out.println(USER_PERMS_KEY + " : " + permissions);
			System.out.println(COUNTRY_KEY + " : " + country);

			
			doc.add(new Field(FIRST_NAME_KEY, firstname, Field.Store.YES, Field.Index.ANALYZED));
			doc.add(new Field(LAST_NAME_KEY, lastname, Field.Store.YES, Field.Index.ANALYZED));
			doc.add(new Field(COUNTRY_KEY, country, Field.Store.YES, Field.Index.ANALYZED));
			
			doc.add(new NumericField(ACTIVE_KEY, Field.Store.YES, true).setIntValue(active));
			doc.add(new NumericField(USER_PERMS_KEY, Field.Store.YES, true).setIntValue(permissions));
			
			obj.index(doc);	  
			
			System.out.println(".....................................................");
			
			numIndexed++;
	    }
	    
	    System.out.println("A total of " + numIndexed + " documents were indexed\n");
	    
	    obj.close();
	}
}
