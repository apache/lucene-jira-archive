#!/bin/bash

# $Id: create_jar.sh 51 2010-05-13 20:46:58Z iekpo $

JAVA_CLASSES_OUTPUT_FOLDERS="/home/iekpo/Desktop/bitwise_tmp_classes"

JAVA_PATH_TO_SOURCE_CODE="/home/iekpo/java_workspace/bitwise_plugin/src"

JAVA_BITWISE_PLUGIN_JARFILE_NAME="bitwise_filter_plugin.jar"

compile_source_code()
{
    # Folder for source code documentation
    JAVADOC_FOLDER="$JAVA_CLASSES_OUTPUT_FOLDERS/documentation"
    
    # Remove if exists
    rm -fvR $JAVADOC_FOLDER
    
    mkdir -p $JAVADOC_FOLDER
    
    # This directory must exist for the javac compiler to use. CREATE IF NOT EXISTS
    mkdir -p $JAVA_CLASSES_OUTPUT_FOLDERS
    
    echo "Compiling files in $JAVA_PATH_TO_SOURCE_CODE to $JAVA_CLASSES_OUTPUT_FOLDERS";
    javac $JAVA_PATH_TO_SOURCE_CODE/org/apache/lucene/bitwise/*.java  -d $JAVA_CLASSES_OUTPUT_FOLDERS
    
    javac -sourcepath $JAVA_PATH_TO_SOURCE_CODE $JAVA_PATH_TO_SOURCE_CODE/org/apache/solr/bitwise/*.java -d $JAVA_CLASSES_OUTPUT_FOLDERS
    
    #javadoc -d $JAVADOC_FOLDER -sourcepath $JAVA_PATH_TO_SOURCE_CODE org.apache.lucene.bitwise org.apache.solr.bitwise
}

generate_jar_file()
{
    TARGET_CLASS_FILES_FOLDER="$JAVA_CLASSES_OUTPUT_FOLDERS"
    
    cd $TARGET_CLASS_FILES_FOLDER
    
    jar -cvf $JAVA_BITWISE_PLUGIN_JARFILE_NAME org
}

compile_source_code

generate_jar_file