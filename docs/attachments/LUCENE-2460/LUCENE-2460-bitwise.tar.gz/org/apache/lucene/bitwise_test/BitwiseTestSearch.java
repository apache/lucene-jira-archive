package org.apache.lucene.bitwise_test;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import static org.apache.lucene.bitwise_test.IndexConfig.*;

import java.io.IOException;

import org.apache.lucene.bitwise.BitwiseFilter;
import org.apache.lucene.bitwise.BitwiseFilterResult;
import org.apache.lucene.bitwise.BitwiseOperation;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.FilteredQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;


/**
 * BitwiseTestSearch class
 * 
 * Used for illustrating how to use the BitwiseFilter filter
 * 
 * @author Israel Ekpo <iekpo@php.net>
 */
public class BitwiseTestSearch extends BitwiseTestBase {

	public BitwiseTestSearch()
	{
		
	}
	
	public void search() throws IOException, ParseException
	{
		setupSearch();
		
		// term
		Term t = new Term(COUNTRY_KEY, "us");
		
		// term query
		Query q = new TermQuery(t);
		
		// maximum number of documents to display
		int limit = 1000;
		
		int sourceValue = 0 ;
		
		boolean negate = false;
		
		BitwiseFilter bitwiseFilter = new BitwiseFilter(USER_PERMS_KEY, BitwiseOperation.BITWISE_XOR, sourceValue, negate, q);
		
		Query fq = new FilteredQuery(q, bitwiseFilter);
		
		ScoreDoc[] hits = isearcher.search(fq, null, limit).scoreDocs;
		
		BitwiseFilterResult resultFilter = bitwiseFilter.getResultFilter();
		
		for (int i = 0; i < hits.length; i++) {
			
			Document hitDoc = isearcher.doc(hits[i].doc);
			
			System.out.println(FIRST_NAME_KEY + " field has a value of " + hitDoc.get(FIRST_NAME_KEY));
			System.out.println(LAST_NAME_KEY + " field has a value of " + hitDoc.get(LAST_NAME_KEY));
			System.out.println(ACTIVE_KEY + " field has a value of " + hitDoc.get(ACTIVE_KEY));
			
			System.out.println(USER_PERMS_KEY + " field has a value of " + hitDoc.get(USER_PERMS_KEY));

			System.out.println("doc ID --> " + hits[i].doc);			
			
			System.out.println("...............................................................");
		}
		
		System.out.println("sourceValue = " + sourceValue + ",operation = " + resultFilter.getOperation().getOperationName() + ", negate = " + negate);
		
		System.out.println("A total of " + hits.length + " documents were found from the search\n");
		
		shutdown();
	}
	
	public static void main(String args[]) throws IOException, ParseException
	{
		BitwiseTestSearch search = new BitwiseTestSearch();
		
		search.search();
	}
}
