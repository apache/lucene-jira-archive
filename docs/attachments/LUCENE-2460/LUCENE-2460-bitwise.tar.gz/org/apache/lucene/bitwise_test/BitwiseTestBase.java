
package org.apache.lucene.bitwise_test;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import static org.apache.lucene.bitwise_test.IndexConfig.*;

import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.IndexDeletionPolicy;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.KeepOnlyLastCommitDeletionPolicy;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

/**
 * BitwiseTestBase class
 * 
 * Used by the indexing and searching classes to set up the index
 * 
 * @author Israel Ekpo <iekpo@php.net>
 * @version $Id: BitwiseTestBase.java 52 2010-05-13 21:00:33Z iekpo $
 */
abstract public class BitwiseTestBase {

	public BitwiseTestBase()
	{
	}
	
	public void setUp() throws IOException
	{
		directoryPath = INDEX_PATH;
		
		File file = new File(directoryPath);
		
		directory = FSDirectory.open(file);
		
		analyzer = new StandardAnalyzer(Version.LUCENE_CURRENT);
	}
	
	public void shutdown() throws IOException
	{
		directory.close();
	}
	
	public void setupIndex() throws IOException
	{
		setUp();
		
		if (!recreateIndex)
		{
			IndexDeletionPolicy deletionPolicy = new KeepOnlyLastCommitDeletionPolicy();
			
			iwriter = new IndexWriter(directory, analyzer, deletionPolicy, new IndexWriter.MaxFieldLength(25000));
			
		} else {			
			
			iwriter = new IndexWriter(directory, analyzer, true, new IndexWriter.MaxFieldLength(25000));
		}
	}
	
	public void setupSearch() throws IOException
	{
		// Setting up the base
		setUp();
		
		isearcher = new IndexSearcher(directory, true); // read-only=true
	}
	
	protected Directory directory;
	protected String directoryPath;
	protected Analyzer analyzer;
	protected IndexWriter iwriter;
	protected IndexSearcher isearcher;
}
