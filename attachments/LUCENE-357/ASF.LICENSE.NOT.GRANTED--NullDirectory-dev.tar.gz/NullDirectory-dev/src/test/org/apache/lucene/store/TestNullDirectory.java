package org.apache.lucene.store;

import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
//import java.io.PrintStream;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import junit.textui.TestRunner;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;

/**
 * Test NullDirectory against different kinds of directories.
 *
 * @author Ravi(ndra) Rao
 */
public class TestNullDirectory extends TestCase
{
  private final static String indexDir = "./build/test/index";

  public static void main(String[] args)
  {
    TestRunner.run(suite());
  }

  public static TestSuite suite()
  {
    TestSuite suite = new TestSuite(TestNullDirectory.class);
    return suite;
  }

  public void setUp()
  {
  }

  public void tearDown()
  {
  }

  // Test merging two instances of NullDirectory.
  public void testNullNull()
  {
    merge(new NullDirectory(), "testNullNull()", true);
  }

  // Test merging good RAM directory to NullDirectory.
  public void testNullGoodRam() throws IOException
  {
    merge(ramDir(), "testNullGoodRam()", true);
  }

  // Test merging bad RAMDirectory with NullDirecotory.
  public void testNullBadRam() throws IOException
  {
    merge(corrupt(ramDir()), "testNullBadRam()", false);
  }

  // Test merging good FSDirectory with NullDirectory.
  public void testNullGoodFs() throws IOException
  {
    merge(fsDir(), "testNullGoodFs()", true);
  }

  // Test merging bad FSDirectory with NullDirectory.
  public void testNullBadFs() throws IOException
  {
    merge(corrupt(fsDir()), "testNullBadFs()", false);
  }

  private void merge(Directory d, String testName, boolean failOnError)
  {
    try
      {
        IndexWriter w = new IndexWriter(new NullDirectory(), new WhitespaceAnalyzer(), true);
        //        w.infoStream = new PrintStream(System.out);
        w.addIndexes(new Directory[] {d});
        w.close();
      }
    catch(Throwable t)
      {
        if (failOnError)
          fail(testName);
        else
          assertTrue(true);
      }
  }

  private Directory corrupt(Directory d) throws IOException
  {
    InputStream is = d.openFile("_1.cfs");
    long len = is.length();

    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    for (long i = 0; i < len; i++)
      baos.write(is.readByte());

    is.close();

    OutputStream os = d.createFile("_1.cfs");

    byte[] bytes = baos.toByteArray();
    for (int i = 0; i < bytes.length; i++)
      {
        if (i == bytes.length/2)
          os.writeByte((byte) 123);
        os.writeByte(bytes[i]);
      }
    os.close();

    return d;
  }

  private Directory ramDir() throws IOException
  {
    return makeIndex(new RAMDirectory());
  }

  private Directory fsDir() throws IOException
  {
    return makeIndex(FSDirectory.getDirectory(indexDir, true));
  }

  public Directory makeIndex(Directory d) throws IOException
  {
    Document doc = new Document();
    doc.add(Field.Text("content", "Hello world!"));

    IndexWriter w = new IndexWriter(d, new WhitespaceAnalyzer(), true);
    w.addDocument(doc);
    w.optimize();
    w.close();

//     String[] files = d.list();
//     System.out.println("--- " + d.toString() + " ---");        
//     for (int i = 0; i < files.length; i++)
//       System.out.println("file: " + files[i]);

    return d;
  }
}
