package org.apache.lucene.store;

import java.io.IOException;

import org.apache.lucene.store.InputStream;

/**
 * A NullInputStream must pretend to recognize a few files and have
 * the correct set of headers for those file.  See the section on file
 * formats on the Lucene web site.
 *
 * See {@link NullDirectory}, {@link NullOutputStream}.
 *
 * @author Ravindra Rao
 */
public class NullInputStream extends InputStream
{
  String file;

  private final static byte[] nullSegmentBytes;
  private final static byte[] nullTisBytes;
  private final static byte[] nullTiiBytes;

  static
  {
    nullSegmentBytes = new byte[12];

    nullSegmentBytes[3] = (byte) -1;
    nullSegmentBytes[2] = (byte) (-1 >> 8);
    nullSegmentBytes[1] = (byte) (-1 >> 16);
    nullSegmentBytes[0] = (byte) (-1 >> 24);

    nullSegmentBytes[4] = (byte) 0;
    nullSegmentBytes[5] = (byte) 0;
    nullSegmentBytes[6] = (byte) 0;
    nullSegmentBytes[7] = (byte) 0;
    nullSegmentBytes[8] = (byte) 0;
    nullSegmentBytes[9] = (byte) 0;
    nullSegmentBytes[10] = (byte) 0;
    nullSegmentBytes[11] = (byte) 1;

    nullTisBytes = new byte[4];
    nullTisBytes[3] = (byte) -2;
    nullTisBytes[2] = (byte) (-2 >> 8);
    nullTisBytes[1] = (byte) (-2 >> 16);
    nullTisBytes[0] = (byte) (-2 >> 24);

    nullTiiBytes = new byte[4];
    nullTiiBytes[3] = nullTiiBytes[2] = nullTiiBytes[1]
      = nullTiiBytes[0] = (byte) 0;
  }

  public NullInputStream(String name)
  {
    file = name;
    if ("segments".equals(file))
      length = 20;
    else if (file.endsWith(".fnm"))
      length = 1;
    else if (file.endsWith(".tis"))
      length = 20;
    else if (file.endsWith(".tii"))
      length = 4;
    else
      length = 0;
  }

  protected void readInternal(byte[] b, int offset, int length)
    throws IOException
  {
    for (int i = offset; i < length; i++)
      b[i] = (byte) 0;

    if ("segments".equals(file))
      readInternalNullSegment(b);
    else if (file.endsWith(".tis"))
      readInternalNullTis(b);
    else if (file.endsWith(".tii"))
      readInternalNullTii(b);
  }

  private void readInternalNullTii(byte[] b)
  {
    System.arraycopy(nullTiiBytes, 0, b, 0, 4);
  }

  private void readInternalNullTis(byte[] b)
  {
    System.arraycopy(nullTisBytes, 0, b, 0, 4);
  }

  private void readInternalNullSegment(byte[] b)
  {
    System.arraycopy(nullSegmentBytes, 0, b, 0, 12);
  }

  public void close() throws IOException
  {
  }

  protected void seekInternal(long pos) throws IOException
  {
  }

  public Object clone()
  {
    return (NullInputStream) super.clone();
  }
}
