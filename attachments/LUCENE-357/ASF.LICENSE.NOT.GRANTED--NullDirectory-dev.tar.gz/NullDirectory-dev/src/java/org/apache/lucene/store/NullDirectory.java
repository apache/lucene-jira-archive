package org.apache.lucene.store;

import java.io.IOException;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.Lock;
import org.apache.lucene.store.InputStream;
import org.apache.lucene.store.OutputStream;

/**
 * An instance of NullDirectory cannot itself be used as an index
 * because its input and output streams don't do anything useful.
 * However one can merge another index with this one thereby causing a
 * read of the other index.  If the other index has been corrupted, the
 * read will fail.
 *
 * This idea was proposed by Doug Cutting in the Lucene user's mailing
 * list.
 *
 * See {@link NullInputStream}, {@link NullOutputStream}.
 *
 * @author Ravindra Rao
 */
public class NullDirectory extends Directory 
{
  /** A NullDirectory has only one file. */
  public String[] list() throws IOException
  {
    return new String[] {"segments"};
  }

  /** Returns true iff a file with the given name exists. */
  public boolean fileExists(String name) throws IOException
  {
    return "segments".equals(name) || name.endsWith(".cfs");
  }

  /** Returns the time the named file was last modified. */
  public long fileModified(String name) throws IOException
  {
    return System.currentTimeMillis();
  }

  /** Set the modified time of an existing file to now. */
  public void touchFile(String name) throws IOException
  {
    return;
  }

  /** In a NullDirectory there is nothing to remove. */
  public void deleteFile(String name) throws IOException
  {
    return;
  }

  /** In a NullDirectory there is nothing to rename */
  public void renameFile(String from, String to) throws IOException
  {
    return;
  }

  /** Returns the length of a file in the directory. */
  public long fileLength(String name) throws IOException
  {
    return 0L;
  }

  /** Creates a new, empty file in the directory with the given name.
      Returns a stream writing this file. */
  public OutputStream createFile(String name) throws IOException
  {
    return new NullOutputStream(name);
  }

  /**
   * Even though a NullDirectory has no index behind it, a
   * NullInputStream is required because the operation of merge will
   * try to optimize the index (ie NullDirectory).  That merge will
   * require input streams which must be well behaved.  See
   * NullInputStream.
   */
  public InputStream openFile(String name) throws IOException
  {
    return new NullInputStream(name);
  }

  /** Construct a {@link Lock}.
   * @param name the name of the lock file
   */
  public Lock makeLock(String name)
  {
    return new Lock()
      {
        public boolean obtain() throws IOException
        {
          return true;
        }

        public void release()
        {
        }

        public boolean isLocked()
        {
          return false;
        }
      };
  }

  /** Closes the store. */
  public void close() throws IOException
  {
    return;
  }
}
