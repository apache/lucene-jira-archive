package org.apache.lucene.store;

import java.io.IOException;

import org.apache.lucene.store.OutputStream;

/**
 * An output stream that does nothing.  Useful for validating indexes.
 *
 * See {@link NullDirectory}, {@link NullInputStream}.
 *
 * @author Ravindra Rao
 */
public class NullOutputStream extends OutputStream 
{
  private String file;

  public NullOutputStream(String name)
  {
    this.file = name;
  }

  protected void flushBuffer(byte[] b, int len) throws IOException
  {
    return;
  }

  public void seek(long pos) throws IOException
  {
    return;
  }

  public long length() throws IOException
  {
    return 0L;
  }
}
