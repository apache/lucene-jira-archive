package org.apache.lucene.store;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2001 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Lucene" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Lucene", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */ 

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.zip.Adler32;
import java.util.zip.CheckedInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import org.apache.lucene.store.RAMFile; // it`s based on the RAMDirectory
import org.apache.lucene.store.RAMInputStream;
import org.apache.lucene.store.RAMOutputStream;

/**
 * Read-only implementation of Directory as ZIP file via URL connection.
 * Please note the constructor downloads and uncompresses all index to 
 * memory. This straight method is very useful for applets that have
 * restricted privilegies.
 * 
 * This implementation is based on the RAMDirectory. It uses it`s RAM
 * scheme for storing files.
 * 
 * @see org.apache.lucene.store.Directory
 * @see org.apache.lucene.store.RAMDirectory
 * @author Lukas Zapletal [lzap@seznam.cz]
 */

public class URLDirectory extends Directory {
    Hashtable files = new Hashtable();

    /** 
	 * Opens new directory from specified URL, downloads <b>ALL</b>
	 * contents of the ZIP file and decopresses it in the memory.
     *
     * @param url URL of the file (must be HTTP protocol)
     */
    public URLDirectory(URL url) throws IOException {
        ZipEntry ze;
        int x;

        URLConnection con = url.openConnection();
        con.connect();

        ZipInputStream zis = new ZipInputStream(new CheckedInputStream(con.getInputStream(), new Adler32()));
        BufferedInputStream bis = new BufferedInputStream(zis);

        // load all ZIP entries
        while((ze = zis.getNextEntry()) != null) {
            String name = ze.toString();

            // create RAM file
            OutputStream ros = createFile(name);

            // and copy the contents (using buffered input stream)
            while((x = bis.read()) != -1)
                ros.writeByte((byte) x);

            ros.close();
        }

        zis.close();
    }

    /** Returns an array of strings, one for each file in the directory. */
    public final String[] list() {
        String[] result = new String[files.size()];
        int i = 0;
        Enumeration names = files.keys();
        while (names.hasMoreElements())
            result[i++] = (String)names.nextElement();
        return result;
    }

    /** Returns true iff the named file exists in this directory. */
    public final boolean fileExists(String name) {
        RAMFile file = (RAMFile)files.get(name);
        return file != null;
    }

    /** Returns the time the named file was last modified. */
    public final long fileModified(String name) throws IOException {
        RAMFile file = (RAMFile)files.get(name);
        return file.lastModified;
    }

    /** Set the modified time of an existing file to now. */
    public void touchFile(String name) throws IOException {
      RAMFile file = (RAMFile)files.get(name);
      file.lastModified = System.currentTimeMillis();
    }
    
     /** Returns the length in bytes of a file in the directory. */
    public final long fileLength(String name) {
        RAMFile file = (RAMFile)files.get(name);
        return file.length;
    }

    /** Removes an existing file in the directory. Note this method DO NOT modify ZIP archive. */
    public final void deleteFile(String name) {
        files.remove(name);
    }

    /** Removes an existing file in the directory. Note this method DO NOT modify ZIP archive. */
    public final void renameFile(String from, String to) {
        RAMFile file = (RAMFile)files.get(from);
        files.remove(from);
        files.put(to, file);
    }

    /** 
	 * Creates a new, empty file in the directory with the given name.
	 * 
	 * Please note this method changes only the memory state.
	 * It doesn`t modify the ZIP archive. 
	 * @return a stream writing this file
	 */
    public final OutputStream createFile(String name) {
        RAMFile file = new RAMFile();
        files.put(name, file);
        return new RAMOutputStream(file);
    }

    /** Returns a stream reading an existing file */
    public final InputStream openFile(String name) {
        RAMFile file = (RAMFile)files.get(name);
        return new RAMInputStream(file);
    }

    /** 
	 * Construct a dummy {@link Lock}. No locking is needed in readonly mode.
     * @param name the name of the lock file
     */
    public final Lock makeLock(final String name) {
        return new Lock() {
            public boolean obtain() throws IOException {
                return true;
            }
            public void release() {
            }
        };
    }

    /** Closes the store to future operations. */
    public final void close() {
    }
}
