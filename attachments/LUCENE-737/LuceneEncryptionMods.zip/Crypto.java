package org.apache.lucene.util;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.bouncycastle.jce.provider.*;

public class Crypto {
	public static Cipher	cipher	= null;

	private static Key		key			= null;

	/**
	 * Sets the encryption/decryption key.
	 * 
	 * @param password
	 *          the user supplied password as a String
	 */
	public static void setKey(String password) {
		if (password == null) {
			key = null;
		} else {
			Crypto.key = new SecretKeySpec(password.getBytes(), "RC4");
		}
	}

	/**
	 * Returns true if the encryption key is null.
	 * 
	 * @return true if the key is null, false otherwise
	 */
	public static boolean isNullKey() {
		if (key == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Create the cipher after adding the encryption algorithm provider.
	 * To use the encryption API additions to Lucene, first create the cipher,
	 * then provide the encryption key, e.g.
	 * 
	 * import org.apache.lucene.util.Crypto; //where the cryptography API additions are kept
	 * Crypto.setCypher();
	 * Crypto.setKey("mypassword");
	 * 
	 * Encryption/decryption of the data and index is automatic, but the search terms 
	 * must be encrypted before searching, as follows:
	 * 
	 * String termToSearch = "anyword";
	 * String encryptedTermToSearch = new String(Crypto.encrypt(termToSearch.getBytes()), "UTF8");
	 * Query query = new TermQuery(new Term(field, encryptedTermToSearch));
	 * 
	 * @throws NoSuchAlgorithmException,NoSuchPaddingException
	 */
	public static void setCypher() throws NoSuchAlgorithmException,
			NoSuchPaddingException {
		Security.insertProviderAt(new BouncyCastleProvider(), 2);
		cipher = Cipher.getInstance("RC4");
	}

	/**
	 * Provides encryption services.
	 * 
	 * @param clearText
	 *          the data to be encrypted, in a byte[]
	 * @return the encrypted data, in a byte[]
	 * @throws GeneralSecurityException,
	 *           IOException
	 */
	public static byte[] encrypt(byte[] clearText)
			throws GeneralSecurityException, IOException {
		byte[] ciphertext = new byte[clearText.length];
		// Initialise for encryption.
		cipher.init(Cipher.ENCRYPT_MODE, key);
		// Encrypt the data in one block
		ciphertext = cipher.doFinal(clearText);
		return ciphertext;
	}

	/**
	 * Provides decryption services.
	 * 
	 * @param cipherText
	 *          the data to be decrypted, in a byte[]
	 * @return the decrypted, plaintext data, in a byte[]
	 * @throws GeneralSecurityException,
	 *           IOException
	 */
	public static byte[] decrypt(byte[] cipherText)
			throws GeneralSecurityException, IOException {
		byte[] clearText = new byte[cipherText.length];
		// Initialise for decryption.
		cipher.init(Cipher.DECRYPT_MODE, key);
		// Decrypt the data in one block
		clearText = cipher.doFinal(cipherText);
		return clearText;
	}
}
