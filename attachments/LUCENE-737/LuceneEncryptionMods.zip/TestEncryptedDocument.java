/*package krypto;

import java.io.File;
import junit.framework.TestCase;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Crypto;
import org.apache.lucene.document.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

*//**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//*
*//**
 * Tests {@link Document} class field encryption.
 * 
 * @author Bernhard Messer
 * @version $Id: TestBinaryDocument.java 387550 2006-03-21 15:36:32Z yonik $
 * @version $Id: TestEncryptedDocument.java 480234 2006-11-27 15:36:32Z victorn $
 *//*
public class TestEncryptedDocument extends TestCase {
  String            binaryValStored     = "this text will be stored as a byte array in the index";
  String            binaryValEncrypted  = "this text will be also stored with encryption as a byte array in the index";
  String            binaryValCompressed = "this text will be also stored and compressed as a byte array in the index";
  private Directory dir;

  public void testEncryptedFieldInIndex() throws Exception {
    // dir = new RAMDirectory();
    dir = FSDirectory.getDirectory(new File(System.getProperty("user.home"),
    "encryptIndex"), true);
    Crypto.setCypher();
    *//***************************************************************************
     * NOTE that the password is hard coded here for testing purposes only.
     * Normally it would be asked from the user.
     **************************************************************************//*
    Crypto.setKey("mypassword");
    Field binaryFldStored = new Field("binaryStored", binaryValStored
    .getBytes(), Field.Store.YES);
    Field stringFldStored = new Field("stringStored", binaryValStored,
    Field.Store.YES, Field.Index.TOKENIZED, Field.TermVector.NO);
    Field stringFldEncrypted = new Field("encrypted", binaryValEncrypted,
    Field.Store.ENCRYPT, Field.Index.UN_TOKENIZED, Field.TermVector.NO);
    Field stringFldcompressed = new Field("stringCompressed",
    binaryValCompressed, Field.Store.COMPRESS, Field.Index.TOKENIZED,
    Field.TermVector.NO);
    try {
      // binary fields with store off are not allowed
      new Field("fail", binaryValEncrypted.getBytes(), Field.Store.NO);
      fail();
    } catch (IllegalArgumentException iae) {
      System.out.println("illegal argument");
    }
    Document doc = new Document();
    doc.add(binaryFldStored);
    doc.add(stringFldStored);
    doc.add(stringFldEncrypted);
    doc.add(stringFldcompressed);
    *//** test for field count *//*
    assertEquals(4, doc.getFields().size());
    *//** add the doc to a ram index *//*
    // RAMDirectory dir = new RAMDirectory();
    IndexWriter writer = new IndexWriter(dir, new StandardAnalyzer(), true);
    writer.addDocument(doc);
    writer.close();
    *//** open a reader and fetch the document *//*
    IndexReader reader = IndexReader.open(dir);
    Document docFromReader = reader.document(0);
    assertTrue(docFromReader != null);
    *//**
     * fetch the binary stored field and compare it's content with the original
     * one
     *//*
    String binaryFldStoredTest = new String(docFromReader
    .getBinaryValue("binaryStored"));
    assertTrue(binaryFldStoredTest.equals(binaryValStored));
    *//** fetch the string field and compare it's content with the original one *//*
    String stringFldStoredTest = new String(docFromReader.get("stringStored"));
    assertTrue(stringFldStoredTest.equals(binaryValStored));
    *//**
     * fetch the encrypted string field and compare it's content with the
     * original one
     *//*
    Crypto.setKey("yourpassword");
    String stringFldEncryptedTest = new String(docFromReader.get("encrypted"));
    assertFalse(stringFldEncryptedTest.equals(binaryValEncrypted));
    Crypto.setKey("mypassword");
    stringFldEncryptedTest = new String(docFromReader.get("encrypted"));
    assertTrue(stringFldEncryptedTest.equals(binaryValEncrypted));
    *//**
     * fetch the compressed string field and compare it's content with the
     * original one
     *//*
    String stringFldCompressedTest = new String(docFromReader
    .get("stringCompressed"));
    assertTrue(stringFldCompressedTest.equals(binaryValCompressed));
    *//** delete the document from index *//*
    reader.deleteDocument(0);
    assertEquals(0, reader.numDocs());
    reader.close();
    Crypto.setKey(" ");
  }
}
*/