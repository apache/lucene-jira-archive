/*package krypto;

import junit.framework.TestCase;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Hits;
import org.apache.lucene.util.Crypto;
import java.io.File;

*//**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *//*
*//**
 * Tests {@link Document} class.
 * 
 * @author Otis Gospodnetic
 * @version $Id: TestDocument.java 208846 2005-07-02 16:40:44Z dnaber $
 * @version $Id: TestDocument.java 480234 2006-11-27 15:36:32Z victorn $
 *//*
public class TestDocument extends TestCase {
  String            binaryVal           = "this text will be stored as a byte array in the index";
  String            binaryVal2          = "this text will be also stored as a byte array in the index";
  String            stringValEncrypted  = "this string will be stored (encrypted) as a byte array in the index";
  String            stringValCompressed = "this string will be stored (compressed) as a byte array in the index";
  private Directory dir;

  public void testFieldTypes() throws Exception {
    Crypto.setCypher();
    // dir = new RAMDirectory();
    dir = FSDirectory.getDirectory(new File(System.getProperty("user.home"),
    "encryptedIndex"), true);
    *//***************************************************************************
     * NOTE that the password is hard coded here for testing purposes only.
     * Normally it would be asked from the user.
     **************************************************************************//*
    Crypto.setKey("mypassword");
    IndexWriter writer = new IndexWriter(dir, new StandardAnalyzer(), true);
    writer.setMaxBufferedDocs(10);
    writer.setMergeFactor(10);
    writer.setUseCompoundFile(true);
    for (int i = 0; i < 20; i++) {
      Document doc = new Document();
      Field stringFld = new Field("string", binaryVal, Field.Store.YES,
      Field.Index.NO);
      Field binaryFld = new Field("binary", binaryVal.getBytes(),
      Field.Store.YES);
      Field binaryFld2 = new Field("binary", binaryVal2.getBytes(),
      Field.Store.YES);
      Field stringFldEncrypted1 = new Field("stringEncrypted",
      stringValEncrypted, Field.Store.ENCRYPT, Field.Index.TOKENIZED,
      Field.TermVector.NO);
      Field stringFldEncrypted2 = new Field("stringEncryptedUntokenized",
      stringValEncrypted, Field.Store.ENCRYPT, Field.Index.UN_TOKENIZED,
      Field.TermVector.YES);
      Field stringFldCompressed = new Field("stringCompressed",
      stringValCompressed, Field.Store.COMPRESS, Field.Index.TOKENIZED,
      Field.TermVector.NO);
      doc.add(stringFld);
      doc.add(binaryFld);
      doc.add(stringFldEncrypted1);
      doc.add(stringFldEncrypted2);
      doc.add(stringFldCompressed);
      assertEquals(5, doc.getFields().size());
      assertTrue(binaryFld.isBinary());
      assertTrue(binaryFld.isStored());
      assertFalse(binaryFld.isIndexed());
      assertFalse(binaryFld.isTokenized());
      assertFalse(binaryFld.isEncrypted());
      *//**
       * isEncrypted means "is to be encrypted", actual encryption takes place
       * later when the document is added to the index by the index writer. At
       * which point the field type will change from string to binary. (i.e.
       * binary or compressed fields cannot be encrypted as well).
       *//*
      assertTrue(stringFldEncrypted1.isEncrypted());
      assertTrue(stringFldEncrypted1.isTokenized());
      assertTrue(stringFldEncrypted1.isStored());
      assertFalse(stringFldEncrypted1.isTermVectorStored());
      assertFalse(stringFldEncrypted1.isBinary());
      assertFalse(stringFldEncrypted1.isCompressed());
      //
      assertTrue(stringFldEncrypted2.isEncrypted());
      assertFalse(stringFldEncrypted2.isTokenized());
      assertTrue(stringFldEncrypted2.isStored());
      assertTrue(stringFldEncrypted2.isTermVectorStored());
      assertFalse(stringFldEncrypted2.isBinary());
      assertFalse(stringFldEncrypted2.isCompressed());
      //    
      assertTrue(stringFldCompressed.isCompressed());
      assertFalse(stringFldCompressed.isEncrypted());
      assertFalse(stringFldCompressed.isBinary());
      //    
      String binaryTest = new String(doc.getBinaryValue("binary"));
      assertTrue(binaryTest.equals(binaryVal));
      String stringTest = doc.get("string");
      assertTrue(binaryTest.equals(stringTest));
      doc.add(binaryFld2);
      assertEquals(6, doc.getFields().size());
      //    
      byte[][] binaryTests = doc.getBinaryValues("binary");
      assertEquals(2, binaryTests.length);
      binaryTest = new String(binaryTests[0]);
      String binaryTest2 = new String(binaryTests[1]);
      assertFalse(binaryTest.equals(binaryTest2));
      assertTrue(binaryTest.equals(binaryVal));
      assertTrue(binaryTest2.equals(binaryVal2));
      //  
      String encryptTest1 = doc.get("stringEncrypted");
      assertTrue(encryptTest1 != null);
      assertTrue(encryptTest1.equals(stringValEncrypted));
      String encryptTest2 = doc.get("stringEncryptedUntokenized");
      assertTrue(encryptTest2 != null);
      assertTrue(encryptTest2.equals(stringValEncrypted));
      *//** add the doc to the index *//*
      writer.addDocument(doc);
    }
    writer.optimize();
    writer.close();
    Searcher searcher = new IndexSearcher(dir);
    *//***************************************************************************
     * The test below is executed twice, the first time with the wrong password.
     * Search for something that does exists and which will be decrypted. First
     * encrypt the search term and convert it to String. NOTE that the password
     * is hard coded in the encryption/decryption routines for testing purposes
     * only. Normally it would be obtained from the user.
     **************************************************************************//*
    Crypto.setKey("yourpassword");
    String term = "array";
    String text = new String(Crypto.encrypt(term.getBytes()), "UTF8");
    Query query = new TermQuery(new Term("stringEncrypted", text));
    Hits hits = searcher.search(query);
    assertEquals(0, hits.length());
    //
    query = new TermQuery(new Term("stringEncryptedUntokenized", text));
    hits = searcher.search(query);
    assertEquals(0, hits.length());    
    //
    Crypto.setKey("mypassword");
    text = new String(Crypto.encrypt(term.getBytes()), "UTF8");
    query = new TermQuery(new Term("stringEncrypted", text));
    hits = searcher.search(query);
    assertEquals(20, hits.length());
    //
    query = new TermQuery(new Term("stringEncryptedUntokenized", text));
    hits = searcher.search(query);
    assertEquals(0, hits.length());
    searcher.close();
    *//***************************************************************************
     * Open a reader and fetch the document
     * 
     **************************************************************************//*
    IndexReader reader = IndexReader.open(dir);
    Document docFromReader = reader.document(0);
    assertTrue(docFromReader != null);
    *//***************************************************************************
     * Fetch the binary stored field and compare it's content with the original
     * one
     **************************************************************************//*
    String binaryFldStoredTest = new String(docFromReader
    .getBinaryValue("binary"));
    assertTrue(binaryFldStoredTest.equals(binaryVal));
    *//***************************************************************************
     * Fetch the encrypted field and compare it's content with the original
     * string. The field will be returned as an un-decrypted byte[] by
     * docFromReader.getBinaryValue().
     **************************************************************************//*
    String stringFldEncryptedTest = new String(docFromReader
    .getBinaryValue("stringEncrypted"));
    assertFalse(stringFldEncryptedTest.equals(stringValEncrypted));
    *//***************************************************************************
     * The encrypted string will be returned as a decrypted String by
     * docFromReader.get()
     **************************************************************************//*
    stringFldEncryptedTest = docFromReader.get("stringEncrypted");
    assertTrue(stringFldEncryptedTest.equals(stringValEncrypted));
    *//***************************************************************************
     * The encrypted untokenized string will be returned as a decrypted String
     * by docFromReader.get()
     **************************************************************************//*
    stringFldEncryptedTest = docFromReader.get("stringEncryptedUntokenized");
    assertTrue(stringFldEncryptedTest.equals(stringValEncrypted));
    *//***************************************************************************
     * Fetch the compressed string field and compare it's content with the
     * original one
     **************************************************************************//*
    String stringFldCompressedTest = new String(docFromReader
    .get("stringCompressed"));
    assertTrue(stringFldCompressedTest.equals(stringValCompressed));
    *//***************************************************************************
     * Delete the document from index
     * 
     **************************************************************************//*
    reader.deleteDocument(0);
    assertEquals(19, reader.numDocs());
    reader.close();
  }

  *//**
   * Tests {@link Document#removeField(String)} method for a brand new Document
   * that has not been indexed yet.
   * 
   * @throws Exception on error
   *//*
  public void testRemoveForNewDocument() throws Exception {
    Document doc = makeDocumentWithFields();
    assertEquals(9, doc.getFields().size());
    doc.removeFields("keyword");
    assertEquals(7, doc.getFields().size());
    doc.removeFields("doesnotexists"); // removing non-existing fields is
    // siltenlty ignored
    doc.removeFields("keyword"); // removing a field more than once
    assertEquals(7, doc.getFields().size());
    doc.removeField("text");
    assertEquals(6, doc.getFields().size());
    doc.removeField("text");
    assertEquals(5, doc.getFields().size());
    doc.removeField("text");
    assertEquals(5, doc.getFields().size());
    doc.removeField("doesnotexists"); // removing non-existing fields is
    // silently ignored
    assertEquals(5, doc.getFields().size());
    doc.removeFields("unindexed");
    assertEquals(3, doc.getFields().size());
    doc.removeFields("unstored");
    assertEquals(1, doc.getFields().size());
    doc.removeFields("doesnotexists"); // removing non-existing fields is
    // silently ignored
    doc.removeFields("encrypted");
    assertEquals(0, doc.getFields().size());
  }

  public void testConstructorExceptions() {
    new Field("name", "value", Field.Store.YES, Field.Index.NO); // okay
    new Field("name", "value", Field.Store.NO, Field.Index.UN_TOKENIZED); // okay
    try {
      new Field("name", "value", Field.Store.NO, Field.Index.NO);
      fail("fail1");
    } catch (IllegalArgumentException e) {
      // expected exception
    }
    new Field("name", "value", Field.Store.YES, Field.Index.NO,
    Field.TermVector.NO); // okay
    try {
      new Field("name", "value", Field.Store.YES, Field.Index.NO,
      Field.TermVector.YES);
      fail("fail2");
    } catch (IllegalArgumentException e) {
      // expected exception
    }
  }

  *//**
   * Tests {@link Document#getValues(String)} method for a brand new Document
   * that has not been indexed yet.
   * 
   * @throws Exception on error
   *//*
  public void testGetValuesForNewDocument() throws Exception {
    doAssert(makeDocumentWithFields(), false);
  }

  *//**
   * Tests {@link Document#getValues(String)} method for a Document retrieved
   * from an index.
   * 
   * @throws Exception on error
   *//*
  public void testGetValuesForIndexedDocument() throws Exception {
    RAMDirectory dir = new RAMDirectory();
    IndexWriter writer = new IndexWriter(dir, new StandardAnalyzer(), true);
    writer.addDocument(makeDocumentWithFields());
    writer.close();
    Searcher searcher = new IndexSearcher(dir);
    // search for something that does exists
    Query query = new TermQuery(new Term("keyword", "test1"));
    // ensure that queries return expected results without DateFilter first
    Hits hits = searcher.search(query);
    assertEquals(1, hits.length());
    doAssert(hits.doc(0), true);
    searcher.close();
  }

  private Document makeDocumentWithFields() {
    Document doc = new Document();
    doc.add(new Field("keyword", "test1", Field.Store.YES,
    Field.Index.UN_TOKENIZED));
    doc.add(new Field("keyword", "test2", Field.Store.YES,
    Field.Index.UN_TOKENIZED));
    doc.add(new Field("text", "test1", Field.Store.YES, Field.Index.TOKENIZED));
    doc.add(new Field("text", "test2", Field.Store.YES, Field.Index.TOKENIZED));
    doc.add(new Field("unindexed", "test1", Field.Store.YES, Field.Index.NO));
    doc.add(new Field("unindexed", "test2", Field.Store.YES, Field.Index.NO));
    doc.add(new Field("unstored", "test1", Field.Store.NO,
    Field.Index.TOKENIZED));
    doc.add(new Field("unstored", "test2", Field.Store.NO,
    Field.Index.TOKENIZED));
    doc.add(new Field("encrypted", "to be encrypted", Field.Store.YES,
    Field.Index.TOKENIZED));
    return doc;
  }

  private void doAssert(Document doc, boolean fromIndex) {
    String[] keywordFieldValues = doc.getValues("keyword");
    String[] textFieldValues = doc.getValues("text");
    String[] unindexedFieldValues = doc.getValues("unindexed");
    String[] unstoredFieldValues = doc.getValues("unstored");
    assertTrue(keywordFieldValues.length == 2);
    assertTrue(textFieldValues.length == 2);
    assertTrue(unindexedFieldValues.length == 2);
    // this test cannot work for documents retrieved from the index
    // since unstored fields will obviously not be returned
    if (!fromIndex) {
      assertTrue(unstoredFieldValues.length == 2);
    }
    assertTrue(keywordFieldValues[0].equals("test1"));
    assertTrue(keywordFieldValues[1].equals("test2"));
    assertTrue(textFieldValues[0].equals("test1"));
    assertTrue(textFieldValues[1].equals("test2"));
    assertTrue(unindexedFieldValues[0].equals("test1"));
    assertTrue(unindexedFieldValues[1].equals("test2"));
    // this test cannot work for documents retrieved from the index
    // since unstored fields will obviously not be returned
    if (!fromIndex) {
      assertTrue(unstoredFieldValues[0].equals("test1"));
      assertTrue(unstoredFieldValues[1].equals("test2"));
    }
  }
}
*/