/**
 * Copyright (C) 2006-2013 EMBL - European Bioinformatics Institute
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package uk.ac.ebi.ebinocle.search.lucene.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.lucene.facet.search.FacetsCollector;
import org.apache.lucene.facet.search.params.FacetRequest;
import org.apache.lucene.facet.search.params.FacetSearchParams;
import org.apache.lucene.facet.search.results.FacetResult;
import org.apache.lucene.facet.taxonomy.CategoryPath;
import org.apache.lucene.facet.taxonomy.TaxonomyReader;
import org.apache.lucene.index.AtomicReaderContext;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Collector;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Scorer;
import org.apache.lucene.search.Scorer.ChildScorer;

/**
 * Utility class to create Facet Sideways navigation. Permit to obtain:
 * <ul>
 * <li>facet query: sideways oriented query to permit to match near miss (used in facet counting)</li>
 * <li>facet collector: a collector that discriminate near misses to collect in the proper collector</li>
 * <li>result collector: a wrapper to a normal result collector that skip misses and count only full matches</li>
 * </ul>
 * 
 * http://markmail.org/thread/jmnq6z2x7ayzci5k
 * 
 * @author nbuso@ebi.ac.uk EMBL-EBI - External Services Group
 *
 */
public class DrillSideways {

	public abstract static class ASidewayCollector extends Collector {
		protected int numSelFacets;
		protected Scorer facetsScorer;
		protected DrillSidewaysQuery swQuery;
		
		@Override
		public void setScorer(Scorer scorer) throws IOException {
			// 2 clauses
			// 0 - baseQuery clause
			// 1 - facetsQuery clause
			assert scorer.getChildren().size() == 2;
			swQuery = (DrillSidewaysQuery) scorer.getWeight().getQuery();
			
			facetsScorer = ((List<ChildScorer>)scorer.getChildren()).get(1).child;
			setNumSelectedFacets();
		}
		
		private void setNumSelectedFacets() {
			numSelFacets = swQuery.fSels.size();
		}
		
		/**
		 * Say if the document is in "DrillDown" matches instead of "DrillSideway"
		 * 
		 * @return
		 * @throws IOException
		 */
		protected boolean isFullMatch() throws IOException {
			int numClausesForFullMatch = numSelFacets;
			if (numSelFacets == 1) {
				// there is also the matchallquery
				numClausesForFullMatch = 2;
			}
			return facetsScorer.freq() == numClausesForFullMatch;
		}

		@Override
		public boolean acceptsDocsOutOfOrder() {
			return false;
		}
	}

	/**
	 * Collector that count sideways the facets
	 * 
	 * @author nbuso
	 *
	 */
	public static class FacetSidewayMultiCollector extends ASidewayCollector {

		private Map<String, FacetsCollector> facetCollectorsMap;		
		
		private FacetSidewayMultiCollector(FacetSearchParams facetSearchParams,
            IndexReader indexReader, TaxonomyReader taxonomyReader) {
			
			facetCollectorsMap = new HashMap<String, FacetsCollector>();
			FacetsCollector fCollector = null;
			for (FacetRequest facetRequest : facetSearchParams.getFacetRequests()) {
				fCollector = new FacetsCollector(new FacetSearchParams(facetRequest), indexReader, taxonomyReader);
				facetCollectorsMap.put(facetRequest.getCategoryPath().components[0], fCollector);
			}
		}
		
		@Override
		public void setScorer(Scorer scorer) throws IOException {
			super.setScorer(scorer);
			for (Collector c : facetCollectorsMap.values()) {
				c.setScorer(scorer);
			}
		}

		/**
		 * 
		 * @return null if the doc is not related to a facet, the facet id otherwise
		 */
		private String getFacetToCount(int doc) throws IOException {
			if (isFullMatch()) {
				return null;
			}
			// look for which facet to count for this document
			// one clause of the BooleanQuery must not match
			int i = 0;
			// order maintained! it's not in the API
			for (Scorer.ChildScorer childScorer : facetsScorer.getChildren()) {
				// from suggestion by Mike McCandless
				if (childScorer.child.docID() != doc) { // near miss
					return swQuery.fSels.get(i).id;
				}
				i++;
			}
			
			return null;
		}
		
		@Override
		public void collect(int doc) throws IOException {
			String facetIdToCount = getFacetToCount(doc);
			if (facetIdToCount != null) {
				facetCollectorsMap.get(facetIdToCount).collect(doc);
			} else {
				for (FacetsCollector c : facetCollectorsMap.values()) {
					c.collect(doc);
				}
			}
		}

		@Override
		public void setNextReader(AtomicReaderContext context)
			throws IOException {
			
			for (Collector c : facetCollectorsMap.values()) {
				c.setNextReader(context);
			}
		}
		
		public List<FacetResult> getFacetResult() throws IOException {
			List<FacetResult> toReturn = new ArrayList<FacetResult>();
			for (FacetsCollector c : facetCollectorsMap.values()) {
				toReturn.addAll(c.getFacetResults());
			}
			return toReturn;
		}
	}
	
	/**
	 * Simple collector wrapper that skip sideways and count only drilldown for the query results
	 * 
	 * @author nbuso
	 *
	 */
	public static class StandardSideawayCollector extends ASidewayCollector {
		private Collector wrapped;

		public StandardSideawayCollector(Collector toWrap) {
			wrapped = toWrap;
		}
		
		@Override
		public void setScorer(Scorer scorer) throws IOException {
			super.setScorer(scorer);
			wrapped.setScorer(scorer);
		}
		
		@Override
		public void collect(int doc) throws IOException {
			if (isFullMatch()) {
				wrapped.collect(doc);
			}
		}
		
		@Override
		public void setNextReader(AtomicReaderContext context)
				throws IOException {
			wrapped.setNextReader(context);
		}

		@Override
		public boolean acceptsDocsOutOfOrder() {
			return false;
//			return wrapped.acceptsDocsOutOfOrder();
		}
	}
	
	/**
	 * Representation of a facet selection.
	 * 
	 * Should this class represent also how a selection should participate to the query? (Occur.SHOULD/multiselection, Occur.MUST/single selection)
	 * 
	 * @author nbuso
	 *
	 */
	public static class DrillFacetSelection {
		public String id;
		private List<CategoryPath> values;
		public Occur occur; // ???? is always in OR?
		
		public DrillFacetSelection(String id) {
			this.id = id;
			values = new ArrayList<CategoryPath>();
		}
		
		public DrillFacetSelection(String id, CategoryPath...cps) {
			this(id);
			for (CategoryPath cp : cps) {
				addValue(cp);
			}
		}
		
		public void addValue(CategoryPath cp) {
			if (!cp.components[0].equals(id)) {
				throw new IllegalArgumentException(
					String.format("This selection for facet [%s] can't accept value: %s", id, cp));
			}
			values.add(cp);
		}
		
		public List<CategoryPath> getValues() {
			return values;
		}
	}
	
	public static class DrillSidewaysQuery extends BooleanQuery {
		// could be these info are not later reused and can be not maintained?
		public Query bq;
		public BooleanQuery subQuery;
		public List<DrillFacetSelection> fSels;
		
		public FacetSearchParams fsp;
		
		public DrillSidewaysQuery(Query baseQuery, FacetSearchParams facetSearchParam, List<DrillFacetSelection> facetSelections) {
			bq = baseQuery;
			fsp = facetSearchParam;
			fSels = new ArrayList<DrillSideways.DrillFacetSelection>();
			add(bq, Occur.MUST);
			subQuery = new BooleanQuery();
			add(subQuery, Occur.MUST);
			
			// as soon as you remove the dummy MatchAllDocsQuery remove it and put addSidewaySelection public
			for (DrillFacetSelection s : facetSelections) {
				addSidewaySelection(s);
			}
			
			if (facetSelections.size() == 1) {
				Query dummyQuery = new MatchAllDocsQuery();
				dummyQuery.setBoost(0.0f);
				subQuery.add(dummyQuery, Occur.SHOULD);
				subQuery.setMinimumNumberShouldMatch(1);
			} else {
				subQuery.setMinimumNumberShouldMatch(facetSelections.size() - 1);
			}
		}
		
		private void addSidewaySelection(DrillFacetSelection s) {
			fSels.add(s);
			Query facetQuery = FacetDrillDown.query(fsp.getFacetIndexingParams(), null,
					s.occur, s.values.toArray(new CategoryPath[s.values.size()]));
			subQuery.add(facetQuery, Occur.SHOULD);
		}
	}

	/**
	 * Create a query that enable sideways count of facets. Mainly based Michael construction, should we create a more specific Query?
	 * 
	 * @param baseQuery
	 * @param fsp
	 * @param selections
	 * @return
	 */
	public static BooleanQuery createQuery(Query baseQuery, FacetSearchParams fsp, List<DrillFacetSelection> selections) {
		BooleanQuery mainQuery = new DrillSidewaysQuery(baseQuery, fsp, selections);
		
		return mainQuery;
	}
	
	/**
	 * Return a Facet collector able to count sideways
	 * 
	 * @param facetSearchParams
	 * @param indexReader
	 * @param taxonomyReader
	 * @return
	 */
	public static FacetSidewayMultiCollector createFacetSidewayCollector(FacetSearchParams facetSearchParams,
            IndexReader indexReader, TaxonomyReader taxonomyReader) {
		
		return new DrillSideways.FacetSidewayMultiCollector(facetSearchParams, indexReader, taxonomyReader);
	}
	
	/**
	 * Return a wrapped "result" collector that collect drilldown with a sideways query
	 * 
	 * @param collector
	 * @return
	 */
	public static Collector wrapResultCollector(Collector collector) {
		return new StandardSideawayCollector(collector);
	}
}
