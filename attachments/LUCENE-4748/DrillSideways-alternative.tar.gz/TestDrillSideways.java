/**
 * Copyright (C) 2006-2013 EMBL - European Bioinformatics Institute
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *         http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package uk.ac.ebi.ebinocle.search.lucene.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.facet.index.FacetFields;
import org.apache.lucene.facet.search.ScoredDocIdCollector;
import org.apache.lucene.facet.search.params.CountFacetRequest;
import org.apache.lucene.facet.search.params.FacetSearchParams;
import org.apache.lucene.facet.search.results.FacetResult;
import org.apache.lucene.facet.search.results.FacetResultNode;
import org.apache.lucene.facet.taxonomy.CategoryPath;
import org.apache.lucene.facet.taxonomy.TaxonomyReader;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyReader;
import org.apache.lucene.facet.taxonomy.directory.DirectoryTaxonomyWriter;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Collector;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.MatchAllDocsQuery;
import org.apache.lucene.search.MultiCollector;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopScoreDocCollector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;

import uk.ac.ebi.ebinocle.search.lucene.util.DrillSideways.DrillFacetSelection;
import uk.ac.ebi.ebinocle.search.lucene.util.DrillSideways.FacetSidewayMultiCollector;

/**
 * Adaptation of Mike McCandless test, simpler than ebinocle related ones.
 * 
 * @author nbuso@ebi.ac.uk EMBL-EBI - External Services Group
 *
 */
public class TestDrillSideways extends TestCase {

	private DirectoryTaxonomyWriter taxoWriter;
	private IndexWriter writer;
	private FacetFields facetFields;

	private void add(String... categoryPaths) throws IOException {
		Document doc = new Document();
		List<CategoryPath> paths = new ArrayList<CategoryPath>();
		for (String categoryPath : categoryPaths) {
			paths.add(new CategoryPath(categoryPath, '/'));
		}
		facetFields.addFields(doc, paths);
		writer.addDocument(doc);
	}

	private Directory newDirectory() throws Exception {
//		File tempDir = Files.createTempDirectory("luTestDir"+System.currentTimeMillis()).toFile();
//		tempDir.mkdirs();
		Directory fsDir = new RAMDirectory(); //FSDirectory.open(tempDir);
		return fsDir;
	}
	
	public void test() throws Exception {
		Directory dir = newDirectory();
		Directory taxoDir = newDirectory();
		writer = new IndexWriter(dir, new IndexWriterConfig(Version.LUCENE_41, new StandardAnalyzer(Version.LUCENE_41)));

		// Writes facet ords to a separate directory from the
		// main index:
		taxoWriter = new DirectoryTaxonomyWriter(taxoDir,
				IndexWriterConfig.OpenMode.CREATE);

		// Reused across documents, to add the necessary facet
		// fields:
		facetFields = new FacetFields(taxoWriter);

		add("Author/Bob", "Publish Date/2010/10/15");
		add("Author/Lisa", "Publish Date/2010/10/20");
		add("Author/Lisa", "Publish Date/2012/1/1");
		add("Author/Susan", "Publish Date/2012/1/7");
		add("Author/Frank", "Publish Date/1999/5/5");

		writer.commit();
		IndexSearcher searcher = new IndexSearcher(DirectoryReader.open(dir));
		writer.close();

		// System.out.println("searcher=" + searcher);

		taxoWriter.commit();
		TaxonomyReader taxoReader = new DirectoryTaxonomyReader(taxoWriter);
		taxoWriter.close();

		// Count both "Publish Date" and "Author" dimensions, in
		// drill down:
		FacetSearchParams fsp = new FacetSearchParams(new CountFacetRequest(
				new CategoryPath("Publish Date"), 10), new CountFacetRequest(
				new CategoryPath("Author"), 10));

		// Simple case: drill down on a single field; in this
		// case the drill sideways + drill down counts == drill
		// down of just the query:
		
		
		Query baseQuery = new MatchAllDocsQuery();
		List<DrillFacetSelection> selections = new ArrayList<DrillSideways.DrillFacetSelection>();
		selections.add(new DrillSideways.DrillFacetSelection("Author", new CategoryPath("Author", "Lisa")));
		BooleanQuery facetedQuery = DrillSideways.createQuery(baseQuery, fsp, selections);
		
		TopScoreDocCollector hitCollector = TopScoreDocCollector.create(Math.min(10, searcher.getIndexReader().maxDoc()), null, true);
		ScoredDocIdCollector docIdsCollector = ScoredDocIdCollector.create(searcher.getIndexReader().maxDoc(), false);
		
		FacetSidewayMultiCollector facetCollector = DrillSideways.createFacetSidewayCollector(fsp, searcher.getIndexReader(), taxoReader);
		Collector resultsCollectors = DrillSideways.wrapResultCollector(MultiCollector.wrap(hitCollector, docIdsCollector));
		
		searcher.search(facetedQuery, MultiCollector.wrap(MultiCollector.wrap(resultsCollectors, facetCollector)));

		ScoreDoc[] hits = hitCollector.topDocs().scoreDocs;
		List<FacetResult> facetR = facetCollector.getFacetResult(); 
		
		assertEquals(2, hitCollector.getTotalHits());
		// System.out.println(r.drillDownResults);
		// System.out.println(r.drillSidewaysResults);
		assertEquals(2, facetR.size());
		// check to have all the values for the facets
		assertEquals(7, countFacetsValues(facetR));
		// nocommit why sorting by label descending...?
		assertEquals("Publish Date: 2012=1 2010=1",
				toString(facetR.get(0)));
		assertEquals("Author: Lisa=2 Frank=1 Susan=1 Bob=1", toString(facetR.get(1)));

//		assertEquals(1, facetR.size());
//		// nocommit how are these sorted...?
//		assertEquals("Author: Frank=1 Susan=1 Bob=1",
//				toString(facetR.get(0)));

		// More interesting case: drill down on two fields
		
		
		selections = new ArrayList<DrillSideways.DrillFacetSelection>();
		selections.add(new DrillFacetSelection("Author", new CategoryPath("Author", "Lisa")));
		selections.add(new DrillFacetSelection("Publish Date", new CategoryPath("Publish Date", "2010")));

		facetedQuery = DrillSideways.createQuery(baseQuery, fsp, selections);
		
		hitCollector = TopScoreDocCollector.create(Math.min(10, searcher.getIndexReader().maxDoc()), null, true);
		docIdsCollector = ScoredDocIdCollector.create(searcher.getIndexReader().maxDoc(), false);
		
		facetCollector = DrillSideways.createFacetSidewayCollector(fsp, searcher.getIndexReader(), taxoReader);
		resultsCollectors = DrillSideways.wrapResultCollector(MultiCollector.wrap(hitCollector, docIdsCollector));
//		resultsCollectors = DrillSideways.wrapResultCollector(hitCollector);
		
		searcher.search(facetedQuery, MultiCollector.wrap(MultiCollector.wrap(resultsCollectors, facetCollector)));

		hits = hitCollector.topDocs().scoreDocs;
		facetR = facetCollector.getFacetResult();
		
		assertEquals(1, hitCollector.getTotalHits());
		assertEquals(2, facetR.size());
		// Lisa had 2012  and 2010 Publish Date:
		assertEquals("Publish Date: 2012=1 2010=1",
				toString(facetR.get(0)));
		// Lisa and Bob had Publish Date=2010
		assertEquals("Author: Lisa=1 Bob=1", toString(facetR.get(1)));

		// Even more interesting case: drill down on two fields,
		// but one of them is OR
		selections = new ArrayList<DrillSideways.DrillFacetSelection>();
		selections.add(new DrillFacetSelection("Author", new CategoryPath("Author", "Lisa"), new CategoryPath("Author", "Bob")));
		selections.add(new DrillFacetSelection("Publish Date", new CategoryPath("Publish Date", "2010")));

		facetedQuery = DrillSideways.createQuery(baseQuery, fsp, selections);
		
		hitCollector = TopScoreDocCollector.create(Math.min(10, searcher.getIndexReader().maxDoc()), null, true);
		docIdsCollector = ScoredDocIdCollector.create(searcher.getIndexReader().maxDoc(), false);
		
		facetCollector = DrillSideways.createFacetSidewayCollector(fsp, searcher.getIndexReader(), taxoReader);
		resultsCollectors = DrillSideways.wrapResultCollector(MultiCollector.wrap(hitCollector, docIdsCollector));
//		resultsCollectors = DrillSideways.wrapResultCollector(hitCollector);
		
		searcher.search(facetedQuery, MultiCollector.wrap(MultiCollector.wrap(resultsCollectors, facetCollector)));

		hits = hitCollector.topDocs().scoreDocs;
		facetR = facetCollector.getFacetResult();
		

		assertEquals(2, hitCollector.getTotalHits());
		assertEquals(2, facetR.size());
		assertEquals("Publish Date: 2010=2 2012=1",
				toString(facetR.get(0)));
		assertEquals("Author: Lisa=1 Bob=1",
				toString(facetR.get(1)));
//		assertEquals(2, r.drillSidewaysResults.size());
//		// Nobody besides Bob and Lisa had Publish Date=2010
//		assertEquals("Author:", toString(r.drillSidewaysResults.get(0)));
//		// Lisa only had 2012 as the other Publish Date:
//		assertEquals("Publish Date: 2012=1",
//				toString(r.drillSidewaysResults.get(1)));

		searcher.getIndexReader().close();
		taxoReader.close();
		dir.close();
		taxoDir.close();
		
	}
	
	private int countFacetsValues(List<FacetResult> facetResult) {
		int facetValuesCounts = 0;
		for (FacetResult facetResult2 : facetResult) {
			for (FacetResultNode frn : facetResult2.getFacetResultNode().getSubResults()) {
				facetValuesCounts += frn.getValue();
			}
		}
		return facetValuesCounts;
	}

	/** Just gathers counts of values under the dim. */
	private String toString(FacetResult fr) {
		StringBuilder b = new StringBuilder();
		FacetResultNode node = fr.getFacetResultNode();
		b.append(node.getLabel());
		b.append(":");
		for (FacetResultNode childNode : node.getSubResults()) {
			b.append(' ');
			b.append(childNode.getLabel().components[1]);
			b.append('=');
			b.append((int) childNode.getValue());
		}
		return b.toString();
	}
}
