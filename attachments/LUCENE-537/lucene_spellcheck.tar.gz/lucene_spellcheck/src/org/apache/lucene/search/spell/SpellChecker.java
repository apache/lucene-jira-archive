package org.apache.lucene.search.spell;

/**
 * Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.util.Iterator;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Index;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.store.Directory;

/**
 *  <p>
 *	Spell Checker class  (Main class) <br/>
 * (initially inspired by the David Spencer code)
 *  </p>
 *  
 *  <p>
 *  Spell Checker spellchecker= new SpellChecker (spellDirectory);<br/>
 *  <br/>
 *  //To index a field of a user index <br/>
 *  spellchecker.indexDictionary(new LuceneDictionary(my_lucene_reader, a_field));<br/>
 *<br/>
 *   //To index a file containing words  <br/>
 *  spellchecker.indexDictionary(new PlainTextDictionary(new File("myfile.txt")));<br/>
 *</p>
 * 
 * @author Nicolas Maisonneuve
 * @version 1.0
 */
public class SpellChecker {

	/**
	 * Field name for each word in the ngram index.
	 */
	public static final String F_WORD = "word";

	/**
	 * the spell index
	 */
	Directory ngramIndex;

	/**
	 * Boost value for start and end grams
	 */
	private float bStart = 2.0f;
	private float bEnd = 1.0f;

	private IndexReader ngramIndexReader;
	float min = 0.5f;

	private IndexSearcher ngramIndexSearcher;

	public void setSpellIndex(Directory spellindex) throws IOException {
		this.ngramIndex = spellindex;
		ngramIndexSearcher = new IndexSearcher(this.ngramIndex);
	}

	/**
	 *  Set the accuraty 0<min<1 default 0.5
	 * @param min float
	 */
	public void setAccuraty(float min) {
		this.min = min;
	}

	public SpellChecker(Directory gramIndex) throws IOException {
		this.setSpellIndex(gramIndex);
	}

	/**
	 * Suggest similar words
	 * @param word String the word you want a spell check done on
	 * @param num_sug int the number of suggest words
	 * @throws IOException
	 * @return String[]
	 */
	public Suggestion[] suggestSimilar(String word, int num_sug) throws IOException {
		return this.suggestSimilar(word, num_sug, null, false);
	}

	/**
	 * Suggest similar words (restricted or not of a field of a user index)
	 * @param word String the word you want a spell check done on
	 * @param numOfSuggestions int the number of suggest words
	 * @param tokenFrequencyVector if not null ,the suggest words are restricted to the words present.
	 * @param suggestOnlyMorePopularTerms boolean return only the suggest words that are more frequent than the searched word
	 * @throws IOException
	 * @return String[] the sorted list of the suggest words with this 2 criteri
	 * first criteria : the edit distance, second criteria (only if restricted mode): the popularity
	 * of the suggest words in the field of the user index
	 */
	public Suggestion[] suggestSimilar(String word, int numOfSuggestions, TokenFrequencyVector tokenFrequencyVector, boolean suggestOnlyMorePopularTerms) throws IOException {

		final TRStringDistance sd = new TRStringDistance(word);
		final int lengthWord = word.length();

		final int goalFreq = (suggestOnlyMorePopularTerms && tokenFrequencyVector != null) ? tokenFrequencyVector.getFrequency(word) : 0;
		if (!suggestOnlyMorePopularTerms && goalFreq > 0) {
			return new Suggestion[] {
				new Suggestion(1f, goalFreq, word)
			}; // return the word if it exist in the index and i don't want a more popular word
		}

		BooleanQuery query = new BooleanQuery();
		String[] grams;
		String key;

		for (int ng = getMin(lengthWord); ng <= getMax(lengthWord); ng++) {

			key = "gram" + ng; // form key

			grams = formGrams(word, ng); // form word into ngrams (allow dups too)

			if (grams.length == 0) {
				continue; // hmm
			}

			if (bStart > 0) { // should we boost prefixes?
				add(query, "start" + ng, grams[0], bStart); // matches start of word

			}
			if (bEnd > 0) { // should we boost suffixes
				add(query, "end" + ng, grams[grams.length - 1], bEnd); // matches end of word

			}
			for (int i = 0; i < grams.length; i++) {
				add(query, key, grams[i]);
			}

		}

		Hits hits = ngramIndexSearcher.search(query);
		SuggestionQueue sugqueue = new SuggestionQueue(numOfSuggestions);

		int stop = Math.min(hits.length(), 10 * numOfSuggestions); // go thru more than 'maxr' matches in case the distance filter triggers
		Suggestion sugword = new Suggestion();
		for (int i = 0; i < stop; i++) {

			sugword.setString(hits.doc(i).get(F_WORD)); // get orig word)

			if (sugword.getString().equals(word)) {
				continue; // don't suggest a word for itself, that would be silly
			}

			//edit distance/normalize with the min word length
			sugword.setScore(1.0f - ((float) sd.getDistance(sugword.getString()) / Math.min(sugword.getString().length(), lengthWord)));
			if (sugword.getScore() < min) {
				continue;
			}

			if (tokenFrequencyVector != null) { 
				sugword.setFreq(tokenFrequencyVector.getFrequency(sugword.getString()));
				if ((suggestOnlyMorePopularTerms && goalFreq > sugword.getFreq()) || sugword.getFreq() < 1) { // don't suggest a word that is not present in the field
					continue;
				}
			}
			sugqueue.insert(sugword);
			if (sugqueue.size() == numOfSuggestions) {
				//if queue full , maintain the min score
				min = ((Suggestion) sugqueue.top()).getScore();
			}
			sugword = new Suggestion();
		}

		// convert to ordered array 
		Suggestion[] list = new Suggestion[sugqueue.size()];
		for (int i = sugqueue.size() - 1; i >= 0; i--) {
			list[i] = (Suggestion) sugqueue.pop();
		}

		return list;
	}

	/**
	 * Add a clause to a boolean query.
	 */
	private static void add(BooleanQuery q, String k, String v, float boost) {
		Query tq = new TermQuery(new Term(k, v));
		tq.setBoost(boost);
		q.add(new BooleanClause(tq, Occur.SHOULD));
	}

	/**
	 * Add a clause to a boolean query.
	 */
	private static void add(BooleanQuery q, String k, String v) {
		q.add(new BooleanClause(new TermQuery(new Term(k, v)), Occur.SHOULD));
	}

	/**
	 * Form all ngrams for a given word.
	 * @param text the word to parse
	 * @param ng the ngram length e.g. 3
	 * @return an array of all ngrams in the word and note that duplicates are not removed
	 */
	private static String[] formGrams(String text, int ng) {
		int len = text.length();
		String[] res = new String[len - ng + 1];
		for (int i = 0; i < len - ng + 1; i++) {
			res[i] = text.substring(i, i + ng);
		}
		return res;
	}

	public void clearIndex() throws IOException {
		IndexReader.unlock(ngramIndex);
		IndexWriter writer = new IndexWriter(ngramIndex, null, true);
		writer.close();
	}

	/**
	 * if the word exist in the index
	 * @param word String
	 * @throws IOException
	 * @return boolean
	 */
	public boolean exist(String word) throws IOException {
		if (ngramIndexReader == null) {
			ngramIndexReader = IndexReader.open(ngramIndex);
		}
		return ngramIndexReader.docFreq(new Term(F_WORD, word)) > 0;
	}

	/**
	 * Index a Dictionary
	 * @param dict the dictionary to index
	 * @throws IOException
	 */
	public void buildNGramIndex(Dictionary dict) throws IOException {

		IndexReader.unlock(ngramIndex);
		IndexWriter writer = new IndexWriter(ngramIndex, new WhitespaceAnalyzer(), !IndexReader.indexExists(ngramIndex));
		writer.setMergeFactor(300);
		writer.setMaxBufferedDocs(150);

		Iterator iter = dict.getWordsIterator();
		while (iter.hasNext()) {
			String word = (String) iter.next();

			int len = word.length();
			if (len < 3) {
				continue; // too short we bail but "too long" is fine...
			}

			if (this.exist(word)) { // if the word already exist in the gramindex
				continue;
			}

			// ok index the word
			Document doc = createDocument(word, getMin(len), getMax(len));
			writer.addDocument(doc);
		}
		// close writer
		writer.optimize();
		writer.close();

		// close reader
		ngramIndexReader.close();
		ngramIndexReader = null;
	}

	private int getMin(int l) {
		if (l > 5) {
			return 3;
		}
		if (l == 5) {
			return 2;
		}
		return 1;
	}

	private int getMax(int l) {
		if (l > 5) {
			return 4;
		}
		if (l == 5) {
			return 3;
		}
		return 2;

	}

	private static Document createDocument(String text, int ng1, int ng2) {
		Document doc = new Document();
		doc.add(new Field(F_WORD, text, Store.YES, Index.UN_TOKENIZED)); // orig term
		addGram(text, doc, ng1, ng2);
		return doc;
	}

	private static void addGram(String text, Document doc, int ng1, int ng2) {
		int len = text.length();
		for (int ng = ng1; ng <= ng2; ng++) {
			String key = "gram" + ng;
			String end = null;
			for (int i = 0; i < len - ng + 1; i++) {
				String gram = text.substring(i, i + ng);
				doc.add(new Field(key, gram, Store.YES, Index.UN_TOKENIZED));
				if (i == 0) {
					doc.add(new Field("start" + ng, gram, Store.YES, Index.UN_TOKENIZED));
				}
				end = gram;
			}
			if (end != null) { // may not be present if len==ng1
				doc.add(new Field("end" + ng, end, Store.YES, Index.UN_TOKENIZED));
			}
		}
	}

	protected void finalize() throws Throwable {
		if (ngramIndexReader != null) {
			ngramIndexReader.close();
		}
		if (ngramIndexSearcher != null) {
			ngramIndexSearcher.close();
		}
	}

}
