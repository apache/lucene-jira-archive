package org.apache.lucene.search.spell;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;

import java.io.IOException;

/**
 * User: kalle
 * Date: 2006-mar-31
 * Time: 04:04:58
 */
public class LuceneTokenFrequencyVector implements TokenFrequencyVector {

    private IndexReader ir;
    private String field;

    public LuceneTokenFrequencyVector(Directory directory, String field) throws IOException {
        ir = IndexReader.open(directory);
        this.field = field;
    }

    public Integer getFrequency(String token) throws IOException {
        Integer ret = ir.docFreq(new Term(field, token));
        if (ret == 0) {
            return null;
        } else {
            return ret;
        }
    }

    public void close() throws IOException {
        ir.close();
    }

    @Override
    protected void finalize() throws Throwable {
        close();
    }
}
