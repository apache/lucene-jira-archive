package org.apache.lucene.search.spell;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.Hits;
import org.apache.lucene.store.RAMDirectory;

import java.io.IOException;
import java.util.Iterator;

/**
 * User: kalle
 * Date: 2006-mar-14
 * Time: 23:29:41
 * 
 * create a dictionary based on the documents returned by a query
 */
public class LuceneQueryDictionary implements Dictionary {

    private LuceneDictionary dict;

    public LuceneQueryDictionary(Hits hits, Analyzer analyzer, String field) throws IOException {
        RAMDirectory dir = new RAMDirectory();
        IndexWriter hitWriter = new IndexWriter(dir, analyzer, true);

        hitWriter.close();
        for (int i = 0; i < hits.length(); i++) {
            hitWriter.addDocument(hits.doc(i));
        }
        hitWriter.close();
        IndexReader r = IndexReader.open(dir);
        dict = new LuceneDictionary(r, field);
        r.close();
        dir.close();
    }

    /**
     * return all the words present in the dictionnary
     * @return Iterator
     */
    public Iterator getWordsIterator() {
        return dict.getWordsIterator();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
    }
}
