package org.apache.lucene.search.spell;

import java.io.File;
import java.util.Iterator;
import java.util.LinkedList;

import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class TestCaseSpellChecker {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {

		boolean create = false;
		File ngramPath = new File("/tmp/ngramIndex");
		if (!ngramPath.exists()) {
			ngramPath.mkdirs();
			create = true;
		}
		Directory ngramIndex = FSDirectory.getDirectory(ngramPath, create);
		if (create) {
			new IndexWriter(ngramIndex, null, true).close();
		}

		final SpellChecker spellChecker = new SpellChecker(ngramIndex);

		if (create) {
			final LinkedList<String> words = new LinkedList<String>();
            words.add("rationalization");            
            words.add("civilization");
			words.add("civilizations");
			words.add("civilian");
			words.add("nations");
			spellChecker.buildNGramIndex(new Dictionary() {
				public Iterator getWordsIterator() {
					return words.iterator();
				}
			});
		}

		String[] testWords = new String[] {
				"civilziation", "civiliation", "icvilizations", "liation", "notation", "leif", "foo", "rational", "realization", "implementation"
		};
		
		for (final String testWord : testWords) {
			new Thread(new Runnable() {
				public void run() {
					try {
						synchronized (System.out) {
							Suggestion[] suggestions = spellChecker.suggestSimilar(testWord, 3);
							if (suggestions.length == 0) {
								System.out.println(testWord + " has no suggestions.");
							} else {
								for (Suggestion suggested : suggestions) {
									System.out.println(testWord + " ~"+suggested.getScore()+" " + suggested.getString() +" " + suggested.getFreq());
								}
							}							
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}).start();
		}
		
		ngramIndex.close();
	}

}
