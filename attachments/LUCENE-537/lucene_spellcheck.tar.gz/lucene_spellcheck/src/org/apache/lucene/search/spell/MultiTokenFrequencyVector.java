package org.apache.lucene.search.spell;

import java.io.IOException;

/**
 * User: kalle
 * Date: 2006-mar-31
 * Time: 04:26:02
 *
 * Treats a bunch of TokenFrequencyVector:s as one. I.e. span spell check over multiple contexts.
 */
public class MultiTokenFrequencyVector implements TokenFrequencyVector {

    private Iterable<TokenFrequencyVector> vectors;

    public MultiTokenFrequencyVector(Iterable<TokenFrequencyVector> vectors) {
        this.vectors = vectors;
    }

    public Integer getFrequency(String token) throws IOException {
        Integer ret = 0;
        for (TokenFrequencyVector v : vectors) {
            Integer tmp = v.getFrequency(token);
            if (tmp != null) {
                ret+=tmp;
            }
        }
        if (ret == 0) {
            return null;
        } else {
            return ret;
        }
    }

    public void close() throws IOException {
        for (TokenFrequencyVector v : vectors) {
            v.close();
        }
    }

    @Override
    protected void finalize() throws Throwable {
        close();
        super.finalize();
    }
}
