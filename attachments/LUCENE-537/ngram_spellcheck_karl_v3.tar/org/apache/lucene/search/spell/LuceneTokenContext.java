package org.apache.lucene.search.spell;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;

import java.io.IOException;

/**
 * User: kalle
 * Date: 2006-mar-31
 * Time: 04:04:58
 */
public class LuceneTokenContext implements TokenContext {

    private IndexReader ir;
    private String field;

    public LuceneTokenContext(Directory directory, String field) throws IOException {
        ir = IndexReader.open(directory);
        this.field = field;
    }

    public int getTokenFrequency(String token) throws IOException {
        return ir.docFreq(new Term(field, token));
    }

    public void close() throws IOException {
        ir.close();
    }

    @Override
    protected void finalize() throws Throwable {
        close();
    }
}
