package org.apache.lucene.search.spell;

import java.util.LinkedList;
import java.util.Map;
import java.util.Map.Entry;
import java.io.IOException;

public interface TokenContext {


    public abstract int getTokenFrequency(String token) throws IOException;

    public abstract void close() throws IOException;

}