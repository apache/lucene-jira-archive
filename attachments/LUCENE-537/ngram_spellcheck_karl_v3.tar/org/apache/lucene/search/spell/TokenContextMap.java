package org.apache.lucene.search.spell;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.TermFreqVector;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.Directory;

import java.io.IOException;
import java.io.Serializable;
import java.util.*;
import java.util.Map.Entry;

public class TokenContextMap implements Serializable, TokenContext {

    private static final long serialVersionUID = 1l;

    private Map<String, Integer> frequenciesByToken;

    public TokenContextMap() {
        this(5000);
    }

    public TokenContextMap(int size) {
        frequenciesByToken = new HashMap<String, Integer>(size);
    }

    private boolean dirty = true;
    private transient LinkedList<Map.Entry<String, Integer>> entriesOrderedByFrequency;

    public synchronized final LinkedList<Map.Entry<String, Integer>> getEntriesOrderedByFrequency() {
        if (dirty || entriesOrderedByFrequency == null) {
            entriesOrderedByFrequency = new LinkedList<Map.Entry<String, Integer>>(frequenciesByToken.entrySet());
            Collections.sort(entriesOrderedByFrequency, new Comparator<Map.Entry<String, Integer>>() {
                public int compare(Entry<String, Integer> arg0, Entry<String, Integer> arg1) {
                    return arg0.getValue().compareTo(arg1.getValue());
                }

            });
            dirty = false;
        }
        return entriesOrderedByFrequency;
    }

    /* (non-Javadoc)
      * @see org.apache.lucene.search.spell.TokenFrequencyVector#getWeight(java.lang.String)
      */
    public int getTokenFrequency(String token) {
        Integer ret = frequenciesByToken.get(token);
        if (ret == null) {
            ret = 0;
        }
        return ret;
    }

    /* (non-Javadoc)
      * @see org.apache.lucene.search.spell.TokenFrequencyVector#increaseWeight(java.lang.String)
      */
    public final int increaseFrequency(String token) {
        return increaseFrequency(token, 1);
    }

    /* (non-Javadoc)
      * @see org.apache.lucene.search.spell.TokenFrequencyVector#increaseWeight(java.lang.String, long)
      */
    public final synchronized int increaseFrequency(String token, int amount) {
        Integer ret = frequenciesByToken.get(token);
        if (ret == null) {
            ret = amount;
        } else {
            ret += amount;
        }
        frequenciesByToken.put(token, ret);
        dirty = true;
        return ret;
    }

    public void close() throws IOException {
        frequenciesByToken.clear();
    }

    public static TokenContextMap factory(Directory dir, Query query, String field) throws IOException {
        TokenContextMap ret = new TokenContextMap();
        IndexSearcher searcher = new IndexSearcher(dir);
        Hits hits = searcher.search(query);
        IndexReader ir = IndexReader.open(dir);
        for (int i = 0; i < hits.length(); i++) {
            TermFreqVector tfv = ir.getTermFreqVector(hits.id(i), field);
            if (tfv != null) {
                String[] terms = tfv.getTerms();
                if (terms != null) {           // overkill?
                    for (String s : terms) {
                        ret.increaseFrequency(s);
                    }
                }
            }
        }
        ir.close();
        searcher.close();
        return ret;
    }

}
