package org.apache.lucene.search.spell;

import java.io.IOException;

/**
 * User: kalle
 * Date: 2006-mar-31
 * Time: 04:26:02
 *
 * Treats a bunch of TokenFrequencyVector:s as one. I.e. span spell check over multiple contexts.
 */
public class MultiTokenContext implements TokenContext {

    private Iterable<TokenContext> vectors;

    public MultiTokenContext(Iterable<TokenContext> vectors) {
        this.vectors = vectors;
    }

    public int getTokenFrequency(String token) throws IOException {
        int ret = 0;
        for (TokenContext v : vectors) {
            if (v != null) {
                Integer tmp = v.getTokenFrequency(token);
                if (tmp != null) {
                    ret += tmp;
                }
            }
        }

            return ret;

    }

    public void close() throws IOException {
        for (TokenContext v : vectors) {
            v.close();
        }
    }

    @Override
    protected void finalize() throws Throwable {
        close();
        super.finalize();
    }
}
