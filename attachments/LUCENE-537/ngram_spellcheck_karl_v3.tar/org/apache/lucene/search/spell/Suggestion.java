package org.apache.lucene.search.spell;

import java.io.Serializable;

/**
 * Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 *  SuggestWord Class
 *  used in suggestSimilat method in SpellChecker class
 *  @author Nicolas Maisonneuve
 */
 public final class Suggestion implements Serializable  {

    private static final long serialVersionUID = 1l;
    
    /**
     * the score of the word
     */
    private float score;


    /**
     * The freq of the word
     */
    private int freq;


    /**
     * the suggested word
     */
    private String suggestion;


    
    
    
    public Suggestion(float score, int freq, String string) {
		this.score = score;
		this.freq = freq;
		this.suggestion = string;
	}
    
    public Suggestion() {		
	}


    


	public final int getFreq() {
		return freq;
	}

	public final void setFreq(int freq) {
		this.freq = freq;
	}

	public final float getScore() {
		return score;
	}

	public final void setScore(float score) {
		this.score = score;
	}

	public final String getSuggestion() {
		return suggestion;
	}

	public final void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}

	public final int compareTo (Suggestion a) {
        //first criteria: the edit distance
        if (score>a.score) {
            return 1;
        }
        if (score<a.score) {
            return-1;
        }

        //second criteria (if first criteria is equal): the popularity
        if (freq>a.freq) {
            return 1;
        }

        if (freq<a.freq) {
            return-1;
        }

        return 0;
    }
	
	/**
	 * 
	 */
	public boolean equals(Object o) {
		if (o == null || !(o instanceof Suggestion)) {
			return false;
		}
		Suggestion s = (Suggestion)o;
		if (this == s || s.getSuggestion().equals(suggestion)) {
			return true;
		}
		return false;
	}
}
