/*
 * TestRanking.java
 *
 * Created on December 12, 2004, 3:57 PM
 */

package com;

import java.io.IOException;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.queryParser.DistributingMultiFieldQueryParser;
import org.apache.lucene.queryParser.MultiFieldQueryParser;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Similarity;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;

/**
 * Demonstration of Lucene problems with ranking queries that search multiple fields, and solution of these
 * problems with MaxDisjunctionQuery and a distributed multi-field query parser.
 * @author Williams
 */
public class TestRanking {
    
    // Run the test, printing all results to System.out  
    public static void main(String[] args) throws ParseException, IOException {
          Directory directory = new RAMDirectory();
          // 1.  Use a custom similarity to eliminate all tf and idf effects, just to isolate what is being tested.
          Similarity similarity = new TestRankingSimilarity();
          Analyzer analyzer = new StandardAnalyzer();
          IndexWriter writer = new IndexWriter(directory, analyzer, true);
          writer.setSimilarity(similarity);
          // 2.  Create two documents doc1 and doc2, each with two fields title and description.
          //     doc1 has "elephant" in title and "elephant" in description.
          //     doc2 has "elephant" in title and "albino" in description.
          Document doc1 = new Document();
          doc1.add(Field.Text("title", "elephant"));
          doc1.add(Field.Text("description", "elephant"));
          writer.addDocument(doc1);
          Document doc2 = new Document();
          doc2.add(Field.Text("title", "elephant"));
          doc2.add(Field.Text("description", "albino"));
          writer.addDocument(doc2);
          writer.close();
          // 3.  Express query for "albino elephant" against both fields.  Problems:
          String base = "albino elephant";
          String expanded = "title:albino description:albino title:elephant description:elephant";
          Query multiFieldedQuery = MultiFieldQueryParser.parse(base, new String[]{"title", "description"}, analyzer);
          Query expandedQuery = QueryParser.parse(expanded, "default", analyzer);
          Query simpleDistributedQuery = DistributingMultiFieldQueryParser.parse(base, new String[]{"title", "description"},
                                                                                       new float[]{1.0f, 1.0f}, analyzer);
          Query distributedQuery = DistributingMultiFieldQueryParser.parse(base, new String[]{"title", "description"},
                                                                                 new float[]{4.0f, 1.0f}, analyzer);
          IndexSearcher searcher = new IndexSearcher(directory);
          searcher.setSimilarity(similarity);
          System.out.print("MultiFieldQueryParser:  ");
          //     a.  MultiFieldQueryParser won't recognize either document as containing both terms,
          //         due to the way it expands the query across fields.
          showHits(multiFieldedQuery, searcher);
          System.out.print("Simple Query Expansion:  ");
          //     b.  Expressing query as "title:albino description:albino title:elephant description:elephant"
          //         will score both documents equivalently, since each matches two query terms.
          showHits(expandedQuery, searcher);
          System.out.print("Simplified DistributedMultiFieldQueryParser:  ");
          // 4.  Comparison to MaxDisjunctionQuery and my method for expanding queries across fields.
          //     This will recognize that doc2 has both terms matched while doc1 only has 1 term matched, score doc2 over doc1.
          showHits(simpleDistributedQuery, searcher);
          System.out.print("DistributedMultiFieldQueryParser:  ");
          // Above simplified form used no field boosting just to show this is not required for to solve the fundamental problem.
          // More realistically, I use field boosting to make title matches more important than descriptions, as this shows.
          showHits(distributedQuery, searcher);
          searcher.close();
          // REFINEMENT:  Add a third document doc3 with elephant in title and both albino and elephant in description.
          //              All techniques will recognize this as best since it matches more terms.
          //              Only MaxDisjunctionQuery continues to properly differentiate doc1 and doc2.
          //              The purpose of the ~0.1 is to ensure that MaxDisjunctionQuery also recognizes doc3 as best, i.e. pure
          //              max would lose the fact of additional matches, while pure some loses the advantage of covering more terms.
          //              So, MaxDisjunctionQuery uses a hybrid that captures both effects.
          IndexWriter writer2 = new IndexWriter(directory, analyzer, false);
          writer2.setSimilarity(similarity);
          Document doc3 = new Document();
          doc3.add(Field.Text("title", "elephant"));
          doc3.add(Field.Text("description", "albino elephant"));
          writer2.addDocument(doc3);
          writer2.close();
          IndexSearcher searcher2 = new IndexSearcher(directory);
          searcher2.setSimilarity(similarity);
          System.out.println("\n\n+++++++++++++  REFINEMENT ++++++++++++++++\n");
          System.out.print("MultiFieldQueryParser:  ");
          showHits(multiFieldedQuery, searcher2);
          System.out.print("Simple Query Expansion:  ");
          showHits(expandedQuery, searcher2);
          System.out.print("Simplified DistributedMultiFieldQueryParser:  ");
          showHits(simpleDistributedQuery, searcher2);
          System.out.print("DistributedMultiFieldQueryParser:  ");
          showHits(distributedQuery, searcher2);
          searcher2.close();
      }
      
      public static void showHits(Query query, Searcher searcher) throws IOException {
          System.out.println(query);
          Hits hits = searcher.search(query);
          for (int i=0; i<hits.length(); i++) {
              Document doc = hits.doc(i);
              System.out.print(hits.score(i));
              System.out.print("  title:");
              System.out.print(doc.get("title"));
              System.out.print(" description:");
              System.out.println(doc.get("description"));
              System.out.println(searcher.explain(query, hits.id(i)));
              System.out.println("--------------------------");
          }
          System.out.println("*************************************************************");
      }
 
}
