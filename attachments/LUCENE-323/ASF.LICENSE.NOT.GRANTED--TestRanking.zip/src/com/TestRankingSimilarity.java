/*
 * TestRankingSimilarity.java
 *
 * Created on December 13, 2004, 10:58 AM
 */

package com;

import org.apache.lucene.search.DefaultSimilarity;

/**
 * Similarity to eliminate tf, idf and lengthNorm effects to isolate test case.
 * @author Williams
 */
public class TestRankingSimilarity extends DefaultSimilarity {
    
    /** Creates a new instance of TestRankingSimilarity */
    public TestRankingSimilarity() {
    }

    public float tf(float freq) {
        if (freq > 0.0f) return 1.0f;
        else return 0.0f;
    }

    public float lengthNorm(String fieldName, int numTerms) {
        return 1.0f;
    }

    public float idf(int docFreq, int numDocs) {
        return 1.0f;
    }

}
