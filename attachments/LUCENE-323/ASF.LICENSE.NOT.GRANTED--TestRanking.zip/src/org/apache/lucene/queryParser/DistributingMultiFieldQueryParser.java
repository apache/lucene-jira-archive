/*
 * DistributingMultiFieldQueryParser.java
 *
 * Created on December 13, 2004, 11:32 AM
 */

package org.apache.lucene.queryParser;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.MaxDisjunctionQuery;
import org.apache.lucene.search.MultiTermQuery;
import org.apache.lucene.search.PhraseQuery;
import org.apache.lucene.search.PrefixQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.RangeQuery;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.WildcardQuery;

/**
 * Version of MultiFieldQueryParser to work with MaxDisjunctionQuery.
 * Extracted from real app -- NOT COMPLETE as a Lucene QueryParser.
 * @author Williams
 */
public class DistributingMultiFieldQueryParser {
    
    /** The tieBreakerMultiplier used in the automatically generated MaxDisjunctionQuery's that search for a single term
     * in all of the default fields */
    public static float EXPANDED_FIELD_TIE_BREAKER = 0.1f;
    
    private static final String DEFAULT_FIELD = "DMFQP_DEFAULT";
    
    public static Query parse(String queryString, String[] fields, float[] boosts, Analyzer analyzer) throws ParseException {
        return expandDefaultFields(QueryParser.parse(queryString, DEFAULT_FIELD, analyzer), fields, boosts);
    }
    
    /**
     * Rewrite query such that every query term that does not specify a field searches all of the specified fields.
     * @param query the parsed query prior to field expansion of unfielded terms
     * @param fields the fields across which terms with no explicit fields should search
     * @param boosts the respective boosts for fields, in 1-1 correspondence
     * @throws ParseException if we cannot interpret the query
     * @return a new Query in which the unfielded terms will search the fields with the corresponding boosts
     */
    public static Query expandDefaultFields(Query query, String[]fields, float[] boosts) throws ParseException {
        if (query instanceof TermQuery) {
            Term t = ((TermQuery) query).getTerm();
            if (t.field().equals(DEFAULT_FIELD)) {
                String text = t.text();
                MaxDisjunctionQuery mdq = new MaxDisjunctionQuery(EXPANDED_FIELD_TIE_BREAKER);
                mdq.setBoost(query.getBoost());
                for (int i = 0; i < fields.length; i++) {
                    TermQuery tq = new TermQuery(new Term(fields[i], text));
                    tq.setBoost(boosts[i]);
                    mdq.add(tq);
                }
                return mdq;
            }
            else return query;
        }
        else if (query instanceof PhraseQuery) {
            PhraseQuery pq = (PhraseQuery)query;
            Term[] terms = pq.getTerms();
            if (terms.length == 0) return query;    // No need to expand empty phrase!
            if (terms[0].field().equals(DEFAULT_FIELD)) {
                int slop = pq.getSlop();
                MaxDisjunctionQuery mdq = new MaxDisjunctionQuery(EXPANDED_FIELD_TIE_BREAKER);
                mdq.setBoost(query.getBoost());
                for (int i=0; i<fields.length; i++) {
                    PhraseQuery npq = new PhraseQuery();
                    npq.setBoost(boosts[i]);
                    npq.setSlop(slop);
                    for (int j=0; j<terms.length; j++) {
                        npq.add(new Term(fields[i], terms[j].text()));
                    }
                    mdq.add(npq);
                }
                return mdq;
            }
            else return query;
        }
        else if (query instanceof BooleanQuery) {
            BooleanClause[] clauses = ((BooleanQuery) query).getClauses();
            BooleanQuery bq = new BooleanQuery();
            bq.setBoost(query.getBoost());
            for (int i=0; i<clauses.length; i++)
                bq.add(expandDefaultFields(clauses[i].query, fields, boosts), clauses[i].required, clauses[i].prohibited);
            return bq;
        }
        else if (query instanceof RangeQuery) {
            if (((RangeQuery)query).getField().equals(DEFAULT_FIELD))
                throw new ParseException("Range queries are meaningless without specifying a range field:  " + query.toString());
            return query;
        }
        else if (query instanceof MultiTermQuery) { // WildcardQuery or FuzzyQuery
            // ***** TODO:  MaxDisjunctionQuery vs. BooleanQuery for expansion is not clear in this case.
            // Ideally would get the disjunction of terms, put those in BooleanQuery, and then use
            // MaxDisjunctionQuery on each term to expand the fields.
            Term t = ((MultiTermQuery) query).getTerm();
            if (t.field().equals(DEFAULT_FIELD)) {
                String text = t.text();
                MaxDisjunctionQuery mdq = new MaxDisjunctionQuery(EXPANDED_FIELD_TIE_BREAKER);
                mdq.setBoost(query.getBoost());
                for (int i = 0; i < fields.length; i++) {
                    Term nt = new Term(fields[i], text);
                    Query nq;
                    if (query instanceof WildcardQuery) nq = new WildcardQuery(nt);
                    else if (query instanceof FuzzyQuery) nq = new FuzzyQuery(nt);
                    else throw new ParseException("Unknown type of MultiTermQuery:  " + query.toString());
                    nq.setBoost(boosts[i]);
                    mdq.add(nq);
                }
                return mdq;
            }
            else return query;
        }
        else if (query instanceof PrefixQuery) {
            // ***** TODO: See comment for MultiTermQuery.  Same applies here.
            Term t = ((PrefixQuery) query).getPrefix();
            if (t.field().equals(DEFAULT_FIELD)) {
                String text = t.text();
                MaxDisjunctionQuery mdq = new MaxDisjunctionQuery(EXPANDED_FIELD_TIE_BREAKER);
                mdq.setBoost(query.getBoost());
                for (int i = 0; i < fields.length; i++) {
                    Term nt = new Term(fields[i], text);
                    Query nq = new PrefixQuery(nt);
                    nq.setBoost(boosts[i]);
                    mdq.add(nq);
                }
                return mdq;
            }
            else return query;            
        }
        /* None of MaxDisjunctionQuery, PhrasePrefixQuery nor FilteredQuery should be possible results of a query string parse. */
        else throw new ParseException("UNKNOWN type of query:  " + query.getClass() + " PRINTS AS " + query.toString());
    }
 
}
