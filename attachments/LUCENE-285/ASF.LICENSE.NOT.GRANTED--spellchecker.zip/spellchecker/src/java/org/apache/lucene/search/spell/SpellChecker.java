package org.apache.lucene.search.spell;
/**
 * Copyright 2002-2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


import java.io.IOException;
import org.apache.lucene.store.Directory;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Hits;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.TermEnum;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.analysis.WhitespaceAnalyzer;

/**
 * Spell Checker inspired by the David Spencer code
 *
 * @author Nicolas Maisonneuve
 * @version 1.0
 */
public class SpellChecker {

    /**
     * Field name for each word in the ngram index.
     */
    public static final String F_WORD="word";


    /**
     * Store transpositions too.
     */
    public static final String F_TRANSPOSITION="transposition";


    /**
     * the gram index
     */
    Directory gramindex;


    /**
     * the min number of chars to form ngrams with (3 is suggested)
     */public int ng1=3;


    /**
     * the max number of chars to form ngrams with, can be equal to ng1
     */
    public int ng2=4;


    /**
     * Boost value for start and end grams
     */
    public float bStart=2.0f;
    public float bEnd=1.0f;


    /**
     * Max Edit distance allow
     */
    final int maxd=5;


    public void setSpellIndex (Directory gramindex) {
        this.gramindex=gramindex;
    }


    public SpellChecker (Directory gramIndex) {
        this.setSpellIndex(gramIndex);
    }


    /**
     * Suggest similar words
     * @param word String the word you want a spell check done on
     * @param num_sug int the number of suggest words
     * @throws IOException
     * @return String[]
     */
    public String[] suggestSimilar (String word, int num_sug) throws IOException {
        return this.suggestSimilar(word, num_sug, null, null, false);
    }


    /**
     * Suggest similar words (restricted or not of a field of a user index)
     * @param word String the word you want a spell check done on
     * @param num_sug int the number of suggest words
     * @param IndexReader the indexReader of the user index (can be null see field param)
     * @param field String the field of the user index: if field is not null ,the suggest
     * words are restricted to the words present in this field.
     * @param morePopular boolean return only the suggest words that are more frequent than the searched word
     * (only if restricted mode = (indexReader!=null and field!=null)
     * @throws IOException
     * @return String[] the sorted list of the suggest words with this 2 criteri
     * first criteria : the edit distance, second criteria (only if restricted mode): the popularity
     * of the suggest words in the field of the user index
     */
    public String[] suggestSimilar (String word, int num_sug, IndexReader ir, String field
    , boolean morePopular) throws IOException {

        final TRStringDistance sd=new TRStringDistance(word);

        int goalFreq=(morePopular&&ir!=null)?ir.docFreq(new Term(field, word)):0;
        if (!morePopular&&goalFreq>0) {
            return new String[] {
            word}; // return the word if it exist in the index and i don't want a more popular word
        }

        BooleanQuery query=new BooleanQuery();
        String[] grams;
        String key;
        for (int ng=ng1; ng<=ng2; ng++) {

            key="gram"+ng; // form key

            grams=formGrams(word, ng); // form word into ngrams (allow dups too)

            if (grams.length==0) {
                continue; // hmm
            }

            if (bStart>0) { // should we boost prefixes?
                add(query, "start"+ng, grams[0], bStart); // matches start of word

            }
            if (bEnd>0) { // should we boost suffixes
                add(query, "end"+ng, grams[grams.length-1], bEnd); // matches end of word

            }
            for (int i=0; i<grams.length; i++) {
                add(query, key, grams[i]);
            }

        }

        IndexSearcher searcher=new IndexSearcher(this.gramindex);
        Hits hits=searcher.search(query);
        SuggestWordQueue sugqueue=new SuggestWordQueue(num_sug);

        int stop=Math.min(hits.length(), 100*num_sug); // go thru more than 'maxr' matches in case the distance filter triggers
        SuggestWord sugword=new SuggestWord();
        for (int i=0; i<stop; i++) {

            sugword.string=hits.doc(i).get(F_WORD); // get orig word)

            if (sugword.string==word) {
                continue; // don't suggest a word for itself, that would be silly
            }

            sugword.dist=sd.getDistance(sugword.string);

            if (maxd>0&&sugword.dist>maxd) {
                continue;
            }

            if (ir!=null) { // use the user index
                sugword.freq=ir.docFreq(new Term(field, sugword.string)); // freq in the index
                if ((morePopular&&goalFreq>sugword.freq)||sugword.freq<1) { // don't suggest a word that is not present in the field
                    continue;
                }
            }
            sugqueue.insert(sugword);
            sugword=new SuggestWord();
        }

        // convert to array string
        String[] list=new String[sugqueue.size()];
        int i=0;
        while (sugqueue.size()>0) {
            list[i]=((SuggestWord) sugqueue.pop()).string;
            i++;
        }

        searcher.close();
        return list;
    }


    /**
     * Add a clause to a boolean query.
     */
    private static void add (BooleanQuery q, String k, String v, float boost) {
        Query tq=new TermQuery(new Term(k, v));
        tq.setBoost(boost);
        q.add(new BooleanClause(tq, false, false));
    }


    /**
     * Add a clause to a boolean query.
     */
    private static void add (BooleanQuery q, String k, String v) {
        q.add(new BooleanClause(new TermQuery(new Term(k, v)), false, false));
    }


    /**
     * Form all ngrams for a given word.
     * @param text the word to parse
     * @param ng the ngram length e.g. 3
     * @return an array of all ngrams in the word and note that duplicates are not removed
     */
    private static String[] formGrams (String text, int ng) {
        int len=text.length();
        String[] res=new String[len-ng+1];
        for (int i=0; i<len-ng+1; i++) {
            res[i]=text.substring(i, i+ng);
        }
        return res;
    }


    public void clearIndex () throws IOException {
        IndexReader.unlock(gramindex);
        IndexWriter writer=new IndexWriter(gramindex, new WhitespaceAnalyzer(), true);
        writer.close();
    }


    /**
     * add all keywords of a specified field in a index
     * @param ir IndexReader the user index
     * @param field String the field to extract keyword
     * @throws IOException
     */
    public void addWords (IndexReader ir, String field) throws IOException {
        int minThreshold=5;

        boolean create=!IndexReader.indexExists(gramindex);
        IndexWriter writer=new IndexWriter(gramindex, new WhitespaceAnalyzer(), create);
        IndexReader gramr=IndexReader.open(gramindex);

        final TermEnum enum=ir.terms(new Term(field, ""));
        while (enum.next()) {
            Term t=enum.term();
            String fieldt=t.field();
            if (fieldt!=field) {
                break;
            }
            /*
                         int df=enum.docFreq();
                         if (df<minThreshold) {
                continue;
                         }
             */
            String text=t.text();
            int len=text.length();
            if (len<ng1) {
                continue; // too short we bail but "too long" is fine...
                // but note that long tokens that are rare prob won't get here anyway as they won't
                // pass the 'minThreshold' check above
            }

            if (gramr.docFreq(new Term(F_WORD, text))>0) {
                continue; // if the word already exist in the gramindex
            }

            // ok add document to the gram index
            Document doc=createDocument(text, ng1, ng2);
            writer.addDocument(doc);
        }
        writer.optimize();
        writer.close();
        gramr.close();
    }


    private static Document createDocument (String text, int ng1, int ng2) {
        Document doc=new Document();
        doc.add(Field.Keyword(F_WORD, text)); // orig term
        addTranspositions(text, doc);
        addGram(text, doc, ng1, ng2);
        return doc;
    }


    private static void addTranspositions (String s, Document doc) {
        int len=s.length();
        for (int i=0; i<(len-1); i++) {
            char c1=s.charAt(i);
            char c2=s.charAt(i+1);
            if (c1!=c2) {
                doc.add(Field.Keyword(F_TRANSPOSITION, s.substring(0, i)+c2+c1+s.substring(i+2)));
            }
        }
    }


    private static void addGram (String text, Document doc, int ng1, int ng2) {
        int len=text.length();
        for (int ng=ng1; ng<=ng2; ng++) {
            String key="gram"+ng;
            String end=null;
            for (int i=0; i<len-ng+1; i++) {
                String gram=text.substring(i, i+ng);
                doc.add(Field.Keyword(key, gram));
                if (i==0) {
                    doc.add(Field.Keyword("start"+ng, gram));
                }
                end=gram;
            }
            if (end!=null) { // may not be present if len==ng1
                doc.add(Field.Keyword("end"+ng, end));
            }
        }
    }


}
