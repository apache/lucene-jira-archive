README.txt
==========

This is the source distribution of kuromoji-solr.

A distribution can be built using

  % mvn package

Please see dist/README.txt for instructions for integrating
Kuromoji with Apache Solr.
