package org.atilika.kuromoji.solr;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.io.Reader;
import java.util.Map;

import org.apache.lucene.analysis.Tokenizer;
import org.apache.solr.analysis.BaseTokenizerFactory;
import org.apache.solr.common.SolrException;
import org.atilika.kuromoji.Tokenizer.Mode;

public class KuromojiTokenizerFactory extends BaseTokenizerFactory{
	private static final String MODE = "mode";

	private static final String USER_DICT_PATH = "user-dictionary";

	private  org.atilika.kuromoji.Tokenizer tokenizer;

	@Override
	public void init(Map<String,String> args) {
		this.args = args;
		Mode mode = args.get(MODE) != null ? Mode.valueOf(args.get(MODE).toUpperCase()) : Mode.NORMAL;
		String userDictionaryPath = args.get(USER_DICT_PATH);
		try {
			this.tokenizer = org.atilika.kuromoji.Tokenizer.builder().mode(mode).userDictionary(userDictionaryPath).build();
		} catch (Exception e) {
			throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, e);
		}
	}

	@Override
	public Tokenizer create(Reader input) {
		try {
			return new KuromojiTokenizer(tokenizer, input);
		} catch (IOException e) {
			throw new SolrException(SolrException.ErrorCode.SERVER_ERROR, e);
		}
	}

}
