How to install OJVMDirectory implementation
-------------------------------------------
- Unpack or checkout Lucene sources.

- Unpack or checkout OJVM sources.

- Copy to $LUCENE_ROOT/contrib
  # cd $LUCENE_ROOT/contrib
  # cp -rp $OJVM_ROOT .
  
- Edit $LUCENE_ROOT/build.xml adding a target for creating a jar file with test sources.
  <target name="jar-test" depends="compile-test">
    <jar
      destfile="${build.dir}/${final.name}-test.jar"
      basedir="${build.dir}/classes/test"
      excludes="**/*.java"
      />
  </target>
  
- Update Lucene's BufferedIndexInput.BUFFER_SIZE according to your DB Block size
  Before compile and upload Lucene core library you can change org.apache.lucene.store.BufferedIndexInput.BUFFER_SIZE
  constant to the value of your db_block_size init parameters, this change will improve reading
  performance by using same block size as the physical block size that your database use.
  
- Put JUnit library into $ANT_HOME/lib, we tested this source with junit-3.8.2.jar

- Run Ant's target:
  # cd $LUCENE_ROOT
  # ant clean
  # ant jar-core
  # ant jar-test
  # cd contrib/snowball/
  # ant jar-core

- Install OJVM required libraries on $LUCENE_ROOT/contrib/ojvm/lib  
  CartridgeServices.jar
  ODCI.jar
  ojdbc14.jar
  xdb.jar
  xmlparserv2.jar
  aurora.zip
  These libraries are into $ORACLE_HOME

- Compile OJVM Directory
  # cd $LUCENE_ROOT/contrib/ojvm
  # ant jar-core
  # ant jar-test
- Edit your ~build.properties file with your Database values:
db.str=orcl
db.usr=LUCENE
db.pwd=LUCENE
dba.usr=sys
dba.pwd=change_on_install
javac.debug=true
javac.source=1.4
javac.target=1.4

  db.str is your SQLNet connect string for your target database, check first with tnsping
- Upload your code to the database
  # ant install-ojvm
  # ant test-domain-index

- For Oracle 10g is strongly recommended that use the target ncomp as:
  # ant ncomp-ojvm
  # ant test-domain-index
  This target perform native compilation of Lucene Core, Snowball and OJVMDirectory libraries
  NCOMPing these classes means translate it to C and creates shared libraries (.dll or .so)
  there are a lot of performance improvement with this version.
  
- For Oracle 11g you can perform a post-installation step:
  # ant jit-lucene-classes
  This target force to translate all Lucene, Snowball and OJVMDirectory classes to assembler.
  Instead of waiting that the database compile it by detecting most used classes or method.
  
- This target will create a LUCENE oracle user and install everything on this schema

Usage examples
--------------
- Lucene Domain Index syntax examples using these table definitions:
create table t1 (
f1 number,
f2 varchar2(200),
f3 varchar2(200),
f4 number unique);

create table t2 (
f5 number primary key,
f6 varchar2(200), 
f7 date,
CONSTRAINT t2_t1_fk FOREIGN KEY (f5)
      REFERENCES t1(f4) ON DELETE cascade);

1) Simple Index
     create index it1 on t1(f2) indextype is lucene.LuceneIndex 
         parameters('Analyzer:org.apache.lucene.analysis.SimpleAnalyzer');
Create a domain index on table t1 column f2 using SimpleAnalyzer as Lucene Analyzer.
After this DDL command is execute two new tables, one AQ queue and one index are at user's schema,
name it1$.T, it1$QT, it1$Q and it1$DI respectively.

2) Simple Index with extra parameters
     create index it1 on t1(f2) indextype is lucene.LuceneIndex 
        parameters('Stemmer:English');
Create a domain index on table t1 column f2 using English Stemmer.

3) Alter Index
     alter index it1 
        parameters('UserDataStore:org.apache.lucene.indexer.DefaultUserDataStore');
     alter index it1 
        parameters('ExtraCols:t1.f3,t1.f4,t2.f6,t2.f7;ExtraTabs:t2;WhereCondition:t1.f4=t2.f5;FormatCols:t1.f4(000),t2.f7(day)');
Modify above index declaration adding more lookup columns and tables also selecting 
padding to 000 on t1.f4 and day resolution for t2.f7.
Lucene Index will contains columns:
    F2: default column index on table t1 (Note capital name selected by Oracle)
    t1.f3,t1.f4: two extra columns from table t1, t1.f4 padded to 000
    t2.f6,t2.f7: two extra columns from table t2, t2.f7 rounded to day
During the index full scan or update a query like this is executed:
    select T1.F2,t1.f3,t1.f4,t2.f6,t2.f7 from T1,t2 where t1.f4=t2.f5;
Note that ExtraTabs is concatenated with T1 and a where condition to perform the join is added.
To detect modification on columns not included on the main index declaration a trigger is needed:
CREATE OR REPLACE TRIGGER L$IT1
BEFORE UPDATE OF f3,f4 ON t1
FOR EACH ROW
BEGIN
      :new.f2 := :new.f2;
END;
/

   alter index it1 
      parameters('MaxBufferedDocs:500');
Change Lucene index parameter MaxBufferedDocs, other Lucene Index Writer parameter defined are:
MergeFactor
MaxBufferedDocs
MaxMergeDocs
MaxBufferedDeleteTerms
UseCompoundFile (true|false)
FormatCols a coma separated list of columnName(fmt) where fmt can be:
0000 left padding for numbers,  default is 0000000000
xxxxx left padding for VARCHAR2, default is null, no left padding
day,year,.... rounding for DATE/TIMESTAMP, default is day
XPath expr, for XMLType columns this will be evaluated as obj.extract(XPathExpr) 
where obj is an XMLType java object, default is null no XPath evaluation.
LobStorageParameters default "PCTVERSION 0 ENABLE STORAGE IN ROW CACHE READS NOLOGGING"
See Lucene and BLOB documentation for more details, 
Example LOB 11g syntax:
  "PCTVERSION 0 ENABLE STORAGE IN ROW CHUNK 32768 CACHE READS FILESYSTEM_LIKE_LOGGING"

   alter index it1 
      parameters('~MaxBufferedDocs:500');
Drops MaxBufferedDocs preference from the index parameters list


Synchronizing Domain Index changes:
  begin
    LuceneDomainIndex.sync(USER||'.IT1');
  end;
Apply pending changes such as insert,update on master or lookup columns.
Note: Delete operation are not queued.
Note: By default index name are capitalized

Domain Index Optimization:
  begin
    LuceneDomainIndex.optimize(USER||'.IT1');
  end;
Optimize Lucene Index.

Query syntax examples:
   select lscore(1),f2,f3 from t1 where lcontains(f2, 'ravi AND t1.f3:modified',1) > 0;
Find rows which have 'ravi' on t1.f2 column and 'modified' on t1.f3

   select lscore(1),f2,f3 from t1 where lcontains(f2, 'ravi AND t2.f7:20070815',1)>0;
Find rows which have 'ravi' on t1.f2 column and t2.f7 is equal to 20070815.
Note: Columns of time Date or Timestamp are automatically indexed using Lucene DateTools utility
rounded to Day.
For the above query no join operation and filter operation are required on table t2, this
operations are resolved inside Lucene Index and direct lookup by rowid is performed on t1 table.

   select lscore(1),f2,f3,f6,f7 from t1,t2 
     where lcontains(f2, 'ravi AND t2.f7:[20070815 TO 20070830]',1)>0
     and t1.f4=t2.f5;
Find rows which have 'ravi' on t1.f2 column and date from 20070815 to 20070830 on column t2.f7
Again no filter and join operation are performed on t2 table to evaluate lcontains operator
t1.f2 and t2.f7 columns are inside Lucene Index and Lucene performs these operations.
Once a set of rowids are complaints with lcontains operator then t1 rows are located
by rowid and t2 table is joined with these rows using his primary key.

   select /*+ DOMAIN_INDEX_SORT */ lscore(1),f2,f4 from t1 
     where lcontains(f2,'Ravi OR t1.f4:[103 TO 107]',1)>0 order by lscore(1) asc;
Find rows which have 'ravi' on column t1.f2 and t1.f4 in a range 103 to 107.
DOMAIN_INDEX_SORT hint tell to the optimizer that the sort order returned by
Lucene Domain Index lscore function is the expected order, so no sort by operation
is performed in memory.
Lucene support ascending and descending order based on document score, descending
order is by default, so document with highest score are returned first.

Index Sync Mode:
By now only OnLine and Deferred modes are supported, for example:
     alter index it1 
       parameters('SyncMode:OnLine');
Enable OnLine mode synchronization of the Lucene Index, it means that after each DML
operation which affects the master column of the index, a LuceneDomainIndex.sync is executed.
To do this an AQ message callback is enable at IDX$Q queue, so the index changes are
automatically synchronized when a user commit the changes.

     alter index it1 
       parameters('~SyncMode:OnLine');
Disable OnLine mode, and the AQ callback is unregisterd.
By default Lucene Index works in Deferred mode which means you has to manually call
to LuceneDomainIndex.sync('LUCENE.IT1') to see insert/update changes on rows, delete
operations are always synced.

Synchronization of extra columns
OnLine mode sync is only attached to the master column of the index, if you want to
see rows changes automatically on Lucene Index you has to create triggers for doing that.
For example, for these two tables:
    create table t1 (
        f1 number,
        f2 varchar2(200),
        f3 varchar2(200),
        f4 number unique);
    create table t2 (
        f5 number primary key,
        f6 varchar2(200), 
        f7 date,
        CONSTRAINT t2_t1_fk FOREIGN KEY (f5)
        REFERENCES t1(f4) ON DELETE cascade);
and an index created as:
    create index it1 on t1(f2) indextype is lucene.LuceneIndex 
        parameters('Stemmer:English;SyncMode:Online');
    alter index it1 
        parameters('ExtraCols:t1.f3,t1.f4,t2.f6,t2.f7;ExtraTabs:t2;WhereCondition:t1.f4=t2.f5(+)');
You can create these triggers to automatically update Lucene Index on changes of
extra columns of the base table and extra columns of the satellite table.
A trigger for detecting changes on extra columns of the master table can be:
    CREATE OR REPLACE TRIGGER L$IT1
    BEFORE UPDATE OF f3,f4 ON t1
    FOR EACH ROW
    BEGIN
        :new.f2 := :new.f2;
    END;
Trigger for detecting changes on satellite table:
    CREATE OR REPLACE TRIGGER LT$IT1
    AFTER UPDATE OF f6,f7 ON t2
    FOR EACH ROW
    DECLARE
        ridlist sys.ODCIRidList;
    BEGIN
        SELECT ROWID 
           BULK COLLECT INTO ridlist
           FROM T1 WHERE F4=:NEW.f5;
        LuceneDomainIndex.enqueueChange(USER||'.IT1',ridlist,'update');
    END;
First trigger only signal to Oracle Database that f2 column (master column of the index)
has changed, so Oracle will call to ODCIUpdate Data Catridge API.
Second trigger is bit complex, because we need to find which rows of the master
table are affected, for doing this a select operation is needed to get a list of
rowids changed, this list of rowids is enqueued on Lucene Domain index queue pending
changes given a fully qualify index name, the rowid and the operation.
Note that delete operation are not signaled because will be automatically deleted
by the constraint.
Also a table level trigger is required to apply all pending changes on the master
table after the enqueue row level operations.
At the index definition we use an Outer Join syntax on the where condition, this
is because this example is not typically master detail definition, so at the time
of the row insertions on T1 table some rows on T2 can not be defined yet.

A master detail example is showed here:
    create table t2 (
        f4 number primary key,
        f5 VARCHAR2(200));
    create table t1 (
        f1 number, 
        f2 CLOB, 
        f3 number,
        CONSTRAINT t1_t2_fk FOREIGN KEY (f3)
        REFERENCES t2(f4) ON DELETE cascade);
Index definition:
    create index it1 on t1(f3) indextype is lucene.LuceneIndex 
        parameters('SyncMode:OnLine;ExtraCols:f2,t2.f5;ExtraTabs:t2;WhereCondition:t1.f3=t2.f4');
Note that OnLine mode is activated because we choose f3 as master column and f2
as extra columns.
To get the index synced we defined this trigger:
    CREATE OR REPLACE TRIGGER LT$IT1
    AFTER UPDATE OF f5 ON t2
    FOR EACH ROW
    DECLARE
        ridlist sys.ODCIRidList;
    BEGIN
        SELECT ROWID 
           BULK COLLECT INTO ridlist
           FROM T1 WHERE F3=:NEW.f4;
        LuceneDomainIndex.enqueueChange(USER||'.IT1',ridlist,'update');
    END;

Note that a trigger for detecting changes on f2 is not created because is CLOB column,
you has to manually signal to Data Catridge API the changes, for example:
    UPDATE t1 SET f2 = 'Nipun', f3 = f3 WHERE f1 = 3;
Here we are updating f2, but f3 is assigned with his own value to propagate the change
on Lucene Domain Index.
This example where the master index column is not the expected column for regular queries
requires that the column name must be specific designed on lcontains operator, for example:
    select lscore(1),f2 from t1 where lcontains(f3, 'f2:ravi',1) > 0;


Count Hits function
-------------------

LuceneDomainIndex.countHits(idx,qry,order)
  
  This function should be used for replacing select count(*) where lcontains()..
  Count Hits 3 parameters:
  Full qualified Index Name, for example SCOTT.SOURCE_BIG_LIDX
  Query Parser string, for example "procedure OR function" without our extension for rownum
  Sorting, "ASC" or "DESC" these values doesn't affect count operation but are important if
  you will use the same Query in a:
      select /*+ DOMAIN_INDEX_SORT */ ... where lcontains(col,qry,1) order lscore(1) DESC;
  DML because if qry and ASC|DESC combination are equals between countHits and lcontains/lscore
  a Lucene Hits structure will be cached and not re-executed.

Inline pagination
-----------------
  You can select an specific window (pagination) of your query injecting a Query Parser like
  range query inside lcontains() operator. For example:
      select /*+ DOMAIN_INDEX_SORT */ ... where lcontains(col,'rownum:[20 TO 40] AND word1',1) order lscore(1) DESC;
  Lucene Domain Index implementation will extract automatically the pagination information
  rownum:[n TO m] AND from the beginning of the query syntax and return to the Oracle optimizer
  a subset to 20 rowids. This extension provide a lot of performance improvement by eliminating
  the needs of use Oracle's Top-N syntax which need to collect all rowids and then filter to calculate
  the window.
  
Known caveats
-------------
1) User who want to create index requires:
   grant execute on dbms_aq to scott;
This grant is required for enqueue/dequeue changes on the Queue asociated
to the Lucene Domain Index.
2) SyncMode:OnLine should be reserved only for index which a number of update/insert operation 
are too small compared to delete/select operations, because each message process requires almost open
and IndexWriter/IndexReader on the associated Lucene Index by a background process, except for
bulk collect operation or "insert into ... select ... from" which are processed in bacth on 150 rows.
Tables with many insert/update operations by seconds should be use LuceneDomainIndex.sync(idx) procedure
called by DBMS_JOB periodically.
3) Syntax for Inline pagination is only supported at the beginning of the Query, it means that if you
want to perform pagination lcontains() query syntax must be start with "rownum:[n TO m] AND" note that
this syntax is case sensitive. Also this extraction is performed by spliting the query by position and
does not take into account grouping operator, so this query "rownum:[1 TO 10] AND word1 OR word2" will
be passed to Lucene's Query Parser as "word1 OR word2" which is not semantically the original one if you
look precedence operator. We can try to modify Query Parser class to solve this semantic issues.