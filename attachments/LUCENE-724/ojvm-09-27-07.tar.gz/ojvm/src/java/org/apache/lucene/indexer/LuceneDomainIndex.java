package org.apache.lucene.indexer;

import java.io.IOException;

import java.math.BigDecimal;

import java.sql.Connection;
import java.sql.SQLException;

import java.util.HashMap;
import java.util.Hashtable;

import oracle.ODCI.ODCIEnv;
import oracle.ODCI.ODCIIndexCtx;
import oracle.ODCI.ODCIIndexInfo;
import oracle.ODCI.ODCIPredInfo;
import oracle.ODCI.ODCIQueryInfo;
import oracle.ODCI.ODCIRidList;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.driver.OracleConnection;

import oracle.jpub.runtime.MutableStruct;

import oracle.sql.CLOB;
import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;

import oracle.xdb.XMLType;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.snowball.SnowballAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryWrapperFilter;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.store.OJVMUtil;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

 /**
  * A Data Catridge API implementation.
  *
  * @version $Id: LuceneDomainIndex.java,v 1.13 2007/09/27 12:19:03 mochoa Exp $
  * @author Marcelo F. Ochoa
  */
public class LuceneDomainIndex implements CustomDatum, CustomDatumFactory {
    static final String enableCallBackStmt = 
        "call LuceneDomainIndex.enableCallBack(?)";

    static final String disableCallBackStmt = 
        "call LuceneDomainIndex.disableCallBack(?)";

    static final String crtLuceneTableStmt = 
        "call LuceneDomainIndex.createTable(?,?)";

    static final String drpLuceneTableStmt = 
        "call LuceneDomainIndex.dropTable(?)";

    static final String crtLuceneQueueStmt = 
        "call LuceneDomainAdm.createQueue(?)";

    static final String drpLuceneQueueStmt = 
        "call LuceneDomainAdm.dropQueue(?)";

    static final String purgueLuceneQueueStmt = 
        "call LuceneDomainAdm.purgueQueue(?)";

    public static final String _SQL_NAME = "LUCENE.LUCENEDOMAININDEX";

    public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

    static final java.math.BigDecimal SUCCESS = new java.math.BigDecimal("0");

    static final java.math.BigDecimal ERROR = new java.math.BigDecimal("1");

    static final int TRUE = 1;

    static final int FALSE = 0;

    static int[] _sqlType = { 4 };


    /**
     * SYS.ODCIConst.QueryFirstRows
     */
    static final int QUERY_FIRST_ROWS = 1;

    /**
     * SYS.ODCIConst.QueryAllRows
     */
    static final int QUERY_ALL_ROWS = 2;

    /**
     * SYS.ODCIConst.QuerySortAsc
     */
    static final int QUERY_SORT_ASC = 4;

    /**
     * SYS.ODCIConst.QuerySortDesc
     */
    static final int QUERY_SORT_DESC = 8;

    /**
     * SYS.ODCIConst.QueryBlocking
     */
    static final int QUERY_BLOCKING = 16;

    static CustomDatumFactory[] _factory = new CustomDatumFactory[1];

    MutableStruct _struct;

    static final LuceneDomainIndex _LuceneDomainIndexFactory =
        new LuceneDomainIndex();

    public static CustomDatumFactory getFactory() {
        return _LuceneDomainIndexFactory;
    }

    /* constructor */

    public LuceneDomainIndex() {
        _struct = new MutableStruct(new Object[1], _sqlType, _factory);
    }

    /* CustomDatum interface */

    public Datum toDatum(OracleConnection c) throws SQLException {
        return _struct.toDatum((Connection)c, _SQL_NAME);
    }

    /* CustomDatumFactory interface */

    public CustomDatum create(Datum d, int sqlType) throws SQLException {
        if (d == null)
            return null;
        LuceneDomainIndex o = new LuceneDomainIndex();
        o._struct = new MutableStruct((STRUCT)d, _sqlType, _factory);
        return o;
    }

    /* shallow copy method: give object same attributes as argument */

    void shallowCopy(LuceneDomainIndex d) throws SQLException {
        _struct = d._struct;
    }

    /* accessor methods */

    public Integer getScanctx() throws SQLException {
        return (Integer)_struct.getAttribute(0);
    }

    public void setScanctx(Integer scanctx) throws SQLException {
        _struct.setAttribute(0, scanctx);
    }

    /**
     * @param ia
     * @param env
     * @return an string with the indexschema.indexname[.partitionname]
     * @throws SQLException
     */
    public static String getIndexPrefix(ODCIIndexInfo ia,
                                        ODCIEnv env) throws SQLException {
        String indexPrefix;
        if (ia.getIndexPartition() != null && env.getCallProperty() != null)
            indexPrefix =
                    ia.getIndexSchema() + "." + ia.getIndexName() + "." + ia.getIndexPartition();
        else
            indexPrefix = ia.getIndexSchema() + "." + ia.getIndexName();
        return indexPrefix;
    }

    /**
     * Invoked when a domain index or a domain index partition is altered using
     * an ALTERINDEX or an ALTER INDEX PARTITION statement.
     * @param ia Contains information about the index and the indexed column
     * @param parms Parameter string,
     *              IN: With ALTER INDEX PARAMETERS or ALTER INDEX REBUILD,
     *              contains the user specified parameter string With ALTER INDEX RENAME,
     *              contains the new name of the domain index
     *              OUT: Valid only with ALTER INDEX PARAMETERS or ALTER INDEX REBUILD;
     *              Contains the resultant string to be stored in system catalogs
     * @param option Specifies one of the following options:
     *              - AlterIndexNone if ALTER INDEX [PARTITION] PARAMETERS
     *              - AlterIndexRename if ALTER INDEX RENAME [PARTITION]
     *              - AlterIndexRebuild if ALTER INDEX REBUILD [PARTITION]
     *                [PARALLEL (DEGREE deg)] [PARAMETERS]
     *              - AlterIndexUpdBlockRefs if ALTER INDEX [schema.]index UPDATE BLOCK REFERENCES
     * @param env The environment handle passed to the routine
     * @return ODCIConst.Success on success, ODCIConst.Error on error,
     *         or ODCIConst.Warning otherwise.
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIIndexAlter(ODCIIndexInfo ia,
                                                      String[] parms,
                                                      java.math.BigDecimal option,
                                                      ODCIEnv env) throws SQLException {
        //System.out.println("Alter parms: '" + parms[0] + "' option = "+option);
        //System.out.println("ODCIIndexInfo.getIndexName: " + ia.getIndexName() +
        //                   " ODCIIndexInfo.getIndexSchema: " +
        //                   ia.getIndexSchema() +
        //                   " ODCIIndexInfo.getIndexPartition: " +
        //                   ia.getIndexPartition());
        //System.out.println("getIndexCols.length: "+ia.getIndexCols().length());
        //dumpIA(ia);
        String directoryPrefix = getIndexPrefix(ia, env);
        OJVMDirectory dir = OJVMDirectory.getDirectory(directoryPrefix);
        Parameters parameters = dir.getParameters();
        try {
            String columnName =
                ia.getIndexCols().getElement(0).getColName().replaceAll("\"",
                                                                        "");
            String columnTypeName =
                ia.getIndexCols().getElement(0).getColTypeName();
            String tableSchema =
                ia.getIndexCols().getElement(0).getTableSchema();
            String tableName = ia.getIndexCols().getElement(0).getTableName();
            String partition =
                ((ia.getIndexPartition() != null && env.getCallProperty() !=
                  null) ? ia.getIndexCols().getElement(0).getTablePartition() :
                 null);
            if (parms != null && parms[0] != null &&
                option.equals(BigDecimal.valueOf(0))) {
                String paramstr = parms[0];
                String[] parmList = paramstr.split(";");
                for (int i = 0; i < parmList.length; i++) {
                    String[] nameValue = parmList[i].split(":");
                    String name = nameValue[0];
                    String value = nameValue[1];
                    if (name.startsWith("~")) { // If parameter name start with ~ means remove it
                        if ("SyncMode".equalsIgnoreCase(name.substring(1)))
                            disableOnLineSync(directoryPrefix);
                        parameters.removeParameter(name.substring(1));
                    } else {
                        if ("SyncMode".equalsIgnoreCase(name) && "Online".equalsIgnoreCase(value))
                            enableOnLineSync(directoryPrefix);
                        parameters.setParameter(name, value);
                    }
                }
            } else
                throw new SQLException("ODCIIndexAlter error parameter is null or option not implemented.");
            parameters.setParameter("ColName", columnName);
            parameters.setParameter("TypeName", columnTypeName);
            parameters.setParameter("TableSchema", tableSchema);
            parameters.setParameter("TableName", tableName);
            parameters.setParameter("Partition", partition);
            dir.setParameters(parameters);
            //System.out.println("Parameters:\n"+parameters.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
                if (dir != null)
                    dir.close();
                dir = null;
            } catch (IOException e) {
                e.printStackTrace();
                return ERROR;
            }
        }
        return SUCCESS;
    }

    /**
     * When a user issues a CREATE INDEX statement that references the indextype,
     * Oracle calls your ODCIIndexCreate() method, passing it any parameters specified
     * as part of the CREATE INDEX... PARAMETERS (...) statement, plus the description
     * of the index.
     * Typically, this method creates the tables or files in which you plan to store
     * index data. Unless the base table is empty, the method should also build the index.
     * @param ia Contains information about the index and the indexed column
     * @param parms Parameter string,
     *              IN: With ALTER INDEX PARAMETERS or ALTER INDEX REBUILD,
     *              contains the user specified parameter string With ALTER INDEX RENAME,
     *              contains the new name of the domain index
     *              OUT: Valid only with ALTER INDEX PARAMETERS or ALTER INDEX REBUILD;
     *              Contains the resultant string to be stored in system catalogs
     * @param env The environment handle passed to the routine
     * @return ODCIConst.Success on success, ODCIConst.Error on error,
     *         or ODCIConst.Warning otherwise.
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIIndexCreate(ODCIIndexInfo ia,
                                                       String parms,
                                                       ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexWriter writer = null;
        Parameters parameters = new Parameters();
        //System.out.println("Create parms: '" + parms + "'");
        //System.out.println("ODCIIndexInfo.getIndexName: " + ia.getIndexName() +
        //                   " ODCIIndexInfo.getIndexSchema: " +
        //                   ia.getIndexSchema() +
        //                   " ODCIIndexInfo.getIndexPartition: " +
        //                   ia.getIndexPartition());
        //System.out.println("getIndexCols.length: "+ia.getIndexCols().length());
        String directoryPrefix = getIndexPrefix(ia, env);
        try {
            if (parms != null) {
                String[] parmList = parms.split(";");
                for (int i = 0; i < parmList.length; i++) {
                    String[] nameValue = parmList[i].split(":");
                    parameters.setParameter(nameValue[0], nameValue[1]);
                }
            }
            String columnName = 
                ia.getIndexCols().getElement(0).getColName().replaceAll("\"",
                                                                        "");
            String columnTypeName =
                ia.getIndexCols().getElement(0).getColTypeName();
            String tableSchema =
                ia.getIndexCols().getElement(0).getTableSchema();
            String tableName = ia.getIndexCols().getElement(0).getTableName();
            String partition =
                ((ia.getIndexPartition() != null && env.getCallProperty() !=
                  null) ? ia.getIndexCols().getElement(0).getTablePartition() :
                 null);
            parameters.setParameter("ColName", columnName);
            parameters.setParameter("TypeName", columnTypeName);
            parameters.setParameter("TableSchema", tableSchema);
            parameters.setParameter("TableName", tableName);
            parameters.setParameter("Partition", partition);
            int mergeFactor =
                Integer.parseInt(parameters.getParameter("MergeFactor",
                                                         "" + IndexWriter.DEFAULT_MERGE_FACTOR));
            int maxBufferedDocs =
                Integer.parseInt(parameters.getParameter("MaxBufferedDocs",
                                                         "" +
                                                         IndexWriter.DEFAULT_MAX_BUFFERED_DOCS));
            int maxMergeDocs =
                Integer.parseInt(parameters.getParameter("MaxMergeDocs",
                                                         "" + IndexWriter.DEFAULT_MAX_MERGE_DOCS));
            int maxBufferedDeleteTerms =
                Integer.parseInt(parameters.getParameter("MaxBufferedDeleteTerms",
                                                         "" +
                                                         IndexWriter.DEFAULT_MAX_BUFFERED_DELETE_TERMS));
            Analyzer analyzer = getAnalyzer(parameters);
            UserDataStore userDataStore = getUserDataStore(parameters);
            String extraCols = parameters.getParameter("ExtraCols");
            String extraTabs = parameters.getParameter("ExtraTabs");
            String whereCondition = parameters.getParameter("WhereCondition");
            String syncMode = parameters.getParameter("SyncMode", "deferred");
            boolean useCompountFileName = "true".equalsIgnoreCase(parameters.getParameter("UseCompoundFile", "true"));
            String LobStorageParameters = parameters.getParameter("LobStorageParameters",
                    "PCTVERSION 0 ENABLE STORAGE IN ROW CACHE READS NOLOGGING");
            /*
            System.out.println("Indexing column: '"+columnName+"'");
            System.out.println("Parameters:\n"+parameters.toString());
            System.out.println("User Data Store function: "+userDataStore+" extraCols: "+extraCols);
             */
            createLuceneStore(directoryPrefix, LobStorageParameters);
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            dir.setParameters(parameters);
            writer = new IndexWriter(dir, analyzer, true);
            writer.setMergeFactor(mergeFactor);
            writer.setMaxMergeDocs(maxMergeDocs);
            writer.setMaxBufferedDocs(maxBufferedDocs);
            writer.setUseCompoundFile(useCompountFileName);
            writer.setMaxBufferedDeleteTerms(maxBufferedDeleteTerms);
            TableIndexer index =
                new TableIndexer(dir.getConnection(), tableSchema, tableName,
                                 partition);
            index.setUserDataStore(userDataStore);
            index.setExtraColsStr(extraCols);
            index.setExtraTabsStr(extraTabs);
            index.setExtraWhereStr(whereCondition);
            index.index(writer, columnName);
            if ("OnLine".equalsIgnoreCase(syncMode))
                enableOnLineSync(directoryPrefix);
            dir.removeCachedSearcher();
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
                if (writer != null)
                    writer.close();
                if (dir != null)
                    dir.close();
            } catch (IOException e) {
                e.printStackTrace();
                return ERROR;
            }
        }
        return SUCCESS;
    }

    /**
     * When a user issues a DROP statement against a table that contains a
     * column or object type attribute indexed by your indextype, Oracle calls your
     * ODCIIndexDrop() method. This method should leave the domain index empty.
     * @param ia
     * @param env
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIIndexDrop(ODCIIndexInfo ia,
                                                     ODCIEnv env) throws SQLException {
        String directoryPrefix = getIndexPrefix(ia, env);
        OJVMDirectory dir = OJVMDirectory.getDirectory(directoryPrefix);
        Parameters parameters = dir.getParameters();
        if ("OnLine".equalsIgnoreCase(parameters.getParameter("SyncMode")))
            disableOnLineSync(directoryPrefix);
        dropLuceneStore(directoryPrefix);
        return SUCCESS;
    }

    /**
     * When a user issues a TRUNCATE statement against a table that contains a
     * column or object type attribute indexed by your indextype, Oracle calls your
     * ODCIIndexTruncate() method. This method should leave the domain index empty.
     * @param ia
     * @param env
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIIndexTruncate(ODCIIndexInfo ia,
                                                         ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexWriter writer = null;
        String directoryPrefix = getIndexPrefix(ia, env);
        //System.out.println("Truncate. on index: " + directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            Parameters parameters = dir.getParameters();
            Analyzer analyzer = getAnalyzer(parameters);
            boolean useCompountFileName = "true".equalsIgnoreCase(parameters.getParameter("UseCompoundFile", "true"));
            // Discard pending changes and purge deleted documents
            discard(directoryPrefix);
            // open a writer object with last argument to true cause truncation on lucene index
            writer = new IndexWriter(dir, analyzer, true);
            writer.setUseCompoundFile(useCompountFileName);
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
                if (writer != null)
                    writer.close();
                writer = null;
                if (dir != null)
                    dir.close();
                dir = null;
            } catch (IOException e) {
                e.printStackTrace();
                return ERROR;
            }
        }
        return SUCCESS;
    }

    /**
     * Overloading version for XMLType columns
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal TextContains(XMLType text,
                                                    String keyStr,
                                                    ODCIIndexCtx ctx,
                                                    LuceneDomainIndex[] sctx,
                                                    java.math.BigDecimal scanflg) throws SQLException,
                                                                                         IOException,
                                                                                         ParseException {
        String valueStr = ((text != null) ? text.extract("//text()","").getStringVal() : "");
        return TextContains(((valueStr != null) ?
                             valueStr : ""), keyStr,
                            ctx, sctx, scanflg); // column value is not used
    }

    /**
     * Overloading version for CLOB columns data type
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal TextContains(CLOB text, String keyStr,
                                                    ODCIIndexCtx ctx,
                                                    LuceneDomainIndex[] sctx,
                                                    java.math.BigDecimal scanflg) throws SQLException,
                                                                                         IOException,
                                                                                         ParseException {
        String valueStr = (text != null ) ? text.getSubString(1, (int)text.length()) : "";
        return TextContains(((valueStr != null) ?
                             valueStr : ""),
                            keyStr, ctx, sctx,
                            scanflg); // column value is not used
    }

    /**
     * Functional implementation for the SQL Operator lcontains(colum,'text to search')>0
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     * @throws IOException
     */
    public static java.math.BigDecimal TextContains(String text, String keyStr,
                                                    ODCIIndexCtx ctx,
                                                    LuceneDomainIndex[] sctx,
                                                    java.math.BigDecimal scanflg) throws SQLException,
                                                                                         IOException,
                                                                                         ParseException {

        int flag = scanflg.intValue();
        //System.out.println("TextContains. Operator rowid='" + ((ctx!=null) ? ctx.getRid() : "null") +
        //                   "' text='"+text+"' key= '"+keyStr+"' scanflg='"+flag+"'"+
        //                   " sctx= "+sctx);
        ODCIIndexInfo ia = (ctx != null) ? ctx.getIndexInfo() : null;
        //System.out.println("TextContains. ODCIIndexInfo="+ia);
        if (flag == 1 && sctx != null &&
            sctx[0] != null) { // close index operation
            return new BigDecimal("1");
        }
        if (ia == null &&
            flag > 0) { // no Domain Index is bound to a particular column
            if (flag == 2 &&
                text.matches(keyStr)) // note that here is not lucene query syntas, is regexp!!
                return new BigDecimal("1");
            else
                return new BigDecimal("0");
        }
        //dumpIA(ia);
        String directoryPrefix =
            (ia.getIndexPartition() != null) ? ia.getIndexSchema() + "." +
            ia.getIndexName() + "." + ia.getIndexPartition() :
            ia.getIndexSchema() + "." + ia.getIndexName();
        Entry entry = OJVMDirectory.getCachedSearcher(directoryPrefix);
        TermQuery tq = new TermQuery(new Term("rowid", ctx.getRid()));
        Searcher searcher = entry.getSeacher();
        String columnName =
            ia.getIndexCols().getElement(0).getColName().replaceAll("\"", "");
        QueryParser parser = new QueryParser(columnName, entry.getAnalyzer());
        Query qry = parser.parse(keyStr);
        String qryStr = qry.toString(columnName);
        Filter docsFilter = null;
        docsFilter = entry.getFilter(qryStr);
        if (docsFilter == null) {
            docsFilter = new QueryWrapperFilter(qry);
            entry.addFilter(qryStr, docsFilter);
            //System.out.println("TextContains: storing cachingFilter: "+docsFilter.hashCode()+" and searcher: "+searcher.hashCode()+" key: "+qryStr);
        } // else
        //   System.out.println("TextContains: using cachingFilter: "+docsFilter.hashCode()+" and searcher: "+searcher.hashCode());
        if (sctx == null || sctx[0] == null) {
            sctx[0] = new LuceneDomainIndex();
            sctx[0].setScanctx(new Integer(1));
        }
        Hits hits = searcher.search(tq, docsFilter);
        return BigDecimal.valueOf(hits.length());
    }

    /**
     * Overloading version for XMLType column data type
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal TextScore(XMLType text, String keyStr,
                                                 ODCIIndexCtx ctx,
                                                 LuceneDomainIndex[] sctx,
                                                 java.math.BigDecimal scanflg) throws SQLException {
        return TextScore("", keyStr, ctx, sctx, scanflg);
    }

    /**
     * Overloading version for CLOB column data type
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal TextScore(CLOB text, String keyStr,
                                                 ODCIIndexCtx ctx,
                                                 LuceneDomainIndex[] sctx,
                                                 java.math.BigDecimal scanflg) throws SQLException {
        return TextScore("", keyStr, ctx, sctx, scanflg);
    }

    /**
     * Return a pre-computed value of the score() value for a particular rowid.
     * We assume that OCIFetch function was called first and store the score for
     * each rowid visited.
     * @param text
     * @param keyStr
     * @param ctx
     * @param sctx
     * @param scanflg
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal TextScore(String text, String keyStr,
                                                 ODCIIndexCtx ctx,
                                                 LuceneDomainIndex[] sctx,
                                                 java.math.BigDecimal scanflg) throws SQLException {
        LuceneDomainContext sbtctx;
        //System.out.println("TextScore. Operator rowid='" + ctx.getRid() +
        //                   "' text='"+text+"' key= '"+keyStr+"' scanflg='"+scanflg+"'");
        int key;
        if (sctx == null || sctx[0] == null) // Sanity checks
            throw new SQLException("LuceneDomainIndex parameter is null. Are you using lcontains in a not index column?");
        key = sctx[0].getScanctx().intValue();
        //System.out.println("ContextManager key=" + key);

        // Get the resultSet back from the ContextManager using the key
        sbtctx = (LuceneDomainContext)ContextManager.getContext(key);
        if (!sbtctx.isStoreScore())
            throw new SQLException("TextScore do not have pre-computed score values");
        Hashtable cachedRowids = sbtctx.getScoreList();
        //System.out.println("TextScore getting slist: "+cachedRowids.hashCode());
        Float scoreValue = (Float)cachedRowids.get(ctx.getRid());
        if (scoreValue == null)
            throw new SQLException("Ooops, I can't find a pre-cached score with this rowid= '" +
                                   ctx.getRid() + "'");
        return new java.math.BigDecimal(scoreValue.doubleValue());
    }

    /**
     * Oracle calls your ODCIStart() method at the beginning of an index scan,
     * passing it information on the index and the operator. Typically, this method:
     * - Initializes data structures used in the scan
     * - Parses and executes SQL statements that query the tables storing the index data
     * - Saves any state information required by the fetch and cleanup methods, and
     *   returns the state or a handle to it
     * - Sometimes generates a set of result rows to be returned at the first invocation of
     *   ODCIFetch()
     * The information on the index and the operator is not passed to the fetch and cleanup
     * methods. Thus, ODCIStart() must save state data that needs to be shared
     * among the index scan routines and return it through an output sctx parameter. To
     * share large amounts of state data, allocate cursor-duration memory and return a
     * handle to the memory in the sctx parameter.
     * As member methods, ODCIFetch() and ODCIClose() are passed the
     * built-in SELF parameter, through which they can access the state data.
     * @param sctx IN: The value of the scan context returned by some previous related
     *                 query-time call (such as the corresponding ancillary operator, if
     *                 invoked before the primary operator); NULL otherwise
     *             OUT: The context that is passed to the next query-time call; the next
     *                  query-time call will be to ODCIIndexFetch
     * @param ia Contains information about the index and the indexed column
     * @param op Contains information about the operator predicate
     * @param qi Contains query information (hints plus list of ancillary operators referenced)
     * @param strt The start value of the bounds on the operator return value.
     *             The datatype is the same as that of the operator's return value
     * @param stop The stop value of the bounds on the operator return value.
     *             The datatype is the same as that of the operator's return value.
     * @param cmpval The value arguments of the operator invocation. The number and
     *               datatypes of these arguments are the same as those of the value
     *               arguments to the operator.
     * @param env The environment handle passed to the routine
     * @return ODCIConst.Success on success, or ODCIConst.Error on error
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIStart(LuceneDomainIndex[] sctx,
                                                 ODCIIndexInfo ia,
                                                 ODCIPredInfo op,
                                                 ODCIQueryInfo qi,
                                                 java.math.BigDecimal strt,
                                                 java.math.BigDecimal stop,
                                                 java.math.BigDecimal cmppos,
                                                 String cmpval,
                                                 ODCIEnv env) throws java.sql.SQLException {
        //System.out.println("ODCIStart. cmpos '" + cmppos);
        return ODCIStart(sctx, ia, op, qi, strt, stop, cmpval, env);
    }

    /**
     * Oracle calls your ODCIStart() method at the beginning of an index scan,
     * passing it information on the index and the operator. Typically, this method:
     * - Initializes data structures used in the scan
     * - Parses and executes SQL statements that query the tables storing the index data
     * - Saves any state information required by the fetch and cleanup methods, and
     *   returns the state or a handle to it
     * - Sometimes generates a set of result rows to be returned at the first invocation of
     *   ODCIFetch()
     * The information on the index and the operator is not passed to the fetch and cleanup
     * methods. Thus, ODCIStart() must save state data that needs to be shared
     * among the index scan routines and return it through an output sctx parameter. To
     * share large amounts of state data, allocate cursor-duration memory and return a
     * handle to the memory in the sctx parameter.
     * As member methods, ODCIFetch() and ODCIClose() are passed the
     * built-in SELF parameter, through which they can access the state data.
     * @param sctx IN: The value of the scan context returned by some previous related
     *                 query-time call (such as the corresponding ancillary operator, if
     *                 invoked before the primary operator); NULL otherwise
     *             OUT: The context that is passed to the next query-time call; the next
     *                  query-time call will be to ODCIIndexFetch
     * @param ia Contains information about the index and the indexed column
     * @param op Contains information about the operator predicate
     * @param qi Contains query information (hints plus list of ancillary operators referenced)
     * @param strt The start value of the bounds on the operator return value.
     *             The datatype is the same as that of the operator's return value
     * @param stop The stop value of the bounds on the operator return value.
     *             The datatype is the same as that of the operator's return value.
     * @param cmpval The value arguments of the operator invocation. The number and
     *               datatypes of these arguments are the same as those of the value
     *               arguments to the operator.
     * @param env The environment handle passed to the routine
     * @return ODCIConst.Success on success, or ODCIConst.Error on error
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIStart(LuceneDomainIndex[] sctx,
                                                 ODCIIndexInfo ia,
                                                 ODCIPredInfo op,
                                                 ODCIQueryInfo qi,
                                                 java.math.BigDecimal strt,
                                                 java.math.BigDecimal stop,
                                                 String cmpval,
                                                 ODCIEnv env) throws java.sql.SQLException {
        //System.out.println(".ODCIStart Operator '" + op.getObjectName() +
        //                   "' cmpval='" + cmpval + "' strt= '" + strt +
        //                   "' stop='" + stop + "'");
        //dumpIA(ia);
        //dumpOP(op);
        //dumpQI(qi);
        //dumpEnv(env);
        //dumpLastSQL();
        String directoryPrefix = getIndexPrefix(ia, env);
        int key;
        int qiFlags = qi.getFlags().intValue();
        //System.out.println(".ODCIStart qiFlags="+qiFlags);
        boolean storeScore =
            "LSCORE".equals((qi.getAncOps() != null && qi.getAncOps().length() >
                             0) ?
                            qi.getAncOps().getElement(0).getObjectName() : "");
        boolean reverse = (qiFlags & QUERY_SORT_ASC) == QUERY_SORT_ASC;
        boolean hasPagination = false;
        LuceneDomainContext sbtctx; // cntxt obj that holds the ResultSet and Statement
        Searcher searcher = null;
        Hits hits = null;
        sbtctx = new LuceneDomainContext();
        sbtctx.setStoreScore(storeScore);
        int startIndex = 0;
        int endIndex = 0;
        if ((qiFlags & QUERY_FIRST_ROWS) == QUERY_FIRST_ROWS)
            sbtctx.setFirstRows(true);
        //System.out.println(".ODCIStart parsedSQL="+getSQL());
        //dumpPlanTable();
        sbtctx.setStartTime(System.currentTimeMillis());
        if (!op.getObjectName().equalsIgnoreCase("lcontains"))
            throw new SQLException("Expected lcontains operator, use lcontains(column,'text to search')>0");
        //if (strt==null && stop!=null)
        //    throw new SQLException("NOT functionality is not implemented, use lcontains(column,'text to search')>0");
        //int strtValue = (strt!=null) ? strt.intValue() : 0 ;
        //int stopValue = (stop!=null) ? stop.intValue() : 0 ;
        //if (strtValue<=0 && stopValue<=0)
        //    throw new SQLException("Incorrect value for the operator, use lcontains(column,'text to search')>0");
        try {
            Entry entry = OJVMDirectory.getCachedSearcher(directoryPrefix);
            String columnName =
                ia.getIndexCols().getElement(0).getColName().replaceAll("\"",
                                                                        "");
            //System.out.println("Indexing column: '"+columnName+"'");
            //System.out.println("Analyzer: "+entry.getAnalyzer());
            QueryParser parser =
                new QueryParser(columnName, entry.getAnalyzer());
            String queryString = cmpval.trim();
            if (queryString.startsWith("rownum:[")) {
                int pos = queryString.indexOf(" AND ");
                if (pos<0)
                    throw new RuntimeException("Invalid rownum syntax in lcontains() operator, can not find AND conector syntax is 'rownum:[nn TO mm] AND restOfQueryParserSyntax'");
                String rowNumInfo = queryString.substring(0,pos);
                queryString = queryString.substring(pos + 5);
                pos = rowNumInfo.indexOf(" TO ");
                if (pos<0)
                    throw new RuntimeException("Invalid rownum syntax in lcontains() operator, no rownum:[nn TO mm] syntax");
                startIndex = Integer.parseInt(rowNumInfo.substring(8, pos).trim())-1;
                endIndex = 
                    Integer.parseInt(rowNumInfo.substring(pos + 4, rowNumInfo.length() - 
                                                          1).trim())-1;
                if (endIndex < 0 || startIndex < 0) // Sanity checks
                    throw new RuntimeException("Invalid rownum syntax in lcontains() operator, index can not be less than 1");
                if (endIndex<startIndex)
                    throw new RuntimeException("Invalid rownum syntax in lcontains() operator, end index is less than begin index");
                //System.out.println("from: '" + startIndex + "'");
                //System.out.println("to: '" + endIndex + "'");
                //System.out.println("queryString: '" + queryString + "'");
                hasPagination = true;
            }
            Query qry = parser.parse(queryString);
            String qryStr =
                ((reverse) ? "ASC:(" : "DESC:(") + qry.toString(columnName) +
                ")";
            hits = entry.getHits(qryStr);
            //System.out.println("qryStr: "+qryStr);
            if (hits == null) { // is new query using this parser
                searcher = entry.getSeacher();
                Filter docsFilter = null;
                docsFilter = entry.getFilter(qryStr);
                if (docsFilter == null) {
                    docsFilter = new QueryWrapperFilter(qry);
                    entry.addFilter(qryStr, docsFilter);
                    //System.out.println("ODCIStart: storing cachingFilter: "+docsFilter.hashCode()+" and searcher: "+searcher.hashCode()+" key: "+qryStr);
                }//  else
                 //   System.out.println("ODCIStart: using cachingFilter: "+docsFilter.hashCode()+" and searcher: "+searcher.hashCode());
                if (reverse)
                    hits = searcher.search(qry, docsFilter, new Sort(new SortField[] { new SortField(null,
                                                                          SortField.SCORE,
                                                                          true),
                                                                     SortField.FIELD_DOC }));
                else
                    hits = searcher.search(qry, docsFilter);
                entry.setHits(qryStr, hits);
                //System.out.println("ODCIStart: storing cachingHits: "+hits.hashCode()+" on the entry: "+entry.hashCode()+" key: "+qryStr);
            }// else
             //   System.out.println("ODCIStart: using cachingHits: " + 
             //                       hits.hashCode() + " on the entry: " + 
             //                       entry.hashCode() + " key: " + qryStr);
            if (!hasPagination || endIndex >= hits.length())
                endIndex = hits.length() - 1;
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } catch (ParseException p) {
            p.printStackTrace();
            return ERROR;
        }
        sbtctx.setStartIndex(startIndex);
        sbtctx.setEndIndex(endIndex);
        sbtctx.setHits(hits);
        sctx[0] = new LuceneDomainIndex();
        key = ContextManager.setContext((Object)sbtctx);

        //System.out.println("ContextManager key=" + key);

        // set the key into the self argument so that we can retrieve the
        // context with this key later.
        sctx[0].setScanctx(new Integer(key));
        return SUCCESS;
    }

    /**
     * Oracle calls your ODCIFetch() method to return the row identifiers of
     * the next batch of rows that satisfies the operator predicate, passing it
     * the state data returned by ODCIStart() or the previous ODCIFetch() call.
     * The operator predicate is specified in terms of the operator expression
     * (name and arguments) and a lower and upper bound on the operator return values.
     * Thus, ODCIFetch() must return the row identifiers of the rows for which
     * the operator return value falls within the specified bounds. To indicate
     * the end of index scan, return a NULL.
     * @param nrows Is the maximum number of result rows that can be returned to
     *              Oracle in this call
     * @param rids  Is the array of row identifiers for the result rows being
     *              returned by this call
     * @param env   The environment handle passed to the routine
     * @return ODCIConst.Success on success, or ODCIConst.Error on error
     * @throws SQLException
     */
    public java.math.BigDecimal ODCIFetch(java.math.BigDecimal nrows,
                                          ODCIRidList[] rids,
                                          ODCIEnv env) throws java.sql.SQLException, 
                                                              IOException {
        LuceneDomainContext sbtctx; // cntxt obj that holds the ResultSet and Statement
        String rid;
        float score = 0;
        int done = FALSE;
        int nRows = nrows.intValue();
        String[] rlist = new String[nRows];
        Hashtable slist = null;
        int key = getScanctx().intValue();
        //System.out.println(".ODCIFetch ContextManager key=" + key);
        //System.out.println(".ODCIFetch nrows : " + nRows);
        //dumpEnv(env);
        // Get the resultSet back from the ContextManager using the key
        sbtctx = (LuceneDomainContext)ContextManager.getContext(key);
        boolean storeScore = sbtctx.isStoreScore();
        // Gets pre-computed hits
        Hits hits = sbtctx.getHits();
        // Gets current windows, specially for pagination
        int startIndex = sbtctx.getStartIndex();
        int endIndex = sbtctx.getEndIndex();
        //System.out.println(".ODCIFetch storeScore: " + storeScore);
        //System.out.println(".ODCIFetch firstRows: " + firstRows);
        if (storeScore)
            slist = new Hashtable(nRows);
        //***************
        // Fetch rowids *
        //***************
        //System.out.println(" startIndex= "+startIndex+" endIndex= "+endIndex);
        for (int i = 0; done != TRUE && i < nRows; i++) {
            //System.out.println("i="+i);
            if (startIndex <= endIndex) {
                // append rowid to collection
                try {
                    Document doc = hits.doc(startIndex);
                    rid = doc.get("rowid");
                    if (storeScore) // lscore operator is involved
                        score = hits.score(startIndex);
                } catch (IOException e) {
                    e.printStackTrace();
                    throw new SQLException(e.getMessage());
                }
                rlist[i] = new String(rid);
                if (storeScore)
                    slist.put(rid, new Float(score));
                startIndex++;
            } else {
                // append null rowid to collection, signal Oracle that there is no more rowids
                rlist[i] = null;
                done = TRUE;
            }
        }
        // update current position
        sbtctx.setStartIndex(startIndex);
        // Store last fetch of score List to be used by score() ancillary operator
        //System.out.println("ODCIFetch storing slist: "+slist.hashCode());
        if (storeScore)
            sbtctx.setScoreList(slist);
        // Since rids is an out parameter we need to set the ODCIRidList
        // object into the first position to be passed out.
        rids[0] = new ODCIRidList(rlist);
        return SUCCESS;
    }

    /**
     * Oracle calls your ODCIIndexClose() method when the cursor is closed or reused,
     * passing it the current state. ODCIIndexClose() should perform whatever cleanup
     * or closure operations your indextype requires.
     * @param env The environment handle passed to the routine
     * @return ODCIConst.Success on success, ODCIConst.Error on error
     * @throws SQLException
     */
    public java.math.BigDecimal ODCIClose(ODCIEnv env) throws java.sql.SQLException {
        LuceneDomainContext sbtctx; // contxt obj that holds the ResultSet and Statement
        //Directory dir = null;
        //IndexSearcher searcher = null;
        int key = getScanctx().intValue();
        sbtctx = (LuceneDomainContext)ContextManager.clearContext(key);
        //System.out.println("ODCIClose key=" + key);
        //dumpEnv(env);
        long elapsedTime = System.currentTimeMillis() - sbtctx.getStartTime();
        //System.out.println("Elapsed time: "+elapsedTime+" millisecond.");
        // Get the resultSet and statement back from the ContextManager
        // so that we can close them.
        return SUCCESS;
    }

    /**
     * When a user deletes a record, Oracle calls your ODCIIndexDelete() method,
     * rids is a list of rowids to be deleted.
     * @param ia
     * @param rids
     * @param env
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal ODCIDelete(ODCIIndexInfo ia, ODCIRidList rids,
                                                  ODCIEnv env) throws SQLException {
        
        OJVMDirectory dir = null;
        IndexReader reader = null;
        String directoryPrefix = getIndexPrefix(ia, env);
        String  [] ridArray = rids.getArray();
        int count = ridArray.length;
        //System.out.println("Delete.  count: '" + count +
        //                   "' on index: " + directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            reader = IndexReader.open(dir);
            for(int i=0;i<count;i++)
              reader.deleteDocuments(new Term("rowid", ridArray[i]));
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
                if (reader != null)
                    reader.close();
                if (dir != null)
                    dir.close();
            } catch (IOException e) {
                e.printStackTrace();
                return ERROR;
            }
        }
        return SUCCESS;
    }
    
    /**
     * Process changes from Lucene Domain Index queue working in SyncMode:Deferred
     * Queue operation are first consumed in PLSQL (faster) then a list of deleted
     * and inserted rowids are sent to this method.
     * @param prefix
     * @throws IOException
     * @throws SQLException
     */
    public static void sync(String prefix, ODCIRidList deleted, ODCIRidList inserted) throws IOException, SQLException {
        if (deleted.length() == 0 && inserted.length() == 0) // Sanity checks
            return; // Shorcut ;)
        //System.out.println(".sync : "+prefix+" deleted: "+deleted.length()+" inserted: "+inserted.length());
        OJVMDirectory dir = null;
        IndexReader reader = null;
        IndexWriter writer = null;
        try {
            dir = OJVMDirectory.getDirectory(prefix);
            Parameters par = dir.getParameters();
            String col = par.getParameter("ColName");
            String tableSchema = par.getParameter("TableSchema");
            String tableName = par.getParameter("TableName");
            String partition = par.getParameter("Partition");
            reader = IndexReader.open(dir);
            String [] deletedArray = deleted.getArray();
            int size = deletedArray.length;
            for (int i=0; i<size ; i++)
                reader.deleteDocuments(new Term("rowid", deletedArray[i]));
            reader.close();
            reader = null;
            int mergeFactor =
                Integer.parseInt(par.getParameter("MergeFactor", "" +
                                                  IndexWriter.DEFAULT_MERGE_FACTOR));
            int maxBufferedDocs =
                Integer.parseInt(par.getParameter("MaxBufferedDocs",
                                                  "" + IndexWriter.DEFAULT_MAX_BUFFERED_DOCS));
            int maxMergeDocs =
                Integer.parseInt(par.getParameter("MaxMergeDocs",
                                                  "" + IndexWriter.DEFAULT_MAX_MERGE_DOCS));
            Analyzer analyzer = getAnalyzer(par);
            writer = new IndexWriter(dir, analyzer, false);
            writer.setMergeFactor(mergeFactor);
            writer.setMaxMergeDocs(maxMergeDocs);
            writer.setMaxBufferedDocs(maxBufferedDocs);
            UserDataStore userDataStore = getUserDataStore(par);
            String extraCols = par.getParameter("ExtraCols");
            String extraTabs = par.getParameter("ExtraTabs");
            String whereCondition = par.getParameter("WhereCondition");
            TableIndexer index =
                new TableIndexer(dir.getConnection(), tableSchema, tableName,
                                 partition);
            index.setUserDataStore(userDataStore);
            index.setExtraColsStr(extraCols);
            index.setExtraTabsStr(extraTabs);
            index.setExtraWhereStr(whereCondition);
            index.index(writer, col, inserted.getArray());
            writer.close();
            writer = null;
            dir.close();
            dir = null;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error syncing the index: " + prefix +
                                       " - " + e.getMessage());
        } finally {
            if (reader != null)
                reader.close();
            if (writer != null)
                writer.close();
            if (dir != null)
                dir.close();
        }
    }

    /**
     * Optimize Lucene Index, first Lucene Index parameters from parameters storage
     * then call to IndexWriter.optimize method
     * @param directoryPrefix
     * @throws IOException
     * @throws SQLException
     * @see IndexWriter#optimize
     */
    public static void optimize(String directoryPrefix) throws IOException,
                                                               SQLException {
        OJVMDirectory dir = null;
        IndexWriter writer = null;
        //System.out.println("Truncate. optimize index: " + directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            Parameters parameters = dir.getParameters();
            int mergeFactor =
                Integer.parseInt(parameters.getParameter("MergeFactor",
                                                         "" + IndexWriter.DEFAULT_MERGE_FACTOR));
            int maxBufferedDocs =
                Integer.parseInt(parameters.getParameter("MaxBufferedDocs",
                                                         "" +
                                                         IndexWriter.DEFAULT_MAX_BUFFERED_DOCS));
            int maxMergeDocs =
                Integer.parseInt(parameters.getParameter("MaxMergeDocs",
                                                         "" + IndexWriter.DEFAULT_MAX_MERGE_DOCS));
            Analyzer analyzer = getAnalyzer(parameters);
            boolean useCompountFileName = "true".equalsIgnoreCase(parameters.getParameter("UseCompoundFile", "true"));
            // open a writer object with last argument to true cause truncation on lucene index
            writer = new IndexWriter(dir, analyzer, false);
            writer.setMergeFactor(mergeFactor);
            writer.setMaxMergeDocs(maxMergeDocs);
            writer.setMaxBufferedDocs(maxBufferedDocs);
            writer.setUseCompoundFile(useCompountFileName);
            writer.optimize();
            // after optimize purge deleted documents
            dir.purge();
        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                if (writer != null)
                    writer.close();
                if (dir != null)
                    dir.close();
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            }
        }
    }

    /**
     * Discard pending changes on Lucene Domain Index by deleting messages on his queue
     * @param prefix
     */
    public static void discard(String prefix) {
        OracleCallableStatement cs = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            cs = (OracleCallableStatement)conn.prepareCall(purgueLuceneQueueStmt);
            cs.setString(1, prefix);
            cs.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            //throw new RuntimeException("Error syncing the index: "+prefix+" - "+e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(cs, null);
        }
    }

    /**
     * Count Hits for in a given index for an specific query
     * Index is using syntax SCHEMA.IDX_NAME
     * Query is a QueryParser syntax without the extension "rownum:[n TO m] AND"
     * order means DESC or ASC, if you use a proper value according
     * to your next query order by clause countHits will pre-cached the query.
     * @param directoryPrefix
     * @param cmpval
     * @param order
     * @return
     * @throws SQLException
     * @see QueryParser
     */
    public static java.math.BigDecimal countHits(String directoryPrefix, 
                                                 String cmpval, 
                                                 String order) throws SQLException {
       Searcher searcher = null;
       Hits hits = null;
       try {
            Entry entry = OJVMDirectory.getCachedSearcher(directoryPrefix);
            Parameters parameters = entry.getDirectory().getParameters();
            String columnName = parameters.getParameter("ColName");
            QueryParser parser =
                new QueryParser(columnName, entry.getAnalyzer());
            String queryString = cmpval.trim();
            Query qry = parser.parse(queryString);
            String qryStr = null;
            if ("DESC".equalsIgnoreCase(order))
                qryStr = "DESC:(" + qry.toString(columnName) + ")";
            else
                qryStr = "ASC:(" + qry.toString(columnName) + ")";
            hits = entry.getHits(qryStr);
            if (hits == null) { // is new query using this parser
                searcher = entry.getSeacher();
                Filter docsFilter = null;
                docsFilter = entry.getFilter(qryStr);
                if (docsFilter == null) {
                    docsFilter = new QueryWrapperFilter(qry);
                    entry.addFilter(qryStr, docsFilter);
                }
                if ("ASC".equalsIgnoreCase(order))
                    hits = searcher.search(qry, docsFilter, new Sort(new SortField[] { new SortField(null,
                                                                          SortField.SCORE,
                                                                          true),
                                                                     SortField.FIELD_DOC }));
                else
                    hits = searcher.search(qry, docsFilter);
                entry.setHits(qryStr, hits);
                //System.out.println("ODCIStart: storing cachingHits: "+hits.hashCode()+" on the entry: "+entry.hashCode()+" key: "+qryStr);
            } // else
            return new BigDecimal(hits.length());
        } catch (IOException e) {
            e.printStackTrace();
            throw new SQLException(e.getLocalizedMessage());
        } catch (ParseException p) {
            p.printStackTrace();
            throw new SQLException(p.getLocalizedMessage());
        }
    }
    
    /**
     * Two parameters during the index creation time of the index can be used
     * to customize the analyzer of the index
     * Stemmer:language or Analyzer:fully.class.name.toAnalyzer
     * example:
     * create index source_big_lidx on test_source_big(text)
     *   indextype is lucene.LuceneIndex
     *   parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer;MergeFactor:1000;MaxBufferedDocs:1000');
     * or
     * create index source_big_lidx on test_source_big(text)
     *   indextype is lucene.LuceneIndex
     *   parameters('Stemmer:Spanish;MergeFactor:1000;MaxBufferedDocs:1000');
     * a valid list of languages are in
     *    [LUCENE_HOME]/contrib/snowball/src/java/net/sf/snowball/ext
     * @param parameters array extracted from the create index args or from the storage
     * @return an Analyzer instance
     * @throws SQLException
     */
    public static Analyzer getAnalyzer(Parameters parameters) throws SQLException {
        String stemmerStr = parameters.getParameter("Stemmer");
        if (stemmerStr != null &&
            stemmerStr.length() > 0) // Using stemmer parameter
            return new SnowballAnalyzer(stemmerStr);
        String analizerStr =
            parameters.getParameter("Analyzer", "org.apache.lucene.analysis.SimpleAnalyzer");
        //System.out.println("Analyzer: '"+analizerStr+"'");
        Analyzer analyzer = null;
        try {
            Class clazz = analizerStr.getClass().forName(analizerStr);
            analyzer = (Analyzer)clazz.newInstance();
        } catch (ClassNotFoundException c) {
            c.printStackTrace();
            throw new SQLException(c.getMessage());
        } catch (InstantiationException i) {
            i.printStackTrace();
            throw new SQLException(i.getMessage());
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            throw new SQLException(e.getMessage());
        }
        return analyzer;
    }

    /**
     * This parameters during the index creation time of the index can be used
     * to customize the document retrieval process using a User Defined Function
     * example:
     * create index source_big_lidx on test_source_big(text)
     *   indextype is lucene.LuceneIndex
     *   parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer;UserDataStore:org.apache.lucene.indexer.DefaultUserDataStore;ExtraCols:f3,f4');
     * This function must implement the interface org.apache.lucene.indexer.UserDataStore
     * have an empty contructor and implement the method Field [] getExtraFields(rowid,colsName[],colsVal[])
     * which will return an Array of Lucene Field not including the rowid and column asociated to the index
     * this set of Field will be added to the Lucene Document to be indexed.
     * @param parameters array extracted from the create index args or from the storage
     * @return an Analyzer instance
     * @throws SQLException
     */
    public static UserDataStore getUserDataStore(Parameters parameters) throws SQLException {
        String userDataStoreClass =
            parameters.getParameter("UserDataStore", "org.apache.lucene.indexer.DefaultUserDataStore");
        if (userDataStoreClass == null ||
            userDataStoreClass.length() == 0) // Sanity checks
            return null;
        //System.out.println(".getUserDataStore userDataStoreClass="+userDataStoreClass);
        UserDataStore userDataStore = null;
        try {
            Class clazz =
                userDataStoreClass.getClass().forName(userDataStoreClass);
            userDataStore = (UserDataStore)clazz.newInstance();
            String formatCols = 
                parameters.getParameter("FormatCols");
            HashMap formatMaps = new HashMap();
            if (formatCols != null) {
              String []formatColsArr = formatCols.split(",");
              for(int i=0;i<formatColsArr.length;i++) {
                  String colFormat = formatColsArr[i];
                  int pos = colFormat.indexOf('(');
                  String colName = colFormat.substring(0,pos);
                  if (pos<0)
                      throw new RuntimeException("Invalid format in param FormatCols.");
                  else {
                      String format = colFormat.substring(pos+1,colFormat.length()-1);
                      //System.out.println("format for col="+colName+" '"+format+"'");
                      formatMaps.put(colName,format);
                  }
              }
            }
            userDataStore.setColumnFormat(formatMaps);
        } catch (ClassNotFoundException c) {
            c.printStackTrace();
            throw new SQLException(c.getMessage());
        } catch (InstantiationException i) {
            i.printStackTrace();
            throw new SQLException(i.getMessage());
        } catch (IllegalAccessException e) {
            e.printStackTrace();
            throw new SQLException(e.getMessage());
        }
        return userDataStore;
    }

    private static void enableOnLineSync(String prefix) {
        OracleCallableStatement cs = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            //System.out.println("tableName: "+tableName+" columnName: "+columnName+" prefix: "+prefix);
            cs = (OracleCallableStatement)conn.prepareCall(enableCallBackStmt);
            cs.setString(1,prefix);
            cs.execute();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
        } finally {
            OJVMUtil.closeDbResources(cs, null);
        }
    }

    private static void disableOnLineSync(String prefix) {
        OracleCallableStatement cs = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            cs = (OracleCallableStatement)conn.prepareCall(disableCallBackStmt);
            cs.setString(1,prefix);
            cs.execute();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
        } finally {
            OJVMUtil.closeDbResources(cs, null);
        }
    }
    
    private static void createLuceneStore(String prefix, String LobStorageParameters) {
        OracleCallableStatement cs = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            cs = (OracleCallableStatement)conn.prepareCall(crtLuceneTableStmt);
            cs.setString(1,prefix);
            cs.setString(2,LobStorageParameters);
            cs.execute();
            cs.close();
            cs = (OracleCallableStatement)conn.prepareCall(crtLuceneQueueStmt);
            cs.setString(1,prefix);
            cs.execute();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
        } finally {
            OJVMUtil.closeDbResources(cs, null);
        }
    }
    
    private static void dropLuceneStore(String prefix) {
        OracleCallableStatement cs = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            cs = (OracleCallableStatement)conn.prepareCall(drpLuceneQueueStmt);
            cs.setString(1,prefix);
            cs.execute();
            cs.close();
            cs = (OracleCallableStatement)conn.prepareCall(drpLuceneTableStmt);
            cs.setString(1,prefix);
            cs.execute();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
        } finally {
            OJVMUtil.closeDbResources(cs, null);
        }
    }
}
