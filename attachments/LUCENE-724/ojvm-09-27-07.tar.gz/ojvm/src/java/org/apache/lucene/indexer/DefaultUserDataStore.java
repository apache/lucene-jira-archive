package org.apache.lucene.indexer;

import java.io.BufferedReader;
import java.io.IOException;

import java.io.InputStream;

import java.io.InputStreamReader;

import java.math.BigDecimal;

import java.net.URL;

import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;

import java.text.DecimalFormat;

import java.util.Map;

import oracle.sql.CLOB;

import oracle.xdb.XMLType;

import oracle.xml.parser.v2.SAXParser;
import oracle.xml.parser.v2.XMLParseException;

import org.apache.lucene.document.DateTools;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;

import org.apache.lucene.util.StringUtils;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * This class is an example of how to implement an User Data Store function
 */
public class DefaultUserDataStore implements UserDataStore {
    protected Map formats;
    
    protected Object []cachedFormaters;
        
    protected ContentHandler saxHandler = null;

    protected SAXParser saxParser = new SAXParser();

    public DefaultUserDataStore() {
    }

    public void setColumnFormat(Map formats) {
        this.formats = formats;
    }
    
    private void initFormaters(String col, Object value,
                               String[] extraNames,
                               Object[] extraVals) {
        int numFormaters = (extraVals != null) ? extraVals.length+1 : 1;
        this.cachedFormaters = new Object[numFormaters];
        String format = (String)this.formats.get(col);
        if (value instanceof Date || value instanceof Timestamp)
            cachedFormaters[0] = getDateResolution((format != null) ? format : "day");
        else if (value instanceof BigDecimal || value instanceof Double || value instanceof Float)
            cachedFormaters[0] = new DecimalFormat((format != null) ? format : "0000000000");
        else if (value instanceof String || value instanceof XMLType)
            cachedFormaters[0] = format;
        for(int i=1;i<numFormaters;i++) {
            Object objVal = extraVals[i-1];
            format = (String)this.formats.get(extraNames[i-1]);
            if (objVal instanceof Date || objVal instanceof Timestamp)
                cachedFormaters[i] = getDateResolution((format != null) ? format : "day");
            else if (objVal instanceof BigDecimal || objVal instanceof Double || objVal instanceof Float)
                cachedFormaters[i] = new DecimalFormat((format != null) ? format : "0000000000");
            else if (objVal instanceof String || objVal instanceof XMLType)
                cachedFormaters[i] = format;
        }
        this.saxHandler = new MyContentHandler();
        this.saxParser.setContentHandler(this.saxHandler);
    }
    
    public DateTools.Resolution getDateResolution(String resolution) {
        if ("year".equalsIgnoreCase(resolution))
            return DateTools.Resolution.YEAR;
        else if ("month".equalsIgnoreCase(resolution))
            return DateTools.Resolution.MONTH;
        else if ("day".equalsIgnoreCase(resolution))
            return DateTools.Resolution.DAY;
        else if ("hour".equalsIgnoreCase(resolution))
            return DateTools.Resolution.HOUR;
        else if ("minute".equalsIgnoreCase(resolution))
            return DateTools.Resolution.MINUTE;
        else if ("second".equalsIgnoreCase(resolution))
            return DateTools.Resolution.SECOND;
        else if ("millisecond".equalsIgnoreCase(resolution))
            return DateTools.Resolution.MILLISECOND;
        else
            throw new RuntimeException(".setDateResolution: Invalid DateTools.Resolution");
    }

    public StringBuffer textExtractor(XMLType obj) throws IOException,
                                                          SQLException {
        StringBuffer result = new StringBuffer("");
        if (obj == null) // Sanity checks
            return result;
        ((MyContentHandler)saxHandler).setTextResult(result);
        try {
            saxParser.parse(obj.getInputStream());
        } catch (XMLParseException e) {
            e.printStackTrace();
            throw new SQLException("XMLParseException: " + e.getMessage());
        } catch (SAXException e) {
            e.printStackTrace();
            throw new SQLException("SAXException: " + e.getMessage());
        }
        ((MyContentHandler)saxHandler).setTextResult(null);
        return result;
    }

    public static String readStream(InputStream inputStream) {
        StringBuffer buffer = new StringBuffer();
        try {
            BufferedReader reader = 
                new BufferedReader(new InputStreamReader(inputStream));
            while (true) {
                String line = reader.readLine();
                if (line != null) {
                    buffer.append(line);
                } else {
                    break;
                }
            }
        } catch (IOException iox) {
            iox.printStackTrace();
        }
        return buffer.toString();
    }

    public String valueExtractor(Object value, Object formatter) throws SQLException,
                                                      IOException {
        String valueStr = null;
        if (value != null) { // Sanity checks
            //System.out.println(".valueExtractor class: " +
            //                   value.getClass().getName());
            if (value instanceof CLOB)
                valueStr = readStream(((CLOB)value).binaryStreamValue());
            else if (value instanceof URL)
                valueStr = readStream(((URL)value).openStream());
            else if (value instanceof XMLType)
                valueStr = (formatter != null) ? ((XMLType)value).extract((String)formatter,"").getStringVal() : textExtractor(((XMLType)value)).toString();
            else if (value instanceof Date)
                valueStr =
                        DateTools.dateToString((Date)value, (DateTools.Resolution)formatter);
            else if (value instanceof Timestamp)
                valueStr =
                        DateTools.timeToString(((Timestamp)value).getTime(), (DateTools.Resolution)formatter);
            else if (value instanceof BigDecimal)
                valueStr =
                        ((DecimalFormat)formatter).format(((BigDecimal)value).doubleValue());
            else if (value instanceof Double)
                valueStr =
                        ((DecimalFormat)formatter).format(((Double)value).doubleValue());
            else if (value instanceof Float)
                valueStr =
                        ((DecimalFormat)formatter).format(((Float)value).doubleValue());
            else if (value instanceof String && formatter != null) {
                String fmtString = (String)formatter;
                valueStr = 
                        StringUtils.leftPad((String)value,fmtString.length(),fmtString.charAt(0));
            } else
                valueStr = value.toString();
            //System.out.println(".valueExtractor string: "+valueStr);
        }
        return valueStr;
    }

    public Field getField(String name, Object objVal, Object formatters) throws SQLException,
                                                             IOException {
        Field fld = null;
        if (objVal instanceof Timestamp || objVal instanceof Date ||
            objVal instanceof BigDecimal)
            fld = new Field(name, valueExtractor(objVal,formatters), Field.Store.NO, Field.Index.UN_TOKENIZED);
        else
            fld = new Field(name, valueExtractor(objVal,formatters), Field.Store.NO, Field.Index.TOKENIZED);
        return fld;
    }

    public Document getDocument(String rowid, String col, Object value,
                                String[] extraNames,
                                Object[] extraVals) throws SQLException,
                                                           IOException {
        if (this.saxHandler == null)
            initFormaters(col,value,extraNames,extraVals);
        Document doc = new Document();
        doc.add(new Field("rowid", rowid, Field.Store.YES,
                          Field.Index.UN_TOKENIZED));
        if (value != null) { // Sanity checks
            doc.add(getField(col, value, this.cachedFormaters[0]));
            int numCols = extraNames.length;
            for (int i = 0; i < numCols; i++) {
                Object objVal = extraVals[i];
                if (objVal != null) // Sanity checks
                  doc.add(getField(extraNames[i], objVal,this.cachedFormaters[i+1]));
            }
        }
        //System.out.println(".getDocument: doc="+doc);
        return doc;
    }

    public static class MyContentHandler extends DefaultHandler {
        StringBuffer textResult = null;

        public void startElement(String uri, String localName, String qName,
                                 Attributes atts) {
            int i = atts.getLength();
            for (int j = 0; j < i; j++) {
                textResult.append(atts.getValue(j)).append(' ');
                //System.out.println(".adding: "+atts.getValue(j));
            }
        }

        public void endElement(String uri, String localName, String qName) {
        }

        public void characters(char[] chars, int start, int length) {
            String strPart = new String(chars, start, length);
            textResult.append(strPart).append(' ');
            //System.out.println(".adding: "+strPart);
        }

        public void setTextResult(StringBuffer buff) {
            this.textResult = buff;
        }
    }
}
