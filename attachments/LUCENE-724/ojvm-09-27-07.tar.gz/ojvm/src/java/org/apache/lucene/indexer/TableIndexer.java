package org.apache.lucene.indexer;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Hit;
import org.apache.lucene.search.HitIterator;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.store.OJVMUtil;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public class TableIndexer {
    /**
     * Database connection used by this indexer
     */
    protected Connection conn;

    /**
     * Schema (database user name) owner of the table to index
     */
    protected String schemaName;

    /**
     * Table name to index
     */
    protected String tableName;

    /**
     * Partinion to index
     */
    protected String partitionName;

    /**
     * User Defined Data Store function (control which columns are added to the index)
     */
    protected UserDataStore userDataStore;

    /**
     * Coma separated list of extra columns to index
     */
    protected String extraColsStr;

    /**
     * Coma separated list of tables used to scan (joined to tableName)
     */
    protected String extraTabsStr;

    /**
     * Where condition used to join above tables and columns
     */
    protected String extraWhereStr;

    /**
     * Array of extra columns indexed, parsed from
     * @see #extraColsStr
     */
    protected String[] extraCols;

    /**
     * Default empty constructor
     */
    public TableIndexer() {
        this.userDataStore = new DefaultUserDataStore();
        this.extraCols = new String[0];
        this.extraColsStr = null;
    }

    /**
     * Constructor to index a given table name and using default KRB database connection
     * @param tableName
     */
    public TableIndexer(String tableName) {
        try {
            this.conn = OJVMUtil.getConnection();
            this.tableName = tableName;
            this.schemaName =
                    this.conn.getMetaData().getUserName().toUpperCase();
            this.partitionName = null;
            this.userDataStore = new DefaultUserDataStore();
            this.extraCols = new String[0];
            this.extraColsStr = null;
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
    }

    /**
     * Constructor for indexing a given schema.tablename
     * @param schemaName
     * @param tableName
     */
    public TableIndexer(String schemaName, String tableName) {
        try {
            this.conn = OJVMUtil.getConnection();
            this.tableName = tableName;
            this.schemaName = schemaName;
            this.partitionName = null;
            this.userDataStore = new DefaultUserDataStore();
            this.extraCols = new String[0];
            this.extraColsStr = null;
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
    }

    /**
     * Constructor for indexing a given table name and using an specific connection
     * @param conn
     * @param tableName
     */
    public TableIndexer(Connection conn, String tableName) {
        try {
            this.conn = conn;
            this.tableName = tableName;
            this.schemaName =
                    this.conn.getMetaData().getUserName().toUpperCase();
            this.partitionName = null;
            this.userDataStore = new DefaultUserDataStore();
            this.extraCols = new String[0];
            this.extraColsStr = null;
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
    }

    /**
     * @param conn
     * @param schemaName
     * @param tableName
     */
    public TableIndexer(Connection conn, String schemaName, String tableName) {
        this.conn = conn;
        this.schemaName = schemaName;
        this.tableName = tableName;
        this.partitionName = null;
        this.userDataStore = new DefaultUserDataStore();
        this.extraCols = new String[0];
        this.extraColsStr = null;
    }

    /**
     * @param conn
     * @param schemaName
     * @param tableName
     * @param partitionName
     */
    public TableIndexer(Connection conn, String schemaName, String tableName,
                        String partitionName) {
        this.conn = conn;
        this.schemaName = schemaName;
        this.tableName = tableName;
        this.partitionName = partitionName;
        this.userDataStore = new DefaultUserDataStore();
        this.extraCols = new String[0];
        this.extraColsStr = null;
    }

    /**
     * Returns a select stamenent like:
     * select T1.F2,t1.f3,t1.f4,t2.f6,t2.f7 from T1,t2 where t1.f4=t2.f5;
     * if ExtraTabs is t2 and ExtraCols is t1.f3,t1.f4,t2.f6,t2.f7
     * Note that: T1.F2 is the master table.columns of the index
     * @param col
     * @param withRowid
     * @return a JDBC Select statement
     */
    private String getSelectStmt(String col, boolean withRowid) {
        StringBuffer selectStmt = new StringBuffer("SELECT ");
        if (this.extraTabsStr == null)
            selectStmt.append("/*+ DYNAMIC_SAMPLING(0)*/ ");
        if (withRowid)
            selectStmt.append(this.tableName).append(".rowid,");
        selectStmt.append(this.tableName).append(".\"").append(col).append("\"");
        if (this.userDataStore != null)
            selectStmt.append(",").append(this.extraColsStr);
        selectStmt.append(" FROM ").append(schemaName).append(".").append(tableName);
        if (this.partitionName != null && this.partitionName.length() > 0)
            selectStmt.append(" PARTITION (").append(partitionName).append(")");
        if (this.extraTabsStr != null && this.extraTabsStr.length() > 0)
            selectStmt.append(",").append(this.extraTabsStr);
        if (!withRowid ||
            (this.extraWhereStr != null && this.extraWhereStr.length() > 0)) {
            selectStmt.append(" where ");
            if (!withRowid)
                selectStmt.append(this.tableName).append(".rowid = ? ");
            if (this.extraWhereStr != null &&
                this.extraWhereStr.length() > 0) {
                if (!withRowid)
                    selectStmt.append("and ");
                selectStmt.append(this.extraWhereStr);
            }
        }
        selectStmt.append(" for update nowait");
        //System.out.println("select stmt: " + selectStmt);
        return selectStmt.toString();
    }

    /**
     * Index a set of rowids, called from LuceneQueue class
     * @param writer Lucene writer
     * @param col master column of the index
     * @param rowids Set of rowid to index
     * @throws IOException
     * @see LuceneQueue
     */
    public void index(IndexWriter writer, String col,
                      String []rowids) throws IOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = this.conn.prepareStatement(this.getSelectStmt(col, false));
            int numRows = rowids.length;
            int numExtraCols = this.extraCols.length;
            for (int j=0;j<numRows;j++) {
                String rowid = rowids[j];
                stmt.setString(1, rowid);
                rs = stmt.executeQuery();
                if (rs.next()) {
                    Object value = rs.getObject(1);
                    Object[] extraValues = new Object[numExtraCols];
                    for (int i = 0; i < numExtraCols; i++) {
                        extraValues[i] = rs.getObject(i + 2);
                    }
                    Document doc =
                        userDataStore.getDocument(rowid, col, value, this.extraCols,
                                                  extraValues);
                    writer.addDocument(doc);
                    //System.out.println(".index doc=" + doc);
                } else
                    throw new RuntimeException("Error adding new rows to: " +
                                               schemaName + "." + tableName +
                                               " - Can't find the rowid " +
                                               rowid);
                rs.close();
                rs = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error indexing the table: " +
                                       schemaName + "." + tableName + " - " +
                                       e.getMessage() + " query: " +
                                       getSelectStmt(col, false));
        } finally {
            OJVMUtil.closeDbResources(stmt, rs);
        }
    }

    /**
     * Index a table executing a full scan, called from LuceneDomainIndex class
     * @param writer Lucene writer
     * @param col master column of the index
     * @throws IOException
     * @see LuceneDomainIndex#ODCIIndexCreate
     */
    public void index(IndexWriter writer, String col) throws IOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = this.conn.prepareStatement(getSelectStmt(col, true));
            rs = stmt.executeQuery();
            int numExtraCols = this.extraCols.length;
            while (rs.next()) {
                String rowid = rs.getString(1);
                Object value = rs.getObject(2);
                Object[] extraValues = new Object[numExtraCols];
                for (int i = 0; i < numExtraCols; i++) {
                    extraValues[i] = rs.getObject(i + 3);
                }
                Document doc =
                    userDataStore.getDocument(rowid, col, value, this.extraCols,
                                              extraValues);
                writer.addDocument(doc);
                //System.out.println(".index doc=" + doc);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error indexing the table: " +
                                       schemaName + "." + tableName + " - " +
                                       e.getMessage() + " query: " +
                                       getSelectStmt(col, true));
        } finally {
            OJVMUtil.closeDbResources(stmt, rs);
        }
    }

    /**
     * Internal function which can be used from Java Stored procedures to create
     * Lucene index for a given column
     * @param schema
     * @param table
     * @param partitionName
     * @param col
     * @throws IOException
     */
    public static void indexTable(String schema, String table,
                                  String partitionName,
                                  String col) throws IOException {
        OJVMDirectory dir;
        dir = OJVMDirectory.getDirectory("LN$" + schema + "." + table + "$IDX");
        IndexWriter writer =
            new IndexWriter(dir, new WhitespaceAnalyzer(), true);
        TableIndexer index =
            new TableIndexer(dir.getConnection(), schema, table,
                             partitionName);
        index.index(writer, col);
        writer.close();
        dir.close();
    }

    /**
     * Internal function which can be used from Java Stored Procedure to query
     * above Lucene Index
     * @param schema
     * @param table
     * @param col
     * @param queryStr
     * @return
     * @throws IOException
     */
    public static String[] query(String schema, String table, String col,
                                 String queryStr) throws IOException {
        OJVMDirectory dir;
        dir = OJVMDirectory.getDirectory("LN$" + schema + "." + table + "$IDX");
        IndexSearcher searcher = null;
        HitIterator iterator = null;
        searcher = new IndexSearcher(dir);
        Hits hits = searcher.search(new TermQuery(new Term(col, queryStr)));
        iterator = (HitIterator)hits.iterator();
        String rows[] = new String[iterator.length()];
        for (int i = 0; iterator.hasNext(); i++) {
            Hit hit = (Hit)iterator.next();
            rows[i] = hit.get("rowid");
        }
        searcher.close();
        dir.close();
        return rows;
    }

    /**
     * setter method for user data store property
     * @param param
     */
    public void setUserDataStore(UserDataStore param) {
        this.userDataStore = param;
    }

    /**
     * getter method for user data store property
     * @return
     */
    public UserDataStore getUserDataStore() {
        return userDataStore;
    }

    /**
     * setter method for extra columns property string
     * Note that this method also update extraCols Array parsing this string
     * using String.split(",") method
     * @param param
     * @see #extraCols
     */
    public void setExtraColsStr(String param) {
        if (param != null && param.length() > 0)
            this.extraCols = param.split(",");
        else
            this.extraCols = new String[0];
        this.extraColsStr = param;
    }

    /**
     * getter method for extra columns property string
     * @return
     */
    public String getExtraColsStr() {
        return extraColsStr;
    }

    /**
     * setter method for extra tabs property
     * @param param
     */
    public void setExtraTabsStr(String param) {
        this.extraTabsStr = param;
    }

    /**
     * getter method for extra tabs property
     * @return
     */
    public String getExtraTabsStr() {
        return extraTabsStr;
    }

    /**
     * setter method for where condition property
     * @param param
     */
    public void setExtraWhereStr(String param) {
        this.extraWhereStr = param;
    }

    /**
     * getter method for where condition property
     * @return
     */
    public String getExtraWhereStr() {
        return extraWhereStr;
    }
}
