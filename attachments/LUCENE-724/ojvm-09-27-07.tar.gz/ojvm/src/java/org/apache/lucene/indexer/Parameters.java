package org.apache.lucene.indexer;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import java.sql.SQLException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/**
 * A class to store Lucene Domain Index parameters
 * OJVMDirectory class store these parameters on
 * lucene_index table
 * @see org.apache.lucene.store.OJVMDirectory
 */
public class Parameters implements Serializable {

    /**
     * In memory storage for parameters
     */
    private HashMap parms = new HashMap();
    
    public Parameters() {
    }

    public Parameters(byte[] st) throws SQLException {
        try {
            ByteArrayInputStream i = new ByteArrayInputStream(st);
            ObjectInputStream in = new ObjectInputStream(i);
            int size_t = in.readInt();
            for (int j = 0; j < size_t; j++) {
                String name = (String)in.readObject();
                String value = (String)in.readObject();
                parms.put(name,value);
            }
        } catch (Exception e) {
            e.printStackTrace();
            throw new SQLException(e.getMessage());
        }
    }

    /**
     * Set a name,value pair parameter
     * @param name
     * @param value
     */
    public void setParameter(String name, String value) {
        parms.put(name,value);
    }

    /**
     * get a parameter value using name as key
     * @param name
     * @return
     */
    public String getParameter(String name) {
        return (String)parms.get(name);
    }

    /**
     * remove an stored parameter by using a given name as key
     * @param name
     */
    public void removeParameter(String name) {
        parms.remove(name);
    }

    /**
     * get a parameter value using name as key
     * if this parameter doesn't exist return a default value
     * @param name
     * @param dfltValue
     * @return
     */
    public String getParameter(String name, String dfltValue) {
        String result = (String)parms.get(name);
        if (result==null || result.length()==0)
            return dfltValue;
        else
            return result;
    }

    /**
     * return a number a parameter stored
     * @return
     */
    public int getSize() {
        return this.parms.size();
    }

    /**
     * Return a serialized version of the parameter store to save in BLOB column
     * @return
     * @throws SQLException
     */
    public byte[] getBytes() throws SQLException {
        try {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(o);
            int size = parms.size();
            out.writeInt(size);
            Set keys = parms.keySet();
            Iterator ite = keys.iterator();
            while(ite.hasNext()) {
                String name = (String)ite.next();
                String value = (String)parms.get(name);
                out.writeObject(name);
                out.writeObject(value);
            }
            out.flush();
            return o.toByteArray();
        } catch (Exception e) {
            throw new SQLException(e.getMessage());
        }
    }

    /**
     * Pretty print all parameters
     * @return
     */
    public String toString() {
        StringBuffer result = new StringBuffer();
        Set keys = parms.keySet();
        Iterator ite = keys.iterator();
        while(ite.hasNext()) {
            String name = (String)ite.next();
            String value = (String)parms.get(name);
            result.append("parameter '").append(name).append("' ");
            result.append("value '").append(value).append("'\n");
        }
        return result.toString();
    }
}
