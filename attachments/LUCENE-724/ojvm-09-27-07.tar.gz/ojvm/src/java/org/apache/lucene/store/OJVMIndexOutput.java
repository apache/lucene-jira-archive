package org.apache.lucene.store;

import java.io.IOException;

import java.sql.Connection;
import java.sql.SQLException;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * A database implementation of IndexOuput using database storage OJVMFile
 *
 * @version $Id: OJVMIndexOutput.java,v 1.6 2007/09/07 21:13:55 mochoa Exp $
 * @author Marcelo F. Ochoa
 */
public class OJVMIndexOutput extends IndexOutput {
    private byte[] currentBuffer = null;

    private OJVMFile file;

    private int pointer = 0;

    private int currentBufferNumber = 0;

    /**
     * Open a file for writting
     * to do this, creates a temporary BLOB and when its closed insert this BLOB
     * at SCHEMA.IDXNAME$T table
     * @param file
     */
    public OJVMIndexOutput(OJVMFile file) {
        this.file = file;
        this.file.openLocatorForWritting();
        currentBuffer = new byte[BufferedIndexOutput.BUFFER_SIZE];
        pointer = 0;
        currentBufferNumber = 0;
        //System.out.println(".OJVMIndexOutput - creating an empty file " +
        //                   this.file.getName());
    }

    /**
     * Open a file for writting given an SQLConnection and his prefix and name
     * @param conn
     * @param prefix
     * @param name
     */
    public OJVMIndexOutput(Connection conn, String prefix, String name) {
        this(new OJVMFile(conn, prefix, name));
    }

    /**
     * Close this file, first flush his memory buffer
     * Lucene do not call flush :(
     * finally close
     * @throws IOException
     */
    public void close() throws IOException {
        this.flush();
        this.file.close();
        //System.out.println(".close " + this.file.getName());
    }

    /**
     * flush the entire buffer
     */
    public void flush() throws IOException {
        //System.out.println(".flush " + this.file.getName() + " pos=" +
        //                   currentBufferNumber *
        //                   BufferedIndexOutput.BUFFER_SIZE + " length=" +
        //                   pointer);
        try {
            this.file.getBlob().setBytes(currentBufferNumber *
                                         BufferedIndexOutput.BUFFER_SIZE + 1,
                                         currentBuffer);
        } catch (SQLException s) {
            throw new IOException(".flush - can write Blob due: " +
                                  s.getLocalizedMessage());
        }
    }

    /** Returns the current position in this file, where the next write will
     * occur.
     * @see #seek(long)
     */
    public long getFilePointer() {
        //System.out.println(".getFilePointer " + this.file.getName() +
        //                   " pointer=" +
        //                   currentBufferNumber * BufferedIndexOutput.BUFFER_SIZE +
        //                   offset);
        return currentBufferNumber * BufferedIndexOutput.BUFFER_SIZE + pointer;
    }

    /** The number of bytes in the file. */
    public long length() throws IOException {
        return file.getSize();
    }

    /** Sets current position in this file, where the next write will occur.
     * @see #getFilePointer()
     */
    public void seek(long pos) throws IOException {
        //System.out.println(".seek " + this.file.getName() + " pos=" + pos);
        int bufferNo = (int)(pos / BufferedIndexOutput.BUFFER_SIZE);
        int bufferPos = bufferNo == 0 ? (int)pos : (int)(pos - pos / bufferNo);
        if (bufferNo != currentBufferNumber) {
            try {
                this.flush();
                // reload a new one
                currentBufferNumber = bufferNo;
                currentBuffer =
                        this.file.getBlob().getBytes(currentBufferNumber *
                                                     BufferedIndexOutput.BUFFER_SIZE +
                                                     1,
                                                     BufferedIndexOutput.BUFFER_SIZE);
                //System.out.println(".seek " + this.file.getName() +
                //                   " reloading bufferNo=" + bufferNo);
            } catch (SQLException s) {
                throw new IOException(".seek - can write Blob due: " +
                                      s.getLocalizedMessage());
            }
        }
        pointer = bufferPos;
    }

    /** Writes a single byte.
     * if pointer == BufferedIndexOutput.BUFFER_SIZE means that we reach a physical
     * end of chunk, so first call to flush and create a new empty buffer
     * because this method writes on his memory buffer, mark it as dirty
     * @see IndexInput#readByte()
     * @see #flush()
     */
    public void writeByte(byte b) throws IOException {
        if (pointer == BufferedIndexOutput.BUFFER_SIZE) {
            // write this buffer and create a new one chunk
            this.flush();
            currentBufferNumber++;
            currentBuffer = new byte[BufferedIndexOutput.BUFFER_SIZE];
            pointer = 0;
        }
        currentBuffer[pointer++] = b;
        if (currentBufferNumber * BufferedIndexOutput.BUFFER_SIZE + pointer >
            file.getSize()) {
            file.setSize(file.getSize() + 1);
        }
    }

    /** Writes an array of bytes.
     * @param b the bytes to write
     * @param length the number of bytes to write
     * @see IndexInput#readBytes(byte[],int,int)
     */
    public void writeBytes(byte[] b, int length) throws IOException {
        for (int offset = 0; offset < length; ++offset) {
            writeByte(b[offset]);
        }
    }

    /** Writes an array of bytes.
     * @param b the bytes to write
     * @param offset the offset in the byte array
     * @param length the number of bytes to write
     * @see IndexInput#readBytes(byte[],int,int)
     */
    public void writeBytes(byte[] b, int offset,
                           int length) throws IOException {
        for (int i = offset; i < length; ++i) {
            writeByte(b[i]);
        }
    }
}
