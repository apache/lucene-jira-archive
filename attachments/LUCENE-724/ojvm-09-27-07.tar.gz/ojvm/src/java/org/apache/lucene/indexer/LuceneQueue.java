package org.apache.lucene.indexer;

import java.io.IOException;

import java.sql.Connection;
import java.sql.SQLException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.store.OJVMUtil;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public class LuceneQueue {
    static final java.math.BigDecimal SUCCESS = new java.math.BigDecimal("0");

    static final java.math.BigDecimal ERROR = new java.math.BigDecimal("1");

    static final int FIRST_MESSAGE = 1;
    static final int NEXT_MESSAGE = 3;

    static final String enqueueStmt = "call LuceneDomainIndex.enqueueChange(?,?,?)";

    static final String dequeueStmt = "call LuceneDomainIndex.dequeueChange(?,?,?,?)";

    public LuceneQueue() {
    }

    /**
     * Process changes on Lucene Domain Index working in SyncMode:Deferred
     * @param prefix
     * @throws IOException
     * @throws SQLException
     */
    public static void sync(String prefix) throws IOException, SQLException {
        //System.out.println(".sync : "+prefix);
        HashMap scheduledDeleteForUpdate = new HashMap();
        HashMap scheduledAdd = new HashMap();
        OracleCallableStatement cs = null;
        Connection conn = null;
        OJVMDirectory dir = null;
        IndexReader reader = null;
        IndexWriter writer = null;
        try {
            dir = OJVMDirectory.getDirectory(prefix);
            Parameters par = dir.getParameters();
            String col = par.getParameter("ColName");
            String tableSchema = par.getParameter("TableSchema");
            String tableName = par.getParameter("TableName");
            String partition = par.getParameter("Partition");
            conn = dir.getConnection();
            cs = (OracleCallableStatement)conn.prepareCall(dequeueStmt);
            cs.setString(1, prefix);
            cs.setInt(2, FIRST_MESSAGE);
            cs.registerOutParameter(3, OracleTypes.VARCHAR);
            cs.registerOutParameter(4, OracleTypes.VARCHAR);
            try {
                cs.execute(); // first message
                String rid = cs.getString(3);
                String operation = cs.getString(4);
                //System.out.println("rid: "+rid+" ("+operation+")");
                if ("delete".equals(operation)) {
                    scheduledDeleteForUpdate.remove(rid);
                    scheduledAdd.remove(rid);
                } else {
                    if ("update".equals(operation)) // require deletion first
                        scheduledDeleteForUpdate.put(rid, "");
                    // insert
                    scheduledAdd.put(rid, "");
                }
                while (true) {
                    cs.setInt(2, NEXT_MESSAGE);
                    cs.execute(); // next message
                    rid = cs.getString(3);
                    operation = cs.getString(4);
                    //System.out.println("rid: "+rid+" ("+operation+")");
                    if ("delete".equals(operation)) {
                        scheduledDeleteForUpdate.remove(rid);
                        scheduledAdd.remove(rid);
                    } else {
                        if ("update".equals(operation)) // require deletion first
                            scheduledDeleteForUpdate.put(rid, "");
                        // insert
                        scheduledAdd.put(rid, "");
                    }
                }
            } catch (SQLException sqe) {
                if (sqe.getErrorCode() != 25228) {
                    sqe.printStackTrace();
                    throw sqe;
                } // else {
                //    System.out.println("No more lucene update msg to dequeue.");
                //}
            }
            if (scheduledDeleteForUpdate.isEmpty() && scheduledAdd.isEmpty())
                return; // Shorcut ;)
            //System.out.println("deleting: "+scheduledDeleteForUpdate.size()+" inserting: "+
            //                       scheduledAdd.size());
            reader = IndexReader.open(dir);
            Set deleted = scheduledDeleteForUpdate.keySet();
            Iterator ite = deleted.iterator();
            while (ite.hasNext()) {
                String rowid = (String)ite.next();
                //System.out.println("Deleting: "+rowid);
                reader.deleteDocuments(new Term("rowid", rowid));
            }
            reader.close();
            reader = null;
            int mergeFactor =
                Integer.parseInt(par.getParameter("MergeFactor", "" +
                                                  IndexWriter.DEFAULT_MERGE_FACTOR));
            int maxBufferedDocs =
                Integer.parseInt(par.getParameter("MaxBufferedDocs",
                                                  "" + IndexWriter.DEFAULT_MAX_BUFFERED_DOCS));
            int maxMergeDocs =
                Integer.parseInt(par.getParameter("MaxMergeDocs",
                                                  "" + IndexWriter.DEFAULT_MAX_MERGE_DOCS));
            Analyzer analyzer = LuceneDomainIndex.getAnalyzer(par);
            writer = new IndexWriter(dir, analyzer, false);
            writer.setMergeFactor(mergeFactor);
            writer.setMaxMergeDocs(maxMergeDocs);
            writer.setMaxBufferedDocs(maxBufferedDocs);
            Set inserted = scheduledAdd.keySet();
            String decimalFormat = par.getParameter("DecimalFormat", "00000");
            String dateResolution = par.getParameter("DateResolution", "day");
            UserDataStore userDataStore =
                LuceneDomainIndex.getUserDataStore(par);
            String extraCols = par.getParameter("ExtraCols");
            String extraTabs = par.getParameter("ExtraTabs");
            String whereCondition = par.getParameter("WhereCondition");
            TableIndexer index =
                new TableIndexer(dir.getConnection(), tableSchema, tableName,
                                 partition);
            index.setUserDataStore(userDataStore);
            index.setExtraColsStr(extraCols);
            index.setExtraTabsStr(extraTabs);
            index.setExtraWhereStr(whereCondition);
            //index.index(writer, col, inserted);
            writer.close();
            writer = null;
            dir.close();
            dir = null;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error syncing the index: " + prefix +
                                       " - " + e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(cs, null);
            if (reader != null)
                reader.close();
            if (writer != null)
                writer.close();
            if (dir != null)
                dir.close();
            scheduledDeleteForUpdate.clear();
            scheduledDeleteForUpdate = null;
            scheduledAdd.clear();
            scheduledAdd = null;
        }
    }

    /**
     * Discard pending changes on Lucene Domain Index by deleting messages on his queue
     * @param prefix
     */
    public static void discard(String prefix) {
        OracleCallableStatement cs = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            cs = (OracleCallableStatement)conn.prepareCall(dequeueStmt);
            cs.setString(1, prefix);
            cs.setInt(2, FIRST_MESSAGE);
            cs.registerOutParameter(3, OracleTypes.VARCHAR);
            cs.registerOutParameter(4, OracleTypes.VARCHAR);
            try {
                cs.execute(); // first message
                String rid = cs.getString(3);
                String operation = cs.getString(4);
                //System.out.println("discarding rid: "+rid+" ("+operation+")");
                while (true) {
                    cs.setInt(2, NEXT_MESSAGE);
                    cs.execute(); // next message
                    rid = cs.getString(3);
                    operation = cs.getString(4);
                    //System.out.println("discarding rid: "+rid+" ("+operation+")");
                }
            } catch (SQLException sqe) {
                if (sqe.getErrorCode() != 25228) {
                    sqe.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            //throw new RuntimeException("Error syncing the index: "+prefix+" - "+e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(cs, null);
        }
    }

    /**
     * Enqueue changes on Lucene Domain Index
     * @param prefix
     * @param rid
     * @param operation
     * @return
     * @throws SQLException
     */
    public static java.math.BigDecimal enqueue(String prefix, String rid,
                                               String operation) throws SQLException {
        OracleCallableStatement cs = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            cs = (OracleCallableStatement)conn.prepareCall(enqueueStmt);
            cs.setString(1, prefix);
            cs.setString(2, rid);
            cs.setString(3, operation);
            cs.execute();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
            return ERROR;
        } finally {
            OJVMUtil.closeDbResources(cs, null);
        }
        return SUCCESS;
    }
}
