package org.apache.lucene.index.store;

/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.indexer.Parameters;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.English;

/**
 * JUnit testcase to test RAMDirectory. RAMDirectory itself is used in many testcases,
 * but not one of them uses an different constructor other than the default constructor.
 * 
 * @author Bernhard Messer
 * 
 * @version $Id: TestDBDirectory.java,v 1.1.1.1 2007/08/27 11:31:13 mochoa Exp $
 */
public class TestDBDirectory extends TestCase {
  
  // add enough document so that the index will be larger than RAMDirectory.READ_BUFFER_SIZE
  private final int docsToAdd = 500;
  
  // setup the index
  public void setUp () throws IOException {
    Parameters parameters = new Parameters();
    parameters.setParameter("ColName","test");
    parameters.setParameter("MergeFactor","129");
    parameters.setParameter("MaxBufferedDocs","129");
    OJVMDirectory dir = null;
    dir = OJVMDirectory.getDirectory("testDB");
    dir.setParameters(parameters);
    
    IndexWriter writer  = new IndexWriter(dir, new WhitespaceAnalyzer(), true);
    // add some documents
    Document doc = null;
    for (int i = 0; i < docsToAdd; i++) {
      doc = new Document();
      doc.add(new Field("content", English.intToEnglish(i).trim(), Field.Store.YES, Field.Index.UN_TOKENIZED));
      writer.addDocument(doc);
    }
    assertEquals(docsToAdd, writer.docCount());
    writer.optimize();
    writer.close();
    dir.close();
  }
  
  public void testDBDirectory () throws IOException {
    Directory dir = null;
    dir = OJVMDirectory.getDirectory("testDB");
    Directory ramDir = new RAMDirectory(dir);
    dir.close();
    
    // open reader to test document count
    IndexReader reader = IndexReader.open(ramDir);
    assertEquals(docsToAdd, reader.numDocs());
    
    // open search zo check if all doc's are there
    IndexSearcher searcher = new IndexSearcher(reader);
    
    // search for all documents
    for (int i = 0; i < docsToAdd; i++) {
      Document doc = searcher.doc(i);
      assertTrue(doc.getField("content") != null);
    }

    // cleanup
    reader.close();
    searcher.close();
    ramDir.close();
  }

  /*public void testDBDirectoryFile () throws IOException {
      Directory dir = null;
      dir = OJVMDirectory.getDirectory("testDB");
      Directory ramDir = new RAMDirectory(dir);
      dir.close();
      
      // open reader to test document count
      IndexReader reader = IndexReader.open(ramDir);
      assertEquals(docsToAdd, reader.numDocs());
      
      // open search zo check if all doc's are there
      IndexSearcher searcher = new IndexSearcher(reader);
      
      // search for all documents
      for (int i = 0; i < docsToAdd; i++) {
        Document doc = searcher.doc(i);
        assertTrue(doc.getField("content") != null);
      }

      // cleanup
      reader.close();
      searcher.close();

      // close the underlaying directory and delete the index
      ramDir.close();

  }
    
  public void testDBDirectoryString () throws IOException {
      Directory dir = null;
      dir = OJVMDirectory.getDirectory("testDB");
      Directory ramDir = new RAMDirectory(dir);
      dir.close();
      
      // open reader to test document count
      IndexReader reader = IndexReader.open(ramDir);
      assertEquals(docsToAdd, reader.numDocs());
      
      // open search zo check if all doc's are there
      IndexSearcher searcher = new IndexSearcher(reader);
      
      // search for all documents
      for (int i = 0; i < docsToAdd; i++) {
        Document doc = searcher.doc(i);
        assertTrue(doc.getField("content") != null);
      }

      // cleanup
      reader.close();
      searcher.close();

      // close the underlaying directory and delete the index
      ramDir.close();
  }

  public void tearDown() {
    }*/
}
