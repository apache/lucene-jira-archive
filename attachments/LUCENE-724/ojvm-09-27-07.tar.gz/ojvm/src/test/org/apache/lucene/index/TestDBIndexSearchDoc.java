package org.apache.lucene.index;

import java.io.IOException;

import java.util.NoSuchElementException;

import junit.framework.TestCase;

import org.apache.lucene.search.Hit;
import org.apache.lucene.search.HitIterator;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.OJVMDirectory;


/**
 * @author mochoa
 * @author Marcelo F. Ochoa
 * @version $Id: TestDBIndexSearchDoc.java,v 1.1.1.1 2007/08/27 11:31:13 mochoa Exp $
 */
public class TestDBIndexSearchDoc extends TestCase {
    public void setUp () throws IOException {
    }

    public void testSearchDoc() throws IOException {
        Directory dir = null;
        IndexSearcher searcher = null;
        HitIterator iterator = null;
        try {
            dir = OJVMDirectory.getDirectory("myindex");
            searcher = new IndexSearcher(dir);
            Hits hits = searcher.search(new TermQuery(new Term("content", "iterator")));

            iterator = (HitIterator) hits.iterator();
            assertEquals(2, iterator.length());
            assertTrue(iterator.hasNext());
            Hit hit = (Hit) iterator.next();
            assertEquals("iterator test doc 1", hit.get("content"));

            assertTrue(iterator.hasNext());
            hit = (Hit) iterator.next();
            assertEquals("iterator test doc 2", hit.getDocument().get("content"));

            assertFalse(iterator.hasNext());

            boolean caughtException = false;
            try {
              iterator.next();
            } catch (NoSuchElementException e) {
              assertTrue(true);
              caughtException = true;
            }

            assertTrue(caughtException);
        } catch (IOException e) {
            throw e;  
        } finally {
            if (searcher!=null)
              searcher.close();
            if (dir!=null)
              dir.close();
        }
    }

    public void tearDown() {
    }
}









