package org.apache.lucene.index;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.OJVMDirectory;

 /**
  * @author mochoa
  * @author Marcelo F. Ochoa
  * @version $Id: TestDBIndexAddDoc.java,v 1.1.1.1 2007/08/27 11:31:13 mochoa Exp $
  */
public class TestDBIndexAddDoc extends TestCase {

    public void setUp () throws IOException {
    }

    public void testAddDoc() throws IOException {
      Directory dir = null;
      IndexWriter writer=null;
      try {
        dir = OJVMDirectory.getDirectory("myindex");
        writer=new IndexWriter(dir,new WhitespaceAnalyzer(),false);
        Document doc = new Document();
        doc.add(new Field("content", "iterator test doc 1", Field.Store.YES, Field.Index.TOKENIZED));
        writer.addDocument(doc);

        doc = new Document();
        doc.add(new Field("content", "iterator test doc 2", Field.Store.YES, Field.Index.TOKENIZED));
        writer.addDocument(doc);
        assertEquals(62,writer.docCount());
        writer.close();
        writer = null;
      } catch (IOException e) {
        throw e;  
      } finally {
        if (writer!=null)
          writer.close();
        if (dir!=null)
          dir.close();
      }
    }

    public void tearDown() {
    }
}









