package org.apache.lucene.index.store;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.lucene.index.Term;
import org.apache.lucene.search.HitIterator;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.util.English;

/**
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * JUnit testcase to test RAMDirectory. RAMDirectory itself is used in many testcases,
 * but not one of them uses an different constructor other than the default constructor.
 *
 * @author Bernhard Messer
 *
 * @version $Id: TestDBDirectorySearch.java,v 1.1.1.1 2007/08/27 11:31:13 mochoa Exp $
 */
public class TestDBDirectorySearch extends TestCase {
  
  // add enough document so that the index will be larger than RAMDirectory.READ_BUFFER_SIZE
  private final int searchCount = 500;
  private final long sleepTime   = 50L;
  Directory dir = null;
  // setup the index
  public void setUp () throws IOException {
      dir = OJVMDirectory.getDirectory("testDB");
  }
  
  public void testDBDirectorySearch() throws IOException,
                                             InterruptedException {
    
    IndexSearcher searcher = null;
    HitIterator iterator = null;
    // simulate search every 5 seconds
    for (int i = 0; i < searchCount; i++) {
        // open search so check if all doc's are there
        searcher = new IndexSearcher(dir);
        Hits hits = searcher.search(new TermQuery(new Term("content", English.intToEnglish(i).trim())));
        iterator = (HitIterator) hits.iterator();
        assertEquals(1, iterator.length());
        assertTrue(iterator.hasNext());
        searcher.close();
        Thread.sleep(sleepTime);
    }
  }

  public void tearDown() throws IOException {
      dir.close();
  }
}
