set long 10000 lines 140 pages 50 timing on echo on
set serveroutput on size 1000000 

begin
  dbms_java.set_output(1000000);
end;
/


-- For remote debugging grant as sys:
-- grant DEBUG CONNECT SESSION, DEBUG ANY PROCEDURE to lucene;
-- To start debuggin:
-- exec dbms_debug_jdwp.connect_tcp('192.168.11.107','4000')
-- Demo indexing an small table (487 rows)
-- test sync(index),optimize(index) procedures and deferred, massive batch inserts

create table test_source_small as 
(
select NAME,TYPE,LINE,TEXT from 
(select rownum as ntop_pos,q.* from (select * from user_source) q)
where ntop_pos>=0 and ntop_pos<100
);

create index source_small_lidx on test_source_small(text) 
indextype is lucene.LuceneIndex 
parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer;MaxBufferedDocs:500');

-- create index source_small_idx on test_source_small(text) 
-- indextype is ctxsys.context;
begin
   LuceneDomainIndex.optimize(USER||'.SOURCE_SMALL_LIDX');
   commit;
end;
/

select count(*) from test_source_small where lcontains(text,'sync')>0;
explain plan for
select count(*) from test_source_small where lcontains(text,'sync')>0;
set echo off
@@explainPlan
set echo on


insert into test_source_small
select NAME,TYPE,LINE,TEXT from (select rownum as ntop_pos,q.* from
(select * from user_source) q)
where ntop_pos>=100 and ntop_pos<200;
begin
   LuceneDomainIndex.optimize(USER||'.SOURCE_SMALL_LIDX');
   commit;
end;
/

select count(*) from test_source_small where lcontains(text,'sync')>0;

explain plan for
select count(*) from test_source_small where lcontains(text,'sync')>0;
set echo off
@@explainPlan
set echo on

insert into test_source_small
select NAME,TYPE,LINE,TEXT from (select rownum as ntop_pos,q.* from
(select * from user_source) q)
where ntop_pos>=200 and ntop_pos<500;
begin
   LuceneDomainIndex.optimize(USER||'.SOURCE_SMALL_LIDX');
   commit;
end;
/

select count(*) from test_source_small where lcontains(text,'type')>0;

explain plan for
select count(*) from test_source_small where lcontains(text,'type')>0;
set echo off
@@explainPlan
set echo on

drop table test_source_small;

-- Sample table with user data store parameter
create table t1 (
f1 number,
f2 varchar2(200),
f3 varchar2(200),
f4 number unique);

insert into t1 values (1, 'ravi','user data1',101);
insert into t1 values (3, 'murthy','user data3',103);
commit;

create table t2 (
f5 number primary key,
f6 varchar2(200), 
f7 date,
CONSTRAINT t2_t1_fk FOREIGN KEY (f5)
      REFERENCES t1(f4) ON DELETE cascade);

insert into t2 values (101, 'extra data1',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-1);
insert into t2 values (103, 'extra data3',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-3);
commit;

-- sample usage of user data stores
create index it1 on t1(f2) indextype is lucene.LuceneIndex 
  parameters('Stemmer:English');

alter index it1 
  parameters('UserDataStore:org.apache.lucene.indexer.DefaultUserDataStore');

alter index it1 
  parameters('ExtraCols:t1.f3,t1.f4,t2.f6,t2.f7;ExtraTabs:t2;WhereCondition:t1.f4=t2.f5(+)');
  
alter index it1 
  parameters('FormatCols:t1.f4(000),t2.f7(day)');

-- Create here this trigger to enqueue changes on parent table
CREATE OR REPLACE TRIGGER LT$IT1
AFTER UPDATE OF f6,f7 ON t2
FOR EACH ROW
DECLARE
  ridlist sys.ODCIRidList;
BEGIN
    SELECT ROWID 
      BULK COLLECT INTO ridlist
      FROM T1 WHERE F4=:NEW.f5;
    LuceneDomainIndex.enqueueChange(USER||'.IT1',ridlist,'update');
END;
/
-- Manually Sync or SyncMode:Online
-- CREATE OR REPLACE TRIGGER LT$IT1$ai
-- AFTER UPDATE OF f6,f7 ON t2
-- CALL LuceneDomainIndex.sync(USER||'.IT1')
--/

-- Force to re-index all
update t1 set f2=f2;

begin
  LuceneDomainIndex.sync(USER||'.IT1');
  commit; -- release lock
end;
/

-- query, returns one row, qryStr: DESC:(ravi)
select * from t1 where lcontains(f2, 'ravi') > 0;

explain plan for
select * from t1 where lcontains(f2, 'ravi') > 0;
set echo off
@@explainPlan
set echo on

-- returns no rows, qryStr: DESC:(aaa)
select * from t1 where lcontains(f2, 'aaa') > 0;

alter index it1 
  parameters('MaxBufferedDocs:500');

-- INSERT TESTS
INSERT INTO t1 VALUES (6, 'he abhorred accents','user data6',106);
INSERT INTO t1 VALUES (7, 'does','user data7',107);
begin
  LuceneDomainIndex.sync(USER||'.IT1');
  commit; -- release lock
end;
/
INSERT INTO t2 VALUES (106, 'extra data6',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-6);
INSERT INTO t2 VALUES (107, 'extra data7',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-7);

-- UPDATE TEST
UPDATE t1 SET f2 = 'Nipun' , f3 = 'user data33 modified' WHERE f1 = 3;
UPDATE t1 SET f2 = f2, f3 = 'user data1 modified' WHERE f1 = 1;
begin
  LuceneDomainIndex.sync(USER||'.IT1');
  commit; -- release lock
end;
/
-- update first related table, then base table
UPDATE t2 SET f6 = 'extra data6 modified' WHERE f5 = 106;
commit; 
-- here a trigger on t2 is fired to enqueue changes on t1
begin
  LuceneDomainIndex.sync(USER||'.IT1');
  commit; -- release lock
end;
/

-- INSERT TESTS
INSERT INTO t1 VALUES (16, 'ravi marcelo','user data16',116);
INSERT INTO t1 VALUES (17, 'marcelo','user data17',117);
begin
  LuceneDomainIndex.sync(USER||'.IT1');
  commit; -- release lock
end;
/
INSERT INTO t2 VALUES (116, 'extra data16',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-16);
INSERT INTO t2 VALUES (117, 'extra data17',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-17);
-- Commit to enqueue changes, see trigger above
commit;
begin
  LuceneDomainIndex.sync(USER||'.IT1');
  commit; -- release lock
end;
/

-- Other inserts
INSERT INTO t1 VALUES (26, 'hello world','user data26',026);
INSERT INTO t1 VALUES (27, 'cdrom','user data27',027);
begin
  LuceneDomainIndex.sync(USER||'.IT1');
  commit; -- release lock
end;
/
INSERT INTO t2 VALUES (026, 'extra data26',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-26);
INSERT INTO t2 VALUES (027, 'extra data27',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-27);
-- Commit to enqueue changes, see trigger above
commit;
begin
  LuceneDomainIndex.sync(USER||'.IT1');
  commit; -- release lock
end;
/

-- return two rows, qryStr: DESC:(ravi)
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

-- returns one row, qryStr: DESC:(+ravi +t1.f3:modifi)
select lscore(1),f2,f3 from t1 where lcontains(f2, 'ravi AND t1.f3:modified',1) > 0;

-- returns one row, qryStr: DESC:(+ravi +t2.f7:20070830)
select lscore(1),f2,f3 from t1 where lcontains(f2, 'ravi AND t2.f7:20070830',1)>0;

-- returns two rows, qryStr: DESC:(+ravi +t2.f7:[20070815 TO 20070830])
select lscore(1),f2,f3 from t1 where lcontains(f2, '(ravi OR Nipun) AND t2.f7:[20070815 TO 20070830]',1)>0;

explain plan for
select lscore(1),f2,f3 from t1 where lcontains(f2, 'ravi AND t2.f7:[20070815 TO 20070830]',1)>0;
set echo off
@@explainPlan
set echo on

-- returns two rows, qryStr: DESC:(+ravi +t2.f7:[20070815 TO 20070830])
select lscore(1),f2,f3,f6,f7 from t1,t2 
where lcontains(f2, '(ravi OR Nipun) AND t2.f7:[20070815 TO 20070830]',1)>0
and t1.f4=t2.f5;

explain plan for
select lscore(1),f2,f3,f6,f7 from t1,t2 
where lcontains(f2, '(ravi OR Nipun) AND t2.f7:[20070815 TO 20070830]',1)>0
and t1.f4=t2.f5;
set echo off
@@explainPlan
set echo on

-- returns two rows, qryStr: DESC:(+ravi +t2.f7:[20070815 TO 20070830])
select /*+ DOMAIN_INDEX_SORT */ lscore(1),f2,f3,f6,f7 from t1,t2 
where lcontains(f2, 'ravi AND t2.f7:[20070815 TO 20070830]',1)>0
and t1.f4=t2.f5;

explain plan for
select /*+ DOMAIN_INDEX_SORT */ lscore(1),f2,f3,f6,f7 from t1,t2 
where lcontains(f2, 'ravi AND t2.f7:[20070815 TO 20070830]',1)>0
and t1.f4=t2.f5;
set echo off
@@explainPlan
set echo on

-- returns one row, qryStr: DESC:(nipun)
select * from t1 where lcontains(f2, 'Nipun') > 0;

explain plan for
select * from t1 where lcontains(f2, 'Nipun') > 0;
set echo off
@@explainPlan
set echo on

-- returns two rows, qryStr: DESC:(nipun t2.f6:"extra data6 modifi")
select * from t1 where lcontains(f2, 'Nipun OR t2.f6:"extra data6 modified"') > 0;

-- This query must return this sequence 1 0 0 0 1 0 0 0
select lcontains(f2,'ravi') from t1;

explain plan for
select lcontains(f2,'ravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST, this operation is never enqueued!!!
DELETE FROM t1 WHERE f2 = 'ravi';

-- This query must return this sequence 0 0 0 1 0 0 0 first rows was deleted!!
select lcontains(f2,'ravi') from t1;

-- query from index table
-- SELECT name,file_size FROM lucene_index;

-- returns one row, "ravi marcelo" still as row, previous delete only drop one row
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'ravi',1) > 0;
set echo off
@@explainPlan
set echo on

-- returns one row, qryStr: DESC:(accent)
select lscore(1),f2 from t1 where lcontains(f2, 'accent',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'accent',1) > 0;
set echo off
@@explainPlan
set echo on

-- Range Query, returns six rows, one matching Ravi, five with range 001 to 107
-- qryStr: ASC:(ravi t1.f4:[001 TO 107])
select /*+ DOMAIN_INDEX_SORT */ lscore(1),f2,f4 from t1 
  where lcontains(f2,'Ravi OR t1.f4:[001 TO 107]',1)>0 order by lscore(1) asc;

-- qryStr: ASC:(t1.f4:[000 TO 100]), returns three rows
select /*+ DOMAIN_INDEX_SORT */ lscore(1),f2,f4 from t1 
  where lcontains(f2,'t1.f4:[001 TO 107]',1)>0 order by lscore(1) asc;

-- DROP TEST
drop table t2;
drop table t1;


-- Traditional master-detail example
create table t2 (
  f4 number primary key,
  f5 VARCHAR2(200));
insert into t2 values (101,'user data1');
insert into t2 values (102,'user data2');
commit;

create table t1 (
  f1 number, 
  f2 CLOB, 
  f3 number,
  CONSTRAINT t1_t2_fk FOREIGN KEY (f3)
      REFERENCES t2(f4) ON DELETE cascade);
      
insert into t1 values (1, 'ravi',101);
insert into t1 values (3, 'murthy',102);
commit;

create index it1 on t1(f3) indextype is lucene.LuceneIndex 
  parameters('Analyzer:org.apache.lucene.analysis.SimpleAnalyzer;ExtraCols:f2');

alter index it1 
  parameters('ExtraCols:f2,t2.f5;ExtraTabs:t2;WhereCondition:t1.f3=t2.f4');
-- Create here this trigger, detects change on dependant table and enqueue it
-- This can not be implemented automatically
CREATE OR REPLACE TRIGGER LT$IT1
AFTER INSERT OR UPDATE OF f5 ON t2
FOR EACH ROW
DECLARE
  ridlist sys.ODCIRidList;
BEGIN
    SELECT ROWID 
      BULK COLLECT INTO ridlist
      FROM T1 WHERE F3=:NEW.f4;
    LuceneDomainIndex.enqueueChange(USER||'.IT1',ridlist,'update');
END;
/

-- Call LuceneDomainIndex.sync(USER||'.IT1') manually or try SyncMode:OnLine
-- CREATE OR REPLACE TRIGGER LT$IT1$ai
-- AFTER INSERT OR UPDATE OF f5 ON t2
-- CALL LuceneDomainIndex.sync(USER||'.IT1')
--/

-- query
select lscore(1),f2 from t1 where lcontains(f3, 'f2:ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f3, 'f2:ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f3, 'f2:aaa') > 0;

explain plan for
select * from t1 where lcontains(f3, 'f2:aaa') > 0;
set echo off
@@explainPlan
set echo on

alter index it1 parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer;MaxBufferedDocs:500');

-- INSERT TESTS
INSERT INTO t1 VALUES (6, 'cheuk',101);
INSERT INTO t1 VALUES (7, 'chau',102);

-- UPDATE TEST, add master key index to force update on f2
UPDATE t1 SET f2 = 'Nipun', f3 = f3 WHERE f1 = 3;

-- INSERT TESTS
INSERT INTO t1 VALUES (16, 'ravi marcelo',101);
INSERT INTO t1 VALUES (17, 'marcelo',102);

commit;

-- Manually Sync, OnLine is disable by default
begin
   LuceneDomainIndex.sync(USER||'.IT1');
   commit;
end;
/

-- SELECT name,file_size FROM lucene_index;
-- return two rows
select lscore(1),f2 from t1 where lcontains(f3, 'f2:ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f3, 'f2:ravi',1) > 0;
set echo off
@@explainPlan
set echo on
-- returns one row
select * from t1 where lcontains(f3, 'f2:Nipun') > 0;

explain plan for
select * from t1 where lcontains(f3, 'f2:Nipun') > 0;
set echo off
@@explainPlan
set echo on

select lcontains(f3,'f2:ravi') from t1;

explain plan for
select lcontains(f3,'f2:ravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST
DELETE FROM t2 WHERE f4 = 102;
commit;
begin
   LuceneDomainIndex.sync(USER||'.IT1');
   commit;
end;
/

-- query from index table
-- SELECT name,file_size FROM lucene_index;

select lscore(1),f2 from t1 where lcontains(f3, 'f2:ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f3, 'f2:ravi',1) > 0;
set echo off
@@explainPlan
set echo on

-- DROP TEST
drop table t1;
drop table t2;


-- XMLType example and SyncMode:OnLine
-- Also sample XPath extract operation
create table t1 (f1 number, f2 XMLType);
insert into t1 values (1, XMLType('<emp id="1"><name>ravi</name></emp>'));
insert into t1 values (3, XMLType('<emp id="3"><name>murthy</name></emp>'));
commit;

-- Column names when you choose f2 as master column for Lucene Index is associated to
-- the internal name SYS_NC000004$, you can choose this name or associate the index
-- to another column and pass f2 as ExtraCols parameter.
create index it1 on t1(f1) indextype is lucene.LuceneIndex 
  parameters('Analyzer:org.apache.lucene.analysis.WhitespaceAnalyzer;ExtraCols:f2;FormatCols:F1(000),f2(/emp/name/text())');

commit;

-- query, returns one row
select lscore(1),f2 from t1 where lcontains(f1, 'f2:ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f1, 'f2:ravi',1) > 0;
set echo off
@@explainPlan
set echo on
-- returns no rows
select * from t1 where lcontains(f1, 'f2:aaa') > 0;

explain plan for
select * from t1 where lcontains(f1, 'f2:aaa') > 0;
set echo off
@@explainPlan
set echo on

alter index it1 
  parameters('Analyzer:org.apache.lucene.analysis.StopAnalyzer;MaxBufferedDocs:500;SyncMode:OnLine');


-- INSERT TESTS
INSERT INTO t1 VALUES (6, XMLType('<emp id="6"><name>cheuk</name></emp>'));
INSERT INTO t1 VALUES (7, XMLType('<emp id="7"><name>chau</name></emp>'));

-- UPDATE TEST
UPDATE t1 SET f2 = XMLType('<emp id="3"><name>Nipun</name></emp>'),f1=f1 WHERE f1 = 3;

-- query, do not see changes
select lscore(1),f2 from t1 where lcontains(f1, 'f2:Nipun',1) > 0;

-- notify changes to AQ
commit;
-- wait changes
begin
   LuceneDomainIndex.optimize(USER||'.IT1');
   commit;
end;
/
-- now we see changes after commit enable changes
select lscore(1),f2 from t1 where lcontains(f1, 'f2:Nipun',1) > 0;
-- Disable SyncMode:OnLine (default is Deferred)
alter index it1 parameters('~SyncMode:OnLine');

-- INSERT TESTS
INSERT INTO t1 VALUES (16, XMLType('<emp id="10"><name>ravi marcelo</name></emp>'));
INSERT INTO t1 VALUES (17, XMLType('<emp id="16"><name>marcelo</name></emp>'));

-- query from index table
-- SELECT name,file_size FROM lucene_index;
-- Manually Sync, OnLine mode was disable above
begin
   LuceneDomainIndex.sync(USER||'.IT1');
end;
/

-- SELECT name,file_size FROM lucene_index;

select lscore(1),f2 from t1 where lcontains(f1, 'f2:ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f1, 'f2:ravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f1, 'f2:Nipun') > 0;

explain plan for
select * from t1 where lcontains(f1, 'f2:Nipun') > 0;
set echo off
@@explainPlan
set echo on

select lcontains(f1,'f2:ravi') from t1;

explain plan for
select lcontains(f1,'f2:ravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST
DELETE FROM t1 WHERE f1 = 1;

-- query from index table
-- SELECT name,file_size FROM lucene_index;

select lscore(1),f2 from t1 where lcontains(f1, 'f2:ravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f1, 'f2:ravi',1) > 0;
set echo off
@@explainPlan
set echo on

-- DROP TEST
drop table t1;


-- IOT Test, also left padding varchar2 string.
create table t1 (f1 number primary key, f2 varchar2(200)) ORGANIZATION INDEX;
insert into t1 values (1, 'ravi');
insert into t1 values (3, 'murthy');
commit;

create index it1 on t1(f2) indextype is lucene.LuceneIndex 
  parameters('Stemmer:English;FormatCols:F2(zzzzzzzzzzzzzzz)');

-- query
select * from t1 where lcontains(f2, 'zzzzzzzzzzzravi') > 0;

explain plan for
select * from t1 where lcontains(f2, 'zzzzzzzzzzzravi') > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f2, 'zzzzzzzzzzzzaaa') > 0;

explain plan for
select * from t1 where lcontains(f2, 'zzzzzzzzzzzzaaa') > 0;
set echo off
@@explainPlan
set echo on

alter index it1 parameters('Stemmer:English;MaxBufferedDocs:500');

-- INSERT TESTS, first insert do not make left padding because is larger than format string
INSERT INTO t1 VALUES (6, 'he abhorred accents');
INSERT INTO t1 VALUES (7, 'does');

-- UPDATE TEST
UPDATE t1 SET f2 = 'Nipun' WHERE f1 = 3;

-- INSERT TESTS
INSERT INTO t1 VALUES (16, 'ravi marcelo');
INSERT INTO t1 VALUES (17, 'marcelo');

begin
  LuceneDomainIndex.optimize(USER||'.IT1');
end;
/

select lscore(1),f2 from t1 where lcontains(f2, 'zzzzzzzzzzzravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'zzzzzzzzzzzravi',1) > 0;
set echo off
@@explainPlan
set echo on

select * from t1 where lcontains(f2, 'zzzzzzzzzzNipun') > 0;

explain plan for
select * from t1 where lcontains(f2, 'zzzzzzzzzzNipun') > 0;
set echo off
@@explainPlan
set echo on

select lcontains(f2,'zzzzzzzzzzzravi') from t1;

explain plan for
select lcontains(f2,'zzzzzzzzzzzravi') from t1;
set echo off
@@explainPlan
set echo on

-- DELETE TEST, this operation is never enqueued!!!
DELETE FROM t1 WHERE f2 = 'ravi';

select lscore(1),f2 from t1 where lcontains(f2, 'zzzzzzzzzzzravi',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'zzzzzzzzzzzravi',1) > 0;
set echo off
@@explainPlan
set echo on

select lscore(1),f2 from t1 where lcontains(f2, 'accent',1) > 0;

explain plan for
select lscore(1),f2 from t1 where lcontains(f2, 'accent',1) > 0;
set echo off
@@explainPlan
set echo on

-- DROP TEST
drop table t1;


create table emails (
 emailFrom VARCHAR2(256),
 emailTo VARCHAR2(256),
 subject VARCHAR2(4000),
 emailDate DATE,
 bodyText CLOB)
/

create index emailbodyText on emails(bodyText) indextype is lucene.LuceneIndex 
parameters('Stemmer:English;ExtraCols:emailDate,subject,emailFrom,emailTo');

-- Create this trigger to automatically detect changes on related columns
CREATE OR REPLACE TRIGGER L$emailbodyText
BEFORE UPDATE OF emailDate,subject ON emails
FOR EACH ROW
BEGIN
      :new.bodyText := :new.bodyText;
END;
/


create index emailFromIdx on emails(emailFrom);

create index emailToIdx on emails(emailTo);

create index emailDateIdx on emails(emaildate);

insert into emails values ('mbraun@uni-hd.de','java-user@lucene.apache.org',
'boosting instead of sorting WAS: to boost or not to boost',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-7,
'Hi Daniel,
>> so a doc from 1973 should get a boost of 1.1973 and a doc of 1975 should
>> get a boost of 1.1975 .
>
> The boost is stored with a limited resolution. Try boosting one doc by 10,
> the other one by 20 or something like that.
You''re right. I thought that with the float values the resolution should
be good enough!
But there is only a difference in the score with a boosting diff of 0.2
(e.g. 1.7 and 1.9).
I know that there were many questions on the list regarding scoring
better new documents.
But I want to avoid any overhead like "FunctionQuery" at query time,
and in my case I have some documents
which have same values in many fields (=>same score) and the only
difference is the year.
However  I don''t want to overboost the score so that the scoring for
other criteria is not considered.
Shortly spoken: As a result of a search I have a list of book titles and
I want  a sort by score AND by year of publication.
But for performance reasons I want to avoid this sorting at query-time
by boosting at index time.
Is that possible?
thanks,
Martin');

insert into emails values ('ab@getopt.org','java-user@lucene.apache.org',
'Re: boosting instead of sorting WAS: to boost or not to boost',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-6,
'Martin Braun wrote:
> Hi Daniel,
>
>
>>> so a doc from 1973 should get a boost of 1.1973 and a doc of 1975 should
>>> get a boost of 1.1975 .
>>>
>> The boost is stored with a limited resolution. Try boosting one doc by 10,
>> the other one by 20 or something like that.
>>
>
> You''re right. I thought that with the float values the resolution should
> be good enough!
> But there is only a difference in the score with a boosting diff of 0.2
> (e.g. 1.7 and 1.9).
>
> I know that there were many questions on the list regarding scoring
> better new documents.
> But I want to avoid any overhead like "FunctionQuery" at query time,
> and in my case I have some documents
> which have same values in many fields (=>same score) and the only
> difference is the year.
>
> However  I don''t want to overboost the score so that the scoring for
> other criteria is not considered.
>
> Shortly spoken: As a result of a search I have a list of book titles and
> I want  a sort by score AND by year of publication.
>
> But for performance reasons I want to avoid this sorting at query-time
> by boosting at index time.
>
> Is that possible?
>
Here''s the trick that works for me, without the issues of boost
resolution or FunctionQuery.
Add a separate field, say "days", in which you will put as many "1" as
many days elapsed since the epoch (not neccessarily since 1 Jan 1970 -
pick a date that makes sense for you). Then, if you want to prioritize
newer documents, just add "+days:1" to your query. Voila - the final
results are a sum of other score factors plus a score factor that is
higher for more recent document, containing more 1-s.
If you are dealing with large time spans, you can split this into years
and days-in-a-year, and apply query boosts, like "+years:1^10.0
+days:1^0.02". Do some experiments and find what works best for you.
--
Best regards,
Andrzej Bialecki     <><
 ___. ___ ___ ___ _ _   __________________________________
[__ || __|__/|__||\/|  Information Retrieval, Semantic Web
___|||__||  \|  ||  |  Embedded Unix, System Integration
http://www.sigram.com  Contact: info at sigram dot com');

insert into emails values ('lucenelist2005@danielnaber.de','java-user@lucene.apache.org',
'Re: boosting instead of sorting WAS: to boost or not to boost',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-5,
'On Thursday 21 December 2006 10:55, Martin Braun wrote:
> and in my case I have some documents
> which have same values in many fields (=>same score) and the only
> difference is the year.
Andrzej''s response sounds like a good solution, so just for completeness:
you can sort by more than one criterion, e.g. first by score, then by
date.
regards
 Daniel
--
http://www.danielnaber.de');

insert into emails values ('codeshepherd@gmail.com','java-user@lucene.apache.org',
'lucene injection',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-4,
'I am bothered about security problems with lucene. Is it vulnerable to
any kind of injection like mysql injection? many times the query from
user is passed to lucene for search without validating.
');

insert into emails values ('erik@ehatchersolutions.com','java-user@lucene.apache.org',
'Re: lucene injection',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-3,
'On Dec 21, 2006, at 4:56 AM, Deepan wrote:
> I am bothered about security problems with lucene. Is it vulnerable to
> any kind of injection like mysql injection? many times the query from
> user is passed to lucene for search without validating.
Rest easy.  There are no known security issues with Lucene, and it
has even undergone a recent static code analysis by Fortify (see the
lucene-dev e-mail list archives).  Unlike SQL, there is no
destructive behavior available through the QueryParser.
     Erik');
       
insert into emails values ('codeshepherd@gmail.com','java-user@lucene.apache.org',
'Re: lucene injection',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-2,
'On Thu, 2006-12-21 at 05:04 -0500, Erik Hatcher wrote:
> On Dec 21, 2006, at 4:56 AM, Deepan wrote:
> > I am bothered about security problems with lucene. Is it vulnerable to
> > any kind of injection like mysql injection? many times the query from
> > user is passed to lucene for search without validating.
>
> Rest easy.  There are no known security issues with Lucene, and it
> has even undergone a recent static code analysis by Fortify (see the
> lucene-dev e-mail list archives).  Unlike SQL, there is no
> destructive behavior available through the QueryParser.
thanks Erik,
>
>       Erik
>
>
> ---------------------------------------------------------------------
> To unsubscribe, e-mail: java-user-unsubscribe@lucene.apache.org
> For additional commands, e-mail: java-user-help@lucene.apache.org
>');

insert into emails values ('lucenelist2005@danielnaber.de','java-user@lucene.apache.org',
'Re: lucene injection',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN')-1,
'On Thursday 21 December 2006 10:56, Deepan wrote:
> I am bothered about security problems with lucene. Is it vulnerable to
> any kind of injection like mysql injection? many times the query from
> user is passed to lucene for search without validating.
This is only an issue if your index has permission information and you
modify the user''s query so that only parts of the index are visible to
him. For example, if you add "+permission:user" to the query the user
might add something like "OR permission:admin" to get access to more
documents. This is also why you should add new parts to the query
programmatically (BooleanQuery) to avoid the use of QueryParser.
Regards
 Daniel
--
http://www.danielnaber.de');

insert into emails values ('lucenelist2005@danielnaber.de','java-user@lucene.apache.org',
'Re: lucene injection',to_date('FRI, 31 AUG 2007 06:28:19 GMT','DY, dd MON YYYY HH24:MI:SS "GMT"','NLS_DATE_LANGUAGE = AMERICAN'),
'On Thursday 21 December 2006 10:56, Deepan wrote:
> I am bothered about security problems with lucene. Is it vulnerable to
> any kind of injection like mysql injection? many times the query from
> user is passed to lucene for search without validating.
This is only an issue if your index has permission information and you
modify the user''s query so that only parts of the index are visible to
him. For example, if you add "+permission:user" to the query the user
might add something like "OR permission:admin" to get access to more
documents. This is also why you should add new parts to the query
programmatically (BooleanQuery) to avoid the use of QueryParser.
Regards
 Daniel
--
http://www.danielnaber.de');

begin
  LuceneDomainIndex.sync(USER||'.EMAILBODYTEXT');
  commit;
end;
/

SELECT * FROM emails where emailfrom like '%@gmail.com' and lcontains(bodytext,'security',1)>0
order by emaildate,lscore(1);

explain plan for
SELECT * FROM emails where emailfrom like '%@gmail.com' and lcontains(bodytext,'security',1)>0
order by emaildate,lscore(1);
set echo off
@@explainPlan
set echo on

SELECT /*+ DOMAIN_INDEX_SORT */ emailfrom FROM emails where emailfrom like '%@gmail.com' and lcontains(bodytext,'security',1)>0
order by lscore(1);

explain plan for
SELECT /*+ DOMAIN_INDEX_SORT */ emailfrom FROM emails where emailfrom like '%@gmail.com' and lcontains(bodytext,'security',1)>0
order by lscore(1);
set echo off
@@explainPlan
set echo on

SELECT /*+ DOMAIN_INDEX_SORT */ count(*) FROM emails where emailfrom like '%@getopt.org' and lcontains(bodytext,'subject:boosting',1)>0
order by lscore(1);

SELECT /*+ DOMAIN_INDEX_SORT */ emailfrom FROM emails where lcontains(bodytext,'security AND emailfrom:@gmail.com',1)>0
order by lscore(1);

drop table emails;
