set long 10000 lines 140 pages 50 timing on echo on
set serveroutput on size 1000000 

begin
  dbms_java.set_output(1000000);
end;
/

/*
declare
  c NUMBER;
begin
  for i in 1..32000 loop
  -- dbms_output.put_line('iteration '||i);
  select count(*) into c from t1 where lcontains(f2, 'ravi') > 0;
  -- dbms_output.put_line('count '||c);
  end loop;
end;
ALTER SESSION SET EVENTS='29891 trace name context forever';
*/


-- Demo indexing a big table (594k rows)
create table test_source_big as (
select owner,name,type,line,text from (select rownum as ntop_pos,q.* from
(select * from all_source) q)
where ntop_pos>=0 and ntop_pos<5000
);
-- MergeFactor,MaxBufferedDocs and MaxMergeDocs reduce IO over the BLOB storage
-- but you can get a java.lang.OutOfMemoryError with bigger values.
create index source_big_lidx on test_source_big(text) 
indextype is lucene.LuceneIndex 
parameters('MaxBufferedDocs:500;MergeFactor:500;FormatCols:line(0000);ExtraCols:line');

-- SQL> create index source_big_lidx on test_source_big(text)
--   2  indextype is lucene.LuceneIndex
--   3  parameters('MaxBufferedDocs:500;MergeFactor:500;LobStorageParameters:PCTVERSION 0 ENABLE STORAGE IN ROW CHUNK 32768 CACHE READS FILESYSTEM_LIKE_LOGGING');
-- Index created.
-- Elapsed: 00:04:54.86

create index source_big_idx on test_source_big(text) 
indextype is ctxsys.context; 
-- SQL> create index source_big_idx on test_source_big(text)
--   2  indextype is ctxsys.context;
-- Index created.
-- Elapsed: 00:01:22.93

insert into test_source_big
select owner,name,type,line,text from (select rownum as ntop_pos,q.* from
(select * from all_source) q)
where ntop_pos>=5000 and ntop_pos<10000;
begin
   LuceneDomainIndex.sync(USER||'.SOURCE_BIG_LIDX');
   commit;
end;
/

-- Must return 9 rows
select count(TEXT) from (select rownum as ntop_pos,q.* from
(select text from test_source_big where lcontains(text,'function')>0) q)
where ntop_pos>=0 and ntop_pos<10;

select sc,TEXT from (select rownum as ntop_pos,q.* from
(select lscore(1) sc,text from test_source_big where lcontains(text,'function',1)>0) q)
where ntop_pos>=0 and ntop_pos<10;

-- Must return 7 rows
select lscore(1) from test_source_big where lcontains(text,'"procedure java"~10',1)>0 order by lscore(1) desc;
select lscore(1) from test_source_big where lcontains(text,'"procedure java"~10',1)>0 order by lscore(1) asc;
-- Must return 2 rows
select /*+ DOMAIN_INDEX_SORT */ lscore(1) from test_source_big where lcontains(text,'(optimize OR sync) AND "LANGUAGE JAVA"',1)>0;
select /*+ DOMAIN_INDEX_SORT */ lscore(1) from test_source_big where lcontains(text,'(optimize OR sync) AND "LANGUAGE JAVA"',1)>0 order by lscore(1) asc;

insert into test_source_big
select owner,name,type,line,text from (select rownum as ntop_pos,q.* from
(select * from all_source) q)
where ntop_pos>=10000 and ntop_pos<15000;
begin
   LuceneDomainIndex.sync(USER||'.SOURCE_BIG_LIDX');
   commit;
end;
/
select count(TEXT) from (select rownum as ntop_pos,q.* from
(select text from test_source_big where lcontains(text,'function')>0) q)
where ntop_pos>=0 and ntop_pos<10;

insert into test_source_big
select owner,name,type,line,text from (select rownum as ntop_pos,q.* from
(select * from all_source) q)
where ntop_pos>=15000 and ntop_pos<20000;
begin
   LuceneDomainIndex.sync(USER||'.SOURCE_BIG_LIDX');
   commit;
end;
/

begin
   LuceneDomainIndex.optimize(USER||'.SOURCE_BIG_LIDX');
   commit;
end;
/


select count(TEXT) from (select rownum as ntop_pos,q.* from
(select text from test_source_big where lcontains(text,'function')>0) q)
where ntop_pos>=0 and ntop_pos<10;

-- Test execution time: 00:00:05.82
select sc,TEXT from (select rownum as ntop_pos,q.* from
(select /*+ DOMAIN_INDEX_SORT */ lscore(1) sc, text 
from test_source_big where lcontains(text,'function',1)>0) q)
where ntop_pos>=1990 and ntop_pos<2000;

select sc,TEXT from (select rownum as ntop_pos,q.* from
(select /*+ DOMAIN_INDEX_SORT */ lscore(1) sc, text 
from test_source_big where lcontains(text,'function',1)>0 order by lscore(1) asc) q)
where ntop_pos>=100 and ntop_pos<110;

-- inline pagination version using lcontains "rownum:[n TO m] AND" option
select /*+ DOMAIN_INDEX_SORT */ lscore(1) sc, text 
from test_source_big where lcontains(text,'rownum:[100 TO 109] AND function',1)>0 order by lscore(1) asc;

-- Test execution time: 00:00:00.38
-- Question: Why this query is faster than the above???, they have same execution plan :(
-- Answer: Context switching from SQL to Java for geetting score of 2000 rows is too high
-- Workaround: use inline pagination syntax, see example above
select TEXT from (select rownum as ntop_pos,q.* from
(select /*+ DOMAIN_INDEX_SORT */ lscore(1) sc,text 
from test_source_big where lcontains(text,'function',1)>0) q)
where ntop_pos>=100 and ntop_pos<110;

select TEXT from (select rownum as ntop_pos,q.* from
(select /*+ DOMAIN_INDEX_SORT */ lscore(1) sc,text 
from test_source_big where lcontains(text,'function',1)>0 order by lscore(1) asc) q)
where ntop_pos>=100 and ntop_pos<110;

-- Workaround: This version of the above query will be 3x faster because
-- only call to lscore() for exactly 10 rows of the pre-computed query
-- Test execution time: 00:00:01.55
select lscore(2),text from test_source_big where rowid in 
(select rd from (select rownum as ntop_pos,q.rowid rd from
  (select /*+ DOMAIN_INDEX_SORT */ text 
   from test_source_big where lcontains(text,'function',1)>0 order by lscore(1) asc) q)
 where ntop_pos>=100 and ntop_pos<110)
and lcontains(text,'function',2)>0;

select count(line) from test_source_big
  where lcontains(text,'varchar2')>0 and line>2600;
  
select count(line) from test_source_big
  where lcontains(text,'varchar2 AND line:[2600 TO 4000]')>0 and line>10;

select sc,TEXT from (select rownum as ntop_pos,q.* from
(select /*+ DOMAIN_INDEX_SORT */ lscore(1) sc, text 
from test_source_big where lcontains(text,'is',1)>0 order by lscore(1) asc) q)
where ntop_pos>=2000 and ntop_pos<2010;

-- inline pagination version using lcontains "rownum:[n TO m] AND" option
select /*+ DOMAIN_INDEX_SORT */ lscore(1) sc, text 
from test_source_big where lcontains(text,'rownum:[2000 TO 2009] AND is',1)>0 order by lscore(1) asc;

-- countHits example
-- Note: usage of last argument of countHits function.
-- if you choose ASC then order by lscore(1) must be ASC, if not Lucene can't found
-- a pre-cached Hits structure
declare 
  hits NUMBER;
  fromRow NUMBER;
  toRow NUMBER;
begin
  hits := LuceneDomainIndex.countHits(USER||'.SOURCE_BIG_LIDX','function OR procedure OR package','ASC');
  fromRow := round(hits*0.75);
  toRow := fromRow+10;
  dbms_output.put_line('Count Hits: '||hits);
  dbms_output.put_line('Score list from rownum: '||fromRow||' to: '||toRow);
  for c in (select /*+ DOMAIN_INDEX_SORT */ lscore(1) sc,text
             from test_source_big where lcontains(text,'rownum:['||fromRow||' TO '||toRow||'] AND  function OR procedure OR package',1)>0 
             order by lscore(1) ASC) loop
    dbms_output.put_line(' '||c.sc||'  '||c.text);
  end loop;
end;
/

-- traditional count(*) example, oops I got ORA-03113: end-of-file on communication channel on 11g
declare 
  hits NUMBER;
  fromRow NUMBER;
  toRow NUMBER;
begin
  select count(text) into hits 
     from test_source_big where lcontains(text,'function OR procedure',1)>0 
     order by lscore(1) ASC;
  fromRow := round(hits*0.75);
  toRow := fromRow+10;
  dbms_output.put_line('Count Hits: '||hits);
  dbms_output.put_line('Score list from rownum: '||fromRow||' to: '||toRow);
  for c in (select /*+ DOMAIN_INDEX_SORT */ lscore(1) sc,text
             from test_source_big where lcontains(text,'rownum:['||fromRow||' TO '||toRow||'] AND function OR procedure',1)>0 
             order by lscore(1) ASC) loop
    dbms_output.put_line(' '||c.sc||'  '||c.text);
  end loop;
end;
/
