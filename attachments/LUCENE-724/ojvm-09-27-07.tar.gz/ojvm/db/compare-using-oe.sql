conn sys/change_on_install@orcl as sysdba

alter user oe identified by oe account unlock;

grant dba to oe;

conn oe/oe@orcl

create index PurchaseOrder_idx on PURCHASEORDER p (value(p)) indextype is ctxsys.context;

select count(*) from PURCHASEORDER p where contains(value(p),'Madonna')>0;

select extract(p.object_value,'/PurchaseOrder/Reference').getStringVal()
from PURCHASEORDER p,resource_view r
where extractValue(r.res,'/Resource/XMLRef')=ref(p) and
under_path(r.res,'/home/OE/PurchaseOrders/2002/Apr')>0
and contains(p.object_value,'Madonna')>0;

create index PurchaseOrder_lidx on PURCHASEORDER p (value(p)) indextype is lucene.LuceneIndex parameters('Stemmer:English');

select count(*) from PURCHASEORDER p where lcontains(value(p),'Madonna')>0;

select extract(p.object_value,'/PurchaseOrder/Reference').getStringVal()
from PURCHASEORDER p,resource_view r
where extractValue(r.res,'/Resource/XMLRef')=ref(p) and
under_path(r.res,'/home/OE/PurchaseOrders/2002/Apr')>0
and lcontains(p.object_value,'Madonna')>0;

begin
  LuceneDomainIndex.optimize('OE.PURCHASEORDER_LIDX');
end;
/

select /*+ FIRST_ROWS(15) */ ntop_pos from (select rownum as ntop_pos,q.* from
(select /*+ FIRST_ROWS(10) */ * from PURCHASEORDER p where lcontains(value(p),'Madonna')>0) q)
where ntop_pos>=0 and ntop_pos<15;

select /*+ FIRST_ROWS(15) */ ntop_pos from (select rownum as ntop_pos,q.* from
(select /*+ FIRST_ROWS(10) */ * from PURCHASEORDER p where contains(value(p),'Madonna')>0) q)
where ntop_pos>=0 and ntop_pos<15;

