rem Compiled valid classes under lucene schema in batch to reduce memory usage
declare
  res NUMBER;
begin
  for c in (SELECT dbms_java.longname(object_name) cName
            FROM user_objects
            WHERE object_type = 'JAVA CLASS' AND status = 'VALID'
            AND dbms_java.longname(object_name) like 'org/apache/lucene/analysis/%') loop
    res := dbms_java.compile_class(c.cName);
  end loop;
end;
/

declare
  res NUMBER;
begin
  for c in (SELECT dbms_java.longname(object_name) cName
            FROM user_objects
            WHERE object_type = 'JAVA CLASS' AND status = 'VALID'
            AND dbms_java.longname(object_name) like 'org/apache/lucene/document/%') loop
    res := dbms_java.compile_class(c.cName);
  end loop;
end;
/

declare
  res NUMBER;
begin
  for c in (SELECT dbms_java.longname(object_name) cName
            FROM user_objects
            WHERE object_type = 'JAVA CLASS' AND status = 'VALID'
            AND dbms_java.longname(object_name) like 'org/apache/lucene/index/%') loop
    res := dbms_java.compile_class(c.cName);
  end loop;
end;
/

declare
  res NUMBER;
begin
  for c in (SELECT dbms_java.longname(object_name) cName
            FROM user_objects
            WHERE object_type = 'JAVA CLASS' AND status = 'VALID'
            AND dbms_java.longname(object_name) like 'org/apache/lucene/queryParser/%') loop
    res := dbms_java.compile_class(c.cName);
  end loop;
end;
/

declare
  res NUMBER;
begin
  for c in (SELECT dbms_java.longname(object_name) cName
            FROM user_objects
            WHERE object_type = 'JAVA CLASS' AND status = 'VALID'
            AND dbms_java.longname(object_name) like 'org/apache/lucene/search/%') loop
    res := dbms_java.compile_class(c.cName);
  end loop;
end;
/

declare
  res NUMBER;
begin
  for c in (SELECT dbms_java.longname(object_name) cName
            FROM user_objects
            WHERE object_type = 'JAVA CLASS' AND status = 'VALID'
            AND dbms_java.longname(object_name) like 'org/apache/lucene/store/%') loop
    res := dbms_java.compile_class(c.cName);
  end loop;
end;
/

declare
  res NUMBER;
begin
  for c in (SELECT dbms_java.longname(object_name) cName
            FROM user_objects
            WHERE object_type = 'JAVA CLASS' AND status = 'VALID'
            AND dbms_java.longname(object_name) like 'org/apache/lucene/util/%') loop
    res := dbms_java.compile_class(c.cName);
  end loop;
end;
/

declare
  res NUMBER;
begin
  for c in (SELECT dbms_java.longname(object_name) cName
            FROM user_objects
            WHERE object_type = 'JAVA CLASS' AND status = 'VALID'
            AND dbms_java.longname(object_name) like 'net/sf/%') loop
    res := dbms_java.compile_class(c.cName);
  end loop;
end;
/

declare
  res NUMBER;
begin
  for c in (SELECT dbms_java.longname(object_name) cName
            FROM user_objects
            WHERE object_type = 'JAVA CLASS' AND status = 'VALID'
            AND dbms_java.longname(object_name) like 'junit/%') loop
    res := dbms_java.compile_class(c.cName);
  end loop;
end;
/

-- compile rest of the classes which have methods uncompiled
-- declare
--   res NUMBER;
-- begin
--   for c in (select distinct name cName from user_java_methods where is_compiled='NO') loop
--     res := dbms_java.compile_class(c.cName);
--   end loop;
-- end;
--/

