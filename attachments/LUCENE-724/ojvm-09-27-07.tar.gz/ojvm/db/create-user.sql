rem usage notes:
rem sqlplus sys/change_on_install@orcl @db/create-user.sql
rem run on the server machine, because it use dbms_java.loadjava

drop user LUCENE cascade;

create user LUCENE identified by LUCENE
default tablespace users
temporary tablespace temp
quota unlimited on users;

grant connect,resource to LUCENE;
grant create public synonym, drop public synonym to LUCENE;
grant create any trigger, drop any trigger to LUCENE;
grant create library to LUCENE;
grant create any directory to LUCENE;
grant create any operator,  create indextype, create table to LUCENE;
grant select any table to LUCENE;
GRANT EXECUTE ON dbms_aq TO LUCENE;
GRANT EXECUTE ON dbms_aqadm TO LUCENE;
grant select on v_$session to LUCENE;
grant select on v_$sqlarea to LUCENE;
-- requires to use DBMS_XPLAN
grant select on V_$SQL_PLAN_STATISTICS_ALL to lucene;
grant select on V_$SQL_PLAN to lucene;
grant select on V_$SESSION to lucene;
grant select on V_$SQL_PLAN_STATISTICS_ALL to lucene;
grant select on V_$SQL to lucene;
-- debugging priv
grant DEBUG CONNECT SESSION, DEBUG ANY PROCEDURE to lucene;
-- Auto trace facilities
grant SELECT_CATALOG_ROLE to lucene;
-- NCOMP required roles on 10g
GRANT JAVA_DEPLOY TO lucene;
GRANT JAVASYSPRIV TO lucene;

-- JUnit required priv
begin
  dbms_java.grant_permission('LUCENE','SYS:java.io.FilePermission', '/junit.properties', 'read' );
  dbms_java.grant_permission('LUCENE','SYS:java.lang.RuntimePermission', 'getClassLoader', '' );
  dbms_java.grant_permission('LUCENE','SYS:java.lang.RuntimePermission', 'accessDeclaredMembers', '' );
  -- Update with your oracle home
  -- NCOMP required roles on 10g
  -- dbms_java.grant_permission('LUCENE', 'java.io.FilePermission', '/u01/app/oracle/product/10.2.0/db_1/-', 'read,write');
end;
/
-- VERY IMPORTANT POINT WITH LUCENE DOMAIN INDEX USAGE.
-- USER LIKE SCOTT REQUIRES GRANT EXECUTE ON:
--      DBMS_AQ
--      DBMS_AQADM
-- PACKAGES, GRANT MUST BE GRANTED DIRECTLY TO SCOTT USER, NOT TROUGH A ROLE.
exit
