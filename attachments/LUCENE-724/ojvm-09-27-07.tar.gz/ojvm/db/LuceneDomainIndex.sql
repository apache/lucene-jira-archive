
---------------------------------------------------------------------
--    LUCENE Index Method  Implemented as Trusted Callouts  --
---------------------------------------------------------------------
-- Drops
drop public synonym lucene_msg_typ;
drop public synonym LContains;
drop public synonym LScore;
drop public synonym LuceneDomainIndex;
drop public synonym LuceneDomainAdm;
-- uncomment this line if you want to drop the domain index without dropping lucene user
-- drop indextype LuceneIndex force;
-- drop operator LScore force;
-- drop operator LContains force;
-- drop type LuceneDomainIndex force;
-- drop table LUCENE_INDEX;

CREATE or replace type lucene_msg_typ as object (
  ridlist     sys.ODCIRidList,
  operation   VARCHAR2(32)
);
/
show errors

CREATE OR REPLACE TYPE lucene_msg_typ_array as VARRAY(32768) of lucene_msg_typ;
/
show errors

-- CREATE INDEXTYPE IMPLEMENTATION TYPE
create type LuceneDomainIndex authid current_user as object
(
  scanctx integer,
  STATIC FUNCTION getIndexPrefix(ia SYS.ODCIIndexInfo, env SYS.ODCIEnv) RETURN VARCHAR2,
  
  STATIC FUNCTION TextContains(Text IN VARCHAR2, Key IN VARCHAR2,
                               indexctx IN sys.ODCIIndexCtx, sctx IN OUT NOCOPY LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextContains(
                java.lang.String, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
  STATIC FUNCTION TextContains(Text IN CLOB, Key IN VARCHAR2,
                               indexctx IN sys.ODCIIndexCtx, sctx IN OUT NOCOPY LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextContains(
                oracle.sql.CLOB, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
  STATIC FUNCTION TextContains(Text IN XMLTYPE, Key IN VARCHAR2,
                               indexctx IN sys.ODCIIndexCtx, sctx IN OUT NOCOPY LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextContains(
                oracle.xdb.XMLType, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',

  STATIC FUNCTION TextScore(Text IN VARCHAR2, Key IN VARCHAR2,
                            indexctx IN sys.ODCIIndexCtx, sctx IN OUT NOCOPY LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextScore(
                java.lang.String, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
  STATIC FUNCTION TextScore(Text IN CLOB, Key IN VARCHAR2,
                            indexctx IN sys.ODCIIndexCtx, sctx IN OUT NOCOPY LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextScore(
                oracle.sql.CLOB, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',
                
  STATIC FUNCTION TextScore(Text IN XMLTYPE, Key IN VARCHAR2,
                            indexctx IN sys.ODCIIndexCtx, sctx IN OUT NOCOPY LuceneDomainIndex, scanflg IN NUMBER) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.TextScore(
                oracle.xdb.XMLType, java.lang.String,
                oracle.ODCI.ODCIIndexCtx, org.apache.lucene.indexer.LuceneDomainIndex[], 
		java.math.BigDecimal) return java.math.BigDecimal',

  STATIC FUNCTION ODCIGetInterfaces(ifclist OUT sys.ODCIObjectList) RETURN NUMBER,
  
  STATIC FUNCTION ODCIIndexCreate(ia sys.ODCIIndexInfo, parms VARCHAR2,
                                  env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexCreate(oracle.ODCI.ODCIIndexInfo, java.lang.String, 
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  STATIC FUNCTION ODCIIndexAlter(ia sys.ODCIIndexInfo, parms IN OUT VARCHAR2, alter_option NUMBER, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexAlter(oracle.ODCI.ODCIIndexInfo, java.lang.String[], java.math.BigDecimal,
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
                
  STATIC FUNCTION ODCIIndexDrop(ia sys.ODCIIndexInfo, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexDrop(oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
                
  STATIC FUNCTION ODCIIndexTruncate(ia SYS.ODCIIndexInfo, env SYS.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
        'org.apache.lucene.indexer.LuceneDomainIndex.ODCIIndexTruncate(oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
                
  STATIC FUNCTION deleteInternal(ia sys.ODCIIndexInfo, ridlist sys.ODCIRidList, env sys.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIDelete(oracle.ODCI.ODCIIndexInfo, oracle.ODCI.ODCIRidList, 
		oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  -- Array DML implementation --
  STATIC FUNCTION ODCIIndexDelete(ia sys.ODCIIndexInfo, ridlist sys.ODCIRidList, env sys.ODCIEnv) RETURN NUMBER,
  
  STATIC FUNCTION ODCIIndexInsert(ia sys.ODCIIndexInfo, ridlist sys.ODCIRidList, env sys.ODCIEnv) RETURN NUMBER,
  
  STATIC FUNCTION ODCIIndexUpdate(ia sys.ODCIIndexInfo, ridlist sys.ODCIRidList, env sys.ODCIEnv) RETURN NUMBER,
  
  STATIC FUNCTION ODCIIndexStart(sctx IN OUT NOCOPY LuceneDomainIndex,
        ia SYS.ODCIIndexInfo, op SYS.ODCIPredInfo, qi sys.ODCIQueryInfo,
        strt number, stop number,
        cmppos NUMBER, cmpval VARCHAR2, env SYS.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIStart(org.apache.lucene.indexer.LuceneDomainIndex[],
                oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIPredInfo, 
		oracle.ODCI.ODCIQueryInfo,
                java.math.BigDecimal, java.math.BigDecimal, java.math.BigDecimal,
                java.lang.String, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  STATIC FUNCTION ODCIIndexStart(sctx IN OUT NOCOPY LuceneDomainIndex,
        ia SYS.ODCIIndexInfo, op SYS.ODCIPredInfo, qi sys.ODCIQueryInfo,
        strt number, stop number,
        cmpval VARCHAR2, env SYS.ODCIEnv) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIStart(org.apache.lucene.indexer.LuceneDomainIndex[],
                oracle.ODCI.ODCIIndexInfo, 
		oracle.ODCI.ODCIPredInfo, 
		oracle.ODCI.ODCIQueryInfo,
                java.math.BigDecimal, java.math.BigDecimal, 
                java.lang.String, oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  MEMBER FUNCTION ODCIIndexFetch(nrows NUMBER, rids OUT NOCOPY SYS.ODCIridlist, env SYS.ODCIEnv) RETURN NUMBER as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIFetch(java.math.BigDecimal, 
	oracle.ODCI.ODCIRidList[], oracle.ODCI.ODCIEnv) return java.math.BigDecimal',

  MEMBER FUNCTION ODCIIndexClose(env SYS.ODCIEnv) RETURN NUMBER as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.ODCIClose(oracle.ODCI.ODCIEnv) return java.math.BigDecimal',
  
  STATIC PROCEDURE sync(prefix VARCHAR2),

  STATIC PROCEDURE syncInternal(prefix VARCHAR2, deleted sys.ODCIRidList, inserted sys.ODCIRidList) as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.sync(java.lang.String, oracle.ODCI.ODCIRidList, oracle.ODCI.ODCIRidList)',

  STATIC PROCEDURE optimize(prefix VARCHAR2),

  STATIC PROCEDURE optimizeInternal(prefix VARCHAR2) as LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.optimize(java.lang.String)',

  STATIC PROCEDURE msgCallBack(context  IN  RAW, 
                               reginfo  IN  SYS.AQ$_REG_INFO, 
                               descr    IN  SYS.AQ$_DESCRIPTOR, 
                               payload  IN  RAW,
                               payloadl IN  NUMBER),

  STATIC PROCEDURE enableCallBack(prefix VARCHAR2),
  STATIC PROCEDURE disableCallBack(prefix VARCHAR2),
  STATIC PROCEDURE enqueueChange(prefix VARCHAR2, rid VARCHAR2, operation VARCHAR2),
  STATIC PROCEDURE enqueueChange(prefix VARCHAR2, ridlist sys.ODCIRidList, operation VARCHAR2),
  STATIC PROCEDURE createTable(prefix VARCHAR2, lobStorageParam VARCHAR2),
  STATIC PROCEDURE dropTable(prefix VARCHAR2),

  STATIC FUNCTION countHits(prefix VARCHAR2, cmpval VARCHAR2, orderBy VARCHAR2) RETURN NUMBER AS LANGUAGE JAVA NAME
	'org.apache.lucene.indexer.LuceneDomainIndex.countHits( 
                java.lang.String, java.lang.String, java.lang.String) return java.math.BigDecimal',

  PRAGMA RESTRICT_REFERENCES (getIndexPrefix, WNDS, WNPS, RNDS, RNPS),
  PRAGMA RESTRICT_REFERENCES (TextContains, WNDS, WNPS),
  PRAGMA RESTRICT_REFERENCES (TextScore, WNDS, WNPS),
  PRAGMA RESTRICT_REFERENCES (ODCIIndexStart, WNDS, WNPS),
  PRAGMA RESTRICT_REFERENCES (ODCIIndexFetch, WNDS, WNPS),
  PRAGMA RESTRICT_REFERENCES (ODCIIndexClose, WNDS, WNPS),
  PRAGMA RESTRICT_REFERENCES (countHits, WNDS, WNPS)
);
/
show errors

create or replace type body LuceneDomainIndex is
  static function getIndexPrefix(ia SYS.ODCIIndexInfo, env SYS.ODCIEnv) return VARCHAR2 is
  begin
    if (ia.IndexPartition is not null and  env.CallProperty is not null) then
      return ia.IndexSchema || '.' || ia.IndexName || '.' || ia.IndexPartition;
    else
      return ia.IndexSchema || '.' || ia.IndexName;
    end if;
  end getIndexPrefix;

  static function ODCIGetInterfaces(
    ifclist out    sys.ODCIObjectList) return number is
  begin
    ifclist := sys.ODCIObjectList(sys.ODCIObject('SYS','ODCIINDEX2'));
    return sys.ODCIConst.Success;
  end ODCIGetInterfaces;
  
  static procedure msgCallBack(context  IN  RAW,
                               reginfo  IN  SYS.AQ$_REG_INFO,
                               descr    IN  SYS.AQ$_DESCRIPTOR,
                               payload  IN  RAW,
                               payloadl IN  NUMBER) is
    dequeue_options     dbms_aq.dequeue_options_t;
    message_properties  dbms_aq.message_properties_t;
    message_handle      RAW(16);
    message             LUCENE.lucene_msg_typ;
    prefix              VARCHAR2(4000) := utl_raw.cast_to_varchar2(context);
    rcount              NUMBER;
    begin
      -- serialize callback excecution acquiring an exclusive on lock on queue table
      EXECUTE IMMEDIATE 'LOCK TABLE '||prefix||'$T IN EXCLUSIVE MODE';
      -- get the consumer name and msg_id from the descriptor
      dequeue_options.msgid := descr.msg_id;
      dequeue_options.consumer_name := descr.consumer_name;
      DBMS_AQ.DEQUEUE(queue_name          =>     descr.queue_name,
                      dequeue_options      =>    dequeue_options,
                      message_properties  =>     message_properties,
                      payload             =>     message,
                      msgid               =>     message_handle);
      if (message.operation = 'update') then
          syncInternal(prefix,message.ridlist,message.ridlist);
      else if (message.operation = 'insert') then
              syncInternal(prefix,sys.ODCIRidList(),message.ridlist);
           else
              null;  -- delete, do nothing on SyncMode:OnLine
           end if;
      end if;
      commit;
  end msgCallBack;
  
  static procedure enableCallBack(prefix VARCHAR2) is
      reginfo             sys.aq$_reg_info;
      reginfolist         sys.aq$_reg_info_list;
  begin
    reginfo := sys.aq$_reg_info(prefix||'$Q',
                                DBMS_AQ.NAMESPACE_AQ,
                                'plsql://LuceneDomainIndex.msgCallBack',
                                utl_raw.cast_to_raw(prefix));
    reginfolist := sys.aq$_reg_info_list(reginfo);
    sys.dbms_aq.register(reginfolist, 1);
  end enableCallBack;
  
  static procedure disableCallBack(prefix VARCHAR2) is
      reginfo             sys.aq$_reg_info;
      reginfolist         sys.aq$_reg_info_list;
  begin
    reginfo := sys.aq$_reg_info(prefix||'$Q',
                                DBMS_AQ.NAMESPACE_AQ,
                                'plsql://LuceneDomainIndex.msgCallBack',
                                utl_raw.cast_to_raw(prefix));
    reginfolist := sys.aq$_reg_info_list(reginfo);
    sys.dbms_aq.unregister(reginfolist, 1);
  end disableCallBack;
  
  static procedure enqueueChange(prefix VARCHAR2, rid VARCHAR2, operation VARCHAR2) is
      ridlist             sys.ODCIRidList;
  begin
      ridlist := sys.ODCIRidList(rid);  -- create a list with one row
      enqueueChange(prefix,ridlist,operation);
  end enqueueChange;
  
  static procedure enqueueChange(prefix VARCHAR2, ridlist sys.odciridlist, operation VARCHAR2) is
      enqueue_options     DBMS_AQ.enqueue_options_t;
      message_properties  DBMS_AQ.message_properties_t;
      message_handle      RAW(16);
      message             LUCENE.lucene_msg_typ;
  begin
      message := LUCENE.lucene_msg_typ(ridlist,operation);
      dbms_aq.enqueue(queue_name         => prefix||'$Q',
                      enqueue_options    => enqueue_options,
                      message_properties => message_properties,
                      payload            => message,
                      msgid              => message_handle);
  end enqueueChange;

  -- Array DML version --
  static function ODCIIndexInsert(ia sys.ODCIIndexInfo, ridlist sys.ODCIRidList, env sys.ODCIEnv) return NUMBER is
  begin
     enqueueChange(getIndexPrefix(ia,env),ridlist,'insert');
     return sys.ODCICONST.SUCCESS;
  end ODCIIndexInsert;
  
  static function ODCIIndexUpdate(ia sys.ODCIIndexInfo, ridlist sys.odciridlist, env sys.ODCIEnv) return NUMBER is
  begin
     enqueueChange(getIndexPrefix(ia,env),ridlist,'update');
     return sys.ODCICONST.SUCCESS;
  end ODCIIndexUpdate;

  static function ODCIIndexDelete(ia sys.ODCIIndexInfo, ridlist sys.odciridlist, env sys.ODCIEnv) return NUMBER is
  begin
     enqueueChange(getIndexPrefix(ia,env),ridlist,'delete');
     return deleteInternal(ia,ridlist,env);
  end ODCIIndexDelete;
  
  static procedure sync(prefix VARCHAR2) is
    type filteredQueue IS TABLE OF BOOLEAN INDEX BY VARCHAR2(18);
    scheduledDeleteForUpdate    filteredQueue;
    scheduledAdd                filteredQueue;
    deleted                     sys.odciridlist;
    inserted                    sys.odciridlist;
    dequeue_options             DBMS_AQ.dequeue_options_t;
    message_properties          DBMS_AQ.message_properties_t;
    message_handle              RAW(16);
    message                     LUCENE.lucene_msg_typ;
    message_no_data             LUCENE.lucene_msg_typ;
    rid                         VARCHAR2(18);
    counter                     INTEGER;
    no_messages                 exception;
    PRAGMA EXCEPTION_INIT (no_messages, -25228);
  begin
   -- use Lucene's storage table as exclusive lock
   EXECUTE IMMEDIATE 'LOCK TABLE '||prefix||'$T IN EXCLUSIVE MODE';
   dequeue_options.wait         := DBMS_AQ.NO_WAIT;
   dequeue_options.navigation   := DBMS_AQ.FIRST_MESSAGE;
   dequeue_options.dequeue_mode := DBMS_AQ.LOCKED;
   LOOP
       DBMS_AQ.DEQUEUE(
          queue_name         => prefix||'$Q',
          dequeue_options    => dequeue_options,
          message_properties => message_properties,
          payload            => message,
          msgid              => message_handle);
       if (message.operation = 'delete') then
         for i in 1 .. message.ridlist.last loop
              scheduledDeleteForUpdate.delete(message.ridlist(i));
              scheduledAdd.delete(message.ridlist(i));
         end loop;
       else if (message.operation = 'update') then
              for i in 1 .. message.ridlist.last loop
                 scheduledDeleteForUpdate(message.ridlist(i)) := TRUE;
              end loop;
            end if;
            for i in 1 .. message.ridlist.last loop
               scheduledAdd(message.ridlist(i)) := TRUE;
            end loop;
       end if;
       dequeue_options.dequeue_mode := dbms_aq.REMOVE_NODATA;
       dequeue_options.msgid := message_handle;
       dequeue_options.deq_condition := '';
       dbms_aq.dequeue(
                  queue_name         => prefix||'$Q',
                  dequeue_options    => dequeue_options,
                  message_properties => message_properties,
                  payload            => message_no_data,
                  msgid              => message_handle);
       dequeue_options.dequeue_mode := DBMS_AQ.LOCKED;
       dequeue_options.msgid := NULL;
       dequeue_options.navigation := dbms_aq.NEXT_MESSAGE;
   END LOOP;
  EXCEPTION
     WHEN no_messages THEN
        counter := 1;
        rid := scheduledDeleteForUpdate.first;
        deleted := sys.ODCIRidList();
        while rid is not null loop
          deleted.extend;
          deleted(counter) := rid;
          counter := counter+1;
          rid := scheduledDeleteForUpdate.next(rid);
        end loop;
        counter := 1;
        rid := scheduledAdd.first;
        inserted := sys.ODCIRidList();
        while rid is not null loop
          inserted.extend;
          inserted(counter) := rid;
          counter := counter+1;
          rid := scheduledAdd.next(rid);
        end loop;
        syncInternal(prefix,deleted,inserted);
  end sync;
  
  static procedure optimize(prefix VARCHAR2) is
  begin
    sync(prefix); -- purge pending changes first
    optimizeInternal(prefix); -- then optimize
  end optimize;
  
  static procedure createTable(prefix VARCHAR2, lobStorageParam VARCHAR2) is
  begin
      EXECUTE IMMEDIATE
'create table '||prefix||'$T (
    NAME          VARCHAR2(30) primary key, 
    LAST_MODIFIED TIMESTAMP,
    FILE_SIZE     INTEGER,
    DATA          BLOB,
    DELETED       CHAR(1)
    ) LOB (DATA) STORE AS SECUREFILE ('||lobStorageParam||')';
      EXECUTE IMMEDIATE
'create index '||prefix||'$DI on '||prefix||'$T (DELETED)';
  end createTable;
  
  static procedure dropTable(prefix VARCHAR2) is
  begin
      EXECUTE IMMEDIATE 'DROP TABLE '||prefix||'$T FORCE';
  end dropTable;
end;
/
show errors

create or replace package LuceneDomainAdm authid definer as
  procedure createQueue(prefix VARCHAR2);
  procedure dropQueue(prefix VARCHAR2);
  procedure purgueQueue(prefix VARCHAR2);
end;
/
show errors

create or replace package body LuceneDomainAdm as
  procedure createQueue(prefix VARCHAR2) is
    reginfo             sys.aq$_reg_info;
    reginfolist         sys.aq$_reg_info_list;
  begin
    DBMS_AQADM.CREATE_QUEUE_TABLE(queue_table        => prefix||'$QT',
                                  queue_payload_type => 'LUCENE.lucene_msg_typ',
                                  sort_list          => 'PRIORITY,ENQ_TIME', 
                                  compatible         => '10.0');
    DBMS_AQADM.CREATE_QUEUE(queue_name         => prefix||'$Q',
                            queue_table        => prefix||'$QT');
    DBMS_AQADM.START_QUEUE(queue_name          => prefix||'$Q');
    commit;
  end createQueue;
  procedure dropQueue(prefix VARCHAR2) is
  begin
    DBMS_AQADM.STOP_QUEUE (queue_name         => prefix||'$Q');
    DBMS_AQADM.DROP_QUEUE (queue_name         => prefix||'$Q');
    DBMS_AQADM.DROP_QUEUE_TABLE (queue_table  => prefix||'$QT');
    commit;
  end dropQueue;
  procedure purgueQueue(prefix VARCHAR2) is
    po dbms_aqadm.aq$_purge_options_t;
  begin
   po.block := TRUE;
   DBMS_AQADM.PURGE_QUEUE_TABLE(
     queue_table     => prefix||'$QT',
     purge_condition => NULL,
     purge_options   => po);
  end purgueQueue;
end;
/
show errors

ALTER JAVA CLASS "org.apache.lucene.indexer.LuceneDomainContext" RESOLVE;
show errors
ALTER JAVA CLASS "org.apache.lucene.indexer.LuceneDomainIndex"  RESOLVE;
show errors

CREATE OR REPLACE OPERATOR LContains
  BINDING (VARCHAR2, VARCHAR2) RETURN NUMBER
  WITH INDEX CONTEXT, SCAN CONTEXT LuceneDomainIndex COMPUTE ANCILLARY DATA
  without column data USING LuceneDomainIndex.TextContains,
  (CLOB, VARCHAR2) RETURN NUMBER
  WITH INDEX CONTEXT, SCAN CONTEXT LuceneDomainIndex COMPUTE ANCILLARY DATA
  without column data USING LuceneDomainIndex.TextContains,
  (sys.XMLType, VARCHAR2) RETURN NUMBER
  WITH INDEX CONTEXT, SCAN CONTEXT LuceneDomainIndex COMPUTE ANCILLARY DATA
  without column data USING LuceneDomainIndex.TextContains;

show errors

CREATE OR REPLACE OPERATOR LScore BINDING 
  (NUMBER) RETURN NUMBER
    ANCILLARY TO LContains(VARCHAR2, VARCHAR2),
                 LContains(CLOB, VARCHAR2),
                 LContains(sys.XMLType, VARCHAR2)
    without column data USING LuceneDomainIndex.TextScore;

show errors

-- CREATE INDEXTYPE
create indextype LuceneIndex
for
lcontains(varchar2, varchar2),
lcontains(CLOB, varchar2),
lcontains(sys.XMLType, varchar2)
using LuceneDomainIndex
without column data
with order by lscore(number)
with rebuild online
with local range partition
with array dml;
-- with composite index;

show errors

-- GRANTS
grant execute on  LuceneIndex to public;
grant execute on  LContains to public;
grant execute on  LScore to public;
grant execute on  LuceneDomainIndex to public;
grant execute on  LuceneDomainAdm to public;
grant execute on  lucene_msg_typ to public;

create public synonym LContains for lucene.LContains;
create public synonym LScore for lucene.LScore;
create public synonym LuceneDomainIndex for lucene.LuceneDomainIndex;
create public synonym LuceneDomainAdm for lucene.LuceneDomainAdm;
create public synonym lucene_msg_typ for lucene.lucene_msg_typ;
exit
