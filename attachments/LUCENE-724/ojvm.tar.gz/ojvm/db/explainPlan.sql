rem output the content of an explain plan command
SELECT  operation operations,
         decode(options, 'BY INDEX ROWID', 'BY ROWID',
         'BY USER ROWID', 'BY ROWID',
         options) options,
         object_name
FROM    plan_table
ORDER BY id;

TRUNCATE TABLE plan_table;
