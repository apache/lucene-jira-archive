rem Run JUnit suites into the OJVM
drop table lucene_regresion_tests;
/

create table lucene_regresion_tests (
   method_or_class    CHAR(1),
   class_name         VARCHAR2(400),
   elapsed_time       NUMBER(6,3),
   result_status      VARCHAR2(32),
   result_count       NUMBER,
   failure_count      NUMBER,
   error_count        NUMBER,
   error_msg          CLOB
   )
/

insert into lucene_regresion_tests values ('c','org.apache.lucene.TestDemo',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.TestHitIterator',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.TestSearch',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.TestSearchForDuplicates',0.0,'-',0,0,0,'');

insert into lucene_regresion_tests values ('c','org.apache.lucene.analysis.TestAnalyzers',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.analysis.TestISOLatin1AccentFilter',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.analysis.TestKeywordAnalyzer',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.analysis.TestLengthFilter',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.analysis.TestPerFieldAnalzyerWrapper',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.analysis.TestStandardAnalyzer',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.analysis.TestStopAnalyzer',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.analysis.TestStopFilter',0.0,'-',0,0,0,'');

insert into lucene_regresion_tests values ('c','org.apache.lucene.document.TestBinaryDocument',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.document.TestDateTools',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.document.TestDocument',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.document.TestNumberTools',0.0,'-',0,0,0,'');

-- Requires directory granted System.getProperty("tempDir")
-- insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestCompoundFile',0.0,'-',0,0,0,'');
-- insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestDoc',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestDocumentWriter',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestFieldInfos',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestFieldsReader',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestFilterIndexReader',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestIndexInput',0.0,'-',0,0,0,'');
-- Requires directory granted System.getProperty("java.io.tmpdir")
-- exec dbms_java.grant_permission( 'SCOTT', 'SYS:java.io.FilePermission', '/tmp', 'read,write,delete')
-- exec dbms_java.grant_permission( 'SCOTT', 'SYS:java.io.FilePermission', '/tmp/-', 'read,write,delete')
-- TODO: Test again using BLOB based storage instead of /tmp file storage to see performance
-- insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestIndexModifier',0.0,'-',0,0,0,'');
-- Requires directory granted System.getProperty("tempDir")
-- insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestIndexReader',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestIndexWriter',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestIndexWriterMerging',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestMultiReader',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestParallelReader',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestSegmentMerger',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestSegmentReader',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestSegmentTermDocs',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestSegmentTermEnum',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestTermVectorsReader',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestTermVectorsWriter',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestWordlistLoader',0.0,'-',0,0,0,'');

-- Requires directory granted System.getProperty("java.io.tmpdir")
-- TODO: Test again using BLOB based storage instead of /tmp file storage to see performance
-- insert into lucene_regresion_tests values ('c','org.apache.lucene.index.store.TestRAMDirectory',0.0,'-',0,0,0,'');

insert into lucene_regresion_tests values ('c','org.apache.lucene.queryParser.TestMultiFieldQueryParser',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.queryParser.TestQueryParser',0.0,'-',0,0,0,'');

insert into lucene_regresion_tests values ('c','org.apache.lucene.search.BaseTestRangeFilter',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestBoolean2',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestBooleanMinShouldMatch',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestBooleanOr',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestBooleanPrefixQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestBooleanQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestBooleanScorer',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestCachingWrapperFilter',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestCustomSearcherSort',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestDateFilter',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestDisjunctionMaxQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestDocBoost',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestFilteredQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestFuzzyQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestMatchAllDocsQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestMultiPhraseQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestMultiSearcher',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestMultiSearcherRanking',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestMultiThreadTermVectors',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestNot',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestPhrasePrefixQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestPhraseQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestPositionIncrement',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestPrefixQuery',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestQueryTermVector',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestRangeQuery',0.0,'-',0,0,0,'');
-- RMI lookup
--insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestRemoteSearchable',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestSetNorm',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestSimilarity',0.0,'-',0,0,0,'');
-- RMI lookup
-- insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestSort',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestTermVectors',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.TestWildcard',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.spans.TestBasics',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.spans.TestSpans',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.search.spans.TestSpansAdvanced',0.0,'-',0,0,0,'');

insert into lucene_regresion_tests values ('c','org.apache.lucene.store.TestLock',0.0,'-',0,0,0,'');

insert into lucene_regresion_tests values ('c','org.apache.lucene.util.TestBitVector',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.util.TestPriorityQueue',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.util.TestSmallFloat',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.util.TestStringHelper',0.0,'-',0,0,0,'');

insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestDBIndex',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestDBIndexAddDoc',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestDBIndexDelDoc',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.TestDBIndexSearchDoc',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.store.TestDBDirectory',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.index.store.TestDBDirectorySearch',0.0,'-',0,0,0,'');

insert into lucene_regresion_tests values ('c','org.apache.lucene.indexer.TestXMLTypeIndexer',0.0,'-',0,0,0,'');
insert into lucene_regresion_tests values ('c','org.apache.lucene.indexer.TestTableIndexer',0.0,'-',0,0,0,'');
commit;

declare
  result XMLType;
begin
  for c in (select * from lucene_regresion_tests 
             where class_name like 'org.apache.lucene.%'
             order by class_name) loop
    result := XMLType(OJVMRunnerAsString(c.method_or_class,c.class_name));
    commit;
    update lucene_regresion_tests 
      set elapsed_time = result.extract('/junitreport/time/text()').getNumberVal(), 
          result_status = result.extract('/junitreport/result/@status').getStringVal(), 
          result_count = result.extract('/junitreport/result/@run_count').getNumberVal(),
          failure_count = result.extract('/junitreport/result/failures/@failure_count').getNumberVal(),
          error_count = result.extract('/junitreport/result/failures/@error_count').getNumberVal(),
          error_msg = result.extract('/*').getClobVal()
      where class_name = c.class_name;
    commit;
  end loop;
end;
/

select * from lucene_regresion_tests order by class_name;

