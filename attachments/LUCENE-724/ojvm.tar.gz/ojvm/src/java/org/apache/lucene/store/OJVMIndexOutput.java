package org.apache.lucene.store;

import java.io.IOException;

import java.sql.Connection;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * A database implementation of IndexOuput.
 *
 * @version $Id: $
 * @author Marcelo F. Ochoa
 */
public class OJVMIndexOutput extends IndexOutput {
    private byte[] currentBuffer = null;

    private OJVMFile file;

    private int pointer = 0;

    private Connection conn;
    
    public OJVMIndexOutput(Connection conn, OJVMFile file) {
        this.file = file;
        this.conn = conn;
    }

    public OJVMIndexOutput(Connection conn, String prefix, String name) {
        this(conn, new OJVMFile(conn,prefix, name));
    }

    public void close() throws IOException {
      this.file.close();
    }

    /**
     * flush the entire buffer
     */
    public void flush() throws IOException {
    }

    public long getFilePointer() {
        return file.getData().size() == 0 ? 0 :
               BufferedIndexOutput.BUFFER_SIZE * (file.getData().size() - 1) +
               pointer;
    }

    public long length() throws IOException {
        return file.getSize();
    }

    public void seek(long pos) throws IOException {
        int bufferNo = (int)(pos / BufferedIndexOutput.BUFFER_SIZE);
        int bufferPos = bufferNo == 0 ? (int)pos : (int)(pos - pos / bufferNo);

        currentBuffer = (byte[])file.getData().elementAt(bufferNo);
        pointer = bufferPos;
    }

    public void writeByte(byte b) throws IOException {
        if (currentBuffer == null ||
            pointer == BufferedIndexOutput.BUFFER_SIZE) {
            file.getData()
                .add(currentBuffer = new byte[BufferedIndexOutput.BUFFER_SIZE]);
            pointer = 0;
        }
        currentBuffer[pointer++] = b;
        if (file.getData().indexOf(currentBuffer) *
            BufferedIndexOutput.BUFFER_SIZE + pointer > file.getSize()) {
            file.setSize(file.getSize() + 1);
        }
    }

    public void writeBytes(byte[] b, int length) throws IOException {
        for (int offset = 0; offset < length; ++offset) {
            writeByte(b[offset]);
        }
    }
} 
