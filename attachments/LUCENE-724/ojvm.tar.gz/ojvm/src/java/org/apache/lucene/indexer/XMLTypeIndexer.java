package org.apache.lucene.indexer;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.xdb.XMLType;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.store.OJVMUtil;

public class XMLTypeIndexer {
    protected Connection conn;
    protected String schemaName;
    protected String tableName;
    protected String partitionName;
    
    public XMLTypeIndexer() {
    }
    
    public XMLTypeIndexer(String tableName) {
        try {
            this.conn = OJVMUtil.getConnection();
            this.tableName = tableName;
            this.schemaName = this.conn.getMetaData().getUserName().toUpperCase();
            this.partitionName = null;
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
    }
    
    public XMLTypeIndexer(String schemaName, String tableName) {
        try {
            this.conn = OJVMUtil.getConnection();
            this.tableName = tableName;
            this.schemaName = schemaName;
            this.partitionName = null;
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
    }
    
    public XMLTypeIndexer(Connection conn, String tableName) {
        try {
            this.conn = conn;
            this.tableName = tableName;
            this.schemaName = this.conn.getMetaData().getUserName().toUpperCase();
            this.partitionName = null;
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
    }
    
    public XMLTypeIndexer(Connection conn, String schemaName, String tableName) {
        this.conn = conn;
        this.schemaName = schemaName;
        this.tableName = tableName;
        this.partitionName = null;
    }
    
    public XMLTypeIndexer(Connection conn, String schemaName, String tableName, String partitionName) {
        this.conn = conn;
        this.schemaName = schemaName;
        this.tableName = tableName;
        this.partitionName = partitionName;
    }
    
    public void index(IndexWriter writer) throws IOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            if (partitionName!=null && partitionName.length()>0)
                stmt = this.conn.prepareStatement("SELECT rowid,extract(object_value,'//text()') FROM "+
                                                  schemaName+"."+tableName+
                                                  " PARTITION ("+partitionName+")");
            else
                stmt = this.conn.prepareStatement("SELECT rowid,extract(object_value,'//text()') FROM "+
                                                  schemaName+"."+tableName);
            rs = stmt.executeQuery();
            while(rs.next()) {
                String rowid = rs.getString(1);
                XMLType row = (XMLType)rs.getObject(2);
                Document doc = new Document();
                doc.add(new Field("rowid", rowid, Field.Store.YES,
                          Field.Index.TOKENIZED));
                doc.add(new Field("content", row.getStringVal(),Field.Store.NO,Field.Index.TOKENIZED));
                writer.addDocument(doc);
            }
        } catch(SQLException e) {
            throw new RuntimeException(e);
        } finally {
          OJVMUtil.closeDbResources(stmt,rs);  
        }
    }
    
    public void sync(IndexWriter writer) throws IOException {
        
    }
    public static void indexTable(String schema, String table, String partition) throws IOException {
        OJVMDirectory dir;
        dir = OJVMDirectory.getDirectory("LN$"+schema+"."+table+"$IDX");
        IndexWriter writer  = new IndexWriter(dir, new WhitespaceAnalyzer(), true);
        XMLTypeIndexer index = new XMLTypeIndexer(dir.getConnection(),schema,table,partition);
        index.index(writer);
        writer.close();
        dir.close();
    }
}
