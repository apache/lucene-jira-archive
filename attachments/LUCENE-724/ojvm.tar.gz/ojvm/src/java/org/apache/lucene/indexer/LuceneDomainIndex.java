package org.apache.lucene.indexer;

import java.io.IOException;

import java.math.BigDecimal;

import java.sql.SQLException;

import java.util.Hashtable;

import oracle.CartridgeServices.ContextManager;
import oracle.CartridgeServices.CountException;
import oracle.CartridgeServices.InvalidKeyException;

import oracle.ODCI.ODCIEnv;
import oracle.ODCI.ODCIIndexCtx;
import oracle.ODCI.ODCIIndexInfo;
import oracle.ODCI.ODCIPredInfo;
import oracle.ODCI.ODCIQueryInfo;
import oracle.ODCI.ODCIRidList;

import oracle.jdbc.driver.OracleConnection;
import oracle.jdbc.OracleTypes;

import oracle.jpub.runtime.MutableStruct;

import oracle.sql.CustomDatum;
import oracle.sql.CustomDatumFactory;
import oracle.sql.Datum;
import oracle.sql.STRUCT;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Hit;
import org.apache.lucene.search.HitIterator;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.OJVMDirectory;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public class LuceneDomainIndex implements CustomDatum, CustomDatumFactory {
    public static final String _SQL_NAME = "LUCENE.LUCENEDOMAININDEX";

    public static final int _SQL_TYPECODE = OracleTypes.STRUCT;

    static final java.math.BigDecimal SUCCESS = new java.math.BigDecimal("0");

    static final java.math.BigDecimal ERROR = new java.math.BigDecimal("1");

    static final int TRUE = 1;

    static final int FALSE = 0;

    static int[] _sqlType = { 4 };

    static CustomDatumFactory[] _factory = new CustomDatumFactory[1];

    MutableStruct _struct;

    static final LuceneDomainIndex _LuceneDomainIndexFactory =
        new LuceneDomainIndex();

    public static CustomDatumFactory getFactory() {
        return _LuceneDomainIndexFactory;
    }

    /* constructor */

    public LuceneDomainIndex() {
        _struct = new MutableStruct(new Object[1], _sqlType, _factory);
    }

    /* CustomDatum interface */

    public Datum toDatum(OracleConnection c) throws SQLException {
        return _struct.toDatum(c, _SQL_NAME);
    }

    /* CustomDatumFactory interface */

    public CustomDatum create(Datum d, int sqlType) throws SQLException {
        if (d == null)
            return null;
        LuceneDomainIndex o = new LuceneDomainIndex();
        o._struct = new MutableStruct((STRUCT)d, _sqlType, _factory);
        return o;
    }

    /* shallow copy method: give object same attributes as argument */

    void shallowCopy(LuceneDomainIndex d) throws SQLException {
        _struct = d._struct;
    }

    /* accessor methods */

    public Integer getScanctx() throws SQLException {
        return (Integer)_struct.getAttribute(0);
    }

    public void setScanctx(Integer scanctx) throws SQLException {
        _struct.setAttribute(0, scanctx);
    }

    protected static String getIndexPrefix(ODCIIndexInfo ia, ODCIEnv env) throws SQLException {
        String indexPrefix;
        if (ia.getIndexPartition() != null && env.getCallProperty()!=null)
            indexPrefix = ia.getIndexSchema() + "." + ia.getIndexName() + "." + ia.getIndexPartition();
        else
            indexPrefix = ia.getIndexSchema() + "." + ia.getIndexName();
        return indexPrefix;
    }
    
    //  ODCIIndexCreate
    public static java.math.BigDecimal ODCIIndexCreate(ODCIIndexInfo ia,
                                                       String parms,
                                                       ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexWriter writer = null;
        System.out.println("Create parms: '" + parms + "'");
        System.out.println("ODCIIndexInfo.getIndexName: " + ia.getIndexName() +
                           " ODCIIndexInfo.getIndexSchema: " +
                           ia.getIndexSchema() +
                           " ODCIIndexInfo.getIndexPartition: " +
                           ia.getIndexPartition());
        System.out.println("getIndexCols.length: "+ia.getIndexCols().length());
        try {
            String directoryPrefix = getIndexPrefix(ia,env);
            dir =
            OJVMDirectory.getDirectory(directoryPrefix);
            writer = new IndexWriter(dir, new WhitespaceAnalyzer(), true);
            TableIndexer index = new TableIndexer(dir.getConnection(),
                                                  ia.getIndexCols().getElement(0).getTableSchema(),
                                                  ia.getIndexCols().getElement(0).getTableName(),
                                                  ((ia.getIndexPartition() != null && env.getCallProperty()!=null) ? ia.getIndexCols().getElement(0).getTablePartition() : null));
            index.index(writer,ia.getIndexCols().getElement(0).getColName());
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
            if (writer != null)
                writer.close();
            if (dir != null)
                dir.close();
            } catch (IOException e) {
                e.printStackTrace();
                return ERROR;
            }
        }
        return SUCCESS;
    }

    // ODCIIndexTruncate
    public static java.math.BigDecimal ODCIIndexTruncate(ODCIIndexInfo ia,
                                                         ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexWriter writer = null;
        String directoryPrefix = getIndexPrefix(ia,env);
        System.out.println("Truncate. on index: " + directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            // open a writer object with last argument to true cause truncation on lucene index
            writer = new IndexWriter(dir, new WhitespaceAnalyzer(), true);
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
              if (writer!=null)
                writer.close();
              if (dir!=null)
                dir.close();
            } catch (IOException e) {
              e.printStackTrace();
              return ERROR;
            }
        }
        return SUCCESS;
    }
    
    // TextContains
    public static java.math.BigDecimal TextContains(
                    String text, String keyStr,
                    ODCIIndexCtx ctx, LuceneDomainIndex[] sctx, 
                    java.math.BigDecimal scanflg) throws SQLException,
                                                                                         IOException {
                        
        int flag = scanflg.intValue();
        System.out.println("TextScore. Operator rowid='" + ((ctx!=null) ? ctx.getRid() : "null") +
                           "' text='"+text+"' key= '"+keyStr+"' scanflg='"+flag+"'");
        int key;
        LuceneDomainContext sbtctx; // cntxt obj that holds the ResultSet and Statement
        HitIterator iterator = null;
        ODCIIndexInfo ia = (ctx!=null) ? ctx.getIndexInfo() : null;
        if (ia==null && flag>0) { // no Domain Index is bound to a particular column
          if (flag==2 && text.indexOf(keyStr)>0)
              return new BigDecimal("1");
          else
              return new BigDecimal("0");
        }
        if (flag==1) { // close index operation
            key = sctx[0].getScanctx().intValue();
            // Get the resultSet back from the ContextManager using the key
            try {
               sbtctx = (LuceneDomainContext)ContextManager.getContext(key);
            } catch (InvalidKeyException ike) {
               System.out.println("ContextManager InvalidKeyException");
               return ERROR;
            }
            sbtctx.getSearcher().close();
            sbtctx.getDir().close();
            System.out.println("Lucene index closed.");
            return SUCCESS;
        }
        String directoryPrefix = (ia.getIndexPartition() != null) 
                                 ? ia.getIndexSchema() + "." + ia.getIndexName() + "." + ia.getIndexPartition()
                                 : ia.getIndexSchema() + "." + ia.getIndexName();
        if (sctx==null || sctx[0]==null) {
            Directory dir = OJVMDirectory.getDirectory(directoryPrefix);
            IndexSearcher searcher = null;
            try {
                searcher = new IndexSearcher(dir);
                Hits hits = searcher.search(
                  new TermQuery(
                    new Term(ia.getIndexCols().getElement(0).getColName(), keyStr)));
                iterator = (HitIterator) hits.iterator();
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("IndexSearcher Exception error "+e.getMessage());
                return ERROR;
            }
            sbtctx = new LuceneDomainContext(dir, searcher, iterator);
            sctx[0] = new LuceneDomainIndex();
            try {
                key = ContextManager.setContext((Object)sbtctx);
            } catch (CountException ce) {
                ce.printStackTrace();
                System.out.println("ContextManager CountException error "+ce.getMessage());
                return ERROR;
            }

            System.out.println("ContextManager key=" + key);
            // set the key into the self argument so that we can retrieve the
            // context with this key later.
            sctx[0].setScanctx(new Integer(key));
            return SUCCESS;
        } else { // there is a context manager initialized
            key = sctx[0].getScanctx().intValue();
            // Get the resultSet back from the ContextManager using the key
            try {
               sbtctx = (LuceneDomainContext)ContextManager.getContext(key);
            } catch (InvalidKeyException ike) {
               System.out.println("ContextManager InvalidKeyException");
               return ERROR;
            }
            iterator = sbtctx.getIterator();
            return SUCCESS;
        }
    }
    
    // TextScore
    public static java.math.BigDecimal TextScore(
                    String text, String keyStr,
                    ODCIIndexCtx ctx, LuceneDomainIndex[] sctx, 
                    java.math.BigDecimal scanflg) throws SQLException {
        LuceneDomainContext sbtctx;
        System.out.println("TextScore. Operator rowid='" + ctx.getRid() +
                           "' text='"+text+"' key= '"+keyStr+"' scanflg='"+scanflg+"'");
        int key;
        if (sctx==null || sctx[0]==null) // Sanity checks
          throw new SQLException("LuceneDomainIndex parameter is null.");
        key = sctx[0].getScanctx().intValue();
        System.out.println("ContextManager key=" + key);

        // Get the resultSet back from the ContextManager using the key
        try {
            sbtctx = (LuceneDomainContext)ContextManager.getContext(key);
        } catch (InvalidKeyException ike) {
            System.out.println("ContextManager InvalidKeyException");
            throw new SQLException("Ooops, I can't find a ContextManager with this key= '"+key+"'");
        }
        Hashtable cachedRowids = sbtctx.getScoreList();
        Float scoreValue = (Float)cachedRowids.get(ctx.getRid());
        if (scoreValue==null)
            throw new SQLException("Ooops, I can't find a pre-cached score with this rowid= '"+ctx.getRid()+"'");
        return new java.math.BigDecimal(scoreValue.doubleValue());
    }
    
    //  ODCIIndexStart
    public static java.math.BigDecimal ODCIStart(LuceneDomainIndex[] sctx,
                                                 ODCIIndexInfo ia,
                                                 ODCIPredInfo op,
                                                 ODCIQueryInfo qi,
                                                 java.math.BigDecimal strt,
                                                 java.math.BigDecimal stop,
                                                 String cmpval,
                                                 ODCIEnv env) throws java.sql.SQLException {
        System.out.println("ODCIStart. Operator '" + op.getObjectName() +
                           "' cmpval='"+cmpval+"' strt= '"+strt+"' stop='"+stop+"'");
        String directoryPrefix = getIndexPrefix(ia,env);
        int key;
        LuceneDomainContext sbtctx; // cntxt obj that holds the ResultSet and Statement
        Directory dir = OJVMDirectory.getDirectory(directoryPrefix);
        IndexSearcher searcher = null;
        HitIterator iterator = null;
        if (!op.getObjectName().equalsIgnoreCase("contains"))
            throw new SQLException("Expected Contains operator");
        try {
            searcher = new IndexSearcher(dir);
            Hits hits = searcher.search(
              new TermQuery(
                new Term(ia.getIndexCols().getElement(0).getColName(), cmpval)));
            iterator = (HitIterator) hits.iterator();
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("IndexSearcher Exception error "+e.getMessage());
            return ERROR;
        }
        sbtctx = new LuceneDomainContext(dir, searcher, iterator);
        sctx[0] = new LuceneDomainIndex();
        try {
            key = ContextManager.setContext((Object)sbtctx);
        } catch (CountException ce) {
            ce.printStackTrace();
            System.out.println("ContextManager CountException error "+ce.getMessage());
            return ERROR;
        }

        System.out.println("ContextManager key=" + key);

        // set the key into the self argument so that we can retrieve the
        // context with this key later.
        sctx[0].setScanctx(new Integer(key));

        return SUCCESS;
    }

    // ODCIIndexFetch

    public java.math.BigDecimal ODCIFetch(java.math.BigDecimal nrows,
                                          ODCIRidList[] rids,
                                          ODCIEnv env) throws java.sql.SQLException {
        LuceneDomainContext sbtctx; // cntxt obj that holds the ResultSet and Statement
        String rid;
        float  score;
        HitIterator iterator = null;
        int idx = 1;
        int done = FALSE;
        int nRows = nrows.intValue();
        String[] rlist = new String[nRows];
        Hashtable  slist = new Hashtable(nRows);
        int key = getScanctx().intValue();
        System.out.println("Fetch nrows : " + nRows);
        System.out.println("ContextManager key=" + key);

        // Get the resultSet back from the ContextManager using the key
        try {
            sbtctx = (LuceneDomainContext)ContextManager.getContext(key);
        } catch (InvalidKeyException ike) {
            System.out.println("ContextManager InvalidKeyException");
            return ERROR;
        }
        iterator = sbtctx.getIterator();

        //***************
        // Fetch rowids *
        //***************
        for (int i = 0; done != TRUE; i++) {
            if (idx > nRows) {
                done = TRUE;
            } else {
                if (iterator.hasNext()) {
                    // append rowid to collection
                    Hit hit = (Hit) iterator.next();
                    try {
                        rid =  hit.get("rowid");
                        score = hit.getScore();
                    } catch (IOException e) {
                        e.printStackTrace();
                        throw new SQLException(e.getMessage());
                    }
                    rlist[i] = new String(rid);
                    slist.put(rid,new Float(score));
                    idx++;
                } else {
                    // append null rowid to collection
                    rlist[i] = null;
                    done = TRUE;
                }
            }
        }

        // Store last fetch of score List to be used by score() ancillary operator
        sbtctx.setScoreList(slist);
        
        // Since rids is an out parameter we need to set the ODCIRidList
        // object into the first position to be passed out.
        rids[0] = new ODCIRidList(rlist);

        return SUCCESS;
    }

    // ODCIIndexClose

    public java.math.BigDecimal ODCIClose(ODCIEnv env) throws java.sql.SQLException {
        LuceneDomainContext sbtctx; // contxt obj that holds the ResultSet and Statement
        Directory dir = null;
        IndexSearcher searcher = null;
        int key = getScanctx().intValue();
        System.out.println("ODCIClose key=" + key);

        // Get the resultSet and statement back from the ContextManager
        // so that we can close them.
        try {
            sbtctx = (LuceneDomainContext)ContextManager.clearContext(key);
        } catch (InvalidKeyException ike) {
            System.out.println("ContextManager InvalidKeyException");
            return ERROR;
        }

        dir = sbtctx.getDir();
        searcher = sbtctx.getSearcher();
        try {
          searcher.close();
          dir.close();
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        }
        return SUCCESS;
    }

    // ODCIIndexInsert

    public static java.math.BigDecimal ODCIInsert(ODCIIndexInfo ia, String rid,
                                                  String newval,
                                                  ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexWriter writer = null;
        String directoryPrefix = getIndexPrefix(ia,env);
        System.out.println("Insert. newval: '" + newval + "' rowid: '" + rid +
                           "' on index: " + directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            writer = new IndexWriter(dir, new WhitespaceAnalyzer(), false);
            Document doc = new Document();
            doc.add(new Field("rowid", rid, Field.Store.YES,
                      Field.Index.TOKENIZED));
            doc.add(new Field(ia.getIndexCols().getElement(0).getColName(),newval,Field.Store.NO,Field.Index.TOKENIZED));
            writer.addDocument(doc);
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
              if (writer!=null)
                writer.close();
              if (dir!=null)
                dir.close();
            } catch (IOException e) {
              e.printStackTrace();
              return ERROR;
            }
        }
        return SUCCESS;
    }

    // ODCIIndexDelete

    public static java.math.BigDecimal ODCIDelete(ODCIIndexInfo ia, String rid,
                                                  String oldval,
                                                  ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexReader reader = null;
        String directoryPrefix = getIndexPrefix(ia,env);
        System.out.println("Delete. oldval: '" + oldval + "' rowid: '" + rid +
                           "' on index: " + directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            reader = IndexReader.open(dir);
            reader.deleteDocuments(new Term("rowid", rid));
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
              if (reader!=null)
                reader.close();
              if (dir!=null)
                dir.close();
            } catch (IOException e) {
              e.printStackTrace();
              return ERROR;
            }        
        }
        return SUCCESS;
    }

    // ODCIIndexUpdate

    public static java.math.BigDecimal ODCIUpdate(ODCIIndexInfo ia, String rid,
                                                  String oldval, String newval,
                                                  ODCIEnv env) throws SQLException {
        OJVMDirectory dir = null;
        IndexReader reader = null;
        IndexWriter writer = null;
        String directoryPrefix = getIndexPrefix(ia,env);
        System.out.println("Update. newval: '" + newval + "' oldval: '" +
                           oldval + "' rowid: '" + rid + "' on index: " +
                           directoryPrefix);
        try {
            dir = OJVMDirectory.getDirectory(directoryPrefix);
            reader = IndexReader.open(dir);
            reader.deleteDocuments(new Term("rowid", rid));
            reader.close();
            reader = null;
            writer = new IndexWriter(dir, new WhitespaceAnalyzer(), false);
            Document doc = new Document();
            doc.add(new Field("rowid", rid, Field.Store.YES,
                      Field.Index.TOKENIZED));
            doc.add(new Field(ia.getIndexCols().getElement(0).getColName(),newval,Field.Store.NO,Field.Index.TOKENIZED));
            writer.addDocument(doc);
        } catch (IOException e) {
            e.printStackTrace();
            return ERROR;
        } finally {
            try {
              if (reader!=null)
                reader.close();
              if (writer!=null)
                writer.close();
              if (dir!=null)
                dir.close();
            } catch (IOException e) {
              e.printStackTrace();
              return ERROR;
            }        
        }
        return SUCCESS;
    }
}
