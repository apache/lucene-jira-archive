package org.apache.lucene.indexer;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.Hit;
import org.apache.lucene.search.HitIterator;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.OJVMDirectory;

public class TestXMLTypeIndexer extends TestCase {
    Directory dir = null;
    public TestXMLTypeIndexer() {
    }

    public void setUp () throws IOException {
       dir = OJVMDirectory.getDirectory("cms_data.cms_docs_idx");
       IndexWriter writer  = new IndexWriter(dir, new WhitespaceAnalyzer(), true);
       XMLTypeIndexer index = new XMLTypeIndexer(((OJVMDirectory)dir).getConnection(),"cms_data","cms_docs");
       index.index(writer);
       writer.close();
   }

    public void testXMLTypeIndexer() throws IOException {
        IndexSearcher searcher = null;
        HitIterator iterator = null;
        searcher = new IndexSearcher(dir);
        Hits hits = searcher.search(new TermQuery(new Term("content", "DBPrism")));

        iterator = (HitIterator) hits.iterator();
        assertEquals(141, iterator.length());
        assertTrue(iterator.hasNext());
        Hit hit = (Hit) iterator.next();
        assertEquals("AAANGBAAEAAAAdAAAE", hit.get("rowid"));
        searcher.close();
    }
    
    public void tearDown() throws IOException {
        dir.close();
    }
}
