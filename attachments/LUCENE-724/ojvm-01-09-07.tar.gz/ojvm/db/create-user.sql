rem usage notes:
rem sqlplus sys/change_on_install@orcl @db/create-user.sql
rem run on the server machine, because it use dbms_java.loadjava

drop user LUCENE cascade;

create user LUCENE identified by LUCENE
default tablespace users
temporary tablespace temp
quota unlimited on users;

grant connect,resource to LUCENE;
grant create public synonym, drop public synonym to LUCENE;
grant create library to LUCENE;
grant create any directory to LUCENE;
grant create any operator,  create indextype, create table to LUCENE;
grant select any table to LUCENE;
GRANT Aq_administrator_role TO LUCENE;
GRANT EXECUTE ON dbms_aq TO LUCENE;
grant select on v_$session to LUCENE;
grant select on v_$sqlarea to LUCENE;

begin
  dbms_java.grant_permission('LUCENE','SYS:java.io.FilePermission', '/junit.properties', 'read' );
  dbms_java.grant_permission('LUCENE','SYS:java.lang.RuntimePermission', 'getClassLoader', '' );
  dbms_java.grant_permission('LUCENE','SYS:java.lang.RuntimePermission', 'accessDeclaredMembers', '' );
end;
/

exit
