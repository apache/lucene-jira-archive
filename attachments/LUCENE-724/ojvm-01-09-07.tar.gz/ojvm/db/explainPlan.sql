rem output the content of an explain plan command
select plan_table_output from table(dbms_xplan.display('plan_table',null,'serial'));
