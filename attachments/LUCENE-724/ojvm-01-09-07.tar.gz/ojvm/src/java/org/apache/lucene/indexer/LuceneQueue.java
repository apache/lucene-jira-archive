package org.apache.lucene.indexer;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.OJVMDirectory;
import org.apache.lucene.store.OJVMUtil;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
public class LuceneQueue {
    static final java.math.BigDecimal SUCCESS = new java.math.BigDecimal("0");

    static final java.math.BigDecimal ERROR = new java.math.BigDecimal("1");

    static final int NO_WAIT = 0;
    static final int FIRST_MESSAGE = 1;
    static final int LOCKED = 2;
    static final int NEXT_MESSAGE = 3;
    static final String cond1 = "tab.user_data.prefix='";

    static final String enqueueStmt =
    "declare\n" +
    "    enqueue_options     dbms_aq.enqueue_options_t;\n" + 
    "    message_properties  dbms_aq.message_properties_t;\n" + 
    "    message_handle      RAW(16);\n" + 
    "    message             lucene_msg_typ;\n" +
    "begin\n" +
    "    message := lucene_msg_typ(?,?,?);\n" + 
    "    dbms_aq.enqueue(queue_name         => 'LUCENE.lucene_msg_queue',\n" + 
    "                    enqueue_options    => enqueue_options,\n" + 
    "                    message_properties => message_properties,\n" + 
    "                    payload            => message,\n" + 
    "                    msgid              => message_handle);\n" +
    "end;";
    
    static final String dequeueStmt = 
    "declare" +
    "    dequeue_options          dbms_aq.dequeue_options_t;\n" + 
    "    message_properties       dbms_aq.message_properties_t;\n" + 
    "    message_handle           RAW(16);\n" + 
    "    message                  lucene_msg_typ;\n" + 
    "    message_no_data          lucene_msg_typ;\n" +
    "begin\n" +
    "    dequeue_options.wait := ?;\n" + 
    "    dequeue_options.navigation := ?;\n" + 
    "    dequeue_options.dequeue_mode := ?;\n" + 
    "    dequeue_options.deq_condition := ?;\n" +
    "    dbms_aq.dequeue(\n" + 
    "                queue_name         => 'LUCENE.lucene_msg_queue',\n" + 
    "                dequeue_options    => dequeue_options,\n" + 
    "                message_properties => message_properties,\n" + 
    "                payload            => message,\n" + 
    "                msgid              => message_handle);\n" +
    "    ? := message.rid;\n" +
    "    ? := message.operation;\n" +
    "    dequeue_options.dequeue_mode := dbms_aq.REMOVE_NODATA;\n" + 
    "    dequeue_options.msgid := message_handle;\n" + 
    "    dequeue_options.deq_condition := '';\n" + 
    "    dbms_aq.dequeue(\n" + 
    "                queue_name         => 'LUCENE.lucene_msg_queue',\n" + 
    "                dequeue_options    => dequeue_options,\n" + 
    "                message_properties => message_properties,\n" + 
    "                payload            => message_no_data,\n" + 
    "                msgid              => message_handle);\n" + 
    "end;";
    
    public LuceneQueue() {
    }

    public static void sync(String prefix) throws IOException,SQLException {
        HashMap scheduledDeleteForUpdate = new HashMap();
        HashMap scheduledAdd = new HashMap();
        OracleCallableStatement cs = null;
        Connection conn = null;
        OJVMDirectory dir = null;
        IndexReader reader = null;
        IndexWriter writer = null;
        try {
            dir = OJVMDirectory.getDirectory(prefix);
            Parameters par = dir.getParameters();
            String col = par.getParameter("ColName");
            String tableSchema = par.getParameter("TableSchema");
            String tableName = par.getParameter("TableName");
            String partition = par.getParameter("Partition");
            //System.out.println("Sync. col: "+col+" Type: "+colTypeName+" schema: "+
            //                   tableSchema+" table: "+tableName+" partition: "+partition);
            conn = dir.getConnection();
            cs =
              (OracleCallableStatement)conn.prepareCall(dequeueStmt);
            cs.setInt(1,NO_WAIT);
            cs.setInt(2,FIRST_MESSAGE);
            cs.setInt(3,LOCKED);
            cs.setString(4,cond1+prefix+"'");
            cs.registerOutParameter(5,OracleTypes.VARCHAR);
            cs.registerOutParameter(6,OracleTypes.VARCHAR);
            try {
                cs.execute(); // first message
                String  rid = cs.getString(5);
                String  operation = cs.getString(6);
                //System.out.println("rid: "+rid+" ("+operation+")");
                if ("delete".equals(operation)) {
                    scheduledDeleteForUpdate.remove(rid);
                    scheduledAdd.remove(rid);
                } else {
                    if ("update".equals(operation)) // require deletion first
                      scheduledDeleteForUpdate.put(rid,"");
                    // insert
                    scheduledAdd.put(rid,"");
                }
                while(true) {
                    cs.setInt(1,NO_WAIT);
                    cs.setInt(2,NEXT_MESSAGE);
                    cs.setInt(3,LOCKED);
                    cs.setString(4,cond1+prefix+"'");
                    cs.execute(); // next message
                    rid = cs.getString(5);
                    operation = cs.getString(6);
                    //System.out.println("rid: "+rid+" ("+operation+")");
                    if ("delete".equals(operation)) {
                        scheduledDeleteForUpdate.remove(rid);
                        scheduledAdd.remove(rid);
                    } else {
                       if ("update".equals(operation)) // require deletion first
                         scheduledDeleteForUpdate.put(rid,"");
                       // insert
                       scheduledAdd.put(rid,"");
                    }
                }
            } catch (SQLException sqe) {
                if (sqe.getErrorCode() != 25228) {
                    sqe.printStackTrace();
                    throw sqe;
                }// else {
                //    System.out.println("No more lucene update msg to dequeue.");
                //}
            }
            reader = IndexReader.open(dir);
            Set deleted = scheduledDeleteForUpdate.keySet();
            Iterator ite = deleted.iterator();
            while(ite.hasNext()) {
                String rowid = (String)ite.next();
                //System.out.println("Deleting: "+rowid);
                reader.deleteDocuments(new Term("rowid", rowid));
            }
            reader.close();
            reader = null;
            int mergeFactor = Integer.parseInt(par.getParameter("MergeFactor",""+IndexWriter.DEFAULT_MERGE_FACTOR));
            int maxBufferedDocs = Integer.parseInt(par.getParameter("MaxBufferedDocs",""+IndexWriter.DEFAULT_MAX_BUFFERED_DOCS));
            int maxMergeDocs = Integer.parseInt(par.getParameter("MaxMergeDocs",""+IndexWriter.DEFAULT_MAX_MERGE_DOCS));
            Analyzer analyzer = LuceneDomainIndex.getAnalyzer(par);
            writer = new IndexWriter(dir, analyzer, false);
            writer.setMergeFactor(mergeFactor);
            writer.setMaxMergeDocs(maxMergeDocs);
            writer.setMaxBufferedDocs(maxBufferedDocs);
            Set inserted = scheduledAdd.keySet();
            TableIndexer index =
                new TableIndexer(dir.getConnection(),tableSchema,tableName,partition);
            index.index(writer, col, inserted);
            writer.close();
            writer = null;
            dir.close();
            dir = null;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error syncing the index: "+prefix+" - "+e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(cs,null);
            if (reader != null)
                reader.close();
            if (writer != null)
                writer.close();
            if (dir != null)
                dir.close();
            scheduledDeleteForUpdate.clear();
            scheduledDeleteForUpdate = null;
            scheduledAdd.clear();
            scheduledAdd = null;
        }
    }
    
    public static void purge(String prefix) throws SQLException {
        PreparedStatement stmt = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            // Purge deleted documents.
            stmt = conn.prepareStatement("DELETE FROM LUCENE_INDEX WHERE PREFIX = ? AND DELETED = 'Y'");
            stmt.setString(1,prefix);
            stmt.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error in purge index: "+prefix+" - "+e.getMessage());
        } finally {
            if (stmt != null)
              stmt.close();
            stmt = null;
        }
    }
    
    public static void discard(Connection conn, String prefix) throws SQLException {
        OracleCallableStatement cs = null;
        try {
            cs =
              (OracleCallableStatement)conn.prepareCall(dequeueStmt);
            cs.setInt(1,NO_WAIT);
            cs.setInt(2,FIRST_MESSAGE);
            cs.setInt(3,LOCKED);
            cs.setString(4,cond1+prefix+"'");
            cs.registerOutParameter(5,OracleTypes.VARCHAR);
            cs.registerOutParameter(6,OracleTypes.VARCHAR);
            try {
                cs.execute(); // first message
                String  rid = cs.getString(5);
                String  operation = cs.getString(6);
                //System.out.println("discarding rid: "+rid+" ("+operation+")");
                while(true) {
                    cs.setInt(1,NO_WAIT);
                    cs.setInt(2,NEXT_MESSAGE);
                    cs.setInt(3,LOCKED);
                    cs.setString(4,cond1+prefix+"'");
                    cs.execute(); // next message
                    rid = cs.getString(5);
                    operation = cs.getString(6);
                    //System.out.println("discarding rid: "+rid+" ("+operation+")");
                }
            } catch (SQLException sqe) {
                if (sqe.getErrorCode() != 25228) {
                    sqe.printStackTrace();
                    throw sqe;
                }
            }
            } catch (SQLException e) {
                e.printStackTrace();
                throw new RuntimeException("Error syncing the index: "+prefix+" - "+e.getMessage());
            } finally {
                OJVMUtil.closeDbResources(cs,null);
            }
    }
    
    public static java.math.BigDecimal enqueue(String prefix, String rid, String operation) throws SQLException {
        OracleCallableStatement cs = null;
        Connection conn = null;
        try {
            conn = OJVMUtil.getConnection();
            cs =
              (OracleCallableStatement)conn.prepareCall(enqueueStmt);
            cs.setString(1,prefix);
            cs.setString(2,rid);
            cs.setString(3,operation);
            cs.execute();
        } catch (SQLException sqe) {
            sqe.printStackTrace();
            return ERROR;
        } finally {
            OJVMUtil.closeDbResources(cs,null);
        }
        return SUCCESS;
    }
}
