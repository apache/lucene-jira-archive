package org.apache.lucene.store;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;

import java.util.Iterator;
import java.util.Map;

import java.util.Set;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.indexer.Entry;
import org.apache.lucene.indexer.LuceneDomainIndex;
import org.apache.lucene.indexer.Parameters;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Searcher;


/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * Main entry point, extends the abstract&nbsp;class
 * @see Directory which encapsulates the access to the storage of the Lucene
 * inverted index.
 * The constructor gets an Oracle database connection with auto commit disabled,
 * then check for the existence of the tables  <strong>lucene_index</strong>
 * and. Also to reduce select operation on the lucene_index table creates
 * an Hashtable with the files stored under the prefix (directory) calling to the
 * method loadPreCachedFileNames().
 * When the user call the close() method the diretory object perform a database
 * commit only if its running outside the Oracle JVM.
 * The createOutput() method will create a new file for writing using
 * OJVMIndexOutput() stream, but the content of the new BLOB created will still
 * unsaved until the close() method is called into the OJVMFile, @see OJVMIndexOutput.
 * The openInput() method opens files for reading using OJVMIndexInput() stream
 * instance which automatically load the content of the BLOB and store it in a
 * Vector() instance to provide direct accces to the content.
 * deleteFile(), fileLength(), fileModified(), renameFile() and touchFile() performs
 * the respective operations on the files stored as rows into the lucene_files table.
 * list() method returns a array list representing all the files stored into
 * the current prefix (sub directory) represented by OJVMDirectory instance.
 * makeLock() method create a commit or write lock on this directory by returning
 * an instance of @see OJVMLock object.
 *
 * @version $Id: $
 * @author Marcelo F. Ochoa
 */
public final class OJVMDirectory extends Directory {
    private static Map cachedSearcher = null;

    private Connection conn = null;

    private Hashtable files = null;

    private Parameters parameters = null;
    
    private String prefix = "_defaultPrefix";

    private boolean readOnly = true;
    
    /**
     * Creates a new <code>DBDirectory</code> instance using a given
     * @param prefix
     */
    public static OJVMDirectory getDirectory(String prefix) {
        return new OJVMDirectory(prefix);
    }

    static void clearCachedSearcher() throws IOException {
        // clear out both the cached field, and the thunk so they don't
        // take up session space between calls
        Set openedSearcher = cachedSearcher.keySet();
        Iterator ite = openedSearcher.iterator();
        while (ite.hasNext()) {
            String searcherPrefix = (String)ite.next();
            Entry entry = (Entry)cachedSearcher.get(searcherPrefix);
            //System.out.println("Closing cached server '"+searcherPrefix+"'");
            entry.getSeacher().close();
            entry.getDirectory().close();
        }
        cachedSearcher.clear();
        cachedSearcher = null;
    }
    
    public void removeCachedSearcher() throws IOException {
        if (cachedSearcher==null)
          return;
        Entry entry = (Entry)cachedSearcher.get(this.prefix);
        if (entry!=null) {
            entry.close();
            cachedSearcher.remove(this.prefix);
        }
    }
    
    public static Entry getCachedSearcher(String prefix) throws IOException,
                                                                   SQLException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Connection conn = null;
        long updateCount = 0;
        try {
            conn = OJVMUtil.getConnection();
            stmt =
                conn.prepareStatement(
                  "SELECT FILE_SIZE FROM LUCENE_INDEX" +
                  " WHERE PREFIX=? AND NAME='updateCount'");
            stmt.setString(1, prefix);
            rs = stmt.executeQuery();
            if (rs.next()) {
                updateCount = rs.getLong(1);
            } else
                throw new RuntimeException("getCachedSearcher can't find '" +
                                           prefix + "/updateCount' file");
        } catch (SQLException s) {
            throw s;
        } finally {
            OJVMUtil.closeDbResources(stmt, rs);
        }
        if (cachedSearcher == null)
            cachedSearcher = new HashMap();
        Entry entry = (Entry)cachedSearcher.get(prefix);
        if (entry == null || updateCount!=entry.getUpdateCount()) {// No cached entry, creates a new one
            if (entry!=null && updateCount!=entry.getUpdateCount())
              entry.close();
            OJVMDirectory dir = new OJVMDirectory(prefix);
            Searcher searcher = new IndexSearcher(dir);
            Parameters parameters = dir.getParameters();
            Analyzer analyzer = LuceneDomainIndex.getAnalyzer(parameters);
            entry = new Entry(dir, searcher, analyzer, updateCount);
            cachedSearcher.put(prefix, entry);
            //System.out.println("Creating cachedSearcher entry "+entry);
        }// else
        //    System.out.println("Found a valid cachedSearcher entry "+entry);
        return entry;
    }

    /**
     * default constructor to allow subclassing
     */
    protected OJVMDirectory() {
    }

    /**
     * Creates a new <code>OJVMDirectory</code> instance from a different
     * <code>Directory</code> implementation.  This can be used to load
     * a disk-based or ram-based index into BLOB implementation.
     *
     * @param dir a <code>Directory</code> value
     * @exception IOException if an error occurs
     */
    public OJVMDirectory(String prefix, Directory dir) throws IOException {
        this(prefix, dir, false);
    }

    /**
     * Clone RAM or Directory index on BLOB storage
     * @param dir source @see Directory
     * @param closeDir, if true close source Directory
     * @throws IOException if an error occurs
     */
    public OJVMDirectory(String prefix, Directory dir, boolean closeDir) throws IOException {
        this(prefix);
        final String[] files = dir.list();
        byte[] buf = new byte[BufferedIndexOutput.BUFFER_SIZE];
        for (int i = 0; i < files.length; i++) {
          // make place on BLOB storage
          IndexOutput os = createOutput(files[i]);
          // read current file
          IndexInput is = dir.openInput(files[i]);
          // and copy BLOB storage
          long len = is.length();
          long readCount = 0;
          while (readCount < len) {
            int toRead = readCount + BufferedIndexOutput.BUFFER_SIZE > len ? (int)(len - readCount) : BufferedIndexOutput.BUFFER_SIZE;
            is.readBytes(buf, 0, toRead);
            os.writeBytes(buf, toRead);
            readCount += toRead;
          }
          // graceful cleanup
          is.close();
          os.close();
        }
        if(closeDir)
          dir.close();
    }
    
    protected OJVMDirectory(String prefix) {
        this.prefix = prefix;
        this.files = new Hashtable();
        this.readOnly = true;
        try {
            this.conn = OJVMUtil.getConnection();
        } catch (SQLException e) {
            throw new InstantiationError(e.getMessage());
        }
        loadPreCachedFileNames();
    }

    /**
     * After Directory creation, use this method to initialize
     * the parameters row with
     * @param param
     * and the updateCount row with 0
     */
    public void setParameters(Parameters param) {
        this.parameters = param;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement("SELECT PREFIX FROM LUCENE_INDEX"+
                                         " WHERE PREFIX = ? AND NAME = 'parameters'");
            stmt.setString(1,this.prefix);
            rs = stmt.executeQuery();
            boolean exists = rs.next();
            rs.close();
            rs = null;
            stmt.close();
            if (exists) { // update
             stmt = conn.prepareStatement("UPDATE LUCENE_INDEX SET LAST_MODIFIED=sysdate,FILE_SIZE=?,DATA=? "+
                                          " WHERE PREFIX = ? AND NAME = 'parameters'");
             stmt.setInt(1,parameters.getSize());
             stmt.setBytes(2,parameters.getBytes());
             stmt.setString(3,this.prefix);
             stmt.execute();
             stmt.close();
             stmt = conn.prepareStatement("UPDATE LUCENE_INDEX SET FILE_SIZE=FILE_SIZE+1 "+
                                          " WHERE PREFIX = ? AND NAME ='updateCount'");
             stmt.setString(1,this.prefix);
             stmt.execute();
            } else {
               stmt = conn.prepareStatement("INSERT INTO LUCENE_INDEX (PREFIX,NAME,LAST_MODIFIED,FILE_SIZE,DATA,DELETED) "+
                                         " VALUES (?,'parameters',sysdate,?,?,'N')");
               stmt.setString(1,this.prefix);
               stmt.setInt(2,parameters.getSize());
               stmt.setBytes(3,parameters.getBytes());
               stmt.execute();
               stmt.close();
               stmt = conn.prepareStatement("INSERT INTO LUCENE_INDEX (PREFIX,NAME,LAST_MODIFIED,FILE_SIZE,DATA,DELETED) "+
                                         " VALUES (?,'updateCount',sysdate,0,empty_blob(),'N')");
               stmt.setString(1,this.prefix);
               stmt.execute();
            }
        } catch (SQLException sqe) {
            throw new InstantiationError(sqe.getMessage());
        } finally {
            OJVMUtil.closeDbResources(stmt,rs);
        }
    }
    
    public Parameters getParameters() {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        if (this.parameters == null)
          try {
            stmt = conn.prepareStatement("SELECT DATA FROM LUCENE_INDEX"+
                                         " WHERE PREFIX=? AND NAME='parameters'");
            stmt.setString(1,this.prefix);
            rs = stmt.executeQuery();
            if (rs.next()) {
                this.parameters = new Parameters(rs.getBytes(1));
            } else
              throw new InstantiationError("loadParameters: Oops this index '"+this.prefix+
                                     "' has no parameters, re-create it.");
          } catch (SQLException sqe) {
            throw new InstantiationError(sqe.getMessage());
          } finally {
            OJVMUtil.closeDbResources(stmt,rs);
          }
        return this.parameters;
    }
    
    /**
     * Closes the store.
     */
    public void close() throws IOException {
        PreparedStatement stmt = null;
        try {
            if (!this.readOnly) {
                stmt = conn.prepareStatement("UPDATE LUCENE_INDEX SET FILE_SIZE=FILE_SIZE+1"+
                                             " WHERE PREFIX=? AND NAME='updateCount'");
                stmt.setString(1,this.prefix);
                int update = stmt.executeUpdate();
                stmt.close();
                stmt = null;
                if (update == 0)
                  throw new IOException("close() failed to update "+this.prefix+"/updateCount row");
                //System.out.println("Close update updateCount row");
            }
            if (!System.getProperty("java.vm.name").equals("JServer VM")) {
                conn.commit();
                conn.close();
            }
        } catch (SQLException e) {
            throw new IOException(e.getMessage());
        } finally {
            conn = null;
        }
        files.clear();
        files = null;
    }
    

    /**
     * Creates a new, empty pseudo file in the pseudo directory with the given name. Returns a
     * stream writing this file.
     */
    public IndexOutput createOutput(String name) throws IOException {
        if (fileExists(name))
            throw new IOException("Cannot overwrite: " + prefix + "/" + name);
        this.readOnly = false;
        OJVMFile file = new OJVMFile(this.conn, this.prefix, name);
        OJVMIndexOutput newFile = new OJVMIndexOutput(this.conn, file);
        files.put(name, "");
        //System.out.println("OJVMIndexOutput: " + prefix + "/" + name);
        return newFile;
    }

    /**
     * Removes an existing file in the directory.
     */
    public void deleteFile(String name) throws IOException {
        PreparedStatement stmt = null;
        try {
            stmt =
              conn.prepareStatement("UPDATE LUCENE_INDEX SET DELETED='Y' WHERE PREFIX=? AND NAME=?");
            stmt.setString(1, prefix);
            stmt.setString(2, name);
            stmt.execute();
            files.remove(name);
        } catch (Exception e) {
            throw new IOException("cannot delete file " + name + ". Reason: " +
                                  e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(stmt, null);
        }
        //System.out.println("deleteFile: " + prefix + "/" + name);
    }

    /**
     * Returns true iff a file with the given name exists.
     */
    public boolean fileExists(String name) throws IOException {
        return files.containsKey(name);
    }

    /**
     * Returns the length of a file in the directory.
     */
    public long fileLength(String name) throws IOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt =
              conn.prepareStatement("SELECT FILE_SIZE FROM LUCENE_INDEX " +
                                    "WHERE PREFIX=? AND NAME=?");
            stmt.setString(1, prefix);
            stmt.setString(2, name);
            rs = stmt.executeQuery();
            rs.next();
            return rs.getLong(1);
        } catch (Exception e) {
            throw new IOException("cannot verify file: " + name +
                                  ". Reason: " + e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(stmt, rs);
        }
    }

    /**
     * Returns the time the named file was last modified.
     */
    public long fileModified(String name) throws IOException {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = conn.prepareStatement("SELECT LAST_MODIFIED FROM LUCENE_INDEX " +
                      "WHERE PREFIX=? AND NAME=?");
            stmt.setString(1, prefix);
            stmt.setString(2, name);
            rs = stmt.executeQuery();
            rs.next();
            return rs.getTimestamp(1).getTime();
        } catch (Exception e) {
            throw new IOException("cannot read file modification timestamp for: " +
                                  name + ". Reason: " + e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(stmt, rs);
        }
    }

    private void loadPreCachedFileNames() {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt =
              conn.prepareStatement("SELECT NAME FROM LUCENE_INDEX WHERE PREFIX=? AND DELETED='N'");
            stmt.setString(1, this.prefix);
            rs = stmt.executeQuery();
            while (rs.next()) {
                String fileNameStr = rs.getString("NAME");
                if ("parameters".equals(fileNameStr) || "updateCount".equals(fileNameStr))
                    continue; // ignore internals files used by the OJVMDirectory
                files.put(fileNameStr, "");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            OJVMUtil.closeDbResources(stmt, rs);
        }
    }

    /**
     * Returns an array of strings, one for each pseudo file in the pseudo directory.
     */
    public String[] list() throws IOException {
        Enumeration en = files.keys();
        String[] results = new String[files.size()];
        int i = 0;
        while (en.hasMoreElements())
            results[i++] = (String)en.nextElement();
        return results;
    }

    /**
     * Construct a {@link Lock}.
     *
     * @param name the name of the lock file
     */
    public Lock makeLock(final String name) {
        return new OJVMLock();
    }

    /**
     * Returns a stream reading an existing file.
     */
    public IndexInput openInput(String name) throws IOException {
        //System.out.println("OJVMIndexInput: " + prefix + "/" + name);
        return new OJVMIndexInput(this.conn,
                                  new OJVMFile(this.conn, this.prefix, name));
    }

    /**
     * Renames an existing file in the directory (prefix). If a file already exists with the new
     * name, then it is replaced. This replacement is atomic, since it is within a single database
     * transaction.
     */
    public void renameFile(String from, String to) throws IOException {
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(
              "DELETE FROM LUCENE_INDEX WHERE PREFIX=? AND NAME=?");
            stmt.setString(1, prefix);
            stmt.setString(2, to);
            stmt.execute();
            stmt.close();
            stmt = conn.prepareStatement(
              "UPDATE LUCENE_INDEX SET NAME=? , LAST_MODIFIED=sysdate, DELETED='N' WHERE PREFIX=? AND NAME=?");
            stmt.setString(1, to);
            stmt.setString(2, prefix);
            stmt.setString(3, from);
            stmt.execute();
            files.remove(from);
            files.put(to, "");
        } catch (SQLException e) {
            throw new IOException("Unable to rename file from " + from +
                                  " to " + to + ". Reason: " + e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(stmt, null);
        }
        //System.out.println("renameFile: " + from + "->" + to);
    }

    /**
     * Set the modified time of an existing file to now.
     */
    public void touchFile(String name) throws IOException {
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(
                      "UPDATE LUCENE_INDEX SET LAST_MODIFIED=sysdate" +
                      " WHERE PREFIX=? AND NAME=?");
            stmt.setString(1, prefix);
            stmt.setString(2, name);
            stmt.execute();
        } catch (SQLException e) {
            throw new IOException("Unable to touch file " + name +
                                  ". Reason: " + e.getMessage());
        } finally {
            OJVMUtil.closeDbResources(stmt, null);
        }
    }

    public Connection getConnection() {
        return conn;
    }
}


