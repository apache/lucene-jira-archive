package org.apache.lucene.store;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.io.File;
import java.util.Hashtable;
import java.util.Enumeration;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.store.Lock;
import org.apache.lucene.store.BufferedIndexOutput;


/**
 * A memory-resident {@link Directory} implementation.
 *
 * @version $Id: AppletDirectory.java 351779 2005-12-02 17:37:50Z bmesser $
 */
public final class AppletDirectory extends Directory
{
    Hashtable files = new Hashtable();
    java.net.URL baseURL= null;
    
    /** Constructs an empty {@link Directory}. */
    public AppletDirectory()
    {
    }
    
    public AppletDirectory(java.net.URL baseURL, java.util.Vector fileNames) throws IOException
    {
        this.baseURL= baseURL;
        java.util.Enumeration filesToLoad = fileNames.elements();
        byte[] buf = new byte[BufferedIndexOutput.BUFFER_SIZE];
        int i= 0;
        while (filesToLoad.hasMoreElements())
        {
            String thisFile= (String) filesToLoad.nextElement();
            // make place on ram disk
            IndexOutput os = createOutput(thisFile);
            // read current file
            java.net.URL thisURL= new java.net.URL(baseURL.toString()+thisFile);
            java.io.InputStream is= thisURL.openStream();
            int bytesRead= is.read(buf);
            while (bytesRead >= 0)
            {
                os.writeBytes(buf, bytesRead);
                bytesRead= is.read(buf);
            }
            
            // graceful cleanup
            is.close();
            os.close();
            i++;            
        }
    }
    
    
    /** Returns an array of strings, one for each file in the directory. */
    public final String[] list()
    {
        String[] result = new String[files.size()];
        int i = 0;
        Enumeration names = files.keys();
        while (names.hasMoreElements())
            result[i++] = (String)names.nextElement();
        return result;
    }
    
    /** Returns true iff the named file exists in this directory. */
    public final boolean fileExists(String name)
    {
        AppletFile file = (AppletFile)files.get(name);
        return file != null;
    }
    
    /** Returns the time the named file was last modified. */
    public final long fileModified(String name)
    {
        AppletFile file = (AppletFile)files.get(name);
        return file.lastModified;
    }
    
    /** Set the modified time of an existing file to now. */
    public void touchFile(String name)
    {
//     final boolean MONITOR = false;
        
        AppletFile file = (AppletFile)files.get(name);
        long ts2, ts1 = System.currentTimeMillis();
        do
        {
            try
            {
                Thread.sleep(0, 1);
            }
            catch (InterruptedException e)
            {}
            ts2 = System.currentTimeMillis();
//       if (MONITOR) {
//         count++;
//       }
        } while(ts1 == ts2);
        
        file.lastModified = ts2;
        
//     if (MONITOR)
//         System.out.println("SLEEP COUNT: " + count);
    }
    
    /** Returns the length in bytes of a file in the directory. */
    public final long fileLength(String name)
    {
        AppletFile file = (AppletFile)files.get(name);
        return file.length;
    }
    
    /** Removes an existing file in the directory. */
    public final void deleteFile(String name)
    {
        files.remove(name);
    }
    
    /** Removes an existing file in the directory. */
    public final void renameFile(String from, String to)
    {
        AppletFile file = (AppletFile)files.get(from);
        files.remove(from);
        files.put(to, file);
    }
    
    /** Creates a new, empty file in the directory with the given name.
      Returns a stream writing this file. */
    public final IndexOutput createOutput(String thisName)
    {
        AppletFile file = new AppletFile();
        files.put(thisName, file);
        return new AppletOutputStream(file);
    }
    
    /** Returns a stream reading an existing file. */
    public final IndexInput openInput(java.net.URL name)
    {
        AppletFile file = (AppletFile)files.get(name);
        return new AppletInputStream(file);
    }

    /** Returns a stream reading an existing file. */
    public final IndexInput openInput(String name)
    {
        AppletFile file = (AppletFile)files.get(name);
        return new AppletInputStream(file);
    }
    
    /** Construct a {@link Lock}.
     * @param name the name of the lock file
     */
    public final Lock makeLock(final String name)
    {
        
        return new Lock()
        {
            public boolean obtain() throws IOException
            {
                return true;
            }
            public void release()
            {
            }
            public boolean isLocked()
            {
                return false;
            }
        };
    }
    
    /** Closes the store to future operations. */
    public final void close()
    {
    }
}