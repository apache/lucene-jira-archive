package org.apache.lucene.indexaccessor;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import junit.framework.TestCase;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.KeywordAnalyzer;
import org.apache.lucene.analysis.WhitespaceAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Index;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Sort;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.LockFactory;
import org.apache.lucene.store.NoLockFactory;

public class TestIndexAccessor extends TestCase {

  private static LockFactory lockFactory = new NoLockFactory();

  final private File index1;

  final private File index2;

  public TestIndexAccessor() {
    String tempDir = System.getProperty("java.io.tmpdir") + "indexaccessor_test";
    index1 = new File(tempDir, "testindex");
    index2 = new File(tempDir, "testindex2");
  }

  private void deleteIndex(File indexDir) throws IOException {
    File[] files = indexDir.listFiles();
    if (files != null) {
      for (int i = 0; i < files.length; i++) {
        if (!files[i].delete()) {
          throw new RuntimeException(files[i] + " could not be deleted !");
        }
      }
    }
    indexDir.delete();
  }

  private void testGetSearcherSpeedImpl(final boolean onlyAccessSearcher, boolean withContention)
      throws IOException, CorruptIndexException, ParseException, InterruptedException {
    Analyzer analyzer = new WhitespaceAnalyzer();
    FSDirectory dir = FSDirectory.getDirectory(index1, lockFactory);
    IndexAccessorFactory.getInstance().createAccessor(dir, analyzer);

    IndexAccessor accessor = IndexAccessorFactory.getInstance().getAccessor(index1);
    IndexWriter writer = accessor.getWriter(false);
    Document doc = new Document();
    doc.add(new Field("field", "test", Store.NO, Index.TOKENIZED));
    writer.addDocument(doc);
    accessor.release(writer);

    final float times = 30000f;
    Thread[] threads = null;
    if (withContention) {
      threads = new Thread[40];
      for (int i = 0; i < threads.length; i++) {
        threads[i] = new Thread() {

          public void run() {
            IndexAccessor accessor = IndexAccessorFactory.getInstance().getAccessor(index1);
            Searcher searcher = null;

            try {
              for (int i = 0; i < times; i++) {
                try {
                  searcher = accessor.getSearcher(null);
                  if (!onlyAccessSearcher) {
                    QueryParser qp = new QueryParser("field", new KeywordAnalyzer());
                    searcher.search(qp.parse("test"));
                  }
                } catch (IllegalStateException e) {
                  break;
                } finally {
                  accessor.release(searcher);
                }
              }
            } catch (IOException e) {
              throw new RuntimeException(e);
            } catch (ParseException e) {
              throw new RuntimeException(e);
            }
          }
        };

        threads[i].setName("searchThread-" + i);
      }

      for (int i = 0; i < threads.length; i++) {
        threads[i].start();
      }
      // give the threads some time to work.
      Thread.sleep(500);
    }

    Searcher searcher = null;
    long execTime = System.currentTimeMillis();

    for (int i = 0; i < times; i++) {
      try {
        searcher = accessor.getSearcher(null);
        if (!onlyAccessSearcher) {
          QueryParser qp = new QueryParser("field", new KeywordAnalyzer());
          searcher.search(qp.parse("test"));
        }
      } catch (IllegalStateException e) {
        break;
      } finally {
        accessor.release(searcher);
      }
    }
    execTime = System.currentTimeMillis() - execTime;

    System.out.println("avg time:" + (execTime / times) + " ms");
    System.out.println("total time:" + execTime + " ms");

    if (threads != null) {
      // Join all the search threads, to ensure they've finished their work.
      for (int i = 0; i < threads.length; i++) {
        threads[i].join();
      }
    }
    IndexAccessorFactory.getInstance().close();
    deleteIndex(index1);
  }

  protected void setUp() throws Exception {
    deleteIndex(index1);
    deleteIndex(index2);
    super.setUp();
  }

  public void testCreateIndex() throws IOException {
    Analyzer analyzer = new WhitespaceAnalyzer();
    FSDirectory dir = FSDirectory.getDirectory(index1, lockFactory);
    IndexAccessorFactory.getInstance().createAccessor(dir, analyzer);

    assertTrue(index1.exists());

    IndexAccessorFactory.getInstance().close();
    deleteIndex(index1);
  }

  /**
   * Test showing that query parsing and searching would dominate running time
   * over synchronized access calls.
   * 
   * @throws IOException
   * @throws ParseException
   * @throws InterruptedException
   */
  public void testGetSearcherSpeed() throws IOException, ParseException, InterruptedException {
    System.out.println("Without Contention");
    System.out.println("Just retrieve and release Searcher 30000 times");
    System.out.println("----");
    testGetSearcherSpeedImpl(true, false);

    System.out.println("");
    System.out.println("Parse query and search on 1 doc 30000 times");
    System.out.println("----");
    testGetSearcherSpeedImpl(false, false);
    System.out.println("");
    System.out.println("");
    System.out.println("With Contention");
    System.out.println("Just retrieve and release Searcher 30000 times");
    System.out.println("----");
    testGetSearcherSpeedImpl(true, true);

    System.out.println("");
    System.out.println("Parse query and search on 1 doc 30000 times");
    System.out.println("----");
    testGetSearcherSpeedImpl(false, true);
  }

  public void testLotsOfAccess() throws Exception {
    Analyzer analyzer = new WhitespaceAnalyzer();
    FSDirectory dir = null, dir2 = null;
    for (int j = 0; j < 2; j++) {
      if (j == 1) {
        dir = FSDirectory.getDirectory(index1, lockFactory);
        dir2 = FSDirectory.getDirectory(index2, lockFactory);
        System.out.println("Standard Run");
        IndexAccessorFactory.getInstance().createAccessor(dir, analyzer);
        IndexAccessorFactory.getInstance().createAccessor(dir2, analyzer);
      } else {
        dir = FSDirectory.getDirectory(index1, lockFactory);
        dir2 = FSDirectory.getDirectory(index2, lockFactory);
        QueryParser qp = new QueryParser("field", analyzer);
        System.out.println("Warm Searchers Run");
        Set<Sort> sorts = new HashSet<Sort>();
        sorts.add(new Sort("field"));
        IndexAccessorFactory.getInstance().createAccessor(dir, analyzer, qp.parse("test"), sorts);
        IndexAccessorFactory.getInstance().createAccessor(dir2, analyzer, qp.parse("test"), sorts);
      }

      Thread[] searchThreads = new Thread[10];
      Thread[] searchThreads2 = new Thread[4];
      Thread[] updateThreads = new Thread[8];
      Thread[] updateThreads2 = new Thread[6];
      for (int i = 0; i < searchThreads.length; i++) {
        searchThreads[i] = new Thread() {

          public void run() {
            IndexAccessor accessor = IndexAccessorFactory.getInstance().getAccessor(index1);
            Searcher searcher = null;

            float times = 600f;

            for (int i = 0; i < times; i++) {
              try {
                searcher = accessor.getSearcher(null);

                QueryParser qp = new QueryParser("field", new KeywordAnalyzer());

                searcher.search(qp.parse("test"));
              } catch (IOException e) {
                throw new RuntimeException(e);
              } catch (ParseException e) {
                throw new RuntimeException(e);
              } finally {
                accessor.release(searcher);
              }
            }

          }
        };
        searchThreads[i].setName("searchThread-" + i);
      }

      for (int i = 0; i < searchThreads2.length; i++) {
        searchThreads2[i] = new Thread() {
          private MultiIndexAccessor mAccessor = IndexAccessorFactory.getInstance()
          .getMultiIndexAccessor();
          public void run() {
            Set<File> indexes = new HashSet<File>();
            indexes.add(index1);
            indexes.add(index2);

            Searcher searcher = null;

            float times = 600f;

            for (int i = 0; i < times; i++) {
              try {
                searcher = mAccessor.getMultiSearcher(indexes);

                QueryParser qp = new QueryParser("field", new KeywordAnalyzer());

                searcher.search(qp.parse("test"));
              } catch (IOException e) {
                throw new RuntimeException(e);
              } catch (ParseException e) {
                throw new RuntimeException(e);
              } finally {
                mAccessor.release(searcher);
              }
            }

          }
        };
        searchThreads2[i].setName("searchThread2-" + i);
      }

      for (int i = 0; i < updateThreads.length; i++) {
        updateThreads[i] = new Thread() {

          public void run() {
            IndexAccessor accessor = IndexAccessorFactory.getInstance().getAccessor(index1);

            float times = 600f;
            IndexWriter writer = null;

            for (int i = 0; i < times; i++) {
              try {
                writer = accessor.getWriter(false);
                writer.setUseCompoundFile(false);
                Document doc = new Document();
                doc.add(new Field("field", "test", Store.NO, Index.TOKENIZED));
                writer.addDocument(doc);
              } catch (IOException e) {
                e.printStackTrace();
                throw new RuntimeException(e);
              } finally {
                if (writer != null) {
                  accessor.release(writer);
                }
              }
            }

          }
        };

        updateThreads[i].setName("updateThread-" + i);
      }

      for (int i = 0; i < updateThreads2.length; i++) {
        updateThreads2[i] = new Thread() {

          public void run() {
            IndexAccessor accessor = IndexAccessorFactory.getInstance().getAccessor(index1);

            float times = 5f;
            IndexWriter writer = null;
            int batchSize = 8;
            boolean needsRelease = true;

            try {
              writer = accessor.getWriter(false);

              for (int i = 0; i < times; i++) {

                if (i % batchSize == 0) {
                  accessor.release(writer);
                  writer = accessor.getWriter(false);

                }
                writer.setUseCompoundFile(false);
                Document doc = new Document();
                doc.add(new Field("field", "test", Store.NO, Index.TOKENIZED));
                writer.addDocument(doc);

              }
            } catch (IOException e) {
              e.printStackTrace();
              throw new RuntimeException(e);
            } finally {
              if (writer != null) {
                accessor.release(writer);
              }
            }

          }
        };

        updateThreads2[i].setName("updateThread2-" + i);
      }

      for (int i = 0; i < searchThreads.length; i++) {
        System.out.println("starting search thread " + searchThreads[i].getName());
        searchThreads[i].start();
      }
      
      for (int i = 0; i < searchThreads2.length; i++) {
        System.out.println("starting search thread " + searchThreads2[i].getName());
        searchThreads2[i].start();
      }

      for (int i = 0; i < updateThreads.length; i++) {
        System.out.println("starting update thread " + updateThreads[i].getName());
        updateThreads[i].start();
      }

      for (int i = 0; i < updateThreads2.length; i++) {
        System.out.println("starting update thread " + updateThreads2[i].getName());
        updateThreads2[i].start();
      }

      for (int i = 0; i < searchThreads.length; i++) {
        searchThreads[i].join();
      }
      
      for (int i = 0; i < searchThreads2.length; i++) {
        searchThreads2[i].join();
      }

      for (int i = 0; i < updateThreads.length; i++) {
        updateThreads[i].join();
      }

      for (int i = 0; i < updateThreads2.length; i++) {
        updateThreads2[i].join();
      }

      Thread.sleep(2000);

      System.out.println("All threads have been started");

      IndexAccessorFactory.getInstance().close();
      dir.close();

      Thread.sleep(4000);
      deleteIndex(index1);
    }
  }

  public void testMultiSimpleSearch() throws Exception {
    Analyzer analyzer = new WhitespaceAnalyzer();
    FSDirectory dir = FSDirectory.getDirectory(index1, lockFactory);
    IndexAccessorFactory factory = IndexAccessorFactory.getInstance();
    factory.createAccessor(dir, analyzer);

    analyzer = new WhitespaceAnalyzer();
    dir = FSDirectory.getDirectory(index2, lockFactory);
    factory.createAccessor(dir, analyzer);

    IndexAccessor accessor = factory.getAccessor(index1);
    IndexAccessor accessor2 = factory.getAccessor(index2);
    IndexWriter writer = accessor.getWriter(false);
    IndexWriter writer2 = accessor2.getWriter(false);
    Document doc = new Document();
    Document doc2 = new Document();
    doc.add(new Field("field", "test", Store.NO, Index.TOKENIZED));
    doc2.add(new Field("field", "test", Store.NO, Index.TOKENIZED));
    writer.addDocument(doc);
    accessor.release(writer);
    writer2.addDocument(doc2);
    accessor2.release(writer2);

    Set<File> indexes = new HashSet<File>();
    indexes.add(index1);
    indexes.add(index2);
    MultiIndexAccessor mia = factory.getMultiIndexAccessor();
    Searcher searcher =  mia.getMultiSearcher(indexes);

    try {
      QueryParser qp = new QueryParser("field", new KeywordAnalyzer());

      Hits hits = searcher.search(qp.parse("test"));

      assertEquals(2, hits.length());
    } finally {
      mia.release(searcher);
    }

    factory.getAccessor(index1);
    writer = accessor.getWriter(false);
    Document doc3 = new Document();
    doc3.add(new Field("field", "test", Store.NO, Index.TOKENIZED));
    writer.addDocument(doc3);
    accessor.release(writer);

    // Must wait for the Readers to reopen
    Thread.sleep(3000);

    searcher = mia.getMultiSearcher(indexes);

    try {
      QueryParser qp = new QueryParser("field", new KeywordAnalyzer());

      Hits hits = searcher.search(qp.parse("test"));

      assertEquals(3, hits.length());
    } finally {
      mia.release(searcher);
    }

    factory.close();
    deleteIndex(index1);
    deleteIndex(index2);
  }

  public void testSimpleReaderRefresh() throws IOException, ParseException {
    IndexAccessorFactory factory = IndexAccessorFactory.getInstance();

    Analyzer analyzer = new WhitespaceAnalyzer();
    FSDirectory dir = FSDirectory.getDirectory(index1, lockFactory);
    factory.createAccessor(dir, analyzer);

    IndexAccessor accessor = factory.getAccessor(index1);
    IndexWriter writer = accessor.getWriter(false);
    Document doc = new Document();
    doc.add(new Field("field", "test", Store.NO, Index.TOKENIZED));
    writer.addDocument(doc);
    accessor.release(writer);

    final Thread[] threads = new Thread[3];
    threads[0] = new Thread() {

      public void run() {
        IndexAccessorFactory factory = IndexAccessorFactory.getInstance();

        IndexAccessor accessor = factory.getAccessor(index1);
        Searcher searcher = null;

        try {
          searcher = accessor.getSearcher(null);

          QueryParser qp = new QueryParser("field", new KeywordAnalyzer());

          Hits hits = searcher.search(qp.parse("test"));

          assertEquals(1, hits.length());
        } catch (IOException e) {
          throw new RuntimeException(e);
        } catch (ParseException e) {
          throw new RuntimeException(e);
        } finally {
          accessor.release(searcher);
        }

        threads[1] = new Thread() {

          public void run() {
            IndexAccessorFactory factory = IndexAccessorFactory.getInstance();

            IndexAccessor accessor = factory.getAccessor(index1);

            IndexWriter writer;

            try {
              writer = accessor.getWriter(false);
              writer.deleteDocuments(new Term("field", "test"));

              Document doc = new Document();
              doc.add(new Field("field", "update", Store.NO, Index.TOKENIZED));
              writer.addDocument(doc);
            } catch (IOException e) {
              throw new RuntimeException(e);
            }

            accessor.release(writer);

            try {
              Thread.sleep(1000);
            } catch (InterruptedException e1) {

            }

            threads[2] = new Thread() {

              public void run() {
                IndexAccessorFactory factory = IndexAccessorFactory.getInstance();

                IndexAccessor accessor = factory.getAccessor(index1);
                Searcher searcher = null;

                try {
                  searcher = accessor.getSearcher(null);

                  QueryParser qp = new QueryParser("field", new KeywordAnalyzer());

                  Hits hits = searcher.search(qp.parse("update"));

                  assertEquals(1, hits.length());
                } catch (IOException e) {
                  throw new RuntimeException(e);
                } catch (ParseException e) {
                  throw new RuntimeException(e);
                } finally {
                  accessor.release(searcher);
                }
              }
            };
            threads[2].start();
          }
        };
        threads[1].start();
      }
    };
    threads[0].start();

    for (int i = 0; i < threads.length; i++) {
      try {
        threads[i].join();
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }

    // cleanup
    IndexAccessorFactory.getInstance().close();
    deleteIndex(index1);
  }

  public void testSingleSimpleSearch() throws IOException, ParseException {
    Analyzer analyzer = new WhitespaceAnalyzer();
    FSDirectory dir = FSDirectory.getDirectory(index1, lockFactory);
    IndexAccessorFactory.getInstance().createAccessor(dir, analyzer);

    IndexAccessor accessor = IndexAccessorFactory.getInstance().getAccessor(index1);
    IndexWriter writer = accessor.getWriter(false);
    Document doc = new Document();
    doc.add(new Field("field", "test", Store.NO, Index.TOKENIZED));
    writer.addDocument(doc);
    accessor.release(writer);

    Searcher searcher = accessor.getSearcher(null);

    try {
      QueryParser qp = new QueryParser("field", new KeywordAnalyzer());

      Hits hits = searcher.search(qp.parse("test"));
      assertEquals(1, hits.length());
    } finally {
      accessor.release(searcher);
    }

    IndexAccessorFactory.getInstance().close();
    deleteIndex(index1);
  }
}
