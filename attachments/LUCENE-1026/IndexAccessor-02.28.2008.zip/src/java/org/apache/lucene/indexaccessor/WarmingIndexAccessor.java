package org.apache.lucene.indexaccessor;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.logging.Level;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Similarity;
import org.apache.lucene.search.Sort;
import org.apache.lucene.store.FSDirectory;

class WarmingIndexAccessor extends DefaultIndexAccessor {

  private Query warmQuery;
  private Set<IndexSearcher> retiredSearchers;
  private Set<Sort> sortFields;
  private int numSearchersForRetirment = 0;

  public WarmingIndexAccessor(FSDirectory dir, Analyzer analyzer, Query warmQuery) {
    this(dir, analyzer, warmQuery, null);
  }

  public WarmingIndexAccessor(FSDirectory dir, Analyzer analyzer, Query warmQuery,
      Set<Sort> sortFields) {
    super(dir, analyzer);

    this.warmQuery = warmQuery;
    this.sortFields = sortFields;
    retiredSearchers = new HashSet<IndexSearcher>();

  }

  /*
   * (non-Javadoc)
   * 
   * @see com.mhs.indexaccessor.IndexAccessor#close()
   */
  public void close() {
    lock.lock();
    try {
      if (closed) {
        return;
      }
      closed = true;
      while ((readingReaderUseCount > 0) || (searcherUseCount > 0) || (writingReaderUseCount > 0)
          || (writerUseCount > 0) || (numReopening > 0)) {
        System.out.println("searcherUseCount:" + searcherUseCount + " writerUseCount:"
            + writerUseCount);
        try {
          condition.await();
        } catch (InterruptedException e) {
        }
      }

      closeCachedReadingReader();
      closeCachedWritingReader();
      closeCachedWriter();

      retireSearchers();
      while (numSearchersForRetirment > 0) {
        try {
          condition.await();
        } catch (InterruptedException e) {
        }
        retireSearchers();
      }

      closeCachedSearchers();
      shutdownAndAwaitTermination(pool);

      // int i = 0;
      // for (IndexSearcher s : createdSearchers) {
      // System.out.println(i++ + ":" + s.getIndexReader().refCount + " :" +
      // s.getIndexReader());
      // }
    } finally {
      lock.unlock();
    }
  }

  /**
   * Reopens all of the Searchers in the Searcher cache. This method is invoked
   * in a synchronized context.
   */
  protected void reopenCachedSearchers() {
    if (logger.isLoggable(Level.FINE)) {
      logger.fine("reopening cached searchers (" + cachedSearchers.size() + "):"
          + Thread.currentThread().getId());
    }
    Set<Similarity> keys = cachedSearchers.keySet();
    for (Similarity key : keys) {
      IndexSearcher searcher = cachedSearchers.get(key);
      try {
        IndexReader oldReader = searcher.getIndexReader();
        Similarity sim = searcher.getSimilarity();
        IndexReader newReader = oldReader.reopen();

        if (newReader != oldReader) {
          retireSearchers();
          IndexSearcher newSearcher = new IndexSearcher(newReader);
          newSearcher.setSimilarity(sim);
          SearcherWarmer warmer = new SearcherWarmer(newSearcher);
          numSearchersForRetirment++;

          pool.execute(warmer);
        }

      } catch (IOException e) {
        logger.log(Level.SEVERE, "error reopening cached Searcher", e);
      }
    }

  }

  private void retireSearchers() {

    Iterator<IndexSearcher> it = retiredSearchers.iterator();

    while (it.hasNext()) {

      IndexSearcher s = it.next();
      if (logger.isLoggable(Level.FINE)) {
        logger.fine("closing retired searcher:" + s.getIndexReader());
      }

      try {
        s.getIndexReader().close();
        s.close();
      } catch (IOException e) {
        logger.log(Level.SEVERE, "error closing cached Searcher", e);
      }
      numSearchersForRetirment--;
    }
    retiredSearchers.clear();

  }

  public class SearcherWarmer implements Runnable {
    private IndexSearcher searcher;

    public SearcherWarmer(IndexSearcher searcher) {
      this.searcher = searcher;
    }

    public void run() {
      if (logger.isLoggable(Level.FINE)) {
        logger.fine("warming up searcher...");
      }
      try {
        if (sortFields != null) {
          for (Sort sort : sortFields) {
            searcher.search(warmQuery, sort);
          }
        } else {
          searcher.search(warmQuery);
        }
      } catch (IOException e) {
        throw new RuntimeException(e);
      }

      if (logger.isLoggable(Level.FINE)) {
        logger.fine("warming done");
      }

      lock.lock();
      try {
        retiredSearchers.add(cachedSearchers.put(searcher.getSimilarity(), searcher));

        WarmingIndexAccessor.this.lock.notifyAll();
      } finally {
        lock.unlock();
      }
    }
  }

}
