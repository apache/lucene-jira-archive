package org.apache.lucene.indexaccessor;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.IOException;
import java.util.Set;
import java.util.logging.Level;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.store.Directory;

class WarmingIndexAccessor extends DefaultIndexAccessor {

  private Query warmQuery;
  private Set<Sort> sortFields;

  /**
   * @param dir
   * @param analyzer
   * @param warmQuery
   */
  public WarmingIndexAccessor(Directory dir, Analyzer analyzer, Query warmQuery) {
    this(dir, analyzer, warmQuery, null);
  }

  /**
   * @param dir
   * @param analyzer
   * @param warmQuery
   * @param sortFields
   */
  public WarmingIndexAccessor(Directory dir, Analyzer analyzer,
      Query warmQuery, Set<Sort> sortFields) {
    super(dir, analyzer);

    this.warmQuery = warmQuery;
    this.sortFields = sortFields;

  }

  /*
   * (non-Javadoc)
   * 
   * @see com.mhs.indexaccessor.IndexAccessor#close()
   */
  public void close() {
    lock.lock();
    try {
      if (closed) {
        return;
      }
      closed = true;
      while ((readingReaderUseCount > 0) || (searcherUseCount > 0)
          || (writingReaderUseCount > 0) || (writerUseCount > 0)
          || (numReopening > 0)) {

        try {
          condition.await();
        } catch (InterruptedException e) {
        }
      }

      closeCachedReadingReader();
      closeCachedWritingReader();
      closeCachedWriter();

      closeCachedSearcher();
      shutdownAndAwaitTermination(pool);

    } finally {
      lock.unlock();
    }
  }

  /**
   * Reopens the cached reading Reader. This method assumes it is invoked in a
   * synchronized context.
   */
  protected void reopenReadingReader() {
    if (cachedReadingReader == null) {
      return;
    }

    logger.fine("reopening cached reading reader");

    try {
      IndexReader newReadingReader = cachedReadingReader.reopen();
      if (newReadingReader != cachedReadingReader) {
        ReaderWarmer warmer = new ReaderWarmer(newReadingReader);

        pool.execute(warmer);
      }
    } catch (IOException e) {
      logger.log(Level.SEVERE, "error reopening reading Reader", e);
    }

  }

  /**
   * Opens a new searcher with the latest cachedReadingReader. This method is
   * invoked in a synchronized context.
   */
  protected void refreshCachedSearcher() {
    // no op - the searcher will be replaced by the ReaderWarmer
  }

  /**
   * Warms a new Reader and updates
   * 
   */
  public class ReaderWarmer implements Runnable {
    private IndexReader newReader;

    public ReaderWarmer(IndexReader newReader) {
      this.newReader = newReader;
    }

    public void run() {
      if (logger.isLoggable(Level.FINE)) {
        logger.fine("warming up reader...");
      }
      IndexSearcher searcher = new IndexSearcher(newReader);
      try {
        if (sortFields != null) {
          for (Sort sort : sortFields) {
            searcher.search(warmQuery, sort);
          }
        } else {
          searcher.search(warmQuery);
        }
      } catch (IOException e) {
        throw new RuntimeException(e);
      }

      logger.fine("warming done");

      lock.lock();
      try {
        while ((readingReaderUseCount > 0) || (searcherUseCount > 0)) {
          try {
            condition.await();
          } catch (InterruptedException e) {
          }
        }

        cachedReadingReader.close();
        cachedReadingReader = newReader;
        if (cachedSearcher != null) {
          cachedSearcher = searcher;
        }
        condition.signalAll();
      } catch (IOException e) {
        throw new RuntimeException(e);
      } finally {
        lock.unlock();
      }
    }
  }

}
