package org.apache.lucene.indexaccessor;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.LogManager;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.store.Directory;

/**
 * An IndexAccessorFactory allows the sharing of IndexAccessors and
 * MultiIndexAccessors across threads.
 * 
 * First call createAccessordioupoui9p9pg qv
 * 
 */
public class IndexAccessorFactory {
  private static final IndexAccessorFactory indexAccessorFactory = new IndexAccessorFactory();
  static {
    LogManager manager = LogManager.getLogManager();
    InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("logger.properties");

    if (is != null) {
      try {
        manager.readConfiguration(is);
      } catch (SecurityException e) {
        throw new RuntimeException(e);
      } catch (IOException e) {
        throw new RuntimeException(e);
      }
    }
  }

  /**
   * @return
   */
  public static IndexAccessorFactory getInstance() {
    return indexAccessorFactory;
  }

  private ConcurrentHashMap<String, IndexAccessor> indexAccessors = new ConcurrentHashMap<String, IndexAccessor>();

  private boolean blockOnWriterRelease;

  private IndexAccessorFactory() {
    // prevent instantiation.
  }

  /**
   * Closes all of the open IndexAccessors and releases any open resources.
   */
  public void close() throws IOException {
    synchronized (indexAccessors) {
      for (IndexAccessor accessor : indexAccessors.values()) {
        accessor.close();
      }
      indexAccessors.clear();
    }
  }

  /**
   * @param dir
   * @param analyzer
   * @return
   * @throws IOException
   */
  public IndexAccessor createAccessor(Directory dir, Analyzer analyzer)
      throws IOException {
    return createAccessor(dir, analyzer, null, null);
  }

  /**
   * @param dir
   * @param analyzer
   * @param query
   * @return
   * @throws IOException
   */
  public IndexAccessor createAccessor(Directory dir, Analyzer analyzer,
      Query query) throws IOException {
    return createAccessor(dir, analyzer, query, null);
  };

  /**
   * @param dir
   * @param analyzer
   * @param query
   * @param sortFields
   * @return
   * @throws IOException
   */
  public IndexAccessor createAccessor(Directory dir, Analyzer analyzer,
      Query query, Set<Sort> sortFields) throws IOException {
    IndexAccessor accessor = null;
    if (query != null) {
      accessor = new WarmingIndexAccessor(dir, analyzer, query, sortFields);
    } else {
      accessor = new DefaultIndexAccessor(dir, analyzer);
    }
    accessor.open();

    String[] dirList = dir.list();
    if (dirList == null || dirList.length == 0) {
      IndexWriter indexWriter = new IndexWriter(dir, null, true);
      indexWriter.close();
    }

    IndexAccessor existingAccessor = indexAccessors.putIfAbsent(
        dir.getLockID(), accessor);
    if (existingAccessor != null) {
      throw new IllegalStateException("IndexAccessor already exists: " + dir);
    }

    return accessor;

  }

  /**
   * @param indexDir
   * @return accessor or null if not exists
   */
  public IndexAccessor getAccessor(Directory directory) {

    IndexAccessor indexAccessor = indexAccessors.get(directory.getLockID());
    if (indexAccessor != null) {
      indexAccessor.setBlockOnWriterRelease(blockOnWriterRelease);
    }
    return indexAccessor;

  }

  /**
   * @return
   */
  public String getInfo() {
    Set<String> keys = indexAccessors.keySet();
    StringBuilder sb = new StringBuilder();
    for (String key : keys) {
      IndexAccessor accessor = indexAccessors.get(key);
      sb.append("<br/>----------------------------");
      sb.append("<br/>Accessor: " + accessor.getDirectory());
      sb.append("<br/>----------------------------");
      sb.append("<br/>Searchers Out: " + accessor.searcherUseCount());
      sb.append("<br/>Writer In Use By: " + accessor.writerUseCount());
      sb.append("<br/>Writing Reader In Use By: "
          + accessor.writingReadersUseCount());
      sb.append("<br/>Reading Readers In Use By: "
          + accessor.readingReadersOut());
      sb.append("<br/>----------------------------");
    }

    return sb.toString();

  }

  /**
   * @return
   */
  public MultiIndexAccessor getMultiIndexAccessor() {
    return new DefaultMultiIndexAccessor();
  }

  /**
   * @param block
   */
  public void setBlockOnWriterRelease(boolean block) {
    this.blockOnWriterRelease = block;
  }
}
