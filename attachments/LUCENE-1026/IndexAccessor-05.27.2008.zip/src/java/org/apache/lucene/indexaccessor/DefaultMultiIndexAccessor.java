package org.apache.lucene.indexaccessor;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.lucene.search.MultiSearcher;
import org.apache.lucene.search.Searchable;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.store.Directory;

/**
 * Default MultiIndexAccessor implementation. *Not* thread safe.
 */
public class DefaultMultiIndexAccessor implements MultiIndexAccessor {

  private final static Logger logger = Logger
      .getLogger(DefaultMultiIndexAccessor.class.getName());

  private final Map<Searcher, IndexAccessor> multiSearcherAccessors = new HashMap<Searcher, IndexAccessor>();

  private boolean released = true;

  public DefaultMultiIndexAccessor() {

  }

  /*
   * (non-Javadoc)
   * 
   * @see com.mhs.indexaccessor.MultiIndexAccessor#getMultiSearcher(org.apache.lucene.search.Similarity,
   *      java.util.Set, org.apache.lucene.index.IndexReader)
   */
  public MultiSearcher getMultiSearcher(Set<Directory> indexes)
      throws IOException {
    if (!released) {
      throw new IllegalStateException(
          "Previous MultiSearcher has not been released");
    }
    released = false;
    if (logger.isLoggable(Level.FINE)) {
      logger.fine("opening new multi searcher");
    }

    Searcher[] searchers = new Searcher[indexes.size()];
    Iterator<Directory> it = indexes.iterator();
    IndexAccessorFactory factory = IndexAccessorFactory.getInstance();

    for (int i = 0; i < searchers.length; i++) {
      Directory index = it.next();
      IndexAccessor indexAccessor = factory.getAccessor(index);
      searchers[i] = indexAccessor.getSearcher();
      multiSearcherAccessors.put(searchers[i], indexAccessor);
    }

    MultiSearcher multiSearcher = new MultiSearcher(searchers);

    return multiSearcher;
  }


  /*
   * (non-Javadoc)
   * 
   * @see com.mhs.indexaccessor.MultiIndexAccessor#release(org.apache.lucene.search.Searcher)
   */
  public void release(MultiSearcher multiSearcher) {
    Searchable[] searchers = multiSearcher.getSearchables();

    for (Searchable searchable : searchers) {
      IndexAccessor accessor = multiSearcherAccessors.remove(searchable);
      accessor.release((Searcher) searchable);
    }
    released = true;

  }

}
