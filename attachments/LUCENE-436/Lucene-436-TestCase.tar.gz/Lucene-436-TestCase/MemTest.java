import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Hits;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import java.io.File;

public class MemTest {
    public static void main (String [] argv)
        throws Exception
    {
        String indexdir = "test";
        String query="+i1:1 +j2:2";
        boolean useRAMDirectory = false;

        for (int ii=0;ii<argv.length;ii++) {
            if (argv[ii].equals("-useRAMDirectory")) {
                useRAMDirectory = true;
            } else if (argv[ii].equals("-indexdir")) {
                ii++;
                indexdir = argv[ii];
            } else if (argv[ii].equals("-query")) {
                ii++;
                query = argv[ii];
            }
        }
        
        System.out.println("Running test");
        System.out.println("Creating test index in directory: " + new File("indexdir").getCanonicalFile());
        // System.out.println("Running query: " + query);
        System.out.println((useRAMDirectory?"Using RAMDirectory":"NOT using RAMDirectory"));
        // System.out.println("Hit <return> to continue");
        // System.in.read();
        
        String osName    = System.getProperty("os.name");
        String osArch    = System.getProperty("os.arch");
        String osVersion = System.getProperty("os.version");
        System.out.println("OS: " + osName + " " + osArch + " " + osVersion);
        
        String vmVersion = System.getProperty("java.vm.version");
        String vmVendor  = System.getProperty("java.vm.vendor");
        String vmName    = System.getProperty("java.vm.name");
        System.out.println("VM: " + vmVendor + " " + vmName + " " + vmVersion);
        
        if (!vmName.equals("Java HotSpot(TM) Client VM")) {
            System.out.println("!!! NOTE !!! I have not observed this bug in this JVM: " + vmName);
            System.out.println("!!! NOTE !!! Please use \"Java HotSpot(TM) Client VM\"");
        }
        if (vmVersion.compareTo("1.5") > 0) {
            System.out.println("!!! NOTE !!! I have not observed this bug in this JVM version: " + vmVersion);
            System.out.println("!!! NOTE !!! Please use version 1.4.x");
        }
        
        // Create index at location.
        // (Delete anything that's already there)
        IndexWriter w = new IndexWriter(indexdir, null, true);
        w.close();
        
        int i = 0;
        try {
            for (i=0;i<4000;i++) {
                
                // Add a new doc to the index:
                IndexWriter w2 = new IndexWriter(indexdir, null, false);
                Document doc = new Document();
                // create some keyword fields (the larger they are, the more the arrival of the OutOfMemoryError is hastened).
                doc.add(Field.Keyword("i1", "i1aaaaaaaaaabbbbbbbbbbccccccccccddddddddddeeeeeeeeeeffffffffff" + i));
                doc.add(Field.Keyword("i2", "i2aaaaaaaaaabbbbbbbbbbccccccccccddddddddddeeeeeeeeeeffffffffff" + i));
                doc.add(Field.Keyword("i3", "i3aaaaaaaaaabbbbbbbbbbccccccccccddddddddddeeeeeeeeeeffffffffff" + i));
                doc.add(Field.Keyword("i4", "i4aaaaaaaaaabbbbbbbbbbccccccccccddddddddddeeeeeeeeeeffffffffff" + i));
                w2.addDocument(doc);
                w2.close();
    
                final IndexSearcher searcher;
                if (useRAMDirectory) {
                    RAMDirectory rd = new RAMDirectory(indexdir);
                    searcher = new IndexSearcher(rd);
                } else {
                    searcher = new IndexSearcher(indexdir);
                }
                Query q = new QueryParser("i", new StandardAnalyzer()).parse(query);
                Hits hits = searcher.search(q);
                for (int k=0;k<hits.length();k++) {
                    Document d = hits.doc(k);
                }
    
                searcher.close();
                if (i%1000==0) {
                    // display progress every 1000 iterations
                    System.out.println("i = " + i);
                }
            }
            System.out.println("PASSED\n\n");
        } catch (OutOfMemoryError e) {
            System.out.println("FAILED at i = " + i + "\n\n");
        }
    }
}
 