#!/bin/bash


# To perform these tests, you must be running SUN's Hotspot JVM
# version 1.4.2.
# Other JVMs or versions might not exhibit the problem (although
# all 1.4.x versions that I've tested DO exhibit this problem).
#
# As a pre-requisite to running this script, you should ensure that
# your JAVA_HOME and PATH environment variables are set up correctly
# so as to use JVM 1.4.2.
#
# Note, we set the maximum memory available to the JVM to just 10MB.
# This hastens the occurence of the out-of-memory problem.


# Where we create the test index
export INDEXDIR="./test"
mkdir "$INDEXDIR"

# COMPILE the test
export CLASSPATH=./lucene-1.4-final.jar:.
javac MemTest.java

# RUN the test against the UN-patched lucene jar
export CLASSPATH=./lucene-1.4-final.jar:.

# This should fail
java -Xmx10M MemTest -location "$INDEXDIR" -useRAMDirectory

# This should pass
java -Xmx10M MemTest -location "$INDEXDIR"


# RUN the test against the PATCHED lucene jar
export CLASSPATH=./lucene-1.4-final-patched.jar:.

# This should pass
java -Xmx10M MemTest -location "$INDEXDIR" -useRAMDirectory

# This should pass
java -Xmx10M MemTest -location "$INDEXDIR"

