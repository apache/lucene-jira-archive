/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.util.BitSet;

/**
 * A set of document number
 * (a BitSet + a iterator)
 * 
 * @author Nicolas Maisonneuve
 */
public final class DocumentSelection {

	private BitSet seldocs;

	private int numdocs;


	DocumentSelection(int numdocs) {
		this.numdocs = numdocs;
		seldocs = new BitSet(numdocs);
	}

	DocumentSelection() {
		seldocs = new BitSet();
	}
	


	/**
	 * is the document selected
	 * 
	 * @param doc
	 * @return
	 */
	public final boolean isSelected(int doc) {
		return seldocs.get(doc);
	}

	/**
	 * select a document
	 * 
	 * @param doc
	 *            the document's number
	 */
	public final void select(int doc) {
		seldocs.set(doc);
	}


	/**
	 * select several documents
	 * 
	 * @param docs
	 *            a bitset: - bitset index = document number - true/false value
	 *            for selected or not the document;
	 */
	public final void select(BitSet docs) {
		seldocs.or(docs);
	}

	/**
	 * Select several documents
	 * 
	 * @param docs
	 *            a array with document's numbers
	 */
	public final void select(int[] docs) {
		for (int i = 0; i < docs.length; i++) {
			seldocs.set(docs[i]);
		}
	}
	
	public final void deselect(int doc) {
		seldocs.clear(doc);
	}

	/**
	 * the number of selected documents
	 * 
	 * @return
	 */
	public int size() {
		return seldocs.cardinality();
	}

	/**
	 * Are all the documents selected ?
	 * can be use to optimize some methods
	 * 
	 * @return
	 */
	public boolean allSelected() {
		return size()==numdocs;
	}

	/**
	 * select all documents
	 */
	public final void selectAllDocs() {
		seldocs.set(0,numdocs);
	}

	public void clear() {
		seldocs.clear();
	}

	public String toString(){
		return seldocs.toString();
	}
	

	
	/** *************************** ITERATION ******************************** */
	
	private int index = 0;

	private boolean first = true;

	
	/**
	 * clear the iterator
	 */
	public void clearIterator() {
		first = true;
		index = 0;
	}

	/**
	 * has a next selected document number
	 * 
	 * @return
	 */
	public boolean next() {

		if (first) {
			index = seldocs.nextSetBit(index);
			first = false;
		} else {
			index = seldocs.nextSetBit(index + 1);
		}
		// System.out.println("next "+index);
		return index >= 0;
	}
	

	/**
	 * the actual document number
	 * 
	 * @return
	 */
	public int doc() {
		return index;
	}
}
