/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.io.IOException;
import java.util.Iterator;
import java.util.TreeMap;

/**
 * Create a term's posting  by using another original term's posting
 * 
 * @author Nicolas Maisonneuve
 */
public class TermReplacer implements TermTransformer {

	private final class ReplaceTerm {
		private Term oldterm;

		private DocumentSelection docs;

		/**
		 * @param docs
		 *            The docs to set.
		 */
		public void setDocs(DocumentSelection docs) {
			this.docs = docs;
		}

		/**
		 * @return Returns the docs.
		 */
		public DocumentSelection getDocs() {
			return docs;
		}
	}

	private final class ReplaceProducter implements TermProducter {

		private final class ReplaceTermEnum extends TermEnum {
			private Term term;

			private Iterator iterTerm;

			private ReplaceTerm rt;

			public void close() throws IOException {
				inputTermEnum.close();
			}

			public int docFreq() {
				throw new UnsupportedOperationException(); // return
				// inputTermEnum.docFreq();
			}

			public boolean next() throws IOException {
				if (!iterTerm.hasNext())
					return false;
				else {
					term = (Term) iterTerm.next();

					return true;
				}
			}

			public Term term() {
				return term;
			}

			public ReplaceTermEnum() {
				iterTerm = replacedTerm.keySet().iterator();
			}
		}

		private final class ReplaceTermPositions implements TermPositions {
			private ReplaceTerm rt;

			public int nextPosition() throws IOException {
				return InputTermPositions.nextPosition();
			}

			public int doc() {
				return InputTermPositions.doc();
			}

			public int freq() {
				return InputTermPositions.freq();
			}

			public void seek(Term arg0) throws IOException {
				rt = getReplacedTerm(arg0, false);
				if (rt != null)
					InputTermPositions.seek(rt.oldterm);
			}

			public void seek(TermEnum tenum) throws IOException {
				seek(tenum.term());
			}

			public void close() throws IOException {
				InputTermPositions.close();
			}

			public boolean next() throws IOException {
				int doc=0;
				if (rt == null)
					return false;
				do {
					if (!InputTermPositions.next()) {
						//System.out.println("end");
						return false;
					}
					doc=InputTermPositions.doc();
					//System.out.println("doc?: "+doc);
				} while (!rt.getDocs().isSelected(doc));
				return true;
			}

			public int read(int[] arg0, int[] arg1) throws IOException {
				throw new UnsupportedOperationException();
			}

			public boolean skipTo(int arg0) throws IOException {
				throw new UnsupportedOperationException();
			}
		}

		TermEnum inputTermEnum;

		TermPositions InputTermPositions;

		public ReplaceProducter(TermProducter input) throws IOException {
			inputTermEnum = input.terms();
			InputTermPositions = input.termPositions();

		}

		public TermEnum terms() throws IOException {
			return new ReplaceTermEnum();
		}

		public TermPositions termPositions() throws IOException {
			return new ReplaceTermPositions();
		}

	}

	TreeMap replacedTerm = new TreeMap();

	final ReplaceTerm getReplacedTerm(Term newterm, boolean create) {
		ReplaceTerm replacedterm = (ReplaceTerm) replacedTerm.get(newterm);
		if (replacedterm == null && create) {
			replacedterm = new ReplaceTerm();
			replacedTerm.put(new Term(newterm.field, newterm.text, false),
					replacedterm);
		}
		return replacedterm;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.lucene.index.TermTransformer#transform(org.apache.lucene.index.TermProducter)
	 */
	public TermProducter transform(TermProducter input) throws IOException {
		return new ReplaceProducter(input);
	}

	/**
	 * Replace a term by another for the selected documents
	 * 
	 * @param inputTerm
	 *            the term used in the TermProducter inputto be replaced
	 * @param newTerm
	 *            the new term
	 * @param docsel
	 *            the selected documents
	 */
	public void replaceTerm(Term inputTerm, Term newTerm, DocumentSelection docsel) {
		ReplaceTerm replacedterm = getReplacedTerm(newTerm, true);
		replacedterm.oldterm = inputTerm;
		replacedterm.setDocs(docsel);
	}

}
