/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.util.Arrays;

/*
* a modified MultipleTermPositions.IntQueue class
*  
*/
public final class IntQueue {
	private int _arraySize;

	private int _index = 0;

	private int _lastIndex = 0;

	private int[] _array;

	IntQueue(int arraySize) {
		_arraySize = arraySize;
		_array = new int[_arraySize];
	}

	IntQueue(int[] pos) {
		_arraySize = pos.length;
		_array = pos;
		_lastIndex=_arraySize;
	}

	IntQueue() {
		this(16);
	}

	final void add(int i) {
		if (_lastIndex == _arraySize)
			growArray();

		_array[_lastIndex++] = i;
	}

	final int next() {
		return _array[_index++];
	}

	final void clearIterator() {
		_index = 0;

	}

	final void sort() {
		Arrays.sort(_array, 0, _lastIndex);
		deletedoublon();
	}

	private final void deletedoublon() {
		int j = 0;
		for (int i = 0; i < _lastIndex; i++) {
			if (_array[i] != _array[j]) {
				j++;
				_array[j] = _array[i];
			}
		}
		_lastIndex = j + 1;
	}

	final void clear() {
		_index = 0;
		_lastIndex = 0;
	}

	final int size() {
		return _lastIndex;
		// return (_lastIndex - _index);
	}

	final void set(int[] pos) {
		_index = 0;
		_arraySize = pos.length;
		_array = pos;
		_lastIndex = _arraySize;
	}

	public String toString() {
		StringBuffer bf = new StringBuffer();
		for (int i = 0; i < _lastIndex; i++) {
			bf.append(_array[i] + " ");
		}
		return bf.toString();
	}

	private void growArray() {
		int[] newArray = new int[_arraySize * 2];
		System.arraycopy(_array, 0, newArray, 0, _arraySize);
		_array = newArray;
		_arraySize *= 2;
	}
}