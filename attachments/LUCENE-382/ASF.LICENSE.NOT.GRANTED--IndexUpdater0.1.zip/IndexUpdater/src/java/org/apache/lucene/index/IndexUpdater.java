/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Field;
import org.apache.lucene.search.HitCollector;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.Directory;

/**
 * Index Updater class <br/>
 * <H3>1. A Exemple: Update a field in several documents </H3>
 * <p>
 * IndexUpdater updater = new IndexUpdater(dir);<br/> <br/> <i>//first we have
 * to select the documents to be updated.<br/></i> <br/> <i>// select all docs
 * except the first </i><br/> DocumentSelection docsel =
 * updater.createDocSelection();<br/> docsel.selectAllDocs();<br/>
 * docsel.deselect(0);<br/> <br/> <i>// another exemple of selection :<br/> //
 * select all the docs with the term (field1,term1)</i><br/> docsel =
 * updater.createDocSelection(new TermQuery("field1","term1")<br/> <br/> <i>//
 * update a field of the selected documents </i><br/>
 * updater.updateField(Field.Text("field1", " term2 term1 val4 term1 term2"),
 * new StandardAnalyzer(),docsel);<br/> <br/> <i>// write and close</i> <br/>
 * updater.close();<p/>
 * <H3>A use cases: indexing document with dynamic field. </H3>
 * <p>
 * I'm going to use it to index RDF file. A ressource = a lucene document. A
 * property = a lucene search Field. Only the literal property can be indexed.
 * Only the URI is stored (see why in limitation section). When i have a
 * property linked with another ressource , i replace the URI of the ressource
 * with its label and have a literal and so indexable property. But If a
 * ressource's label changes and the ressource is linked with 1 million of other
 * ressources, I had to delete and reindex 1 million of lucene doc. To avoid to
 * recreate all the index for a small update, i create this contribution.
 * </p>
 * <H3>2. Limitations and Performance</H3>
 * <p>
 * <ul>
 * <li>The Updater works for :
 * <ul>
 * <li>optimized index: only one segment is allow because each segment has its
 * own document numbers attribution, so i can't update several documents with
 * the same document number (TODO use a reversed method of the MultiIndexReader#initialize() method to overlap this
 * problem)</li>
 * <li>no coumpounded index: with the coumpound mode the lucene files with
 * term's posting lists data (.tii, tis, .frq, .prx) are embedded with all other
 * lucene file and could not rewrite without rewrite all the files) </li>
 * </ul>
 * </LI>
 * <li>it doesn't support TermVector (TODO)</li>
 * <li>it updates just the term posting lists, not the stored values. So if you
 * have a storable field and you update this field your search would work fine
 * but the field value of the results would be the old value. (if i update also
 * the store value it would be similar in time to the del+add docs process)
 * </li>
 * </ul>
 * </p>
 * <p>
 * The performance.<br/> The number of indexed documents are not really a big
 * impact in the performance of the updating. So the updating is very useful
 * when you have a big index and some updates to do in your docs. In my testCase
 * TestIndexUpdater, the updating of small documents takes 100 ms for 10000
 * docs, 450 ms for 100000 docs and 5s for 1 Million of docs).
 * </p>
 * <H3>3. How does it work in internal ? </H3>
 * <p>
 * The goal of this contribution is to rewrite only the files containing
 * information about the term posting list ( .tis , .tii, .frq, prx,). <br/>In
 * the Lucene API, the term posting lists are accessible with
 * IndexReader.Terms() (Enumerate all the terms) and IndexReader.TermPositions()
 * (For a specific term, enumerate each pair <doc number, Freq, <position>^freq > )
 * methods. So, if i modified the output of these 2 methods (add new terms,
 * delete relations between documents and terms, etc..) and rewrite the output
 * in the lucene index, I recreate a new lucene term posting list. That's what
 * this contribution does !
 * </p>
 * <p>
 * To do this, i create a interface called TermProducter containing this 2
 * methods (Terms() and TermPositions()).A class implementing this interface
 * have to produce this 2 kind of ouputs (so it produce the posting lists). For
 * Exemple a IndexReader could implements this interface, but you can also
 * create your own term posting list producter, or create a TermProducter that
 * modify the content of the original IndexReader ouput. Then, with the
 * TermWriter class that takes in input a TermProducter and a lucene index, you
 * can rewrite the lucene term posting list with the content of the
 * TermProducter.
 * </p>
 * <p>
 * So now the question is : How can i modified the term posting list ? , What
 * are my tools ? You have 2 types of Tools : TermGenerator and TermTransformer.
 * <ul>
 * <li>The TermGenerator Interface. It generates a TermProducter instance. Its
 * goal is to create a new posting list. The interface is simple:<br/><i><center>
 * public TermProducter CreateTermProducter();</center></i><br/>There are 2
 * proposed Implementations:
 * <ul>
 * <li> TermReader class: A IndexReader Wrapper implementing TermProducter </li>
 * <li> TermAdder class: you can create your own posting list by adding
 * term/documen relation. It's like a virtual index.</li>
 * </ul>
 * </li>
 * <li>The TermTransformer Interface. It modifies the output of a
 * TermProducter. The interface is: <br/><br/><i><center>public TermProducter
 * transform(TermProducter producter);</center></i><br/> There are 2 proposed
 * Implementations:
 * <ul>
 * <li> TermFilter class. Filter some term/doc relations</li>
 * <li> TermReplacer class. You can replace some term/doc relations by others
 * relations </li>
 * </ul>
 * </li>
 * </ul>
 * </p>
 * <p>
 * Note: You have also a special TermProducter implementation called TermMerger.
 * It merges several TermProducters.</i>
 * </p>
 * <p>
 * Now we can play by combining and create a kind of pipeline For exemple, a
 * update process : <br/> (1) TermReader----> (2) TermFilter ----> (4)TermMeger (
 * -----> (5) TermWriter )<BR/> (3) TermAdder --->---------------------------^
 * <br/>
 * <ul>
 * <li>1 - we read the lucene posting list</li>
 * <li>2 - we delete somes terms</li>
 * <li>3 - we add new terms</li>
 * <li>4 - we merge the 2 TermProducters to create the final TermProducter</li>
 * <li>5 - we write the termproducter informations in the lucene index. </li>
 * </ul>
 * </p>
 * <p>
 * This design allows flexibility because If i just want replace terms i can use
 * this simple/optimized pipeline: (1) TermReader----> (2) TermReplacer
 * (---->TermWriter )
 * </p>
 * 
 * @author Nicolas Maisonneuve
 */
public class IndexUpdater {

	private IndexReader reader;

	private IndexSearcher searcher;

	private TermWriter writer;

	private TermFilter filter;

	private TermReplacer replacer;

	private TermAdder adder;

	/**
	 * Contrutor
	 * 
	 * @param dir
	 *            the lucene index to update
	 * @throws IOException
	 */
	public IndexUpdater(Directory dir) throws IOException {
		reader = IndexReader.open(dir);
		writer = new TermWriter(reader);
	}

	/**
	 * Add a new field in the selected document
	 * 
	 * @param field
	 *            the lucene field
	 * @param analyzer
	 *            the analyzer (used if the field is tokenized)
	 * @param docsel
	 *            the selected documents in which the terms have to be added
	 * @throws IOException
	 */
	public void addField(Field field, Analyzer analyzer,
			DocumentSelection docsel) throws IOException {
		if (adder == null)
			adder = new TermAdder();
		adder.addField(field, analyzer, docsel);
	}

	/**
	 * Replace a term by another for the selected documents
	 * 
	 * @param oldTerm
	 *            the term to be replaced
	 * @param newTerm
	 *            the new term
	 * @param docsel
	 *            the selected documents
	 */
	public void replaceTerm(Term oldTerm, Term newTerm, DocumentSelection docsel) {
		if (replacer == null)
			replacer = new TermReplacer();
		// create a new term (and all the position information) using a
		// original term
		replacer.replaceTerm(oldTerm, newTerm, docsel);

		// delete the old term
		this.deleteTerm(oldTerm, docsel);
	}

	/**
	 * Update a field for the selected documents
	 * 
	 * @param field
	 *            the new field to update (delete the old fiel and replace by
	 *            this)
	 * @param analyzer
	 *            a analyzer if the field is tokenizable
	 * @param docsel
	 *            the selected documents
	 */
	public void updateField(Field field, Analyzer analyzer,
			DocumentSelection docsel) throws IOException {
		// delete all the terms in this field linked with the document selection
		deleteTerm(new Term(field.name(), ""), docsel);

		// add new terms and link them with the selected documents
		addField(field, analyzer, docsel);
	}

	/**
	 * Delete a term or a entire field for the selected documents
	 * 
	 * @param Term
	 *            the term to be deleted. If the value of the term is empty ("")
	 *            the entire field is deleted for these documents
	 * @param docsel
	 *            the selected documents in which the term has to be deletes
	 */
	public void deleteTerm(Term term, DocumentSelection docsel) {
		if (filter == null)
			filter = new TermFilter();
		filter.deleteTerm(term, docsel);
	}

	/**
	 * create a empty document selection
	 * 
	 * @return
	 */
	public DocumentSelection createDocSelection() {
		return new DocumentSelection(reader.numDocs());
	}

	/**
	 * select the documents that are the hits of a lucene query
	 * 
	 * @param query
	 * @return
	 * @throws IOException
	 */
	public DocumentSelection createDocSelection(Query query) throws IOException {
		if (searcher != null)
			searcher = new IndexSearcher(reader);
		final DocumentSelection seldocs = createDocSelection();
		// fill the bitset with the hits;
		searcher.search(query, new HitCollector() {
			public final void collect(int doc, float score) {
				if (score > 0.0)
					seldocs.select(doc);
			}

		});

		return seldocs;
	}

	/**
	 * Write the term postings and close
	 * 
	 * @throws IOException
	 */
	public void close() throws IOException {
		TermProducter producter = createPipeline();
		writer.write(producter);

		if (searcher != null)
			searcher.close();
	}

	/**
	 * Create the transformation pipeline <br>
	 * 
	 * @return the termProducter
	 * @throws IOException
	 */
	private TermProducter createPipeline() throws IOException {
		TermReader treader = new TermReader(reader);
		TermProducter p = treader.createTermProducter();

		if (adder != null || replacer != null) {

			TermMerger termM = new TermMerger();

			if (replacer != null) {
				termM.addProducter(replacer.transform(p));
			}

			if (adder != null) {
				termM.addProducter(adder.createTermProducter());
			}

			if (filter != null) {
				termM.addProducter(filter.transform(p));
			}

			p = termM;
		} else {

			if (filter != null) {
				p = filter.transform(p);
			}
		}

		return p;
	}
}
