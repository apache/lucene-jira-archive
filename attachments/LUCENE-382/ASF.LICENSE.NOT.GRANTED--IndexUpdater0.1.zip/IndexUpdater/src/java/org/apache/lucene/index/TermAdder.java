/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.TreeMap;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.Token;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.document.Field;
import org.apache.lucene.util.PriorityQueue;

/**
 * Term Adder: create Term Postings
 * @author Nicolas Maisonneuve
 *
 */
public final class TermAdder implements TermGenerator {
	private final class PostingData  {

		private IntQueue positions;
		private DocumentSelection docs;
		
		/**
		 * @param docs The docs to set.
		 */
		public void setDocs(DocumentSelection docs) {
			this.docs = docs;
		}

		/**
		 * @return Returns the docs.
		 */
		public DocumentSelection getDocs() {
			return docs;
		}
		
		public PostingData() {
			positions = new IntQueue();
		}

		public IntQueue getPosition() {
			return positions;
		}
	}

	private final class AdderProducter implements TermProducter {

		private final class VirtualTermPosition implements TermPositions {

			private final class DocPostingQueue extends PriorityQueue {

				DocPostingQueue(List list) {
					this.initialize(list.size());
					Iterator iter = list.iterator();
					while (iter.hasNext()) {
						PostingData dp = (PostingData) iter.next();
						//System.out.println("new Queue ");
						dp.getDocs().next();
						put(dp);
					}
				}

				public final boolean lessThan(Object a, Object b) {
					return ((PostingData) a).getDocs().doc() < ((PostingData) b)
							.getDocs().doc();
				}

				final PostingData peek() {
					return (PostingData) top();
				}
			}

			private DocPostingQueue queue;

			private int _doc;

			private IntQueue _pos = new IntQueue();

			public int nextPosition() {
				return _pos.next();
			}

			public void close() {
				queue = null;
			}

			public int doc() {
				return _doc;
			}

			public int freq() {
				return _pos.size();
			}

			public boolean next() {
				_pos.clear();
				if (queue == null || queue.size() == 0)
					return false;
				PostingData dp=  queue.peek();
				
				_doc = dp.getDocs().doc();
				//_pos=queue.peek().getPosition();
				
				do {
					dp = queue.peek();
					dp.positions.clearIterator();
					
					for (int i = 0; i < dp.positions.size(); i++)
						_pos.add(dp.positions.next());
					
					if (dp.getDocs().next())
						queue.adjustTop();
					else {
						queue.pop();
					}
					
				} while (queue.size() > 0
						&& queue.peek().getDocs().doc() == _doc);
				_pos.sort();
				return true;
			}

			public final boolean skipTo(int target) {
				throw new UnsupportedOperationException();
			}

			public void seek(Term term) {
				List listposting = (List) termsPostingList.get(term);
				if (listposting != null) {
					//TODO queue.clear queue.put etc...
					queue = new DocPostingQueue(listposting);
				} else {
					queue = null;
				}
			}

			public void seek(TermEnum termEnum) throws IOException {
				seek(termEnum.term());
			}

			/**
			 * Not implemented.
			 * 
			 * @throws UnsupportedOperationException
			 */
			public int read(int[] arg0, int[] arg1) {
				throw new UnsupportedOperationException();
			}

		}

		private final class VirtualTermEnum extends TermEnum {

			private Iterator iterTerm;

			private Term term;

			VirtualTermEnum() {
				iterTerm = termsPostingList.keySet().iterator();
			}

			public void seek(Term term) {
				iterTerm = termsPostingList.tailMap(term).keySet().iterator();
			}

			public void close() {
				// System.out.println("TermEnum closed");
				iterTerm = null;
			}

			public int docFreq() {
				throw new UnsupportedOperationException();
				// return postingterm.getFreq();
			}

			public boolean next() {
				boolean res = iterTerm.hasNext();
				if (res) {
					term = (Term) iterTerm.next();
				}
				
				return res;
			}

			public Term term() {
				return term;
			}

		}

		public TermPositions termPositions() {
			VirtualTermPosition vtp = new VirtualTermPosition();
			return vtp;
		}

		public TermEnum terms() {
			return new VirtualTermEnum();
		}



	}

	private TreeMap termsPostingList = new TreeMap();

	public TermAdder() {
	}

	final Stack getPostingList(Term term, boolean create) {
		Stack postinglist = (Stack) termsPostingList.get(term);
		if (postinglist == null && create) {
			postinglist = new Stack();
			termsPostingList.put(new Term(term.field, term.text, false),
					postinglist);
		}
		return postinglist;
	}
/**
 * Add a new field in the selected document 
 * @param field the lucene field
 * @param analyzer the analyzer (used if the field is tokenized)
 * @param docsel the selected documents in which the terms have to be added
 * @throws IOException
 */
	public void addField(Field field, Analyzer analyzer, DocumentSelection docsel)
			throws IOException {
		Term termBuffer = new Term("", "");
		String fieldName = field.name();

		if (!field.isTokenized()) { // un-tokenized field
			termBuffer.set(field.name(), field.stringValue());
			Stack pList = getPostingList(termBuffer, true);
			 PostingData dp=new PostingData();
			 dp.setDocs(docsel);
			 dp.getPosition().add(0);
			 pList.push(dp);

		} else {
			// analyze text
			int position = 0;
			TokenStream stream = analyzer.tokenStream(fieldName,
					getReader(field));
			try {

				for (Token t = stream.next(); t != null; t = stream.next()) {

					position += t.getPositionIncrement();

					// System.out.println("val: "+t.termText()+" pos:
					// "+position);

					termBuffer.set(field.name(), t.termText());
					Stack pList = getPostingList(termBuffer, false);
					PostingData dp;
					if (pList == null) {
						pList = getPostingList(termBuffer, true);
						 dp=new PostingData();
						 dp.setDocs(docsel);
						 pList.push(dp);
					}else {
						// possible bug is another dp is already create
						dp=(PostingData)pList.peek();
					}
					dp.getPosition().add(position);
					//System.out.println("term "+ termBuffer+" "+dp.getPosition());
				}

			} finally {
				stream.close();
			}
		}
	}

	private Reader getReader(Field field) {
		Reader reader; // find or make Reader
		if (field.readerValue() != null)
			reader = field.readerValue();
		else if (field.stringValue() != null)
			reader = new StringReader(field.stringValue());
		else
			throw new IllegalArgumentException(
					"field must have either String or Reader value");
		return reader;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.lucene.index.TermGenerator#createTermProducter()
	 */
	public TermProducter createTermProducter() {
		return new AdderProducter();
	}

}
