/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class TestIndexUpdater extends TestCase {

	String indexDir = "d:\\test";

	Directory dir;

	int numdocs = 10000;

	public void testUpdate() throws IOException {

		dir = FSDirectory.getDirectory(indexDir, true);
		long time = System.currentTimeMillis();

		createRealIndex(dir, numdocs);
		System.out.println(" create time: "
				+ (System.currentTimeMillis() - time));

		time = System.currentTimeMillis();

		IndexUpdater updater = new IndexUpdater(dir);

		// select all docs except the last
		DocumentSelection docsel = updater.createDocSelection();
		docsel.selectAllDocs();
		docsel.deselect(numdocs - 1);

//		 select some docs to replace term
		DocumentSelection replacedocs = updater.createDocSelection();
		replacedocs.select(new int[]{1,2,3,5});
		
		
		// add new terms and link them with the selected documents
		updater.updateField(
				Field.Text("field1", "  term2 term1 val4 term1 term2"),
				new StandardAnalyzer(), docsel);

		updater.replaceTerm(new Term("field1", "term2"), new Term("field1",
		"term11"), replacedocs);
		
		// write and close
		updater.close();

		System.out.println(" update time: "
				+ (System.currentTimeMillis() - time));

		// print terms enum after
		IndexReader reader = IndexReader.open(dir);
		System.out.println(" ---- AFTER ----------");
		printTermEnum(reader.terms());

		// no doc freq change for term1
		TermEnum te = reader.terms(new Term("field1", "term1"));
		assertEquals(numdocs, te.docFreq());

		// term3 and term4 deleted for selected docs:
		te = reader.terms(new Term("field1", "term3"));
		assertEquals(numdocs - docsel.size(), te.docFreq());
		te = reader.terms(new Term("field1", "term4"));
		assertEquals(numdocs - docsel.size(), te.docFreq());

		// new term for selected docs: val4
		te = reader.terms(new Term("field1", "val4"));
		assertEquals(docsel.size(), te.docFreq());

		// replace term
		te = reader.terms(new Term("field1", "term11"));
		assertEquals(replacedocs.size(), te.docFreq());
		
		// printTermEnum(reader.terms());
		// position
		// printTermPositions(reader.termPositions(new Term("field1","term1")));

		reader.close();

		dir.close();
	}

	public static void printTermEnum(TermEnum te) throws IOException {

		while (te.next()) {
			System.out.println("te: term :" + te.term() + " docFreq: "
					+ te.docFreq());
		}
	}

	public static void PrintTermEnum(Directory dir) throws IOException {
		IndexReader reader = IndexReader.open(dir);
		printTermEnum(reader.terms());
		reader.close();
	}

	public static void PrintAll(Directory dir) throws IOException {
		IndexReader reader = IndexReader.open(dir);
		printAll(reader.terms(), reader.termPositions());
		reader.close();
	}

	public static void printTermEnum(TermProducter producter)
			throws IOException {
		TermEnum te = producter.terms();
		printTermEnum(te);
	}

	public static void printAll(TermEnum te, TermPositions tp)
			throws IOException {

		while (te.next()) {
			System.out.println("Term: " + te.term() + ", docFreq: ");
			// + te.docFreq());
			tp.seek(te);
			printTermPositions(tp);
		}
		te.close();
		tp.close();
	}

	public static void printAll(TermProducter producter) throws IOException {
		TermEnum te = producter.terms();
		TermPositions tp = producter.termPositions();
		printAll(te, tp);
	}

	public static void printTermPositions(TermPositions tp) throws IOException {
		while (tp.next()) {
			System.out
					.println("  tp: doc :" + tp.doc() + " freq: " + tp.freq());
			for (int i = 0; i < tp.freq(); i++) {
				System.out.println("   pos:  " + tp.nextPosition());
			}
		}
	}

	public TermGenerator createVirtualIndex(int numdocs) throws IOException {
		// select some documents
		DocumentSelection docsel = new DocumentSelection(numdocs);
		docsel.selectAllDocs();
		
		TermAdder adder = new TermAdder();
		adder.addField(Field.UnStored("field1", "term1, term2, term3, term4, term2"),
				new StandardAnalyzer(), docsel);
		adder.addField(Field.UnStored("field2", "term5, term2, term2, term4, term2"),
				new StandardAnalyzer(), docsel);

		return adder;
	}

	public void createRealIndex(Directory dir, int numdocs) throws IOException {

		IndexReader.unlock(dir);

		IndexWriter writer = new IndexWriter(dir, new StandardAnalyzer(), true);
		writer.mergeFactor = 1000;
		writer.minMergeDocs = 1000;

		// important !
		writer.setUseCompoundFile(false);

		for (int i = 0; i < numdocs; i++) {
			Document doc = new Document();
			doc.add(Field.UnStored("field1", "term1, term2, term3, term4, term2"));
			doc.add(Field.UnStored("field2", "term5, term2, term2, term4, term2"));
			writer.addDocument(doc);
		}
		writer.optimize();
		writer.close();
		System.out.println("Indexing finished");

		// IndexReader reader=IndexReader.open(dir);
		// return new TermReader(reader);
	}

}
