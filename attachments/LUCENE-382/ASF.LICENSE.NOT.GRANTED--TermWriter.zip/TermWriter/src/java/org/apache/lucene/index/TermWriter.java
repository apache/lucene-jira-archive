/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.io.IOException;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.store.RAMOutputStream;

/**
 * 
 * Term Writer :  write the term's postings in the index
 * ( use several parts of code of the documentWriter class )
 *  TODO : support TermVector 
 * 
 * @author Nicolas Maisonneuve
 *
 */
public class TermWriter {
	private Directory dir;

	private IndexOutput freqOutput = null;

	private IndexOutput proxOutput = null;

	private TermInfosWriter termInfosWriter = null;

	private int termIndexInterval = IndexWriter.DEFAULT_TERM_INDEX_INTERVAL;

	private String segment;

	private final TermInfo termInfo = new TermInfo();

	private IndexReader reader;

	public TermWriter(IndexReader reader) throws IOException {
		this.reader = reader;
		this.dir = reader.directory();
		SegmentInfos infos = new SegmentInfos();
		infos.read(dir);

		// // check if optimized
		if (infos.size() > 1)
			throw new UnsupportedOperationException(
					" no optimized index no supported");

		segment = infos.info(0).name;

		// check if compoundFile or not
		if (dir.fileExists(segment+".cfs")) {
			// compoundfile = true;
			throw new UnsupportedOperationException(
					" Compound Index no supported , use IndexWriter.setUseCompoundFile(false) to index");
		}

	}

	public void write(TermProducter producter) throws IOException {

		String segmenttmp = segment + "tmp";
		freqOutput = dir.createOutput(segmenttmp + ".frq");
		proxOutput = dir.createOutput(segmenttmp + ".prx");
		FieldInfos fieldInfos = new FieldInfos(dir, segment + ".fnm");
		termInfosWriter = new TermInfosWriter(dir, segmenttmp, fieldInfos,
				IndexWriter.DEFAULT_TERM_INDEX_INTERVAL);

		TermEnum te = producter.terms();
		TermPositions tp = producter.termPositions();
		while (te.next()) {
			writeTerm(te, tp);
		}
		te.close();
		tp.close();

		if (freqOutput != null)
			freqOutput.close();
		if (proxOutput != null)
			proxOutput.close();
		if (termInfosWriter != null)
			termInfosWriter.close();

		reader.close();
		// if (!compoundfile) {
		replaceFile(".frq");
		replaceFile(".prx");
		replaceFile(".tii");
		replaceFile(".tis");
		// }else {//TODO}
		dir.close();
	}

	private void writeTerm(TermEnum termenum, TermPositions postings)
			throws IOException {

		long freqPointer = freqOutput.getFilePointer();
		long proxPointer = proxOutput.getFilePointer();

		postings.seek(termenum);

		int lastDoc = 0;
		int df = 0; // number of docs w/ term
		resetSkip();

		while (postings.next()) {
			int doc = postings.doc();

			df++;
			if ((df % termIndexInterval) == 0) {
				bufferSkip(lastDoc);
			}

			int docCode = (doc - lastDoc) << 1;
			lastDoc = doc;

			int freq = postings.freq();
			if (freq == 1) {
				freqOutput.writeVInt(docCode | 1); // write doc & freq=1
			} else {
				freqOutput.writeVInt(docCode); // write doc
				freqOutput.writeVInt(freq); // write frequency in doc
			}

			int lastPosition = 0; // write position deltas
			for (int j = 0; j < freq; j++) {
				int position = postings.nextPosition();
				proxOutput.writeVInt(position - lastPosition);
				lastPosition = position;
			}
		}

		long skipPointer = writeSkip();

		if (df > 0) {
			// add an entry to the dictionary with pointers to prox and freq
			// files
			termInfo.set(df, freqPointer, proxPointer,
					(int) (skipPointer - freqPointer));
			termInfosWriter.add(termenum.term(), termInfo);
		}

	}

	private void replaceFile(String suffix) throws IOException {
		System.out.println("replace " + segment + suffix + " exist: "
				+ dir.fileExists(segment + suffix));

		dir.deleteFile(segment + suffix);
		dir.renameFile(segment + "tmp" + suffix, segment + suffix);
	}

	private RAMOutputStream skipBuffer = new RAMOutputStream();

	private int lastSkipDoc;

	private long lastSkipFreqPointer;

	private long lastSkipProxPointer;

	private void resetSkip() throws IOException {
		skipBuffer.reset();
		lastSkipDoc = 0;
		lastSkipFreqPointer = freqOutput.getFilePointer();
		lastSkipProxPointer = proxOutput.getFilePointer();
	}

	private void bufferSkip(int doc) throws IOException {
		long freqPointer = freqOutput.getFilePointer();
		long proxPointer = proxOutput.getFilePointer();

		skipBuffer.writeVInt(doc - lastSkipDoc);
		skipBuffer.writeVInt((int) (freqPointer - lastSkipFreqPointer));
		skipBuffer.writeVInt((int) (proxPointer - lastSkipProxPointer));

		lastSkipDoc = doc;
		lastSkipFreqPointer = freqPointer;
		lastSkipProxPointer = proxPointer;
	}

	private long writeSkip() throws IOException {
		long skipPointer = freqOutput.getFilePointer();
		skipBuffer.writeTo(freqOutput);
		return skipPointer;
	}
}
