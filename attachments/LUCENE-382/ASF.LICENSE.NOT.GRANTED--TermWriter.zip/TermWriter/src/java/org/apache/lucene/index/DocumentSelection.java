/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.util.BitSet;

/**
 * A set of selected document number
 * 
 * @author Nicolas Maisonneuve
 */
public final class DocumentSelection {

	private BitSet seldocs;

	private boolean alldocs;

	private int numdocs;

	private int index = 0;

	private boolean first = true;

	DocumentSelection(int numdocs) {
		this.numdocs = numdocs;
	}

	public DocumentSelection copy() {
		DocumentSelection docsel = new DocumentSelection(numdocs);
		if (alldocs)
			docsel.selectAllDocs();
		else
			docsel.selectDocs(seldocs);
		return docsel;
	}

	/**
	 * is the document number selected
	 * 
	 * @param doc
	 * @return
	 */
	public final boolean isSelected(int doc) {
		if (alldocs)
			return true;
		else
			return seldocs.get(doc);
	}

	/**
	 * select a document
	 * 
	 * @param doc
	 *            the document's number
	 */
	public final void selectDoc(int doc) {
		if (seldocs == null) {
			seldocs = new BitSet(numdocs);
			alldocs = false;
		}
		seldocs.set(doc);
	}

	/**
	 * select several documents
	 * 
	 * @param docs
	 *            a bitset: - bitset index = document number - true/false value
	 *            for selected or not document;
	 */
	public final void selectDocs(BitSet docs) {
		if (seldocs == null) {
			seldocs = new BitSet(numdocs);
			alldocs = false;
		}
		seldocs.or(docs);
	}

	/**
	 * Select several documents
	 * 
	 * @param docs
	 *            a array with document's numbers
	 */
	public final void selectDocs(int[] docs) {
		if (seldocs == null) {
			seldocs = new BitSet(numdocs);
			alldocs = false;
		}
		for (int i = 0; i < docs.length; i++) {
			seldocs.set(docs[i]);
		}
	}

	/**
	 * the number of selected documents
	 * 
	 * @return
	 */
	public int size() {
		return seldocs.cardinality();
	}

	/**
	 * Are all the documents selected ?
	 * 
	 * @return
	 */
	public boolean allSelected() {
		return alldocs;
	}

	/**
	 * select all documents
	 */
	public final void selectAllDocs() {
		alldocs = true;
	}

	public void clear() {
		alldocs = false;
		if (seldocs != null) {
			seldocs.clear();
		}
	}

	/** *************************** ITERATION ******************************** */

	/**
	 * clear the iterator
	 */
	public void clearIterator() {
		first = true;
		index = 0;
	}

	/**
	 * has a next selected document number
	 * 
	 * @return
	 */
	public boolean next() {

		if (first) {
			index = seldocs.nextSetBit(index);
			first = false;
		} else {
			index = seldocs.nextSetBit(index + 1);
		}
		// System.out.println("next "+index);
		return index >= 0;
	}

	/**
	 * the actual document number
	 * 
	 * @return
	 */
	public int doc() {
		return index;
	}
}
