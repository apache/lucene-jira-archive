/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.io.IOException;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Field;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class TestIndexUpdater extends PrintableTermTest {

	String indexDir = "d:\\test";

	Directory dir;

	int numdocs = 1000000;

	public void testIndexUpdater() throws IOException {

		dir = FSDirectory.getDirectory(indexDir, false);
		// createRealIndex(dir);

		IndexReader reader = IndexReader.open(dir);
		System.out.println(" ---- BEFORE 1 ----------");
		printTermEnum(reader.terms());
		reader.close();
		//		
		long time = System.currentTimeMillis();
		updateProcess();
		time = System.currentTimeMillis() - time;
		System.out.println(" time: " + time);

		reader = IndexReader.open(dir);
		System.out.println(" ---- AFTER ----------");
		printTermEnum(reader.terms());
		reader.close();

		dir.close();
	}

	/**
	 * update just all doc except one
	 */
	private void updateProcess() throws IOException {
		IndexUpdater updater = new IndexUpdater(dir);

		// select all docs except the last 
		DocumentSelection docsel = updater.createDocSelection();
		for (int i = 0; i < numdocs -1; i++) {
			docsel.selectDoc(i);
		}

		TermAdder adder = new TermAdder();
		TermFilter freader = new TermFilter();
				
		// delete all the terms in this field linked with the document selection
		freader.deleteField("field", docsel);
		
		// add new terms and link them with the selected documents
		adder.addField(Field.Text("field", "  term2 term1 val4 term1 term2"), new StandardAnalyzer(),docsel);
		

		// exemple of possible schema: update process
		//		  
		//         |-<-AddTerm (add new terms)
		// <--MergeTerm
		//         |-<----filterTerm-----<-reader
		//		     (filter deletable terms)
		//
		TermMerger merger = new TermMerger();
		merger.addProducter(adder.createTermProducter());
		merger.addProducter(freader.transform(updater.getTermReader().createTermProducter()));
		
		// set the termproducter
		updater.setTermProducter(merger);
		
		// write and close 
		updater.close();

	}

}
