/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.index;

import java.io.IOException;

import junit.framework.TestCase;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.store.Directory;

public abstract class PrintableTermTest extends TestCase {

	Term[] terms = { new Term("field", "term1"), new Term("field", "term2"),
			new Term("field", "term3"), new Term("field", "term3") };

	public static void printTermEnum(TermEnum te) throws IOException {

		while (te.next()) {
			System.out.println("te: term :" + te.term() + " docFreq: "
					+ te.docFreq());
		}
	}

	public static void PrintTermEnum(Directory dir) throws IOException {
		IndexReader reader = IndexReader.open(dir);
		printTermEnum(reader.terms());
		reader.close();
	}

	public static void PrintAll(Directory dir) throws IOException {
		IndexReader reader = IndexReader.open(dir);
		printAll(reader.terms(), reader.termPositions());
		reader.close();
	}

	public static void printTermEnum(TermProducter producter)
			throws IOException {
		TermEnum te = producter.terms();
		printTermEnum(te);
	}

	public static void printAll(TermEnum te, TermPositions tp)
			throws IOException {

		while (te.next()) {
			System.out.println("Term: " + te.term() + ", docFreq: ");
			// + te.docFreq());
			tp.seek(te);
			printTermPositions(tp);
		}
		te.close();
		tp.close();
	}

	public static void printAll(TermProducter producter) throws IOException {
		TermEnum te = producter.terms();
		TermPositions tp = producter.termPositions();
		printAll(te, tp);
	}

	public static void printTermPositions(TermPositions tp) throws IOException {
		while (tp.next()) {
			System.out
					.println("  tp: doc :" + tp.doc() + " freq: " + tp.freq());
			for (int i = 0; i < tp.freq(); i++) {
				System.out.println("   pos:  " + tp.nextPosition());
			}
		}
	}
	
	public TermGenerator createVirtualIndex(int numdocs ) throws IOException {
		// select some documents
		DocumentSelection docsel= new DocumentSelection(numdocs);
		for (int i = 0; i < numdocs; i++) {
			docsel.selectDoc(i);		
		}
		TermAdder adder= new TermAdder();
		adder.addField(Field.Text("field","val val2 val3 val2 val3"),new StandardAnalyzer(), docsel);
		return adder;	
	}
	
	
	public TermGenerator createRealIndex(Directory dir, int numdocs ) throws IOException {
		// select some documents
		DocumentSelection docsel= new DocumentSelection(numdocs);
		docsel.selectDocs(new int[]{1,2,3, 4, 5});
		
		
		IndexWriter writer = new IndexWriter(dir, new StandardAnalyzer(), true);
		writer.mergeFactor = 1000;
		writer.minMergeDocs = 1000;
		
		//important !
		writer.setUseCompoundFile(false);
		
		for (int i = 0; i < numdocs; i++) {
			Document doc = new Document();
			doc.add(Field.Text("field", "term1, term2, term3, term4, term2"));
			doc.add(Field.Text("field2", "term5, term2, term2, term4, term2"));
			writer.addDocument(doc);
		}
		writer.optimize();
		writer.close();
		System.out.println("Indexing finished");
		
		IndexReader reader=IndexReader.open(dir);
		return new TermReader(reader);
	}
}
