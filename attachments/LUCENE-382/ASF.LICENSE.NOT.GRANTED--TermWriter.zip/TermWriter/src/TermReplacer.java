package org.apache.lucene.index;

import java.io.IOException;
import java.util.TreeMap;

public class TermReplacer implements TermProducter {

	final class ReplacedDocs {
		Term term;
		DocumentSelection docs;
		
		/**
		 * @return Returns the docs.
		 */
		public DocumentSelection getDocs() {
			return docs;
		}

		/**
		 * @param docs The docs to set.
		 */
		public void setDocs(DocumentSelection docs) {
			this.docs = docs;
		}

		/**
		 * @return Returns the term.
		 */
		public Term getTerm() {
			return term;
		}

		/**
		 * @param term The term to set.
		 */
		public void setTerm(Term term) {
			this.term = term;
		}

		ReplacedDocs(int numdocs) {
			docs=new DocumentSelection(numdocs);
		}

	}

	final class ReplacerTermEnum extends TermEnum {
		
		Term termBuffer= new Term("","");
		public void close() throws IOException {
			replacedTermEnum.close();
		}

		public int docFreq() {
			if (repdocs == null) {
				return replacedTermEnum.docFreq();
			} else {
				return (repdocs.getDocs().allSelected()) ? 0 : replacedTermEnum.docFreq()
						- repdocs.getDocs().size();
			}

		}

		private boolean filter(Term term) {

			boolean res;

			// check if term must be deleted
			repdocs = getReplacedDocs(term, false);
			if (repdocs == null) {
				// no , so check if the field must be deleted
				termBuffer.set(term.field, "");
				repdocs = getReplacedDocs(termBuffer, false);
				res = (repdocs == null) ? false : true;

			} else {
				res = true;
			}
			if (!res)
				return false;
			//

			if (docFreq() == 0) {
				System.out.println("thank freq for " + term);
				return true;
			} else
				return false;
		}

		public boolean next() throws IOException {
			do {
				if (!replacedTermEnum.next()) {
					return false;
				}
				term = replacedTermEnum.term();
			} while (filter(term));
			return true;
		}

		public Term term() {
			return term;
		}
	}

	final class FilterTermPositions implements TermPositions {

		public int nextPosition() throws IOException {

			return replacedTermPositions.nextPosition();
		}

		public int doc() {
			return replacedTermPositions.doc();
		}

		public int freq() {
			return replacedTermPositions.freq();
		}

		public int read(int[] arg0, int[] arg1) throws IOException {
			throw new UnsupportedOperationException();
		}

		public void seek(Term arg0) throws IOException {
			term = arg0;
			System.out.println("term " + arg0 + " passed!");
			replacedTermPositions.seek(term);

		}

		public void seek(TermEnum tenum) throws IOException {
			seek(tenum.term());

		}

		public boolean skipTo(int arg0) throws IOException {
			throw new UnsupportedOperationException();
		}

		public void close() throws IOException {
			replacedTermEnum.close();
		}

		public boolean next() throws IOException {
			do {
				if (!replacedTermPositions.next()) {
					return false;
				}
				if (repdocs == null)
					return true;

			} while (repdocs.getDocs().isSelected(replacedTermPositions.doc()));

			return true;
		}
	}

	private TreeMap replacemap = new TreeMap();

	private ReplacedDocs repdocs;

	private Term term;

	private int numDocs;

	private TermEnum replacedTermEnum;

	private TermPositions replacedTermPositions;
	
	/**
	 * get the ReplacedDocs object associated with the term
	 * 
	 * @param term
	 * @param create
	 *            if the term is no found , create it
	 * @return
	 */
	public final ReplacedDocs getReplacedDocs(Term term, boolean create) {
		ReplacedDocs replaceddocs = (ReplacedDocs) replacemap.get(term);
		if (replaceddocs == null && create) {
			replaceddocs = new ReplacedDocs(numDocs);
			replacemap.put(new Term(term.field, term.text, false),
					replaceddocs);
		}
		return replaceddocs;
	}
	
	public void replace(Term oldterm, Term newTerm) {
		ReplacedDocs rd=getReplacedDocs(oldterm,true);
		rd.setTerm(newTerm);
		rd.getDocs().selectAllDocs();
	}
	
	public void replace(Term oldterm, Term newTerm, int[] docs) {
		ReplacedDocs rd=getReplacedDocs(oldterm,true);
		rd.setTerm(newTerm);
		rd.getDocs().selectDocs(docs);
	}

}
