/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.solr.search.concordance;

import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.concordance.charoffsets.TargetTokenNotFoundException;
import org.apache.lucene.search.concordance.cooccur.ConcordanceCooccurConfig;
import org.apache.lucene.search.concordance.cooccur.ConcordanceCooccurSearcher;
import org.apache.lucene.search.concordance.cooccur.IDF;
import org.apache.lucene.search.concordance.cooccur.IDFCalc;
import org.apache.lucene.search.concordance.cooccur.NGramWeightedArrayWindowVisitor;
import org.apache.lucene.search.concordance.cooccur.TFIDFResult;
import org.apache.lucene.search.concordance.cooccur.TFIDFResults;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.MockTokenizer;
import org.apache.lucene.analysis.Tokenizer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.util.CharArraySet;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.AtomicReaderContext;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.RandomIndexWriter;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermContext;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.span.SpanQueryParser;
import org.apache.lucene.search.concordance.ConcordanceConfig;
import org.apache.lucene.search.concordance.ConcordanceResults;
import org.apache.lucene.search.concordance.ConcordanceSearcher;
import org.apache.lucene.search.concordance.ConcordanceSortOrder;
import org.apache.lucene.search.concordance.ConcordanceWindow;
import org.apache.lucene.search.concordance.DocumentMetadataExtractor;
import org.apache.lucene.search.spans.SpanMultiTermQueryWrapper;
import org.apache.lucene.search.spans.SpanQuery;
import org.apache.lucene.search.spans.SpanTermQuery;
import org.apache.lucene.search.spans.Spans;
import org.apache.lucene.store.Directory;
import org.apache.lucene.util.Bits;
import org.apache.lucene.util.Version;

import java.io.IOException;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.Stack;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.cloud.RequestThreads;
import org.apache.solr.cloud.RequestWorker;
import org.apache.solr.cloud.ZkController;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;
import org.apache.solr.common.params.CommonParams;
import org.apache.solr.common.params.ModifiableSolrParams;
import org.apache.solr.common.params.SolrParams;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.common.util.SimpleOrderedMap;
import org.apache.solr.core.SolrCore;
import org.apache.solr.handler.RequestHandlerBase;
import org.apache.solr.request.SolrQueryRequest;
import org.apache.solr.request.SolrRequestHandler;
import org.apache.solr.response.SolrQueryResponse;
import org.apache.solr.schema.IndexSchema;
import org.apache.solr.schema.SchemaField;
import org.apache.solr.search.SolrIndexSearcher;
import org.apache.solr.util.SolrPluginUtils;




/**
 <requestHandler name="/kwCooccur" class="org.apache.solr.handler.KeywordCooccurRankHandler">
		<lst name="defaults">
			<str name="echoParams">explicit</str>
			<str name="defType">spanquery</str>
			<str name="f">content_txt</str>
			<str name="df">content_txt</str>
			<str name="wt">xml</str>
			<str name="minNGram">1</str>
			<str name="maxNGram">2</str>
			<str name="minTF">3</str>
			<str name="numResults">50</str>
			
			<!--  More fields 
			<str name="maxWindows">500</str>
			<str name="debug">false</str>
			<str name="fl">metadata field1,metadata field2,metadata field3</str>
			<str name="targetOverlaps">true</str>
			<str name="contentDisplaySize">42</str>
			<str name="targetDisplaySize">42</str>
			<str name="tokensAfter">42</str>
			<str name="tokensBefore">42</str>
			<str name="sortOrder">TARGET_PRE</str>
			-->
		</lst>
		<lst name="invariants">
			<str name="prop1">value1</str>
			<int name="prop2">2</int>
			<!-- ... more config items here ... -->
		</lst>
	</requestHandler>
 * @author JRROBINSON
 *
 */

public class KeywordCooccurRankHandler extends SolrConcordanceBase
{

	public static final String DefaultName = "/kwCo";
	
	public static final String NODE = "contextKeywords";
	
	@Override public void init(@SuppressWarnings("rawtypes") NamedList args)
	
	{
		super.init(args);
		// this.prop1 = invariants.get("prop1");
	};

	@Override public String getDescription()
	{
		return "Returns tokens that frequently co-occur within cocordance windows";
	}


	@SuppressWarnings("unchecked")
	@Override public void handleRequestBody(SolrQueryRequest req, SolrQueryResponse rsp) throws Exception
	{
		
		boolean isDistrib = isDistributed(req);

		if(isDistrib)
			doZooQuery(req, rsp);
		else
			doQuery(req, rsp);
	}
	
	@SuppressWarnings("unchecked")
	private void doZooQuery(SolrQueryRequest req, SolrQueryResponse rsp) throws SolrServerException, Exception
	{
		SolrParams params = req.getParams();
		String field = getField(params);
		ConcordanceCooccurConfig config = configureParams(field, params);
	
		
		boolean debug =  params.getBool("debug", false);
		NamedList nlDebug = new SimpleOrderedMap();
		
		
		if(debug)
			rsp.add("DEBUG", nlDebug);

		ZkController zoo = req.getCore().getCoreDescriptor().getCoreContainer().getZkController();
		Set<String> nodes = zoo.getClusterState().getLiveNodes();
		
		
		/*
		String q = params.get(CommonParams.Q);
		String handler = getHandlerName(req);
		
		//TODO: this still needs a lot of fine tuning
		//problems:
		//1. it could double count replicated data
		//2. if lots of nodes are returned, this could blow up because it tries to allocate too many threads
		final int MAX_THREADS = 25;
		//3. it executes all threads, even though 1 or 2 threads might return sufficient results
		//		it might be smarter to kick off a few workers, and then collect data and kick off new workers each iteration
		
		
		ExecutorService executor = Executors.newFixedThreadPool(Math.min(nodes.size(), MAX_THREADS));
		
		Stack<RequestWorker> workers = new Stack<RequestWorker>();
		
		//TODO: make this a param?  if content on each node is not about the same size, may not make max when we could
		// if each node has very different types of data, we might want an even distribution
		int partial = (nodes.size() > 1) ?  Math.round(config.getMaxWindows() / (float)nodes.size()) : config.getMaxWindows();
		
		
		ModifiableSolrParams p = getWorkerParams(field, q, params, partial);
		for(String node : nodes)
		{
			String url = "http://" + node.replace("_", "/")  + "/" + req.getCore().getName();
			if(debug)
			{
				nlDebug.add("node", node);
				nlDebug.add("handler", handler);
				nlDebug.add("zkAddy",  node.replace("_", "/"));
				nlDebug.add("url", url);
				nlDebug.add("f", field);
				nlDebug.add("q", q);
	
			}
			
			RequestWorker worker = new RequestWorker(url, handler, p).setName(node);
			workers.add(worker);
			
			executor.execute(worker);

		}
		executor.shutdown();
		
		
		Results results = new Results(config.getMaxWindows(), config.getNumResults());
		
		//collect results while the threads are running
		while(!executor.isTerminated() && !workers.empty()  && !results.hitMax)
		{
			RequestWorker worker = workers.peek();
			if(!worker.isRunning())
			{
				NamedList nl = worker.getResults();
				if(nl != null)
				{
					//String tag = (debug) ? worker.getName() : null;
					results.add(nl, worker.getName());
					workers.pop();
				}
			}
		}
		
		executor.shutdownNow();
		
		//if not enough hits, check any remaining threads that haven't been collected
		for(RequestWorker worker : workers)
		{
			if(results.hitMax) break;
			
			if( worker != null && !worker.isRunning() )
			{
				NamedList nl = worker.getResults();
				if(nl != null)
				{
					//String tag = (debug) ? worker.getName() : null;
					results.add(nl, worker.getName());
				}
			}
		}
		*/
		
		List<String> shards = new ArrayList<String>(nodes.size());
		String thisUrl = req.getCore().getCoreDescriptor().getCoreContainer().getZkController().getBaseUrl();
		
		for(String node : nodes)
		{
			String shard = node.replace("_", "/");
			if(thisUrl.contains(shard))
				continue;
			
			shard += "/" + req.getCore().getName();
			
			shards.add(shard);
		}
		
		RequestThreads<ConcordanceCooccurConfig> threads = initRequestPump(shards, req); 
		
		Results results = new Results(threads.getMetadata());
		
		
		NamedList nl = doLocalSearch(req);
		results.add(nl, "local");
		
		results = spinWait(threads, results);
		
		rsp.add(NODE, results.toNamedList());
		
	}

	
	/**
	 * Max number of request threads to spawn.  Since this service wasn't intended to return 
	 * ALL possible results, it seems reasonable to cap this at something
	 */
	public final static int MAX_THREADS = 25;
	static public RequestThreads<ConcordanceCooccurConfig> initRequestPump(List<String> shards, SolrQueryRequest req)
	{
		return initRequestPump(shards, req, MAX_THREADS);
	}
	static public RequestThreads<ConcordanceCooccurConfig> initRequestPump(List<String> shards, SolrQueryRequest req, int maxThreads)
	{
		SolrParams params = req.getParams();
		String field = SolrConcordanceBase.getField(params);
		String q = params.get(CommonParams.Q);
		ConcordanceCooccurConfig config = configureParams(field, params);
		
		/**/
		RequestThreads<ConcordanceCooccurConfig> threads =  RequestThreads.<ConcordanceCooccurConfig>newFixedThreadPool(Math.min(shards.size(), maxThreads))
															.setMetadata(config);
		
		String handler = getHandlerName(req, DefaultName, KeywordCooccurRankHandler.class);
		int partial = Math.round(config.getMaxWindows() / (float)shards.size()) ;
		
		ModifiableSolrParams p = getWorkerParams(field, q, params, partial);
		
		int i=0;
		for(String node : shards)
		{
			if(i++ > maxThreads)
				break;
			
			//could be https, no?
			String url = "http://" + node;
			
			RequestWorker worker = new RequestWorker(url, handler, p).setName(node);
			threads.addExecute(worker);
		}
		threads.seal();	//disallow future requests (& execute
	
		return threads;
	}
	public static NamedList doLocalSearch(SolrQueryRequest req) throws Exception
	{
		return doLocalSearch(null, req);
	}
	
	//xx
	public static NamedList doLocalSearch(Query filter, SolrQueryRequest req) throws Exception
	{
		SolrParams params = req.getParams();
		String field = getField(params);
		
		

		String fl = params.get(CommonParams.FL);
		SimpleMetadataExtractor metadataExtractor = (fl != null && fl.length() > 0) ? new SimpleMetadataExtractor(fl.split(",")) : new SimpleMetadataExtractor();

		
	
		ConcordanceCooccurConfig config = configureParams(field, params);
		
		IndexSchema schema = req.getSchema();
		SchemaField sf = schema.getField(field);
		Analyzer analyzer = sf.getType().getAnalyzer();
		Filter queryFilter = getFilterQuery( req );
		
		
		SpanQuery query = null;
		String q = params.get(CommonParams.Q);
		SpanQueryParser parser = new SpanQueryParser(field, analyzer);
		//TODO: Is it good Solr to hardcode the queryparser into the response object?
		//Or, do you get the parser from the request?
			
		try
		{
				//SpanQueryParser sqp = new SpanQueryParser(field, analyzer)
			query = parser.parse( q );
		} catch (ParseException e)
		{
				// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		SolrIndexSearcher solr = req.getSearcher();
		IndexReader reader = solr.getIndexReader();
		
		IDF idfer = new IDF(reader);
		NGramWeightedArrayWindowVisitor visitor = new NGramWeightedArrayWindowVisitor(config, idfer);

		try
		{
			ConcordanceCooccurSearcher searcher = new ConcordanceCooccurSearcher();
			searcher.search(reader, query, queryFilter, analyzer, config, visitor);
		} catch (IllegalArgumentException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (TargetTokenNotFoundException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		TFIDFResults overallResults = visitor.getResults();
		NamedList results = toNamedList(overallResults);
		results.add("numDocsVisited", visitor.getNumDocsVisited());
		results.add("numWindowsVisited", visitor.getNumWindowsVisited());

	
		return results;
	}
	
	
	
	public static class Results
	{
		int maxWindows = -1;
		int maxResults = -1;
		
		Results(ConcordanceCooccurConfig config)
		{
			this.maxWindows = config.getMaxWindows();
			this.maxResults = config.getNumResults();
		}
		Results(int maxWindows, int maxResults)
		{
			this.maxWindows = maxWindows;
			this.maxResults = maxResults;
		}
		
		boolean hitMax=false;
		boolean maxTerms=false;
		int size=0;
		int numDocs=0;
		int numWindows=0;
		int numResults=0;
	
		HashMap<String, Keyword> keywords = new HashMap<String, Keyword>();
		
		void add(NamedList nl, String extra)
		{
			NamedList nlRS = (NamedList)nl.get( NODE );
			
			if(nlRS == null)
				nlRS = nl;
			
			
			numDocs += getInt("numDocs", nlRS);
			size += getInt("collectionSize", nlRS);			
			numResults += getInt("numResults", nlRS);			
			numWindows += getInt("numWindows", nlRS);			
			
			hitMax = numWindows >= maxWindows;
			maxTerms = numResults >= maxResults;
			
			Object o = nlRS.get("results");
			if(o != null)
			{
				NamedList nlRes = (NamedList)o;
				
				List<NamedList> res = nlRes.getAll("result");
				
				for(NamedList nlTerm : res)
				{
					Keyword tmp = new Keyword(nlTerm);
					
					Keyword kw = keywords.get(tmp.term);
					
					if(kw == null)
						keywords.put(tmp.term, tmp);
					else
					{
						kw.tf += tmp.tf;
						kw.df += tmp.df;
						kw.minDF += tmp.minDF;
					}
				}
			}
		}
		
		
		
		NamedList toNamedList()
		{
			NamedList nl = new SimpleOrderedMap<>();
			nl.add("hitMax",hitMax );
			nl.add("maxTerms",maxTerms );
			nl.add("numDocs", numDocs);
			nl.add("collectionSize", size);
			nl.add("numWindows", numWindows);
			nl.add("numResults", numResults);
			
			if(keywords.size() > 0)
			{
				
				//sort by new tf-idf's
				Integer[] idxs = new Integer[keywords.size()];
				final double[] tfidfs = new double[keywords.size()];
				final Keyword[] terms = new Keyword[keywords.size()];
				
				int i = 0;
				for(Entry<String, Keyword> kv : keywords.entrySet())
				{
					idxs[i] = i;
					Keyword kw = kv.getValue();
					terms[i] = kw;
					
					tfidfs[i] = kw.tf * Math.log(size / kw.df);
					i++;
				}
				
				//System.out.println(terms);
				//System.out.println(Arrays.toString(terms));
				//System.out.println(tfidfs);
				//System.out.println(Arrays.toString(tfidfs));
				
				Arrays.sort(idxs,new Comparator<Integer>() 
				    	{    
				        	public int compare(Integer a, Integer b)
				        	{ 
				            	int ret = Double.compare(tfidfs[b], tfidfs[a]);
				            	if(ret == 0)
				            		ret = Double.compare(terms[b].df, terms[a].df);
				            	return ret;
				            		
				        	}
				     	}); 
				
				NamedList<NamedList> nlResults = new SimpleOrderedMap<NamedList>();
				for(i=0; i < idxs.length && i < maxResults; i++)
				{
					Keyword kw = terms[idxs[i]];
					NamedList nlKw = new SimpleOrderedMap<Object>();
					
					nlKw.add("term", kw.term);
					nlKw.add("tfidf", tfidfs[idxs[i]]);
					nlKw.add("orig_tfidf", kw.tfidf);
					nlKw.add("tf", kw.tf);
					nlKw.add("df", kw.df);
					nlKw.add("minDF", kw.minDF);
					
					nlResults.add("result", nlKw);
				}
				nl.add("results", nlResults);
			}
			return nl;
		}
	}
	
	
	static class Keyword
	{
		 String term;
		 double tfidf = 0;
		 int tf=0;
		 int df=0;
		 int minDF=0;
		 
		 
		 Keyword(NamedList nl)
		 {
			term = nl.get("term").toString();
			tf = getInt("tf", nl);
			df = getInt("df", nl);
			minDF = getInt("minDF", nl);
			tfidf = getDouble("tfidf", nl);
		 }
		
		@Override public String toString() { return term;}

	}

	private void doQuery(SolrQueryRequest req, SolrQueryResponse rsp) throws Exception, IllegalArgumentException, ParseException, TargetTokenNotFoundException
	{
		NamedList results = doLocalSearch(req);
		rsp.add(NODE, results);
	}
	
	public static ModifiableSolrParams getWorkerParams(String field, String q, SolrParams parent, Integer maxWindows)
	{
		ModifiableSolrParams params = new ModifiableSolrParams();
		
		params.set("f", field);
		params.set("q", q);
		params.set("maxWindows", maxWindows);
		params.set("lq", true); //flag to disallow recursive zoo queries
		params.set("rows", 0);
		setParam("fq", params, parent);
		setParam("anType", params, parent);
		setParam("numResults", params, parent);
		setParam("minNGram", params, parent);
		setParam("maxNGram", params, parent);
		setParam("minTF", params, parent);
		setParam("minDF", params, parent);
		
		setParam("echoParams", params, parent);
		setParam("defType", params, parent);
		setParam("wt", params, parent);
		setParam("debug", params, parent);
		setParam("fl", params, parent);
		setParam("targetOverlaps", params, parent);
		setParam("contentDisplaySize", params, parent);
		setParam("targetDisplaySize", params, parent);
		setParam("tokensAfter", params, parent);
		setParam("tokensBefore", params, parent);
		setParam("sortOrder", params, parent);
		
		return params;
	}
	
	public static Results spinWait(RequestThreads<ConcordanceCooccurConfig> threads)
	{
		Results results = new Results(threads.getMetadata());
		return spinWait(threads, results);
	}
	public static Results spinWait(RequestThreads<ConcordanceCooccurConfig> threads, Results results)
	{
		if(threads == null || threads.empty())
			return results;
		
		while(!threads.isTerminated() && !threads.empty()  && !results.hitMax)
		{
			RequestWorker req = threads.next();
			if(!req.isRunning())
			{
				NamedList nl = req.getResults();
				if(nl != null)
				{
					results.add(nl, req.getName());
				}
				threads.removeLast();
			}
		}
		
		//force complete shutdown
		threads.shutdownNow();
		
		//if not enough hits, check any remaining threads that haven't been collected
		//for(RequestWorker req : otherRequests)
		while(!threads.empty() && !results.hitMax)
		{
			
			RequestWorker req = threads.next();
			
			if( req != null && !req.isRunning() )
			{
				NamedList nl = req.getResults();
				if(nl != null)
				{
					results.add(nl, req.getName());
				}
				
				threads.removeLast();
			}
		}
		
		
		threads.clear();
		threads = null;
		
		return results;
	};
	
	/*
	static String getHandlerName( SolrCore core)
	{
		//I'd be just as happy stripping this off the url if I could figure out how...
		SolrRequestHandler handler = core.getRequestHandler(DefaultName);
		
		if(handler == null)
		{
			for(Entry<String, ? extends KeywordCooccurRankHandler> kv : core.getRequestHandlers(KeywordCooccurRankHandler.class).entrySet())
				return kv.getKey();
		}
		else
			return DefaultName;
		
		return null;
	}
	static String getHandlerName( SolrQueryRequest req)
	{
		return getHandlerName(req.getCore());
	}
*/
	
	@Override protected String getHandlerName(SolrQueryRequest req) 
	{
		return getHandlerName(req, DefaultName, this.getClass());
	};
	
	
	public static ConcordanceCooccurConfig configureParams(String field, SolrParams params)
	{
		ConcordanceCooccurConfig config = new ConcordanceCooccurConfig( field );
		String param = params.get("targetOverlaps");
		if(param != null && param.length() > 0)
		{
			try { config.setAllowTargetOverlaps(Boolean.parseBoolean(param));} catch(Exception e){}
		}
		param = params.get("contentDisplaySize");
		if(param != null && param.length() > 0)
		{
			try { config.setMaxContextDisplaySizeChars(Integer.parseInt(param));} catch(Exception e){}
		}		
		param = params.get("targetDisplaySize");
		if(param != null && param.length() > 0)
		{
			try { config.setMaxTargetDisplaySizeChars(Integer.parseInt(param));} catch(Exception e){}
		}
		param = params.get("maxWindows");
		if(param != null && param.length() > 0)
		{
			try { config.setMaxWindows(Integer.parseInt(param));} catch(Exception e){}
		}
		param = params.get("tokensAfter");
		if(param != null && param.length() > 0)
		{
			try { config.setTokensAfter(Integer.parseInt(param));} catch(Exception e){}
		}
		param = params.get("tokensBefore");
		if(param != null && param.length() > 0)
		{
			try { config.setTokensBefore(Integer.parseInt(param));} catch(Exception e){}
		}
		param = params.get("sortOrder");
		if(param != null && param.length() > 0)
		{
			try { config.setSortOrder( ConcordanceSortOrder.valueOf(param));} catch(Exception e){}
		}
		
		param = params.get("minNGram");
		if(param != null && param.length() > 0)
		{
			try { config.setMinNGram(Integer.parseInt(param));} catch(Exception e){}
		}
		param = params.get("maxNGram");
		if(param != null && param.length() > 0)
		{
			try { config.setMaxNGram(Integer.parseInt(param));} catch(Exception e){}
		}
		param = params.get("minTF");
		if(param != null && param.length() > 0)
		{
			try { config.setMinTermFreq(Integer.parseInt(param));} catch(Exception e){}
		}
		param = params.get("tokensBefore");
		if(param != null && param.length() > 0)
		{
			try { config.setTokensBefore(Integer.parseInt(param));} catch(Exception e){}
		}
		param = params.get("tokensAfter");
		if(param != null && param.length() > 0)
		{
			try { config.setTokensAfter(Integer.parseInt(param));} catch(Exception e){}
		}
		param = params.get("numResults");
		if(param != null && param.length() > 0)
		{
			try { config.setNumResults(Integer.parseInt(param));} catch(Exception e){}
		}
		
		
		return config;
	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static NamedList toNamedList(TFIDFResults results)
	{
		SimpleOrderedMap ret = new SimpleOrderedMap();
		
		ret.add("collectionSize", results.getTotalDocs());
		ret.add("numDocs", results.getNumDocs());
		ret.add("numWindows", results.getWindows());
		
		List<TFIDFResult> list = results.getResults();
		ret.add("numResults", list.size());
		
		if(list.size() > 0)
		{
			NamedList nlResults = new SimpleOrderedMap();
			ret.add("results", nlResults);
			
			for(TFIDFResult result : list)
			{
				NamedList nl = new SimpleOrderedMap();
				nl.add("term", result.getTerm());
				//nl.add("value", result.getValue());
				nl.add("tfidf", result.getTFIDF());
				nl.add("tf", result.getTF());
				nl.add("idf", result.getIDF());
				
				if(result.getDF() != null)
					nl.add("df", result.getDF());
				
				if(result.getMinDF() != null)
					nl.add("minDF", result.getMinDF());
				
				nlResults.add("result", nl);
			}
		}
		
		return ret;
	}


	public static String getField( SolrParams params )
	{
		String fieldName = params.get(CommonParams.FIELD);
		if(fieldName == null || fieldName.equalsIgnoreCase("null"))
		{

			if(fieldName == null || fieldName.equalsIgnoreCase("null"))
				fieldName = params.get(CommonParams.DF);

			if(fieldName == null || fieldName.equalsIgnoreCase("null"))
			{
				//check field list if not in field
				fieldName = params.get(CommonParams.FL);

				//TODO: change when/if request allows for multiple terms
				if(fieldName != null)
					fieldName = fieldName.split(",")[0].trim();
			}

		}
		return fieldName;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public String getSource()
	{
		// TODO Auto-generated method stub
		return null;
	}

}
