/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.solr.search;

import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.core.StopFilterFactory;
import org.apache.lucene.analysis.util.CharArraySet;
import org.apache.lucene.analysis.util.TokenFilterFactory;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.span.SpanQueryParser;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.spans.SpanQuery;
import org.apache.lucene.util.Version;
import org.apache.solr.analysis.TokenizerChain;
import org.apache.solr.common.params.CommonParams;
import org.apache.solr.common.params.SolrParams;
import org.apache.solr.request.SolrQueryRequest;
import org.apache.solr.schema.IndexSchema;
import org.apache.solr.schema.SchemaField;

/**
 * 
  		Regex term queries: /ch[aeiou]rl[aeiou]+/
		Directional phrasal queries with slop:
			[charlie foxtrot]~>10
		Recursive:
			[charlie~0.6 foxtr* (snafu oops doh)]~10
			[[charl* foxtr*]~10 snafu]~>15
		SpanNotNear queries:
			[[charl* foxtr*]~10 snafu]!~15,15
		
		Allows use of analyzer for normalization (crucial for Unicode variants!!!):
			theÃ¢* is normalized before the search so that it will match â€œtheatreâ€� and â€œtheÃ¢treâ€�
		
		Limitations:
			One field
			No range queries
			No boolean â€œandâ€� (aside from phrasal searches)
			
			
			http://scufl.mitre.org:8983/solr/scufl/select?q=[%D8%A7%D9%84%D8%B5%D8%A7%D8%AF%D9%82]~2&wt=xml&indent=true&defType=spanquery&f=content_txt 

 * @author JRROBINSON
 *
 */
public class SpanQParser extends QParser
{

	private SpanQueryParser parser;
	private String fieldName;		
	
	
	public SpanQParser(String qstr, SolrParams local, SolrParams params, SolrQueryRequest req)
	{
		super(qstr, local, params, req);
		

		//initialize the parser
		Analyzer analyzer = null;
		
		IndexSchema schema = req.getSchema();
		fieldName = getField();
		
		SchemaField sf = schema.getField(fieldName);
		if(sf != null && sf.getType() != null)
			analyzer = sf.getType().getAnalyzer();
		else
			analyzer = schema.getAnalyzer();	//default analyzer?
		
		
		CharArraySet stopWords = getStopWords(analyzer);
		
		
		parser = new SpanQueryParser(fieldName, analyzer);
	}

	@Override public Query parse() throws SyntaxError
	{
		SpanQuery query = null;
		try
		{
			String qstr = getString();
			
			query = parser.parse(qstr);
			
			
		} catch (ParseException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new SyntaxError(e.toString());
		}
		
		
		return query;
	}


	static private CharArraySet getStopWords(Analyzer analyzer)
	{
		CharArraySet stopWords = CharArraySet.EMPTY_SET;
		if(analyzer instanceof TokenizerChain )
		{
			final TokenFilterFactory[] factories = ((TokenizerChain) analyzer).getTokenFilterFactories();
			for( TokenFilterFactory f : factories )
			{
				if(f instanceof StopFilterFactory)
				{
					stopWords = ((StopFilterFactory)f).getStopWords();
					
					//TODO: allow multiple sets of stopwords?
					break;
				}
			}
		}
		return stopWords;
	}



	private String getField()
	{
		String fieldName = getParam(CommonParams.FIELD);
		if(fieldName == null || fieldName.equalsIgnoreCase("null"))
		{
			
			if(fieldName == null || fieldName.equalsIgnoreCase("null"))
				fieldName = getParam(CommonParams.DF);
			
			if(fieldName == null || fieldName.equalsIgnoreCase("null"))
			{
				//check field list if not in field
				fieldName = getParam(CommonParams.FL);
				
				//TODO: change when/if parser allows for multiple terms
				if(fieldName != null)
					fieldName = fieldName.split(",")[0].trim();
			}

		}
		return fieldName;
	}




	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
	
		
		System.out.println("Done!");

	}

}
