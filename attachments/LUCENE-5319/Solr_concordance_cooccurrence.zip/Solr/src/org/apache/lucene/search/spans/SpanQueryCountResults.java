/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.search.spans;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class SpanQueryCountResults {
	
	private final Map<String, Integer> freqs;
	private Map<String, Integer> docCounts = new HashMap<String, Integer>();
	private int totalDocs = 0;
	private int totalFreq = 0;
	
	public void addDocumentCounts(Map<String, Integer> newDocCounts){
		int tokenCount = 0;
		for (Map.Entry<String, Integer> entry : newDocCounts.entrySet()){
			String key = entry.getKey();
			Integer i = entry.getValue();
			Integer old = docCounts.get(key);
			old = (old == null) ? new Integer(0) : old;
			old += 1;
			docCounts.put(key, old);
			
			old = freqs.get(key);
			old = (old == null) ? new Integer(0) : old;
			old += i;
			freqs.put(key, old);
			tokenCount += i.intValue();
		}
		totalDocs++;
		totalFreq += tokenCount;
	}
	
	public SpanQueryCountResults() {
		freqs = new HashMap<String, Integer>();
	}
	public SpanQueryCountResults( Map<String, Integer> tfs) {
		freqs = tfs;
	}
	
	public SpanQueryCountResults setDocumentCounts(Map<String, Integer> docCounts){
		this.docCounts = docCounts;
		return this;
	}
	public List<SpanQueryCountResult> getTopN(int n){
		//System.out.println("TOPN:");
		List<SpanQueryCountResult> list = new ArrayList<SpanQueryCountResult>();

		for (Map.Entry<String, Integer> entry : docCounts.entrySet()){
		
			String key = entry.getKey();
			Integer docInt = entry.getValue();
			int docCount = docInt.intValue();
			Integer freqInt = freqs.get(key);
			int freq = (freqInt == null) ? 0 : freqInt.intValue();
			list.add(new SpanQueryCountResult(key, freq, docCount));
		}
//		System.out.println("LIST: " + list.size());
		Collections.sort(list);
		for (int i = list.size()-1; i >= n; i--){
			list.remove(i);
		}
		return list;
	}
	public int getDocFreq(){
		return totalDocs;
	}
	public int getTotalFreq(){
		return totalFreq;
	}
	public int getUniqTerms(){
		return docCounts.size();
	}
	
	public String toString(){
		return "TotalDocs: " + totalDocs + " : " + totalFreq;
	}
}
