/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance;

import java.util.Map;

/**
 * Key element in a concordance view of data.
 * A window consists of the words before a target term (pre), the target term and then the words 
 * after the target term (post).  A window also has a sort key to allow for various methods
 * of sorting.
 * 
 * For various applications, it has also been useful to store the (admittedly ephemeral) 
 * Lucene document id, character offset (start and end) of the full window 
 * as well as metadata from the document for the given window.
 * 
 * This class is experimental and may change in incompatible ways in the future.
 * 
 * Areas for improvement:
 * 1) convert sortKey to an array of Comparables
 * 2) ...
 */
public class ConcordanceWindow{


   private final String sortKey;
	private final String pre;
	private final String target;
	private final String post;
	private final Map<String, String> metadata;
	private final int charStart;
	private final int charEnd;
	private final long docID;

	public ConcordanceWindow(long docID, int charStart, int charEnd, 
	      String pre, String target, String post, String sortKey, Map<String, String> metadata){
		this.pre = pre;
		this.target = target;
		this.post = post;
		this.docID = docID;
		this.charStart = charStart;
		this.charEnd = charEnd;
		this.metadata = metadata;
		this.sortKey = sortKey;
	}
	public long getDocID(){
		return docID;
	}
	
	public int getStart(){
		return charStart;
	}
	public int getEnd(){
	   return charEnd;
	}
	public Map<String, String> getMetadata(){
		return metadata;
	}
	
	  public String getPre(){
	      return pre;
	   }
	   public String getPost(){
	      return post;
	   }
	   public String getTarget(){
	      return target;
	   }
	   public int getSize(){
	      int size = 0;
	      if (pre != null){
	         size += pre.length();
	      }
	      if (target != null){
	         size += target.length();
	      }
	      if (post != null){
	         size += post.length();
	      }
	      return size;
	   }
	public String getSortKey(){
		return sortKey;
	}
	
	public String toString(){
		//this assumes left to right language
		StringBuilder sb = new StringBuilder();
		sb.append(pre).append(":").append(target).append(":").append(post);
		return sb.toString();
	}
	
	  @Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		result = prime * result + charEnd;
		result = prime * result + charStart;
		result = prime * result + (int) (docID ^ (docID >>> 32));
		result = prime * result + ((metadata == null) ? 0 : metadata.hashCode());
		result = prime * result + ((post == null) ? 0 : post.hashCode());
		result = prime * result + ((pre == null) ? 0 : pre.hashCode());
		result = prime * result + ((sortKey == null) ? 0 : sortKey.hashCode());
		result = prime * result + ((target == null) ? 0 : target.hashCode());
		return result;
	}
	  
	   @Override
	public boolean equals(Object obj)
	{
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ConcordanceWindow other = (ConcordanceWindow) obj;
		if (charEnd != other.charEnd)
			return false;
		if (charStart != other.charStart)
			return false;
		if (docID != other.docID)
			return false;
		if (metadata == null)
		{
			if (other.metadata != null)
				return false;
		} else if (!metadata.equals(other.metadata))
			return false;
		if (post == null)
		{
			if (other.post != null)
				return false;
		} else if (!post.equals(other.post))
			return false;
		if (pre == null)
		{
			if (other.pre != null)
				return false;
		} else if (!pre.equals(other.pre))
			return false;
		if (sortKey == null)
		{
			if (other.sortKey != null)
				return false;
		} else if (!sortKey.equals(other.sortKey))
			return false;
		if (target == null)
		{
			if (other.target != null)
				return false;
		} else if (!target.equals(other.target))
			return false;
		return true;
	}

}
