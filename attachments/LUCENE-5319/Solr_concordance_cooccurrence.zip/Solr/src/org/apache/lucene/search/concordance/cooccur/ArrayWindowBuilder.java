/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.cooccur;

import org.apache.lucene.search.concordance.charoffsets.TargetTokenNotFoundException;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetResults;

/**
 * builds an ArrayWindow
 *
 */

public class ArrayWindowBuilder {

   public static ConcordanceArrayWindow buildWindow(int targetStartOffset, int targetEndOffset,
         int tokensBefore, int tokensAfter,
         TokenCharOffsetResults offsetResults, ConcordanceArrayWindow window) throws TargetTokenNotFoundException {
      int startIndexField = offsetResults.getFieldIndex(targetStartOffset);
      int endIndexField =  offsetResults.getFieldIndex(targetEndOffset);
      
      if (startIndexField < 0 || endIndexField < 0){
         throw new TargetTokenNotFoundException("couldn't find character offsets for a target token.\n"+
         "Check that your analyzers are configured properly.\n");
      }
      
      if (tokensBefore > 0){
         int start = targetStartOffset-tokensBefore;
         start = (start < 0) ? 0 : start;
         int end = targetStartOffset;
         for (int i = start; i < end; i++){
            if (offsetResults.getFieldIndex(i) == startIndexField){
               String t = offsetResults.getTerm(i);
               
               if (t.equals(TokenCharOffsetResults.NULL_TERM)){
                  window.addPreStop();
               } else {
                  window.addPre(t);
               }
            }
         }
      }
      if (tokensAfter > 0){
         //get the terms after the target
         int start = targetEndOffset+1;
         //you don't have to worry about getting tokens beyond the window if you
         //use results.getLast()!!!
         int end = start+tokensAfter;

         for (int i = start; i < end && i <= offsetResults.getLast(); i++){
            if (offsetResults.getFieldIndex(i) == endIndexField){
               String t = offsetResults.getTerm(i);
               
               if (t.equals(TokenCharOffsetResults.NULL_TERM)){
                  window.addPostStop();
               } else {
                  window.addPost(t);
               }
            } else if (offsetResults.getFieldIndex(i) > endIndexField) {
               break;
            }
         }
      }
      return window;

   }

}
