/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.search.spans;



public class SpanQueryCountResult implements Comparable<SpanQueryCountResult> {
	public final String term;
	public final int docFreq;
	public final int termFreq;
	
	public SpanQueryCountResult(String term, int termFreq, int docFreq){
		this.term = term;
		this.termFreq = termFreq;
		this.docFreq = docFreq;
	}
	public String getTerm(){
		return term;
	}

	public int getDocFreq(){
		return docFreq;
	}
	public int getTermFreq(){
		return termFreq;
	}
	@Override
	public int compareTo(SpanQueryCountResult other) {
		if (docFreq < other.getDocFreq()){
			return 1;
		} else if (docFreq > other.getDocFreq()){
			return -1;
		}
		if (termFreq < other.getTermFreq()){
			return 1;
		} else if (termFreq > other.getTermFreq()){
			return -1;
		}
		return term.compareTo(other.getTerm());
	}
	
	@Override
	public boolean equals(Object obj){
		if (obj instanceof SpanQueryCountResult){
			SpanQueryCountResult other = (SpanQueryCountResult)obj;
			if (term.equals(other.getTerm()) &&
					docFreq == other.getDocFreq() &&
					termFreq == other.getTermFreq())
				return true;
		}
		return false;
	}
	
	@Override
	public int hashCode(){
		int result = 17;
		result = 31*docFreq+result;
		result = 31*termFreq+result;
		result = 31*term.hashCode()+result;
		return result;
	}
}
