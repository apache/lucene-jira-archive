/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance;


public class ConcordanceConfig {
	
	private final static int defaultTokensBefore = 10;
	private final static int defaultTokensAfter = 10;
	private final static int defaultMaxWindows = 100000;
	private final static int defaultMaxTargetDisplaySizeChars = 1000;
	private final static int defaultMaxContextDisplaySizeChars = 10000;

   private final static ConcordanceSortOrder defaultSortOrder = ConcordanceSortOrder.PRE;

   /**
    * Number of tokens to capture before the target
    */
   private int tokensBefore = defaultTokensBefore;
   
   /**
    * Number of tokens to capture after the target
    */
   private int tokensAfter = defaultTokensAfter;

   /**
    * Maximum number of windows to retrieve
    */
   private int maxWindows = defaultMaxWindows;
   
   /**
    * Maximum target length in characters.
    */
   private int maxTargetDisplaySizeChars = defaultMaxTargetDisplaySizeChars;
   
   /**
    * Dual purpose:
    *    1) Maximum length in characters for the string before the target {@see #ConcordanceWindow.pre}.
    *    2) Maximum length in characters for the string after the target {@see #ConcordanceWindow.post}.
    */
   private int maxContextDisplaySizeChars = defaultMaxContextDisplaySizeChars;

   /**
    * field to search
    */
   private final String fieldName;
   
   /**
    * The results of a SpanQuery in some versions of Lucene allow
    * for target overlaps.
    */
   private boolean allowTargetOverlaps = false;
   
   /**
    * Sort order for the windows
    */
   private ConcordanceSortOrder sortOrder = defaultSortOrder;
   
   public ConcordanceConfig(String fieldName){
      this.fieldName = fieldName;
   }
   
	public int getTokensBefore() {
      return tokensBefore;
   }

   public void setTokensBefore(int tokensBefore) {
      this.tokensBefore = tokensBefore;
   }

   public int getTokensAfter() {
      return tokensAfter;
   }

   public void setTokensAfter(int tokensAfter) {
      this.tokensAfter = tokensAfter;
   }

   public int getMaxWindows() {
      return maxWindows;
   }

   public void setMaxWindows(int maxWindows) {
      this.maxWindows = maxWindows;
   }

   public int getMaxTargetDisplaySizeChars() {
      return maxTargetDisplaySizeChars;
   }

   public void setMaxTargetDisplaySizeChars(int maxTargetDisplaySizeChars) {
      this.maxTargetDisplaySizeChars = maxTargetDisplaySizeChars;
   }

   public int getMaxContextDisplaySizeChars() {
      return maxContextDisplaySizeChars;
   }

   public void setMaxContextDisplaySizeChars(int maxContextDisplaySizeChars) {
      this.maxContextDisplaySizeChars = maxContextDisplaySizeChars;
   }

   public String getFieldName() {
      return fieldName;
   }
   
   public boolean isAllowTargetOverlaps() {
      return allowTargetOverlaps;
   }

   public void setAllowTargetOverlaps(boolean allowTargetOverlaps) {
      this.allowTargetOverlaps = allowTargetOverlaps;
   }

   public ConcordanceSortOrder getSortOrder() {
      return sortOrder;
   }

   public void setSortOrder(ConcordanceSortOrder sortOrder) {
      this.sortOrder = sortOrder;
   }

	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append("sort order: ").append(sortOrder.toString()).append("\n");

		sb.append("tokens before: ").append(tokensBefore).append("\n");
		sb.append("tokens after: ").append(tokensAfter).append("\n");
		sb.append("max results: ").append(maxWindows).append("\n");
		sb.append("maxTargetDisplaySizeChars: ").append(maxTargetDisplaySizeChars).append("\n");
		sb.append("maxContextDisplaySizeChars: ").append(maxContextDisplaySizeChars).append("\n");
				
		
		return sb.toString();
	}
	

}
