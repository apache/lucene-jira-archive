/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.cooccur;
import org.apache.lucene.search.concordance.ConcordanceConfig;

/**
 * configuration class for co-occurrence statistics
 *
 */
public class ConcordanceCooccurConfig extends ConcordanceConfig{
   //TODO change ngram to gram
   //NGram is used generally of any XGram, be it a NGram, a SkipBigram, a WGram, etc
	private int minNGram = 1;
	private int maxNGram = 1;
	private int minTermFreq = 5;
	private int numResults = 20;
   
	public ConcordanceCooccurConfig(String fieldName){
	   super(fieldName);
	}
	   
   public int getMinNGram() {
      return minNGram;
   }
   
   public void setMinNGram(int minNGram) {
      this.minNGram = minNGram;
   }
   
   public int getMaxNGram() {
      return maxNGram;
   }
   
   public void setMaxNGram(int maxNGram) {
      this.maxNGram = maxNGram;
   }
   
   public int getMinTermFreq() {
      return minTermFreq;
   }
   
   public void setMinTermFreq(int minTermFreq) {
      this.minTermFreq = minTermFreq;
   }
      
   public int getNumResults() {
      return numResults;
   }
   
   public void setNumResults(int numResults) {
      this.numResults = numResults;
   }
}
