/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.queryparser.span.clauses;

/**
 * Type of clause: or, near or not near
 *
 */
public class ClauseInfo {
	public enum START_OR_END {
		START,
		END
	};
	public enum TYPE {
		OR,			//spanor
		NEAR,		//spannear
		NOT_NEAR		//spannotnear
	};
	private final int start;
	private final int end;
	private final START_OR_END startOrEnd;
	private final static TYPE type = TYPE.OR;
	
	public ClauseInfo(START_OR_END which, int start, int end){
		this.startOrEnd = which;
		this.start = start;
		this.end = end;
	}
	
	public TYPE getType(){
		return type;
	}
	public int getEnd(){
		return end;
	}
	public int getStart(){
		return start;
	}
	public START_OR_END getStartOrEnd(){
		return startOrEnd;
	}
	
	public static boolean matchTypes(TYPE startType, TYPE endType){
		//this is effectively directional!
		if (startType.equals(endType)){
			return true;
		}
		if (startType.equals(TYPE.NEAR) && 
				(endType.equals(TYPE.NEAR) || endType.equals(TYPE.NOT_NEAR))){
			return true;
		}
		return false;
	}
	public static boolean matchOpenClose(ClauseInfo openMarker, ClauseInfo closeMarker){
		if (openMarker.getStartOrEnd().equals(START_OR_END.START) &&
				closeMarker.getStartOrEnd().equals(START_OR_END.END) &&
					matchTypes(openMarker.getType(), closeMarker.getType())){
			return true;
		}
		
		return false;
	}
}
