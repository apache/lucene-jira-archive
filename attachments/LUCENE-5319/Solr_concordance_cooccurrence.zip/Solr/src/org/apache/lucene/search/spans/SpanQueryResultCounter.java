/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.search.spans;


import java.io.IOException;
import java.io.StringReader;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.lucene.analysis.Analyzer;

import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.util.CharArraySet;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.StoredDocument;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TotalHitCountCollector;
import org.apache.lucene.search.concordance.ConcordanceConfig;
import org.apache.lucene.search.concordance.ConcordanceWindow;
import org.apache.lucene.search.concordance.WindowBuilder;
import org.apache.lucene.search.concordance.charoffsets.DocTokenOffsets;
import org.apache.lucene.search.concordance.charoffsets.DocTokenOffsetsIterator;
import org.apache.lucene.search.concordance.charoffsets.OffsetLengthStartComparator;
import org.apache.lucene.search.concordance.charoffsets.OffsetUtil;
import org.apache.lucene.search.concordance.charoffsets.ReanalyzingTokenCharOffsetsReader;
import org.apache.lucene.search.concordance.charoffsets.SimpleAnalyzerUtil;
import org.apache.lucene.search.concordance.charoffsets.TargetTokenNotFoundException;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetRequests;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetResults;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetsReader;



public class SpanQueryResultCounter {
   private final static long ONE = 1L;
   
   
   public SpanQueryCountResults searchSpans(SpanQuery query, IndexReader reader, Analyzer analyzer, CharArraySet stopWords,
         VariantConfig variantConfig)
               throws TargetTokenNotFoundException, IOException{
      
      query = (SpanQuery)query.rewrite(reader);
      ConcordanceConfig config = new ConcordanceConfig(variantConfig.getField());
      config.setTokensBefore(0);
      config.setTokensAfter(0);
      config.setAllowTargetOverlaps(variantConfig.getAllowTargetOverlaps());
      WindowBuilder windowBuilder = new WindowBuilder();
      DocTokenOffsetsIterator itr = new DocTokenOffsetsIterator();
      Set<String> fields = new HashSet<String>();
      fields.add(config.getFieldName());
      itr.reset(query, null, reader, fields);
      
      

      //		int totalNumDocs = reader.numDocs();
      SpanQueryCountResults results = new SpanQueryCountResults();
      DocTokenOffsets result = null;
      TokenCharOffsetRequests offsetRequests = new TokenCharOffsetRequests();
      TokenCharOffsetResults charOffsets = new TokenCharOffsetResults();
      Map<String, String> metadata = new HashMap<String, String>();
      TokenCharOffsetsReader offsetsReader = new ReanalyzingTokenCharOffsetsReader(analyzer);
      OffsetLengthStartComparator offsetLengthStartComparator = new OffsetLengthStartComparator();

      while (itr.next()){
         result = itr.getDocTokenOffsets();
         StoredDocument document = result.getDocument();
         //System.out.println("new document");
         Map<String, Integer> docCounts = new HashMap<String, Integer>();
         String[] content = document.getValues(variantConfig.getField());

         List<OffsetAttribute> offsets = result.getOffsets();
         if (! config.isAllowTargetOverlaps()){
            //remove overlapping hits!!!
            offsets = OffsetUtil.removeOverlapsAndSort(offsets, offsetLengthStartComparator, null);
         }

         offsetRequests.clear();
         for (OffsetAttribute offset : offsets){
            //used to be i < offset.endOffset()+1, check that this fix makes sense
            for (int i = offset.startOffset(); i < offset.endOffset(); i++){
               offsetRequests.add(i);
            }
            //System.out.println("adding request: "+offset.getStart() + " : " + offset.getEnd());
         }

         charOffsets.clear();
        
         charOffsets = offsetsReader.getTokenCharOffsetResults(document, variantConfig.getField(),
                  offsetRequests, charOffsets);

         if (charOffsets != null){
            for (OffsetAttribute offset : offsets){
               ConcordanceWindow w = windowBuilder.buildConcordanceWindow(ONE, offset.startOffset(), offset.endOffset()-1,
                     metadata, config, content, charOffsets);
               String targ = w.getTarget();
               if (variantConfig.getNormalize()){
                  StringBuilder sb = new StringBuilder();
                  List<String> parts = SimpleAnalyzerUtil.getTermStrings(new StringReader(targ), analyzer);
                  if (parts.size() == 0){
                     targ = "";
                  } else {
                     sb.append(parts.get(0));
                     for (int i = 1; i < parts.size(); i++){
                        sb.append(" ").append(parts.get(i));
                     }
                     targ = sb.toString();
                  }
               }
               Integer i = docCounts.get(targ);
               i = (i == null)? new Integer(0) : i;
               i += 1;
               docCounts.put(targ, i);
            }
            results.addDocumentCounts(docCounts);
         } else {
            System.out.println("CharOffsets are null in SpanQueryResultCounter");
         }

      }
      return results;
   }

   public SpanQueryCountResults searchSingleTerms(Query query, IndexReader reader) throws IOException{
      Query tmpQ = query.rewrite(reader);
      Set<Term> terms = new HashSet<Term>();
      tmpQ.extractTerms(terms);
      
      Map<String, Integer> docCounts = new HashMap<String, Integer>();
      Map<String, Integer> termCounts = new HashMap<String, Integer>();

      for (Term t : terms){
         String targ = t.text();
         int docFreq = reader.docFreq(t);
         if (docFreq == 0){
            continue;
         }
         Integer i = new Integer(docFreq);
         docCounts.put(targ, i);
         
         long tf = reader.totalTermFreq(t);
         termCounts.put(targ, (int)tf);
      }
      SpanQueryCountResults results = new SpanQueryCountResults( termCounts )
      		.setDocumentCounts(docCounts);
      
      return results;
   }


   public int simpleDocCount(Query query, IndexReader reader) 
               throws IOException{
      IndexSearcher searcher = new IndexSearcher(reader);
      TotalHitCountCollector collector = new TotalHitCountCollector();
      searcher.search(query, collector);
      return collector.getTotalHits();
   }
}
