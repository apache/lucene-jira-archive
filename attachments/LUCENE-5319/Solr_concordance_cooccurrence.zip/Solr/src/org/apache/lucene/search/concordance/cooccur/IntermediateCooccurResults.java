/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.cooccur;


import java.util.Map;

import org.apache.lucene.util.OpenBitSet;

/**
 * Stores intermediate cooccurrence results in case
 * one wants to run searchers on different fields or use
 * entirely different types of co-occur searchres
 */
public class IntermediateCooccurResults {
	private Map<String, Integer> terms;
	private int totalWindows;
	private int totalDocs;
	private boolean hitMax = false;
	private OpenBitSet docIDs;
	
	public int getTotalDocs() {
		return totalDocs;
	}
	
	public void setTotalDocs(int totalDocs) {
		this.totalDocs = totalDocs;
	}
	
	public Map<String, Integer> getTerms() {
		return terms;
	}
	
	public void setTerms(Map<String, Integer> terms) {
		this.terms = terms;
	}
	
	public int getTotalWindows() {
		return totalWindows;
	}
	
	public void setTotalWindows(int totalWindows) {
		this.totalWindows = totalWindows;
	}
	
	
	public boolean isHitMax() {
		return hitMax;
	}
	
	public void setHitMax(boolean hitMax) {
		this.hitMax = hitMax;
	}
	
	public OpenBitSet getDocIDs() {
		return docIDs;
	}
	
	public void setDocIDs(OpenBitSet docIDs2) {
		this.docIDs = docIDs2;
	}
	
	/**
	 * This assumes that the underlying ephemeral Lucene doc ids have not changed
	 * between the calculations of the current results and the results that are
	 * being added.
	 * @param results
	 */
	public void addAll(IntermediateCooccurResults results){
		for (Map.Entry<String, Integer> entry : results.getTerms().entrySet()){
			Integer current = terms.get(entry.getKey());
			if (current == null){
				terms.put(entry.getKey(), entry.getValue());
			} else {
				current = current.intValue()+ entry.getValue().intValue();
			}
		}
		if (results.getDocIDs() != null){
			docIDs.or(results.getDocIDs());
		}
		hitMax = (hitMax || results.isHitMax());
		totalWindows += results.getTotalWindows();
	}
}
