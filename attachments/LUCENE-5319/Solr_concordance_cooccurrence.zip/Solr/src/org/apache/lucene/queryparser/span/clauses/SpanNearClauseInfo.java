/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.queryparser.span.clauses;


public class SpanNearClauseInfo extends ClauseInfo{
	private final static TYPE type = TYPE.NEAR;
	private final static int DEFAULT_SLOP = 0;
	private final static boolean DEFAULT_INORDER = true;
	
	private final boolean inOrder;
	private final int slop;
	
	public SpanNearClauseInfo(START_OR_END which, int start, int end){
		super(which, start, end);
		this.inOrder = DEFAULT_INORDER;
		this.slop = DEFAULT_SLOP;
	}
	public SpanNearClauseInfo(START_OR_END which, int start, int end, int slop, boolean inOrder){
		super(which, start, end);
		this.slop = slop;
		this.inOrder = inOrder;
	}
	
	public int getSlop(){
		return slop;
	}
	public boolean getInOrder(){
		return inOrder;
	}
	
	public TYPE getType(){
		return type;
	}
}
