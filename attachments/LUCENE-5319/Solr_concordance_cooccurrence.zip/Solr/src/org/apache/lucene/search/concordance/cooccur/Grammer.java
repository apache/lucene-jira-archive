/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.cooccur;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttributeImpl;

/**
 * TODO:refactor to make this an interface for different xgrammer objects
 *
 */
public class Grammer {
	
	public static List<String> getNGrams(List<String> strings, int min, int max, String delimiter){
		if (min == 1 && max == 1){
			return strings;
		}
		List<String> ret = new ArrayList<String>();
		List<OffsetAttribute> offsets = getNGramOffsets(strings, min, max);
		for (OffsetAttribute offset : offsets){
			ret.add(join(delimiter, strings, offset.startOffset(), offset.endOffset()));
		}
		return ret;
		
	}
	
	public static List<OffsetAttribute> getNGramOffsets(List<String> strings, int min, int max){
		List<OffsetAttribute> ret = new ArrayList<OffsetAttribute>();
		for (int i = 0; i < strings.size(); i++){
			for (int j = i+min-1; j < i+max && j < strings.size(); j++){
			   OffsetAttribute off = new OffsetAttributeImpl();
			   off.setOffset(i,j);
				ret.add(off);
			}
		}
		return ret;
	}

	public static List<String> getWGrams(List<String> strings, Set<Integer> stopIndices,
	      int min, int max, String delimiter){
		List<String> ret = new ArrayList<String>();
		List<OffsetAttribute> offsets = getWGramOffsets(strings, stopIndices, min, max);
		for (OffsetAttribute offset : offsets){
			ret.add(join(delimiter, strings, offset.startOffset(), offset.endOffset()));
		}
		return ret;

	}
	
	public static List<OffsetAttribute> getWGramOffsets(List<String> strings, 
	      Set<Integer> stopIndices, int min, int max ){
		//if an ngram starts or ends with a stop word, do not include it.
		//A wgram may contain stop words inside it, though.
		//The w stands for Wilson, as in George V. Wilson.  As far as I am aware,
		//George is the inventor of this modification of the ngram.
		//Stopwords do not count towards an ngram; so a "bigram" may contain one or 
		//more stopwords inside it.
		List<OffsetAttribute> ret = new ArrayList<OffsetAttribute>();
		for (int i = 0; i < strings.size(); i++){
			if (stopIndices.contains(i)){
				continue;
			}
			int nonStops = 0;
			for (int j = i; nonStops < max && j < strings.size(); j++){
				if(stopIndices.contains(i)){
					continue;
				}
				nonStops++;
				if (nonStops >= min){
				   OffsetAttribute offset = new OffsetAttributeImpl();
				   offset.setOffset(i,j);
					ret.add(offset);
				}
			}
		}
		return ret;
	}
	
	private static String join(String delimiter, List<String> strings, int start, int end){
	   StringBuilder sb = new StringBuilder();
	   for (int i = start; i <= end-1 && i < strings.size()-1; i++){
	      sb.append(strings.get(i));
	      sb.append(delimiter);
	   }
	   if (end < strings.size()){
	      sb.append(strings.get(end));
	   }
	   return sb.toString();
	}
}
