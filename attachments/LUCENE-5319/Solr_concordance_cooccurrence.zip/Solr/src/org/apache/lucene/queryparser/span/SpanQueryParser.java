/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.queryparser.span;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;




import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.span.clauses.ClauseInfo;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.spans.SpanQuery;



/**
 * <p>Parses a query into a {@link SpanQuery} which can be used
 * to fetch {@link Span}s or with IndexSearcher.  This parser includes functionality from:
 * <ul>
 * <li> {@link org.apache.lucene.queryparser.classic.QueryParser classic QueryParser}: most of its syntax</li>
 * <li> {@link org.apache.lucene.queryparser.surround.parser.QueryParser SurroundQueryParser}: recursive parsing for "near" and "not" clauses.</li>
 * <li> {@link ComplexPhraseQueryParser}: can handle "near" queries that include multiterms ({@link WildcardQuery},
 * {@link FuzzyQuery}, {@link RegexpQuery}).</li>
 * <li> {@link AnalyzingQueryParser}: has an option to analyze multiterms.</li>
 * </ul>
 * 
 * </p>
 * 
 * <p>
 * <b>Background</b>
 * This parser was developed for the concordance/analytic search use case -- 
 * the user wants to see every
 * time a span occurs (perhaps with a separate FilterQuery).
 * While the SpanQuery that this parser generates
 * can be used as a Query for traditional information retrieval via IndexSearcher, this syntax
 * offers far more power than the classic syntax , and it may not be needed in the general IR use case.
 *
 * </p>
 * 
 * <p>With luck, this parser will be made obsolete with Lucene-2878, but until then,
 * this parser fills a niche.
 * </p>
 * <p>
 * One goal was to keep the syntax as close to Lucene's classic {@link QueryParser} as possible.
 * </p>
 * <p><b>Similarities and Differences</b></p>
 * 
 * <p> Same as classic syntax:
 * <ul>
 * <li> term: test </li>
 * <li> fuzzy: roam~0.8, roam~2</li>
 * <li> wildcard: te?t, test*, t*st</li>
 * <li> regex: <code>/[mb]oat/</code></li>
 * <li> phrase: &quot;jakarta apache&quot;</li>
 * <li> phrase with slop: &quot;jakarta apache&quot;~3</li>
 * <li> &quot;or&quot; clauses: jakarta apache</li>
 * <li> grouping clauses: (jakarta apache)</li>
 * </ul>
 * </p>
 * <p> Main additions in SpanQueryParser syntax vs. classic syntax:
 * <ul>
 * <li> Can require "in order" for phrases with slop with the ~> operator: &quot;jakarta apache&quot;~>3</li>
 * <li> Can specify "not near" &quot;bieber fever&quot;!~3,10 ::
 * find &quot;bieber&quot; but not if &quot;fever&quot; appears within 3 words before or
 * 10 words after it.</li>
 * <li> Fully recursive phrasal queries with [ and ]; as in: [[jakarta apache]~3 lucene]~>4 :: 
 * find &quot;jakarta&quot; within 3 words of &quot;apache&quot;, and that hit has to be within four
 * words before &quot;lucene&quot;.</li>
 * <li> Can also use [] for single level phrasal queries instead of &quot;&quot; as in: [jakarta apache]</li>
 * <li> Can use &quot;or&quot; clauses in phrasal queries: &quot;apache (lucene solr)&quot;~3 :: 
 * find &quot;apache&quot; and then either &quot;lucene&quot; or &quot;solr&quot; within three words.
 * </li>
 * <li> Can use multiterms in phrasal queries: "jakarta~1 ap*che"~2</li>
 * <li> Did I mention recursion: [[jakarta~1 ap*che]~2 (solr~ /l[ou]+[cs][en]+/)]~10 ::
 * Find something like &quot;jakarta&quot; within two words of &quot;ap*che&quot; and that hit
 * has to be within ten words of something like &quot;solr&quot; or that lucene regex.</li>
 *  </ul>
 * 
 * 
 * 
 * <p> Limitations of SpanQueryParser compared with classic QueryParser:
 * <ol>
 * <li> SpanQueryParser can create a query for only one field.</li>
 * <li> Boolean queries are not allowed.  There is no AND operator; statements with more than one term are either 
 * &quot;or'd&quot; or handled in proximity queries</li>
 * <li> Boosting is not currently supported</li>
 * <li> {@link RangeQuery}s are not yet supported.</li>
 * <li> This parser is not built with .jj or the antlr parser framework.  
 * Regrettably, because it is generating a {@link SpanQuery},
 * it can't use all of the generalizable queryparser infrastructure that was added with Lucene 4.+.</li>
 * </ol>
 * </p>
 * <p> Stop word handling
 * </p>
 * <p>The user can choose to throw a {@link ParseException} if a stop word is encountered.
 * If {@link SpanQueryParserBase.throwExceptionForStopWord} is set to false (default), the following should happen.
 * </p>
 * <p>
 * <ul>
 * <li>Term: "the" will return an empty {@link BooleanSpanQuery} (similar to classic queryparser)</li>
 * <li>SpanOr: (the apache jakarta) will drop the stop word and return a {@link SpanOrQuery} for &quot;apache&quot; 
 * or &quot;jakarta&quot;
 * <li>SpanNear: "apache and jakarta" will drop the "and" and match on only "apache jakarta"<li>
 * </ul></p>
 * <p> Expert: Other subtle differences between SpanQueryParser and classic QueryParser.
 * <ul>
 * <li>Fuzzy queries with slop > 2 are handled by SlowFuzzyQuery.  The developer can set the fuzzyMaxEdits.</li>
 * <li>Regex term queries must currently be preceded or followed by a parenthesis, a square bracket, 
 * white space or the start or end of the string. 
 *    <ul>
 *    <li> &quot;jakarta /ap[aeiou]*che/&quot; is allowed</li>
 *    <li> &quot;jakarta (/ap[aeiou]*che/ /lucene?/)&quot; is allowed</li>
 *    <li> &quot;jakarta/ap[aeiou]*che/&quot; is not allowed</li>
 *    </ul>
 * </li>
 * <li>Fuzzy queries with edit distance >=1 are rounded so that an exception is not thrown.</li>
 * </ul>
 * </p>
 * <p>
 * <b>NOTE</b> You must add the sandbox jar to your class path to include 
 * the currently deprecated {@link SlowFuzzyQuery}.
 * </p>
 * 
 */
public class SpanQueryParser extends SpanQueryParserBase {

   private static final Pattern FUZZY_PATTERN = Pattern.compile("(?s)^(.+)~(\\d+)?(?:\\.(\\d+))?$");
   private static final Pattern WILDCARD_PATTERN = Pattern.compile("([?*])");
   private static final Pattern REGEX_PATTERN = Pattern.compile("(?s)^\\/(.+?)\\/$");
   private static final Pattern ESCAPE_PATTERN = Pattern.compile("\\\\.");//.");


   /**
    * Initialize with field and analyzer.  This parser can only process a single field.
    * It will use the analyzer for normalizing query terms and for tokenizing character runs
    * from non-whitespace languages.
    * @param field
    * @param analyzer
    */
   public SpanQueryParser(String field, Analyzer analyzer){
      init(field, analyzer);
   }
   
   /**
    * returns {@link SpanQuery} or null if an empty string or no parseable content is passed in.
    */
   public SpanQuery parse(String s) throws ParseException{
      SpanQueryParserUtil parserUtil = new SpanQueryParserUtil();
      //treat every query as if it were a big spanOr
      //there is an unsettling, yet small inefficiency to this; fix if solution is obvious

      StringBuilder sb = new StringBuilder();
      sb.append("(").append(s).append(")");
      s = sb.toString();
      Set<Integer> escapedChars = parserUtil.getEscapedExtents(s);
      s = parserUtil.rewriteDoubleQuotes(s, escapedChars);
      List<OffsetAttribute> regexes = parserUtil.extractRegexes(s, escapedChars);
      List<ClauseInfo> clauses = parserUtil.getClauseMarkers(s, regexes, escapedChars);

      return parse(parserUtil, getField(), s, 0, clauses, regexes, escapedChars);
   }


   private SpanQuery parse(SpanQueryParserUtil util, String field, String s, int startMarkerIndex, 
         List<ClauseInfo> clauseMarkers, List<OffsetAttribute> regexes, Set<Integer> escapedChars) 
               throws ParseException{

      if (s == null || s.length() == 0)
         return null;

      ClauseInfo startMarker = clauseMarkers.get(startMarkerIndex);
      int endMarkerIndex = util.findMatching(clauseMarkers, startMarkerIndex);
      ClauseInfo endMarker = clauseMarkers.get(endMarkerIndex);

      List<SpanQuery> queryClauses = new ArrayList<SpanQuery>();

      int childStartInd = startMarkerIndex+1;
      int childEndInd = -1;
      int lastStartChar = startMarker.getEnd();

      while (childStartInd < endMarkerIndex){

         childEndInd = util.findMatching(clauseMarkers, childStartInd);

         //handle the stuff before the clauseMarkers
         int tmpStart = lastStartChar;
         int tmpEnd = clauseMarkers.get(childStartInd).getStart();
         List<SpanQuery> preTermQueries = parseBasicTerms(util, field, s, tmpStart, tmpEnd, regexes, escapedChars);
         for (SpanQuery q : preTermQueries){ 
            queryClauses = addQuery(q, queryClauses);
         }
         SpanQuery tmpQ = parse(util, field, s, childStartInd, clauseMarkers, regexes, escapedChars);
         queryClauses = addQuery(tmpQ, queryClauses);
         lastStartChar = clauseMarkers.get(childEndInd).getEnd();
         childStartInd = childEndInd+1;

      }

      int endInd = (childEndInd > -1) ? childEndInd : startMarkerIndex;
      int contentOffsetStart = clauseMarkers.get(endInd).getEnd();
      int contentOffsetEnd = endMarker.getStart();
      List<SpanQuery> postTermQueries = parseBasicTerms(util, field, s, contentOffsetStart, contentOffsetEnd, 
            regexes, escapedChars);
      for (SpanQuery q : postTermQueries){ 
         queryClauses = addQuery(q,queryClauses);
      }

      return buildQuery(queryClauses, endMarker);
   }


   private List<SpanQuery> parseBasicTerms(SpanQueryParserUtil util, String field, String s, int start, int end, 
         List<OffsetAttribute> regexes, Set<Integer> escapedChars) throws ParseException{

      List<String> termStrings = util.extractTermStringsBasedOnWhitespace(s, start, end, regexes, escapedChars);

      return convertTermStringsToSpanQueries(field, termStrings);
   }


   private List<SpanQuery> addQuery(SpanQuery q, List<SpanQuery> list){
      if (null != q)
         list.add(q);
      return list;
   }


   /**
    * Simply convert termStrs to SpanQueries.
    * @param field
    * @param strings
    * @return
    * @throws ParseException
    */
   private List<SpanQuery> convertTermStringsToSpanQueries(String field, List<String> strings) throws ParseException{
      List<SpanQuery> terms = new ArrayList<SpanQuery>();
      for (String s : strings){
         SpanQuery tmpT = buildAnyTermQuery(s);
         if (tmpT != null){
            terms = addQuery(tmpT, terms);
         }
      }
      return terms;
   }
   /**
    * This identifies and then builds the various span term and/or multiterm queries.
    * Protected for testing purposes.
    * 
    * <p>
    * For {@link FuzzyQuery}, this defaults to {@link FuzzyQuery.defaultMaxEdits} if 
    * no value is specified after the ~.
    * 
    * @param termText
    * @return SpanQuery or null if termText is a stop word
    * @throws ParseException
    * @throws IOException
    */
   protected SpanQuery buildAnyTermQuery(String termText) throws ParseException{
      //TODO: add range query
      //is this a regex term?
      Matcher m = REGEX_PATTERN.matcher(termText);
      if (m.find()){
         return buildRegexTermQuery(getField(), m.group(1));
      }

      Set<Integer> escapes = new HashSet<Integer>();
      m = ESCAPE_PATTERN.matcher(termText);
      while (m.find()){
         escapes.add(m.end()-1);
      }
      SpanQuery q = null;

      //is this a fuzzy term?
      m = FUZZY_PATTERN.matcher(termText);
      if (m.find()){
         String term = m.group(1);
         //if this is not actually an escaped fuzzy marker!!!
         if (! escapes.contains(m.end(1))){

            String slopString = m.group(2);
            String decimalComponent = m.group(3);
            float slop = (float)FuzzyQuery.defaultMaxEdits;
            if (slopString != null){
               if (decimalComponent == null || decimalComponent.length() == 0){
                  decimalComponent = "0";
               }
               try{
                  slop = Float.parseFloat(slopString+"."+decimalComponent);
               } catch (NumberFormatException e){
                  //shouldn't ever happen. If it does, fall back to original value of slop
                  //swallow
               }


            }
            //if the user enters 2.4 for example, round it so that there won't be an 
            //illegalparameter exception
            if (slop >= 1.0f){
               slop = (float)Math.round(slop);
            }
            q = buildFuzzyTermQuery(getField(), term, slop);
         }
      }

      //is this a wildcard term?
      m = WILDCARD_PATTERN.matcher(termText);
      Set<Integer> ws = new HashSet<Integer>();
      while (m.find()){
         if (!escapes.contains(m.start())){
            ws.add(m.start());
         }
      }
      if (ws.size() > 0){
         if (q != null){
            throw new ParseException(
                  "Can't have a single term in a query that is both a wildcard and a fuzzy query");
         }

         if (
               ws.size() == 1 //there's only one wildcard character
               && ws.contains(termText.length()-1)  //it isn't escaped
               && termText.indexOf("*") == termText.length()-1 // it is * not ?
               ){
            //snip final *
            q = buildPrefixQuery(getField(), termText.substring(0, termText.length()-1));
         } else {
            q = buildWildcardQuery(getField(), termText);
         }
      }

      //if you've found anything, return it
      if (q != null){
         return q;
      }
      //treat as basic single term query
      return buildSingleTermQuery(getField(), termText);
   }
}
