/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.cooccur;

import java.io.IOException;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.util.BytesRef;
/**
 * Simple class to calculate IDF based on a reader.
 * 
 * Includes hack for estimating multi-term IDF.
 *
 */
public class IDF {
	private final IndexReader reader;
	private final IDFCalc idfCalc;
	private final int D;
	
	public IDF(IndexReader reader){
		this.reader = reader;
		D = reader.numDocs();
		idfCalc = new IDFCalc( D );
	}

	public double singleTerm(Term t) throws IOException{
		return idfCalc.getIDF(reader.docFreq(t));
	}
	
	/**
	 * Splits s on whitespace and then sums idf for
	 * each subtoken.  This is equivalent to multiplying the probabilities
	 * or, calculating the probability if each term is completely independent of the other.
	 * The result is an upperbound on the actual idf of the phrase.
	 * This is exceedingly fast to compute and yields
	 * decent results in practice.  For more exact IDF for phrases,
	 * consider indexing ngrams.
	 * 
	 * @param s
	 * @param t
	 * @return
	 * @throws IOException
	 */
	public double multiTermSum(String s, Term t) throws IOException{
	   //be careful: must pre-analyze and divide subterms by whitespace!!!
		double sum = 0.0;
		Term tmp = new Term(t.field());
		BytesRef ref = tmp.bytes();
		for (String termString : s.trim().split(" +")){
			ref.copyChars(termString);
			sum += idfCalc.getIDF(reader.docFreq(tmp));
		}
		return sum;
	}

	public double[] multiTermStats(String s, Term t) throws IOException{
		   //be careful: must pre-analyze and divide subterms by whitespace!!!
			double[] stats = new double[] {0.0, Double.MAX_VALUE}; //sum, min df,  ...
			Term tmp = new Term(t.field());
			BytesRef ref = tmp.bytes();
			for (String termString : s.trim().split(" +")){
				ref.copyChars(termString);
				
				int df =  reader.docFreq(tmp);
				double idf = idfCalc.getIDF( df ); 
				stats[0] += idf;
				
				if(df < stats[1]) stats[1] = df;
			}
			return stats;
		}
	
	public double[] multiTermStats(String s, String field) throws IOException{
			return multiTermStats(s, new Term(field, ""));
		}

	public double unIDF(double idf) {
		return idfCalc.unIDF(idf);
	}
	
	public int getD() { return D; }
}
