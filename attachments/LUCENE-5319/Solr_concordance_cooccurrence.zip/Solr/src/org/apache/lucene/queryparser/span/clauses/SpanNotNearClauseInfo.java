/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.queryparser.span.clauses;



public class SpanNotNearClauseInfo extends ClauseInfo{
	private final static int DEFAULT_BEFORE = 0;
	private final static int DEFAULT_AFTER = 0;
	
	private final static TYPE type = TYPE.NOT_NEAR;

	private final int before;
	private final int after;
	public SpanNotNearClauseInfo(START_OR_END which, int start, int end){
		super(which, start, end);
		this.before = DEFAULT_BEFORE;
		this.after = DEFAULT_AFTER;
	}

	public SpanNotNearClauseInfo(START_OR_END which, int start, int end, int slop){
		super(which, start, end);
		this.before = slop;
		this.after = slop;
	}
	public SpanNotNearClauseInfo(START_OR_END which, int start, int end, int before, int after){
		super(which, start, end);
		this.before = before;
		this.after = after;
	}
	public int getBefore(){
		return before;
	}
	public int getAfter(){
		return after;
	}
	public TYPE getType(){
		return type;
	}

}
