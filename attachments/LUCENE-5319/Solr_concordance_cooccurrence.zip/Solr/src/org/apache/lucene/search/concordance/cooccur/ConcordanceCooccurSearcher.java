/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.cooccur;
import java.util.List;


import java.util.Set;
import java.util.HashSet;
import java.io.IOException;


import org.apache.lucene.search.concordance.SpanQueryConverter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.StoredDocument;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;

import org.apache.lucene.queries.ChainedFilter;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryWrapperFilter;
import org.apache.lucene.search.concordance.ConcordanceSearcherUtil;
import org.apache.lucene.search.concordance.charoffsets.DocTokenOffsets;
import org.apache.lucene.search.concordance.charoffsets.DocTokenOffsetsIterator;
import org.apache.lucene.search.concordance.charoffsets.OffsetLengthStartComparator;
import org.apache.lucene.search.concordance.charoffsets.OffsetUtil;
import org.apache.lucene.search.concordance.charoffsets.ReanalyzingTokenCharOffsetsReader;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetsReader;
import org.apache.lucene.search.concordance.charoffsets.TargetTokenNotFoundException;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetRequests;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetResults;
import org.apache.lucene.search.spans.SpanQuery;

/**
 * Calculates term statistics for the tokens before and after
 * a given query term.
 * 
 * This can be very useful to help users identify synonyms or
 * find patterns in their data.
 *
 */
public class ConcordanceCooccurSearcher {

   public boolean search(IndexReader reader, Query query, Filter filter,
         Analyzer analyzer,  
         ConcordanceCooccurConfig config, ArrayWindowVisitor visitor) throws IllegalArgumentException,
         TargetTokenNotFoundException, IOException {
      
      
      if (query instanceof SpanQuery){
         //pass through
         return searchSpan(reader, (SpanQuery)query, filter, analyzer, config, visitor);
      } else {
         //convert regular query to a SpanQuery.
         SpanQueryConverter converter = new SpanQueryConverter();
         SpanQuery spanQuery = converter.convert(config.getFieldName(), query);
         
         Filter origQueryFilter = new QueryWrapperFilter(query);
         Filter updatedFilter = origQueryFilter;
         
         if (filter != null){
            updatedFilter = new ChainedFilter(new Filter[]{origQueryFilter, filter}, ChainedFilter.AND);
         }
         return searchSpan(reader, spanQuery, updatedFilter, analyzer, config, visitor);
      }

   }

   public boolean searchSpan(IndexReader reader, SpanQuery mainQuery, Filter filter,
         Analyzer analyzer,  
         ConcordanceCooccurConfig cConfig, ArrayWindowVisitor visitor) throws IllegalArgumentException,
         TargetTokenNotFoundException, IOException {

      mainQuery = (SpanQuery)mainQuery.rewrite(reader);
      Set<String> fields = new HashSet<String>();
      fields.add(cConfig.getFieldName());

      TokenCharOffsetsReader tokenOffsetsReader = new ReanalyzingTokenCharOffsetsReader(analyzer);

      DocTokenOffsetsIterator itr = new DocTokenOffsetsIterator();
      itr.reset(mainQuery, filter, reader,fields);


      //reusable arrayWindow
      ConcordanceArrayWindow arrayWindow = new ConcordanceArrayWindow();

      TokenCharOffsetRequests offsetRequests = new TokenCharOffsetRequests();
      TokenCharOffsetResults offsetResults = new TokenCharOffsetResults();
      DocTokenOffsets docTokenOffsets = null;
      OffsetLengthStartComparator offsetLengthStartComparator = new OffsetLengthStartComparator();

      //iterate through documents
      while (itr.next()){

         docTokenOffsets = itr.getDocTokenOffsets();
         StoredDocument document = docTokenOffsets.getDocument();
         int docID = docTokenOffsets.getUniqueDocId();
         String[] fieldValues = document.getValues(cConfig.getFieldName());
         if (fieldValues == null){
            throw new IOException("Mismatched content field");
         }
         List<OffsetAttribute> offsets = docTokenOffsets.getOffsets();
         if (! cConfig.isAllowTargetOverlaps()){
            //remove overlapping hits
            offsets = OffsetUtil.removeOverlapsAndSort(offsets, offsetLengthStartComparator, null);
         }
         //can't imagine that this would ever happen
         if (offsets.size() == 0){
            throw new RuntimeException("DEBUG: can't imagine that this would ever happen");
            //just in case this does happen
            //continue;
         }

         //reset and then load offsetRequests
         offsetRequests =  ConcordanceSearcherUtil.getCharOffsetRequests(offsets, cConfig);

         offsetResults.clear();
         offsetResults = tokenOffsetsReader.getTokenCharOffsetResults(
               document, cConfig.getFieldName(), offsetRequests, offsetResults);


         boolean hitMax = visitWindowsInDoc(reader, cConfig, offsetResults, offsets, docID, arrayWindow, visitor);

         if (hitMax == true){
            return true;
         }
      }
      return false;
   }


   private boolean visitWindowsInDoc(IndexReader reader, ConcordanceCooccurConfig config,
         TokenCharOffsetResults offsetResults, List<OffsetAttribute> offsets, int docID,
         ConcordanceArrayWindow window, ArrayWindowVisitor visitor
         ) throws IOException, TargetTokenNotFoundException{

      for (OffsetAttribute offset : offsets){
         //hit max, stop now
         if (visitor.getNumWindowsVisited() >= config.getMaxWindows()){
            return true;
         }
         window.reset();
         window = ArrayWindowBuilder.buildWindow(offset.startOffset(), 
               offset.endOffset()-1, config.getTokensBefore(),
               config.getTokensAfter(), offsetResults, window);
         
         visitor.visit(docID, window);
      }
      return false;
   }
}
