/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.cooccur;


import java.util.Set;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

/**
 * Reusable object that records arrays of terms in the words before a target,
 * in the target and after a target.  It includes information about overall tokens as well.
 * 
 * See also ConcordanceWindow that records strings for the context before, the target and the context
 * after the target.
 *
 */

public class ConcordanceArrayWindow {

   private final static String EMPTY_STRING = " ";
   
	private List<String> pres = new ArrayList<String>();
	private List<String> posts = new ArrayList<String>();
	private Map<String, Integer> tokens = new HashMap<String, Integer>();
   private Set<Integer> preStops = new HashSet<Integer>();
   private Set<Integer> postStops = new HashSet<Integer>();
	private String target = EMPTY_STRING;
	private final StringBuilder sb = new StringBuilder();
	
	public void setTarget(String t){
		this.target = t;
	}
	
	public void addPreStop(){
	   preStops.add(pres.size());
	   addPre(null);
	}
	
	public void addPre(String s){
		if (s == null){
			pres.add("");
		} else {
			pres.add(s);
		}
	}
	public void addPostStop(){
	   postStops.add(posts.size());
	   addPost(null);
	}
	
	public void addPost(String s){
		if (s == null){
			posts.add("");
		} else {
			posts.add(s);
		}
	}

	public Map<String, Integer> getTokens(){
		for (int i = 0; i < pres.size(); i++){
		   if (preStops.contains(i))
		      continue;
		   
		   String s = pres.get(i);
				
			Integer modInt = tokens.get(s);
			if (modInt == null){
				modInt = new Integer(0);
			}
			modInt++;
			tokens.put(s, modInt);
		}
		
		
      for (int i = 0; i < posts.size(); i++){
         if (postStops.contains(i))
            continue;
         
         String s = pres.get(i);
         Integer modInt = tokens.get(s);
			if (modInt == null){
				modInt = new Integer(0);
			}
			modInt++;
			tokens.put(s, modInt);
		}
		return tokens;
	}
	
	public Set<String> getTypes(){
		Set<String> set = new HashSet<String>();
		
		for (int i = 0; i < pres.size(); i++){
         if (preStops.contains(i))
            continue;
         
         String s = pres.get(i);
         set.add(s);
		}
		
      for (int i = 0; i < pres.size(); i++){
         if (postStops.contains(i))
            continue;
         
         String s = posts.get(i);
         set.add(s);
      }
		return set;
	}
	
	public String toString(){
		sb.setLength(0);
		for (int i = 0; i < pres.size()-1; i++){
			sb.append(pres.get(i) + " ");
		}
		if (pres.size() > 0){
			sb.append(pres.get(pres.size()-1));
		}
		sb.append(">"+target+"<");
		for (int i = 0; i < posts.size()-1; i++){
			sb.append(posts.get(i) + " ");
		}
		if (posts.size() > 0){
			sb.append(posts.get(posts.size()-1));
		}
		return sb.toString();
	}
	
	public void reset(){
		pres.clear();
		posts.clear();
		preStops.clear();
		postStops.clear();
		tokens.clear();
		target = EMPTY_STRING;
		sb.setLength(0);
	}
	
	/**
	 * could be dangerous from a security perspective.  
	 * @return
	 */
	protected List<String> getPreList(){
		return pres;
	}
	
	protected List<String> getPostList(){
		return posts;
	}
	
	protected Set<Integer> getPreStopIndices(){
	   return preStops;
	}
	
	protected Set<Integer> getPostStopIndices(){
	   return postStops;
	}
	
   @Override
   public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + ((posts == null) ? 0 : posts.hashCode());
      result = prime * result + ((pres == null) ? 0 : pres.hashCode());
      return result;
   }
   @Override
   public boolean equals(Object obj) {
      if (this == obj)
         return true;
      if (obj == null)
         return false;
      if (!(obj instanceof ConcordanceArrayWindow))
         return false;
      ConcordanceArrayWindow other = (ConcordanceArrayWindow) obj;
      if (posts == null) {
         if (other.posts != null)
            return false;
      } else if (!posts.equals(other.posts))
         return false;
      if (pres == null) {
         if (other.pres != null)
            return false;
      } else if (!pres.equals(other.pres))
         return false;
      return true;
   }
	
	

}
