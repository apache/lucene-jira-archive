/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.cooccur;

import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.lucene.analysis.util.CharArraySet;
import org.apache.lucene.index.Term;
import org.apache.lucene.util.OpenBitSet;
import org.apache.lucene.util.PriorityQueue;

/**
 * Class is not thread safe because of allNGrams
 * 
 * Currently hard-coded to extract WGrams
 * 
 * TODO: refactor
 * 
 */
public class NGramWeightedArrayWindowVisitor implements ArrayWindowVisitor {
   
   private final ConcordanceCooccurConfig config;
   private int numWindowsVisited = 0;
   private OpenBitSet docsVisited = new OpenBitSet();
   
   private final Map<String, Integer> allNGrams = new HashMap<String, Integer>();
   private final IDF idfer;
   
   public NGramWeightedArrayWindowVisitor(ConcordanceCooccurConfig config, IDF idfer){
      this.config = config;
      this.idfer = idfer;
   }

   @Override
   public void visit(int docID, ConcordanceArrayWindow window) throws IOException {

      numWindowsVisited++;
      docsVisited.set(docID);
      extractWGrams(window, allNGrams);
   }
   
   @Override
   public int getNumWindowsVisited() {
      return numWindowsVisited;
   }

   public int getNumDocsVisited(){
      return (int)docsVisited.cardinality();
   }
   
   public TFIDFResults getResults() throws IOException{
      TFIDFPriorityQueue queue = new TFIDFPriorityQueue(config.getNumResults());

      int D = idfer.getD();
      int tf = -1; 
      double idf = -1.0;
      int minTf = config.getMinTermFreq();
      String text = "";
      Term reusableTerm = new Term(config.getFieldName(), "");
      for (Map.Entry<String, Integer> entry : allNGrams.entrySet()){

         tf = entry.getValue().intValue();
         if (tf < minTf)
            continue;

         text = entry.getKey();
         //calculate idf for potential phrase
         double[] stats = idfer.multiTermStats(text, reusableTerm);
         idf = stats[0];
         int estimatedDF = (int) Math.max(1, Math.round(idfer.unIDF(idf)));
         int minDF = (int)stats[1]; 
         
         TFIDFResult r = new TFIDFResult(text, tf, idf);
         r.setDF(estimatedDF);
         r.setMinDF(minDF);
         
         queue.insertWithOverflow(r);
      }
      List<TFIDFResult> results = new LinkedList<TFIDFResult>();

      while(queue.size() > 0){
         results.add(0, queue.pop());
      }
      return new TFIDFResults(results, numWindowsVisited, getNumDocsVisited(), D);
   }
   
   private Map<String, Integer> extractWGrams(ConcordanceArrayWindow window, Map<String, Integer> nGrams) 
         throws IOException{
      
      List<String> tmpGrams = Grammer.getWGrams(window.getPreList(), 
            window.getPreStopIndices(), config.getMinNGram(), config.getMaxNGram(), " ");
      
      tmpGrams.addAll(Grammer.getWGrams(window.getPostList(), 
            window.getPostStopIndices(), config.getMinNGram(), config.getMaxNGram(), " "));
      
      for (String nGram : tmpGrams){
         Integer mod = nGrams.get(nGram);
         if (mod == null){
            mod = new Integer(0);
         }
         mod += 1;
         nGrams.put(nGram, mod);
      }
      return nGrams;
   }


   private class TFIDFPriorityQueue extends PriorityQueue<TFIDFResult>{
      //double precision = 0.00001d;
      public TFIDFPriorityQueue(int maxSize) {
         super(maxSize);
      }

      protected boolean lessThan(TFIDFResult a, TFIDFResult b){
         if (a.getTFIDF() < b.getTFIDF()){
            return true;
         } else if (a.getTFIDF() == b.getTFIDF()){
            if (a.getTerm().compareTo(b.getTerm()) > 0){
               return true;
            }
         }
         return false;
      }
      
   }
}
