/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.charoffsets;

import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.util.OpenBitSet;

/**
 * Class to record results for looking up normalized terms (String)
 * and character offsets for specified tokens.
 * Will return NULL_TERM/NULL_OFFSET if a token offset was not found.
 * 
 * Has utility methods for safely getting the closest found token.  This
 * is useful for when a concordance window ends in a stop word (no term/offset info).
 */

public class TokenCharOffsetResults{
	
	public final static String NULL_TERM = "";
	public final static int NULL_OFFSET = -1;
	public final static FieldIndexCharacterOffsetPair NULL_FIELDINDEXCHAROFFSETPAIR = new FieldIndexCharacterOffsetPair(-1,-1);
	
	private OpenBitSet set = new OpenBitSet();
	private int last = -1;
	private Map<Integer, String> terms  = new HashMap<Integer, String>();
	private Map<Integer, FieldIndexCharacterOffsetPair> starts = 
	         new HashMap<Integer, FieldIndexCharacterOffsetPair>();
	private Map<Integer, FieldIndexCharacterOffsetPair> ends = 
	         new HashMap<Integer, FieldIndexCharacterOffsetPair>();
	
	public void add(int tokenOffset, int fieldIndex, int startCharOffset, int endCharOffset, String term){
		addStart(tokenOffset, fieldIndex, startCharOffset);
		addEnd(tokenOffset, fieldIndex, endCharOffset);
		addTerm(tokenOffset, term);
		set.set(tokenOffset);
	}
	
	private void addTerm(int tokenOffset, String term){
		if (term != null){
			terms.put(tokenOffset, term);
		}
		last =  (tokenOffset > last) ? tokenOffset : last;
	}

	private void addStart(int tokenOffset, int fieldIndex, int charOffset){
		starts.put(tokenOffset, new FieldIndexCharacterOffsetPair(fieldIndex, charOffset));
		last = (tokenOffset > last) ? tokenOffset : last;
	}
	private void addEnd(int tokenOffset, int fieldIndex, int charOffset){
		ends.put(tokenOffset, new FieldIndexCharacterOffsetPair(fieldIndex,charOffset));
		last = (tokenOffset > last) ? tokenOffset : last;
	}

	public int getCharacterOffsetStart(int tokenOffset){
		FieldIndexCharacterOffsetPair cand = starts.get(tokenOffset);
		if (cand == null)
			return NULL_OFFSET;
		
		return cand.getCharOffset();
	}
	
	public int getCharacterOffsetEnd(int tokenOffset){
		FieldIndexCharacterOffsetPair cand = ends.get(tokenOffset);
		if (cand == null)
         return NULL_OFFSET;
      
      return cand.getCharOffset();
		
	}

	public String getTerm(int tokenOffset){
		String s = terms.get(tokenOffset);
		if (s == null){
			return NULL_TERM;
		}
		return s;
	}
	

	public int getLast(){
		return last;
	}
	
	public void clear(){
		terms.clear();
		starts.clear();
		ends.clear();
		last = -1;
		set = new OpenBitSet();
	}
	protected boolean isEmpty(){
	   return set.isEmpty();
	}
	
	  private int getClosestToken(int fieldIndex, int start, int stop, Map<Integer, FieldIndexCharacterOffsetPair> map){
	      if (start < 0 || stop < 0){
	         return NULL_OFFSET;
	      }
	      if (start == stop){
	         return start;
	      }
	      if (start < stop){
	         for (int i = start ; i <= stop; i++){
	            FieldIndexCharacterOffsetPair p = map.get(i);
	            if (p != null && p.getFieldIndex() == fieldIndex){
	               return i;
	            }
	         }
	      } else if (start > stop){
	         for (int i = start; i >= stop; i--){
               FieldIndexCharacterOffsetPair p = map.get(i);
               if (p != null && p.getFieldIndex() == fieldIndex){
                  return i;
               }
	         }
	      }
	      return NULL_OFFSET;
	   }
	  
	   public int getClosestCharStart(int fieldIndex, int start, int stop){

	      int i = getClosestToken(fieldIndex, start, stop, starts);
	      return getCharacterOffsetStart(i);
	   }
	   
	   public int getClosestCharEnd(int fieldIndex, int start, int stop){
	      int i = getClosestToken(fieldIndex, start, stop, ends);
	     
         return getCharacterOffsetEnd(i);
	   }
	   
	   protected String getClosestTerm(int fieldIndex, int start, int stop){
         int i = getClosestToken(fieldIndex, start, stop, starts);
         return getTerm(i);
	   }
	   
	   /*
	    * return: -1 if
	    */
	   public int getFieldIndex(int tokenOffset){
	      FieldIndexCharacterOffsetPair p = starts.get(tokenOffset);
	      if (p == null){
	         return NULL_OFFSET;
	      }
	      return p.getFieldIndex();
	   }
	   protected String debugToString(){
	      StringBuilder sb = new StringBuilder();
	      for (Integer i : terms.keySet()){
	         sb.append(i + " : " + terms.get(i) + " : " + starts.get(i) + " : " + ends.get(i)+"\n");
	      }
	      return sb.toString();
	   }
	   
	  protected OpenBitSet getSet(){
	     return set;
	  }
}
