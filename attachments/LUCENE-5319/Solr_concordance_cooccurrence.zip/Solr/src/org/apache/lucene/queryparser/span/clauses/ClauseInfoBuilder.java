/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.queryparser.span.clauses;



import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.span.clauses.ClauseInfo.TYPE;
/**
 * Used internally by SpanQueryParserUtil to build a clause
 * 
 */
public class ClauseInfoBuilder {

	public static ClauseInfo build(ClauseInfo.START_OR_END startOrEnd,
			TYPE type,  int start, int end) throws ParseException {
		if (type.equals(TYPE.OR)){
			return new ClauseInfo(startOrEnd, start, end);
		} else if (type.equals(TYPE.NEAR)){
			return new SpanNearClauseInfo(startOrEnd, start, end);
		} else if (type.equals(TYPE.NOT_NEAR)){
			return new SpanNotNearClauseInfo(startOrEnd, start, end);
		}
		throw new ParseException(
				String.format("I'm sorry, but I don't recognize this type: %s",  type));
	}
	
	public static ClauseInfo build(ClauseInfo.START_OR_END startOrEnd,
			int start, int end, int slop, boolean inOrder){
		return new SpanNearClauseInfo(startOrEnd, start, end, slop, inOrder);
	}
	public static ClauseInfo build(ClauseInfo.START_OR_END startOrEnd,
			int start, int end, int pre, int post){
		return new SpanNotNearClauseInfo(startOrEnd, start, end, pre, post);
	}

}
