/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance.cooccur;

/**
 * Lucene-agnostic IDF calculator
 *
 */

public class IDFCalc {

	private final static int DEFAULT_UNSEEN_COUNT = 2;
	private final static int MAX_BUFF = 50;

	private final double UNSEEN_IDF;
	private final int docFreq;
	private final double[] buffered = new double[MAX_BUFF];
	
	public IDFCalc(int maxDoc){
		docFreq = maxDoc+1;
		UNSEEN_IDF = getUnbufferedIDF(DEFAULT_UNSEEN_COUNT);
		for (int i = 0; i < MAX_BUFF; i++){
			buffered[i] = getUnbufferedIDF(i);
		}
	}
	
	public double getIDF(int cnt){
		if (cnt <= 0)
			return UNSEEN_IDF;
		
		if (cnt < MAX_BUFF){
			return buffered[cnt];
		}
		//TODO: add a check for cnt > maxDoc
		return getUnbufferedIDF(cnt);
	}
	private double getUnbufferedIDF(int cnt){
		return Math.log((double)(docFreq)/(double)cnt);
	}
	
	public double unIDF(double idf){
		return unIDF(docFreq, idf);
	}
	
	
	static public double unIDF(int docFreq, double idf){
		return (double)(docFreq)/(Math.pow(Math.E, idf));  //make sure the base is the same as above
	}
	
	
	static public double getIDF(int totalDocs, int cnt){
		return Math.log((double)(totalDocs)/(double)cnt);
	}
	
	public static void main(String[] args){
		IDFCalc idf = new IDFCalc(1000);
		double tmp = idf.getIDF(103);
		System.out.println(tmp);
		
		tmp = idf.unIDF(tmp);
		System.out.println(tmp);
	}
}
