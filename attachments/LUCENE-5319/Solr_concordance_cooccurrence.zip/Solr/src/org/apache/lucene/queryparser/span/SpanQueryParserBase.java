/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.queryparser.span;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.tokenattributes.CharTermAttribute;
import org.apache.lucene.analysis.tokenattributes.PositionIncrementAttribute;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParserBase;
import org.apache.lucene.queryparser.span.clauses.ClauseInfo;
import org.apache.lucene.queryparser.span.clauses.SpanNearClauseInfo;
import org.apache.lucene.queryparser.span.clauses.SpanNotNearClauseInfo;
import org.apache.lucene.queryparser.span.clauses.ClauseInfo.TYPE;
import org.apache.lucene.sandbox.queries.SlowFuzzyQuery;
import org.apache.lucene.search.FuzzyQuery;
import org.apache.lucene.search.MultiTermQuery;
import org.apache.lucene.search.PrefixQuery;
import org.apache.lucene.search.RegexpQuery;
import org.apache.lucene.search.WildcardQuery;
import org.apache.lucene.search.spans.SpanMultiTermQueryWrapper;
import org.apache.lucene.search.spans.SpanNearQuery;
import org.apache.lucene.search.spans.SpanNotQuery;
import org.apache.lucene.search.spans.SpanOrQuery;
import org.apache.lucene.search.spans.SpanQuery;
import org.apache.lucene.search.spans.SpanTermQuery;

/**
 * Following the lead of {@link QueryParserBase}, this separates 
 * most of the functionality for creating a {@link SpanQuery}
 * from the actual parser.  This should allow for easy additions
 * of niftier jj or antlr or ?? parsers than the current SpanQueryParser.
 *
 */
public abstract class SpanQueryParserBase {



   private final Pattern WILDCARD_PATTERN = Pattern.compile("(\\\\.)|([?*]+)");

   private NormMultiTerm normMultiTerm = NormMultiTerm.LOWERCASE;
   private MultiTermQuery.RewriteMethod multiTermRewriteMethod = MultiTermQuery.CONSTANT_SCORE_AUTO_REWRITE_DEFAULT;
   private boolean allowLeadingWildcard = false;

   private Analyzer analyzer;
   private String field;
   private int phraseSlop = 0;
   private float fuzzyMinSim = 0.6f;//instead of FuzzyQuery.defaultMinSimilarity 2.0f;
   private int fuzzyMaxEdits   = FuzzyQuery.defaultMaxEdits;
   private int fuzzyPrefixLength = FuzzyQuery.defaultPrefixLength;
   private int spanNearMaxDistance = 100;
   private int spanNotNearMaxDistance = 50;
   private boolean throwExceptionForStopWord = false;
   private Locale locale = Locale.getDefault();


   boolean autoGeneratePhraseQueries = true;


   /** Initializes a span query parser.  Called by the SpanQueryParser constructor
    *  @param f  the field for query terms.
    *  @param a  used to find (and normalize) terms in the query text.
    */
   public void init(String f, Analyzer a) {
      analyzer = a;
      field = f;
   }

   /**
    * Parsers must implement this.
    * 
    * @param s
    * @return {@link SpanQuery} or null if nothing could be parsed
    * @throws ParseException
    */
   public abstract SpanQuery parse(String s) throws ParseException;

   /**
    * Not currently called by parser
    * @param s
    * @return
    */
   public static String escape(String s){
      return QueryParserBase.escape(s);
   }

   /**
    * @see #setMultiTermRewriteMethod(org.apache.lucene.search.MultiTermQuery.RewriteMethod)
    * @return
    */
   public MultiTermQuery.RewriteMethod getMultiTermRewriteMethod() {
      return multiTermRewriteMethod;
   }

   /**
    * 
    * By default QueryParser uses {@link org.apache.lucene.search.MultiTermQuery#CONSTANT_SCORE_AUTO_REWRITE_DEFAULT}
    * when creating a {@link PrefixQuery}, {@link WildcardQuery}, {@link TermRangeQuery},
    * and {@link RegexpQuery}. This implementation is generally preferable because it
    * a) Runs faster b) Does not have the scarcity of terms unduly influence score
    * c) avoids any {@link TooManyClauses} exception.
    * 
    * To set the max number of rewrites to a number higher than the default, use:
    * MultiTermQuery.TopTermsScoringBooleanQueryRewrite(x) or similar.
    * 
    * Beware: as of this writing, SpanMultiTermQueryWrapper.TopTermsSpanBooleanQueryRewrite(maxExpansions)
    * has no effect.
    */
   public void setMultiTermRewriteMethod(
         MultiTermQuery.RewriteMethod multiTermRewriteMethod) {
      this.multiTermRewriteMethod = multiTermRewriteMethod;
   }

   /**
    * @see #setAllowLeadingWildcard(boolean)
    * @return
    */
   public boolean getAllowLeadingWildcard() {
      return allowLeadingWildcard;
   }

   /**
    * Set to <code>true</code> to allow leading wildcard characters.
    * <p>
    * When set, <code>*</code> or <code>?</code> are allowed as
    * the first character of a PrefixQuery and WildcardQuery.
    * Note that this can produce very slow
    * queries on big indexes.
    * <p>
    * Default: false.
    */
   public void setAllowLeadingWildcard(boolean allowLeadingWildcard) {
      this.allowLeadingWildcard = allowLeadingWildcard;
   }

   /**
    * @see #setAnalyzer(Analyzer)
    * @return
    */
   public Analyzer getAnalyzer() {
      return analyzer;
   }

   /**
    * 
    * @param analyzer set analyzer to use in parser
    */
   public void setAnalyzer(Analyzer analyzer) {
      this.analyzer = analyzer;
   }

   /**
    * @see #setField(String)
    * @return
    */
   public String getField() {
      return field;
   }
   /**
    * 
    * @param field which field to parse
    */
   public void setField(String field) {
      this.field = field;
   }
   /**
    * @see #setPhraseSlop(int)
    * @return
    */
   public int getPhraseSlop() {
      return phraseSlop;
   }
   /**
    * 
    * @param phraseSlop default slop to use in phrases
    */
   public void setPhraseSlop(int phraseSlop) {
      this.phraseSlop = phraseSlop;
   }
   /**
    * @see #setFuzzyMinSim(float) 
    * @return
    */
   public float getFuzzyMinSim() {
      return fuzzyMinSim;
   }

   /**
    * For a fuzzy query, if the fuzzy value is <code><</code> 1.0f
    * this will be the minimum allowable similarity.  For example,
    * if this is set to 0.8f and a query of salmonella~0.6 is parsed,
    * the resulting query will be for "salmonella" with a fuzziness of 0.8f.
    * Default is 0.6f.
    * 
    * However, if the fuzzy value is <code>>=</code> 1.0f, then @see #setFuzzyMaxEdits(int).
    * 
    * @param fuzzyMinSim
    */
   public void setFuzzyMinSim(float fuzzyMinSim) {
      this.fuzzyMinSim = fuzzyMinSim;
   }

   /**
    * @see #setFuzzyPrefixLength(int)
    * @return
    */
   public int getFuzzyPrefixLength() {
      return fuzzyPrefixLength;
   }
   /**
    * 
    * @param fuzzyPrefixLength prefix length to use in fuzzy queries. 
    * Default is 0.
    */
   public void setFuzzyPrefixLength(int fuzzyPrefixLength) {
      this.fuzzyPrefixLength = fuzzyPrefixLength;
   }
  
   /**
    * @see #setFuzzyMaxEdits(int)
    * @return
    */
   public int getFuzzyMaxEdits() {
      return fuzzyMaxEdits;
   }

   /**
    * maximum number of edits allowed in a fuzzy query.
    * <b>BEWARE</b> if this is set to anything greater than 2,
    * you'll be out of Automaton land and into brute force land (vintage Lucene <=3.x)
    * This could wreak serious performance problems.
    * @param fuzzyMaxEdits
    */
   public void setFuzzyMaxEdits(int fuzzyMaxEdits) {
      this.fuzzyMaxEdits = fuzzyMaxEdits;
   }

   /**
    * @see #setLocale(Locale)
    * @return
    */
   public Locale getLocale() {
      return locale;
   }

   /**
    * So far, only used in lowercasing of multiterm queries.
    * @param locale
    */
   public void setLocale(Locale locale) {
      this.locale = locale;
   }


   public boolean getAutoGeneratePhraseQueries() {
      return autoGeneratePhraseQueries;
   }

   public void setAutoGeneratePhraseQueries(boolean b) {
      autoGeneratePhraseQueries = b;
   }



   /**
    * When the parser comes across a simple single term, it runs the term 
    * through the analyzer.  This is called by {@link #buildSingleTermQuery(String, String).
    *  Override this for custom handling.
    * In whitespace languages, the returned array will most likely have a length of 1.  
    * It can have a length of 0 if a stop word was passed in as termText;
    * The array may contain null values if the {@link Analyzer} breaks
    * the apparently single term into multiple terms and there is a stopword.  
    * To identify stop words, the Analyzer must have a {@link PositionIncrementAttribute}.
    * If it doesn't, this will silently hide the nulls and not add them to the array.
    * 
    * @param termText apparently simple single term
    * @return array of {@link String} for the parts that the analyzer broke this into.
    * 
    */
   protected String[] analyzeSimpleSingleTerm(String termText) throws ParseException{
      List<String> chunks = new LinkedList<String>();
      try{
         TokenStream ts = analyzer.tokenStream(field, termText);
         ts.reset();
         CharTermAttribute cAttr = ts.getAttribute(CharTermAttribute.class);
         PositionIncrementAttribute posAttr = null;
         if (ts.hasAttribute(PositionIncrementAttribute.class)){
            posAttr = ts.getAttribute(PositionIncrementAttribute.class);
         }
         while(ts.incrementToken()){
            chunks.add(cAttr.toString());
            if (posAttr != null){
               for (int i = 1; i < posAttr.getPositionIncrement(); i++){
                  chunks.add(null);
               }
            }
         }
         ts.end();
         ts.close();
      } catch (IOException e){
         throw new ParseException(String.format(getLocale(), "IOException while trying to parse %s : %s", 
               termText, e.getMessage()));
      }

      return chunks.toArray(new String[chunks.size()]);
   }


   protected SpanQuery buildRegexTermQuery(String field, String termText){
      RegexpQuery regexQuery = new RegexpQuery(new Term(field, termText));
      regexQuery.setRewriteMethod(multiTermRewriteMethod);
      return new SpanMultiTermQueryWrapper<RegexpQuery>(regexQuery);
   }
   /**
    * 
    * @param field
    * @param termText
    * @param slop if < 1.0f, this will be treated as the old minSim, if >= 1.0f, 
    *       this will be rounded and treated as maxEdits
    * @return
    * @throws ParseException
    */
   protected SpanQuery buildFuzzyTermQuery(String field, String termText, float slop)
         throws ParseException{
      String normalized = termText;

      switch(normMultiTerm){
      case NO_NORM:
         break;
      case LOWERCASE:
         normalized = normalized.toLowerCase(getLocale());
         break;
      case ANALYZE:
         normalized = analyzeSingleChunk(field, termText, normalized);
         break;
      }

      if (slop == 0.0f){
         return new SpanTermQuery(new Term(field, normalized));
      }
      //if the user enters 2.4 for example, round it so that there won't be an 
      //illegalparameter exception
      if (slop >= 1.0f){
         slop = (float)Math.round(slop);
      }

      //set the max slop
      if (slop < 1.0f && slop < fuzzyMinSim){
         slop = fuzzyMinSim;
      } else if (slop > 1.0f && slop > fuzzyMaxEdits){
         slop = fuzzyMaxEdits;
      }
      //SlowFuzzyQuery defaults to the Automaton if maxEdits is <= 2.
      //We don't have to reinvent that wheel.
      SlowFuzzyQuery fuzzyQuery = new SlowFuzzyQuery(new Term(field, normalized), slop, fuzzyPrefixLength);
      fuzzyQuery.setRewriteMethod(multiTermRewriteMethod);

      return new SpanMultiTermQueryWrapper<SlowFuzzyQuery>(fuzzyQuery);

   }
   /**
    * @param field
    * @param termText should literally be the prefix. It should not end with *.
    * @return
    * @throws ParseException
    */
   protected SpanQuery buildPrefixQuery(String field, String termText) throws ParseException{
      //could happen with a simple * query
      testLeadingWildcard(termText);

      String normalized = termText;

      switch(normMultiTerm){
      case NO_NORM:
         break;
      case LOWERCASE:
         normalized = normalized.toLowerCase(locale);
         break;
      case ANALYZE:
         normalized = analyzeSingleChunk(field, termText, normalized);
         break;
      }

      PrefixQuery query = new PrefixQuery(new Term(field, normalized));
      query.setRewriteMethod(multiTermRewriteMethod);
      return new SpanMultiTermQueryWrapper<PrefixQuery>(query);

   }

   protected SpanQuery buildWildcardQuery(String field, String termText) throws ParseException{
      testLeadingWildcard(termText);
      String normalized = termText;

      switch(normMultiTerm){
      case NO_NORM:
         break;
      case LOWERCASE:
         normalized = normalized.toLowerCase(locale);
         break;
      case ANALYZE:
         normalized = analyzeWildcard(field, termText);
         break;
      }
      WildcardQuery wildcardQuery = new WildcardQuery(new Term(field, normalized));
      wildcardQuery.setRewriteMethod(multiTermRewriteMethod);
      return new SpanMultiTermQueryWrapper<WildcardQuery>(wildcardQuery);

   }

   /**
    * build what appears to be a simple single term query.  If the analyzer
    * breaks it into multiple terms, treat that as a "phrase" or as an "or"
    * depending on the value of {@link #autoGeneratePhraseQueries}.
    * @param field
    * @param termText
    * @return
    * @throws ParseException
    */
   protected SpanQuery buildSingleTermQuery(String field, String termText) throws ParseException{
      String[] terms = analyzeSimpleSingleTerm(termText);
      if (terms.length == 0){
         if (throwExceptionForStopWord){
            throw new ParseException(
                  String.format("No terms returned after I tried to normalize what I thought was a single term: %s", 
                        termText));
         } else{
            return getEmptyQuery();
         }
      } else if (terms.length == 1){
         return new SpanTermQuery(new Term(field, terms[0]));
      } else {
         //if the analyzer broke this into more than one term,
         //treat it as a boolean query or as a 
         //span near query with no slop and in order
         //depending on the value of autoGeneratePhraseQueries


         List<SpanQuery> nonEmpties = new LinkedList<SpanQuery>();
         for (String piece : terms){
            if (piece != null){
               nonEmpties.add(new SpanTermQuery(new Term(field, piece)));
            } else if (piece == null && throwExceptionForStopWord){
               throw new ParseException("Stop word found in "+termText);
            }
         }

         if (nonEmpties.size() == 0){
            return getEmptyQuery();
         }
         if (nonEmpties.size() == 1){
            return nonEmpties.get(0);
         }

         SpanQuery[] queries = nonEmpties.toArray(new SpanQuery[nonEmpties.size()]);
         if (getAutoGeneratePhraseQueries() == true){
            return new SpanNearQuery(queries, 0, true);
         } else {
            return new SpanOrQuery(queries);
         }
      }
   }

   /**
    * Does this start with a wildcard and is that allowed?
    * @param termText
    * @throws ParseException
    */
   private void testLeadingWildcard(String termText) throws ParseException{
      if (allowLeadingWildcard == false && (
            termText.startsWith("*") || termText.startsWith("?"))){
         throw new ParseException("'*' or '?' not allowed as first character in WildcardQuery with current configuration.");
      }
   }

   /**
    * Will build a SpanQuery clause from components and the ClauseInfo
    * 
    * @param clauses
    * @param clauseInfo
    * @return
    * @throws ParseException
    */
   protected SpanQuery buildQuery(List<SpanQuery> clauses, ClauseInfo clauseInfo) throws ParseException{

      if (clauseInfo.getType().equals(TYPE.OR)){
         return buildSpanOrQuery(clauses);
      } else if (clauseInfo.getType().equals(TYPE.NEAR)){
         SpanNearClauseInfo tmp = (SpanNearClauseInfo)clauseInfo;
         return buildSpanNearQuery(clauses, tmp.getSlop(), tmp.getInOrder());
      } else if (clauseInfo.getType().equals(TYPE.NOT_NEAR)){
         SpanNotNearClauseInfo tmp = (SpanNotNearClauseInfo)clauseInfo;
         return buildSpanNotNearQuery(clauses, tmp.getBefore(), tmp.getAfter());
      }
      throw new ParseException(
            String.format("I don't know how to build a query for a clause of type: %s"+
                  clauseInfo.getType()));
   }

   /**
    * 
    * @param clauses
    * @return {@link SpanOrQuery} might be empty if clauses is null or contains only 
    * empty queries
    */
   protected SpanQuery buildSpanOrQuery(List<SpanQuery> clauses){
      if (clauses == null || clauses.size() == 0)
         return getEmptyQuery();

      List<SpanQuery> nonEmpties = removeEmpties(clauses);
      if (nonEmpties.size() == 0){
         return getEmptyQuery();
      }
      if (nonEmpties.size() == 1)
         return nonEmpties.get(0);

      SpanQuery[] arr = nonEmpties.toArray(new SpanQuery[nonEmpties.size()]);
      return new SpanOrQuery(arr);

   }

   /**
    * 
    * @param clauses
    * @return {@link SpanOrQuery} or null if clauses is null or empty
    */
   protected SpanQuery buildSpanNearQuery(List<SpanQuery> clauses, int slop, boolean inOrder){
      if (clauses == null || clauses.size() == 0)
         return getEmptyQuery();

      List<SpanQuery> nonEmpties = removeEmpties(clauses);
      
      if (nonEmpties.size() == 0){
         return getEmptyQuery();
      }
      
      if (slop > spanNearMaxDistance){
         slop = spanNearMaxDistance;
      }
      
      if (nonEmpties.size() == 1){
         return specialHandlingForSpanNearWithOneComponent(nonEmpties.get(0), slop, inOrder);
      }

      SpanQuery[] arr = nonEmpties.toArray(new SpanQuery[nonEmpties.size()]);
      return new SpanNearQuery(arr, slop, inOrder);
   }

   /**
    * This is meant to "fix" two cases that might be surprising to
    * a non-whitespace language speaker. 
    * If a user entered, e.g. "\u5927\u5B66"~3, and {@link #autoGeneratePhraseQueries} is set
    * to true, then the parser would treat this recursively
    * and yield [[\u5927\u5B66]]~3.  The user probably meant find those two characters
    * within three words of each other, not find those right next to each other and
    * that hit has to be within three words of nothing.
    * 
    * If a user entered the same thing and {@link #autoGeneratePhraseQueries} is set
    * to false, then the parser would treat this as [(\u5927\u5B66)]~3: find one character or the other
    * and then that hit has to be within three words of nothing.
    * 
    * This special handling does create incorrect handling for whitespace languages.
    * [[quick fox]]~1 should only match on "quick fox" and it will now match on "fox green quick".
    * 
    * The current method was chosen because the former use case is probably far more common than
    * the latter.
    * 
    * @param spanQuery this is the sole child of a SpanNearQuery
    * @param slop slop from the parent
    * @param inOrder inOrder from the parent
    * @return
    */
   private SpanQuery specialHandlingForSpanNearWithOneComponent(
         SpanQuery spanQuery, int slop, boolean inOrder) {
      
      if (spanQuery instanceof SpanNearQuery && autoGeneratePhraseQueries == true){
         SpanNearQuery q = (SpanNearQuery)spanQuery;
         if (q.isInOrder() && q.getSlop() == 0){
            
            SpanQuery[] children = q.getClauses();
            //if the grandchildren aren't all SpanTermQueries
            //then this can't be the edge case for the special handling
            for (SpanQuery c : children){
               if ( !(c instanceof SpanTermQuery)) {
                  return spanQuery;
               }
            }
            return new SpanNearQuery(children, slop, inOrder);
         }
      } else if (spanQuery instanceof SpanOrQuery && autoGeneratePhraseQueries == false){
         SpanOrQuery q = (SpanOrQuery)spanQuery;
         SpanQuery[] children = q.getClauses();
         for (SpanQuery c : children){
            if ( !(c instanceof SpanTermQuery)){
               return spanQuery;
            }
         }
         return new SpanNearQuery(children, slop, inOrder);
      }
      return spanQuery;
   }

   /**
    * 
    * @param clauses
    * @return {@link SpanOrQuery}
    */
   protected SpanQuery buildSpanNotNearQuery(List<SpanQuery> clauses, int pre, int post) throws ParseException{
      if (clauses.size() != 2){
         throw new ParseException(
               String.format("SpanNotNear query must have two clauses. I count %d", clauses.size()));
      }
      //if include is an empty query, treat this as just an empty query
      if (isEmptyQuery(clauses.get(0))){
         return clauses.get(0);
      }
      //if exclude is an empty query, return include alone
      if (isEmptyQuery(clauses.get(1))){
         return clauses.get(0);
      }


      if (pre > spanNotNearMaxDistance){
         pre = spanNotNearMaxDistance;
      }
      if (post > spanNotNearMaxDistance){
         post = spanNotNearMaxDistance;
      }
      return new SpanNotQuery(clauses.get(0), clauses.get(1), pre, post);
   }

   private List<SpanQuery> removeEmpties(List<SpanQuery> queries){

      List<SpanQuery> nonEmpties = new ArrayList<SpanQuery>();
      for (SpanQuery q : queries){
         if (!isEmptyQuery(q)){
            nonEmpties.add(q);
         }
      }
      return nonEmpties;
   }
   /**
    * @see #setNormMultiTerm(NormMultiTerm)
    * @return
    */
   public NormMultiTerm getNormMultiTerm() {
      return normMultiTerm;
   }

   /**
    * Set how the parser should analyze multiterms: {@link FuzzyQuery}, 
    * {@link RegexpQuery}, {@link WildcardQuery}.
    * 
    * <p><b>Warning (copied from AnalyzingQueryParser):</b> {@link NormMultiTerm.ANALZYE} should only be used 
    * with analyzers that do not use stopwords
    * or that add tokens. Also, several stemming analyzers are inappropriate: for example, GermanAnalyzer 
    * will turn <code>H&auml;user</code> into <code>hau</code>, but <code>H?user</code> will 
    * become <code>h?user</code> when using this parser and thus no match would be found (i.e.
    * using this parser will be no improvement over {@link NormMultiTerm.LOWERCASE} in such cases).
    * 
    * @param normMultiTerm
    */
   public void setNormMultiTerm(NormMultiTerm normMultiTerm) {
      this.normMultiTerm = normMultiTerm;
   }


   /**
    * Sets an upper limit on the maximum distance for a not near query.
    * If {@link #spanNotNearMaxDistance} is set to 10, and a query of "foo bar"~20,8 is parsed,
    * the returned query will be for a {@link SpanNotQuery} with a pre value of 10 and a post value of 8.
    * The default is 50.
    * @param dist the max distance
    */
   public void setSpanNotNearMaxDistance(int dist){
      assert(dist >= 0);
      spanNotNearMaxDistance = dist;
   }

   /**
    * @see #setSpanNearMaxDistance(int)
    */
   public int getSpanNotNearMaxDistance(){
      return spanNotNearMaxDistance;
   }

   /**
    * @see #setSpanNearMaxDistance(int)
    */
   public int getSpanNearMaxDistance(){
      return spanNearMaxDistance;
   }
   /**
    * Sets an upper limit on the maximum distance for a phrase/near query.
    * If {@link #spanNearMaxDistance} is set to 10, and a query of "foo bar"~20 is parsed,
    * the returned query will be for a {@link SpanNearQuery} with a distance of 10.
    * The default is 100.
    * @param dist the max distance
    */
   public void setSpanNearMaxDistance(int dist){
      assert(dist >= 0);
      spanNearMaxDistance = dist;
   }

   /**
    * @see #getThrowExceptionForStopWord()
    */
   public boolean getThrowExceptionForStopWord(){
      return throwExceptionForStopWord;
   }

   /**
    * If a stopword is encountered during parsing, should the parser throw a ParseException
    * or ignore the stopword?
    * @param toThrowOrNotToThrow
    */
   public void setThrowExceptionForStopWord(boolean toThrowOrNotToThrow){
      throwExceptionForStopWord = toThrowOrNotToThrow;
   }

   /**
    * Returns the analyzed form for the given chunk
    * 
    * If the analyzer produces more than one output token from the given chunk,
    * a ParseException is thrown.
    *
    * @param field The target field
    * @param termStr The full term from which the given chunk is excerpted
    * @param chunk The portion of the given termStr to be analyzed
    * @return The result of analyzing the given chunk
    * @throws ParseException when analysis returns other than one output token
    */
   protected String analyzeSingleChunk(String field, String termStr, String chunk) throws ParseException{
      //plagiarized from AnalyzingQueryParser
      String analyzed = null;
      TokenStream stream = null;
      try{
         stream = getAnalyzer().tokenStream(field, chunk);
         stream.reset();
         CharTermAttribute termAtt = stream.getAttribute(CharTermAttribute.class);
         // get first and hopefully only output token
         if (stream.incrementToken()) {
            analyzed = termAtt.toString();

            // try to increment again, there should only be one output token
            StringBuilder multipleOutputs = null;
            while (stream.incrementToken()) {
               if (null == multipleOutputs) {
                  multipleOutputs = new StringBuilder();
                  multipleOutputs.append('"');
                  multipleOutputs.append(analyzed);
                  multipleOutputs.append('"');
               }
               multipleOutputs.append(',');
               multipleOutputs.append('"');
               multipleOutputs.append(termAtt.toString());
               multipleOutputs.append('"');
            }
            stream.end();
            stream.close();
            if (null != multipleOutputs) {
               throw new ParseException(
                     String.format(getLocale(),
                           "Analyzer created multiple terms for \"%s\": %s", chunk, multipleOutputs.toString()));
            }
         } else {
            // nothing returned by analyzer.  Was it a stop word and the user accidentally
            // used an analyzer with stop words?
            stream.end();
            stream.close();
            throw new ParseException(String.format(getLocale(), "Analyzer returned nothing for \"%s\"", chunk));
         }
      } catch (IOException e){
         throw new ParseException(
               String.format(getLocale(), "IO error while trying to analyze single term: \"%s\"", termStr));
      }
      return analyzed;
   }

   private String analyzeWildcard(String field, String termText) throws ParseException{
      //plagiarized from AnalyzingQueryParser
      Matcher wildcardMatcher = WILDCARD_PATTERN.matcher(termText);
      StringBuilder sb = new StringBuilder();
      int last = 0;

      while (wildcardMatcher.find()){
         // continue if escaped char
         if (wildcardMatcher.group(1) != null){
            continue;
         }

         if (wildcardMatcher.start() > 0){
            String chunk = termText.substring(last, wildcardMatcher.start());
            String analyzed = analyzeSingleChunk(field, termText, chunk);
            sb.append(analyzed);
         }
         //append the wildcard character
         sb.append(wildcardMatcher.group(2));

         last = wildcardMatcher.end();
      }
      if (last < termText.length()){
         sb.append(analyzeSingleChunk(field, termText, termText.substring(last)));
      }
      return sb.toString();
   }

   private SpanQuery getEmptyQuery(){
      SpanQuery q = new SpanOrQuery(new SpanTermQuery[0]);
      return q;
   }

   private boolean isEmptyQuery(SpanQuery q){
      if (q instanceof SpanOrQuery 
            && ((SpanOrQuery)q).getClauses().length == 0){
         return true;
      }
      return false;
   }

}
