/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance;
import java.util.Map;

import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttributeImpl;

import org.apache.lucene.search.concordance.charoffsets.TargetTokenNotFoundException;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetResults;

/**
 * 
 * Builds a {@link ConcordanceWindow}
 *
 */
public class WindowBuilder {
	
   private final static String SPACE = " ";
	private final static String EMPTY_STRING = "";
	public static String INTER_MULTIVALUE_FIELD_PADDING = SPACE;

	
	/**
	 * Makes the assumption that the target token start and target token end 
	 * can be found.  If not, this returns a null.
	 * @param docID
	 *   Lucene internal docid, used only if sort type is DOC
	 * @param targetTokenStart
	 *   Target's start token
	 *   
	 * @param targetTokenEnd
	 *   Target's end token
	 * @param metadata
	 *   Metadata to be stored with the window
	 * @param config
	 *   ConcordanceConfig
	 * @param s
	 *   Original content string
	 * @param offsets
	 *   TokenOffsetResults from 
	 * @return
	 *   ConcordanceWindow or null if character offset information cannot be found for
	 *   both the targetTokenStart and the targetTokenEnd
	 */
	public ConcordanceWindow buildConcordanceWindow(long docID, int targetTokenStart, 
			int targetTokenEnd,
			Map<String, String> metadata,
			ConcordanceConfig config, String[] fieldValues, TokenCharOffsetResults offsets) 
			      throws TargetTokenNotFoundException, IllegalArgumentException{
	   
	   if (targetTokenStart < 0 || targetTokenEnd < 0){
	      throw new IllegalArgumentException("targetTokenStart and targetTokenEnd must be >= 0");
	   }
	   if (targetTokenEnd < targetTokenStart){
	      throw new IllegalArgumentException("targetTokenEnd must be >= targetTokenStart");
	   }
      int startFieldIndex = offsets.getFieldIndex(targetTokenStart);
      int endFieldIndex = offsets.getFieldIndex(targetTokenEnd);
	   /*if (fieldIndex != offsets.getFieldIndex(targetTokenEnd)){
	      //you're asking for a window across different entries in a field.
	      //no soup for you.
	      throw new IllegalArgumentException("Can't request a window across different field indices in a multi-valued field");
	   }*/
	   if (startFieldIndex < 0 || endFieldIndex < 0){
	      //target not found
	      throw new IllegalArgumentException("field index must be >= 0");
	   }
	   if (startFieldIndex >= fieldValues.length || endFieldIndex >= fieldValues.length){
	      //something went horribly wrong.
	      //can't ask for a window from array index out of bounds exception
	      throw new IllegalArgumentException("fieldIndex out of bounds exception");
	   }
      String startS = fieldValues[startFieldIndex];
      String endS = (startFieldIndex == endFieldIndex) ? startS : fieldValues[endFieldIndex];
	   if (startS == null || endS == null){
	      //something went horribly wrong.
	      throw new IllegalArgumentException("field value is null");
	   }
	   int targetCharStart = offsets.getCharacterOffsetStart(targetTokenStart);
	   int targetCharEnd = offsets.getCharacterOffsetEnd(targetTokenEnd);
	   
	   if (targetCharStart < 0 || targetCharEnd < 0){
	      throw new TargetTokenNotFoundException("couldn't find character offsets for a target token.\n"+
	      "Check that your analyzers are configured properly.\n");
	   }
	   
		OffsetAttribute preOffset = getPreOffset(startFieldIndex, targetTokenStart, targetCharStart, config, startS, offsets);
      String preString = silentlySafeSubstring(startS, preOffset);
	
		OffsetAttribute postOffset = getPostOffset(endFieldIndex, targetTokenEnd, targetCharEnd, config, endS, offsets);
      String postString = silentlySafeSubstring(endS, postOffset);
		
      String targ = getTargetString(targetTokenStart, targetTokenEnd, targetCharStart, 
            targetCharEnd, fieldValues, offsets);
		
      String sortKey = getSortKey(docID, startFieldIndex, endFieldIndex, targetTokenStart, targetTokenEnd, config, offsets);
		int charStart = (preOffset == null) ? targetCharStart : preOffset.startOffset();
		int charEnd = (postOffset == null) ? targetCharEnd : postOffset.endOffset();
		return new ConcordanceWindow(docID, charStart, charEnd, preString, targ, postString, 
				sortKey, metadata);
	}
	
	private String getTargetString(int targetTokenStart, int targetTokenEnd,
         int targetCharStart, int targetCharEnd, String[] fieldValues,
         TokenCharOffsetResults offsets) {
	   
	   int startIndex = offsets.getFieldIndex(targetTokenStart);
	   int endIndex = offsets.getFieldIndex(targetTokenEnd);
	   
      if (startIndex == endIndex){
         String s = fieldValues[startIndex];
         return silentlySafeSubstring(s, targetCharStart, targetCharEnd);
      }
      StringBuilder sb = new StringBuilder();
      String fStart = fieldValues[startIndex];
      sb.append(fStart.substring(targetCharStart));
      for (int i = startIndex+1; i < endIndex; i++){
         sb.append(INTER_MULTIVALUE_FIELD_PADDING);
         sb.append(fieldValues[i]);
      }
      sb.append(INTER_MULTIVALUE_FIELD_PADDING);
      sb.append(fieldValues[endIndex].substring(0,targetCharEnd));
      return sb.toString();
   }

   private String getSortKey(long docID, int startFieldIndex, int endFieldIndex, int start, int end, 
			ConcordanceConfig config, TokenCharOffsetResults charOffsets){
	   //TODO: Create interface for sort key generator
	   //for room to grow.  Hard coded for now.
	   
		StringBuilder sb = new StringBuilder();
		ConcordanceSortOrder sortOrder = config.getSortOrder();
		if (sortOrder == ConcordanceSortOrder.NONE){
			return EMPTY_STRING;
		}
		//hack zero left pad the tokenoffset with 10 0's
		if (sortOrder == ConcordanceSortOrder.DOC){
         String docIDString = padLeft(10, "0", Long.toString(docID));
         String startOffsetString = padLeft(10, "0", 
					Integer.toString(start));
			sb.append(docIDString).append(SPACE).append(startOffsetString);
		}
		
		if (sortOrder == ConcordanceSortOrder.TARGET_POST ||
				sortOrder == ConcordanceSortOrder.TARGET_PRE){
		   
			for (int i = start; i <= end; i++){
				String tmp = charOffsets.getTerm(i);
				if (tmp != null && tmp.length() > 0)
					sb.append(tmp + " ");
			}
		}
		if (sortOrder == ConcordanceSortOrder.PRE ||
				sortOrder == ConcordanceSortOrder.TARGET_PRE){
			int tmpStart = start-1;
			int tmpEnd = Math.max(0, start-config.getTokensBefore());
			if (tmpStart < 0){
				sb.append(" ");
			}
		
			for (int i = tmpStart; i >= tmpEnd; i--){
			   if (charOffsets.getFieldIndex(i) == startFieldIndex){
			      String tmp = charOffsets.getTerm(i);
			      if (tmp != null && tmp.length() > 0){
			         sb.append(tmp + " ");
			      }
			   } else {
			      break;
			   }
			}

		} else if (sortOrder == ConcordanceSortOrder.POST ||
				sortOrder == ConcordanceSortOrder.TARGET_POST){
			
			int tmpStart = end+1;
			int tmpEnd = Math.min(end+config.getTokensAfter(), charOffsets.getLast());
		
			if (tmpStart > charOffsets.getLast()){
				sb.append(" ");
			}
			for (int i = tmpStart; i <= tmpEnd; i++){
			   if (charOffsets.getFieldIndex(i) == endFieldIndex){
			      String tmp = charOffsets.getTerm(i);
			      if (tmp != null && tmp.length() > 0){
			         sb.append(tmp).append(SPACE);
			      }
			   } else {
			      break;
			   }
			}
		}
		return sb.toString().trim();
	}
	
	private OffsetAttribute getPreOffset(int fieldIndex, int targetTokenStart, int targetCharStart, 
	      ConcordanceConfig config, String s, TokenCharOffsetResults charOffsets){
		if (config.getTokensBefore() == 0)
			return null;
		
		if (targetTokenStart == 0){
		   return null;
		}
		int startTokenOffset = Math.max(0, targetTokenStart-config.getTokensBefore());
		
		int windowStartChar = charOffsets.getClosestCharStart(fieldIndex, startTokenOffset, targetTokenStart);
		
		int windowEndChar = Math.max(windowStartChar, targetCharStart-1);
		
		return buildOffsetAttribute(windowStartChar, windowEndChar);
	}
	
	
	private OffsetAttribute getPostOffset(int fieldIndex, int targetTokenEnd, int targetCharEnd, 
	      ConcordanceConfig config, String s, TokenCharOffsetResults charOffsets){
		if (config.getTokensAfter() == 0)
			return null;
		int windowTokenEnd = targetTokenEnd+config.getTokensAfter();
		int windowCharStart = targetCharEnd;
		int windowCharEnd = charOffsets.getClosestCharEnd(fieldIndex, windowTokenEnd, targetTokenEnd+1);
		if (windowCharStart >= windowCharEnd){
			return null;
		}
		return buildOffsetAttribute(windowCharStart, windowCharEnd);
	}
	
	private OffsetAttribute buildOffsetAttribute(int start, int end){
      OffsetAttribute off = new OffsetAttributeImpl();
      off.setOffset(start, end);
	   return off;
	}
		
	private String padLeft(int number, String add, String s){
      if (s.length() >= number)
         return s;
               
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < number- s.length(); i++){
         sb.append(add);
      }
      sb.append(s);
      return sb.toString();
   }
	
	private String silentlySafeSubstring(String s, OffsetAttribute offset){
	   if (offset == null)
	      return EMPTY_STRING;
	   
	   return silentlySafeSubstring(s, offset.startOffset(), offset.endOffset());
	}
	
	private String silentlySafeSubstring(String s, int startOffset, int endOffset){

		if (startOffset >= endOffset || startOffset < 0 || 
				startOffset >= s.length() || endOffset > s.length()){
			return EMPTY_STRING;
		}
		//make a new string so that Java cuts off a new string and doesn't keep
		//the old full string in memory; no longer needed in java 7
		return new String(s.substring(startOffset, endOffset));
	}

}
