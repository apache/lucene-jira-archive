/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.lucene.queries.ChainedFilter;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.Filter;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.QueryWrapperFilter;
import org.apache.lucene.search.concordance.charoffsets.DocTokenOffsets;
import org.apache.lucene.search.concordance.charoffsets.DocTokenOffsetsIterator;
import org.apache.lucene.search.concordance.charoffsets.OffsetLengthStartComparator;
import org.apache.lucene.search.concordance.charoffsets.ReanalyzingTokenCharOffsetsReader;
import org.apache.lucene.search.concordance.charoffsets.TargetTokenNotFoundException;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetsReader;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetRequests;
import org.apache.lucene.search.concordance.charoffsets.TokenCharOffsetResults;
import org.apache.lucene.search.spans.SpanQuery;
import org.apache.lucene.util.OpenBitSet;

import org.apache.lucene.analysis.Analyzer;


import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.StoredDocument;


import org.apache.lucene.search.concordance.charoffsets.OffsetUtil;
/**
 * Searches an IndexReader and returns concordance windows via ConcordanceResults.
 * 
 * 
 *
 */
public class ConcordanceSearcher {
   /**
    * 
    * @param reader
    * @param query if SpanQuery, this gets passed through.  If a regular Query, the Query is first
    *    converted to a SpanQuery and the filter is modified to include the original Query.
    * @param filter
    * @param analyzer
    * @param config
    * @param metadataExtractor a simple extractor that a user can implement to pull out custom
    * metadata from the document for each window.
    *    
    * @return ConcordanceRestuls
    * @throws ParseException
    * @throws TargetTokenNotFoundException
    * @throws IllegalArgumentException
    * @throws IOException
    */
   public ConcordanceResults search(IndexReader reader, Query query, Filter filter,
         Analyzer analyzer,
         ConcordanceConfig config, DocumentMetadataExtractor metadataExtractor)
               throws ParseException, TargetTokenNotFoundException,IllegalArgumentException,IOException{
      
      if (query instanceof SpanQuery){
         //pass through
         return searchSpan(reader, (SpanQuery)query, filter, analyzer, config, metadataExtractor);
      } else {
         //convert regular query to a SpanQuery.
         SpanQueryConverter converter = new SpanQueryConverter();
         SpanQuery spanQuery = converter.convert(config.getFieldName(), query);
         
         Filter origQueryFilter = new QueryWrapperFilter(query);
         Filter updatedFilter = origQueryFilter;
         
         if (filter != null){
            updatedFilter = new ChainedFilter(new Filter[]{origQueryFilter, filter}, ChainedFilter.AND);
         }
         return searchSpan(reader, spanQuery, updatedFilter, analyzer, config, metadataExtractor);
      }
   }

   /**
    * Like {@link #search(IndexReader, Query, Filter, Analyzer, ConcordanceConfig, DocumentMetadataExtractor)},
    * but this takes an actual SpanQuery.   
    * @param reader
    * @param spanQuery
    * @param filter
    * @param analyzer
    * @param config
    * @param metadataExtractor
    * @return
    * @throws ParseException
    * @throws TargetTokenNotFoundException
    * @throws IllegalArgumentException
    * @throws IOException
    */
	public ConcordanceResults searchSpan(IndexReader reader, SpanQuery spanQuery, Filter filter,
			Analyzer analyzer,
			ConcordanceConfig config, DocumentMetadataExtractor metadataExtractor) 
					throws ParseException, TargetTokenNotFoundException,IllegalArgumentException,IOException {
	   spanQuery = (SpanQuery)spanQuery.rewrite(reader);
		DocTokenOffsetsIterator itr = new DocTokenOffsetsIterator();
	    Set<String> fields = new HashSet<String>(metadataExtractor.getFieldSelector());
	      fields.add(config.getFieldName());
		itr.reset(spanQuery, filter, reader, fields);
		return buildResults(itr, reader, analyzer, config, metadataExtractor);

	}


	private ConcordanceResults buildResults(DocTokenOffsetsIterator itr, IndexReader reader, 
			Analyzer analyzer,
			ConcordanceConfig config, DocumentMetadataExtractor metadataExtractor) throws IllegalArgumentException,
			TargetTokenNotFoundException, IOException {
		List<ConcordanceWindow> windows = new LinkedList<ConcordanceWindow>();
		
		boolean stop = false;
		int totalNumDocs = reader.numDocs();

		int numTotalWindows = 0;

		TokenCharOffsetRequests requests;
		WindowBuilder windowBuilder = new WindowBuilder();
		TokenCharOffsetsReader tokenOffsetsRecordReader = new ReanalyzingTokenCharOffsetsReader(analyzer);

		TokenCharOffsetResults offsetResults = new TokenCharOffsetResults();
		OpenBitSet docIDs = new OpenBitSet();
		DocTokenOffsets result = null;
		OffsetLengthStartComparator offsetLengthStartComparator = new OffsetLengthStartComparator();
		while (itr.next() && ! stop){
			result = itr.getDocTokenOffsets();
			StoredDocument document = result.getDocument();

			docIDs.set(result.getUniqueDocId());
			

			String[] fieldValues = document.getValues(config.getFieldName());
			if (fieldValues.length == 0){
				throw new IllegalArgumentException("did you forget to load or specify the correct content field?!");
			}
			
			Map<String, String> metadata = metadataExtractor.extract(document);
			List<OffsetAttribute> offsets = result.getOffsets();
			if (! config.isAllowTargetOverlaps()){
				//remove overlapping hits!!!
				offsets = OffsetUtil.removeOverlapsAndSort(offsets, offsetLengthStartComparator, null);
			}
			//get the required character offsets
			requests = ConcordanceSearcherUtil.getCharOffsetRequests(offsets, config);
			offsetResults.clear(); 

			offsetResults = tokenOffsetsRecordReader.getTokenCharOffsetResults(document, 
                  config.getFieldName(), requests, offsetResults);
			
			
			for (OffsetAttribute offset : offsets){	   
			   
				ConcordanceWindow w = windowBuilder.buildConcordanceWindow(result.getUniqueDocId(), offset.startOffset(),
						offset.endOffset()-1,
						metadata, config, fieldValues, offsetResults);

					windows.add(w);
				numTotalWindows++;
				if (config.getMaxWindows() > -1 && windows.size() >= config.getMaxWindows()){
					stop = true;
					break;
				}
			}
		
		}

		ConcordanceResults results = new ConcordanceResults(windows, docIDs, totalNumDocs, numTotalWindows, stop);
		return results;
	}

}
