/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.search.concordance;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ArrayList;

import org.apache.lucene.util.OpenBitSet;

/**
 * Results of a concordance search.  This includes windows and information about the search.
 *
 */

public class ConcordanceResults {
	private final List<ConcordanceWindow> windows;
	private final boolean hitMax; //did the search hit the maximum number of windows

	private int numTotalWindows;
	private int numTotalDocs;
	private OpenBitSet docIDs; //underlying Lucene document ids that had a hit.
	
	public ConcordanceResults(){
		windows = new LinkedList<ConcordanceWindow>();
		hitMax = false;
		numTotalWindows = 0;
		numTotalDocs = 0;
		docIDs = new OpenBitSet();
	}
	
	public ConcordanceResults(List<ConcordanceWindow> windows, OpenBitSet docIDs2, int numTotalDocs, int numTotalWindows, boolean hitMax){
		this.windows = windows;
		this.hitMax = hitMax;
		this.docIDs = docIDs2.clone();
		this.numTotalWindows = numTotalWindows;
		this.numTotalDocs = numTotalDocs;
	}
	
	/**
	 * Sorts the windows according to the windows' sortKey and returns the list.
	 * Does not perform defensive copying of list, and the underlying list's order is changed
	 * by this call.
	 * 
	 * @return
	 */
	public List<ConcordanceWindow> getSortedWindows(){
		Collections.sort(windows, new ConcordanceSorter());
		return windows;
	}
	
	/**
	 * Gets the windows in whatever order they are currently in...
	 * could be insertion order or could be sorted order depending on whether
	 * {@link #getSortedWindows()} has been called.
	 * 
	 * {@see #getSortedWindows()}
	 * @return
	 */
	public List<ConcordanceWindow> getWindows(){
		return windows;
	}
	
	public boolean getHitMax(){
		return hitMax;
	}
	
	public int getNumWindows(){
		return windows.size();
	}
	
	public long getNumDocs(){
		return docIDs.cardinality();
	}
	
	public int getNumTotalDocs(){
		return numTotalDocs;
	}
	
	public int getNumTotalWindows(){
		return numTotalWindows;
	}
	
	/**
	 * The caller must beware not to add duplicate windows.  This call does not check
	 * for duplicates.
	 * 
	 * The purpose of this is to allow a union of concordance results from multiple
	 * concordance searches (e.g. concordance results
	 * across different fields).  This assumes that the underlying Lucene document id
	 * has not changed across the multiple searches!!!
	 * 
	 * @param results
	 */
	public void addAll(ConcordanceResults results){
		windows.addAll(results.getWindows());
		docIDs.or(results.getDocIDs());
		
		numTotalWindows = windows.size();
		numTotalDocs += results.numTotalDocs;
	}
	
	public OpenBitSet getDocIDs(){
		return docIDs;
	}
	
	public void setDocIDs(OpenBitSet docIDs){
		this.docIDs = docIDs;
	}	
}
