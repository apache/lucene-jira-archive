/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.queryparser.span;

import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.lucene.analysis.tokenattributes.OffsetAttribute;
import org.apache.lucene.analysis.tokenattributes.OffsetAttributeImpl;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.span.clauses.ClauseInfo;
import org.apache.lucene.queryparser.span.clauses.ClauseInfoBuilder;



/**
 * Utility class to to handle parsing 
 *
 */

public class SpanQueryParserUtil {
	
	private final static String nearOpen = "[";
	private final static String nearClose = "]";	
	private final static String orOpen = "(";	
	private final static String orClose = ")";
	
	private final Set<String> requiredRegexPres;
	private final Set<String> requiredRegexPosts;
	private final static String clauseString = "\\"+nearOpen+"\\"+
			nearClose+"\\"+orOpen+"\\"+orClose;
	private final static String numberString = "(?:(\\d+)(?:,(\\d+))?)?";
	private final static Pattern CLAUSE_PATTERN = 
	      Pattern.compile("(?s)(["+clauseString+"])(?:(!?~>?)" + numberString+")?");
	
   private final static Pattern ESCAPES_PATTERN = Pattern.compile("(\\\\.)");
   private final static Pattern REGEX_PATTERN = Pattern.compile("(\\\\/|/)");
   private final static Pattern WHITE_SPACE_PATTERN = Pattern.compile("\\s+");
   private final static Pattern WHITE_SPACE_ONLY_PATTERN = Pattern.compile("^\\s*$"); 



	
	public SpanQueryParserUtil(){
		requiredRegexPres = new HashSet<String>();
		requiredRegexPres.add("(");
		requiredRegexPres.add("[");
		requiredRegexPres.add(" ");
		
		requiredRegexPosts = new HashSet<String>();
		requiredRegexPosts.add(")");
		requiredRegexPosts.add("]");
		requiredRegexPosts.add(" ");
	}
	/**
	 * rewrite double quotes to [ ]
	 * @param s string
	 * @param escapedChars escaped characters
	 * @return rewritten query
	 */
	protected String rewriteDoubleQuotes(String s, Set<Integer> escapedChars){
		Matcher dMatcher = Pattern.compile("\"").matcher("");//"
		int last = 0;
		dMatcher.reset(s);
		int i = 0;
		StringBuilder sb = new StringBuilder();
		while (dMatcher.find()){
			if ( escapedChars.contains(dMatcher.start())){
				continue;
			}
			sb.append(s.substring(last, dMatcher.start()));
			if (i%2 == 0){
				sb.append("[");
			} else {
				sb.append("]");
			}
			last = dMatcher.end();
			i++;
		}
		sb.append(s.substring(last));
		return sb.toString();
	}

	/**
	 * get a list of all clause markers
	 * @param s full query string
	 * @param regexes list of regex extents
	 * @param escapedChars set of escaped characters
	 * @return list of start and end clause markers
	 * @throws ParseException
	 */
	protected List<ClauseInfo> getClauseMarkers(String s, List<OffsetAttribute> regexes, 
	      Set<Integer> escapedChars) throws ParseException{
		//Set<Integer> escapedChars = getEscaped(s);
		Set<Integer> inRegex = new HashSet<Integer>();
		for (OffsetAttribute regex : regexes){
			for (int i = regex.startOffset(); i < regex.endOffset(); i++){
				inRegex.add(i);
			}
		}

		Matcher clauseMatcher = CLAUSE_PATTERN.matcher(s);
		List<ClauseInfo> markers = new ArrayList<ClauseInfo>();
		while (clauseMatcher.find()){
			//System.out.println(clauseMatcher.group(0));
			if (inRegex.contains(clauseMatcher.start())){
				
				continue;
			}
			if (escapedChars.contains(clauseMatcher.start())){
				
				continue;
			}

			ClauseInfo marker = buildClauseMarker(clauseMatcher);
			//System.out.println(marker.getStart() + " : " + marker.getEnd());
			markers.add(marker);
		}

		return markers;
	}
	
	/**
	 * builds ClauseMarker based on a matcher that has a match
	 * to a clause marker 
	 * @param m
	 * @return
	 * @throws ParseException
	 */
	private ClauseInfo buildClauseMarker(Matcher m) throws ParseException{
		ClauseInfo.TYPE type = null;
		ClauseInfo.START_OR_END startOrEnd = null;
		
		//basic marker
		String marker = m.group(1);
		
		//near or not near
		String whichNear = m.group(2);
		
		//first bit of digits as in the "2" in [foo bar]~2"
		String firstDigits = m.group(3);
		//second bit of digits as in the "3" in [foo bar]!~2,3"
		//should only be non-null for not near query
		String secondDigits = m.group(4);
		int offsetStart = m.start();
		int offsetEnd = m.end();

		if (marker.equals(nearOpen)){
			type = ClauseInfo.TYPE.NEAR;
			startOrEnd = ClauseInfo.START_OR_END.START;
		} else if (marker.equals(orOpen)){
			type = ClauseInfo.TYPE.OR;
			startOrEnd = ClauseInfo.START_OR_END.START;
		} else if (marker.equals(orClose)){
			type = ClauseInfo.TYPE.OR;
			startOrEnd = ClauseInfo.START_OR_END.END;	
		} else if (marker.equals(nearClose) && whichNear == null){
			type = ClauseInfo.TYPE.NEAR;
			startOrEnd = ClauseInfo.START_OR_END.END;				
		}
		if (type != null && startOrEnd != null){
			return ClauseInfoBuilder.build(startOrEnd, type, offsetStart, offsetEnd);
		}
		//spanNotNear
		if (whichNear.startsWith("!")){
			if (firstDigits == null){
				return ClauseInfoBuilder.build(ClauseInfo.START_OR_END.END, ClauseInfo.TYPE.NOT_NEAR,  offsetStart, offsetEnd);
			}

			//there is a single slop value
			if (firstDigits != null && secondDigits == null){
				int slop = 0;
				try{
					slop = Integer.parseInt(firstDigits);	
				} catch(NumberFormatException e){
					throw new ParseException(
						String.format("There should have been an integer here in span not near query: %s",
								firstDigits));
				}
				return ClauseInfoBuilder.build(ClauseInfo.START_OR_END.END, offsetStart, offsetEnd, slop, slop);
			}
			if (firstDigits != null && secondDigits != null){
				int pre = 0;
				try{
					pre = Integer.parseInt(firstDigits);	
				} catch(NumberFormatException e){
					throw new ParseException(
							String.format("There should have been an integer here in span not near query: %s",
							firstDigits));
				}
				int post = 0;
				try{
					post = Integer.parseInt(secondDigits);	
				} catch(NumberFormatException e){
					throw new ParseException(
							String.format("There should have been an integer here in span not near query: %s",
									secondDigits));
				}

				return ClauseInfoBuilder.build(ClauseInfo.START_OR_END.END, offsetStart, offsetEnd, pre, post);
			}

		} else {
			boolean inOrder = false;
			//[foo bar]~ matches "foo bar" and "bar foo"
			if (whichNear.equals("~") && firstDigits == null){
				return ClauseInfoBuilder.build(ClauseInfo.START_OR_END.END, offsetStart, offsetEnd, 0, inOrder);
			}
			
			if (whichNear.endsWith(">")){
				inOrder = true;	
			}
			//[foo bar]~> 
			if (firstDigits == null){
				return ClauseInfoBuilder.build(ClauseInfo.START_OR_END.END, offsetStart, offsetEnd, 0, inOrder);
			}
			int slop = 0;
			try{
				slop = Integer.parseInt(firstDigits);	
			} catch(NumberFormatException e){
				throw new ParseException(
							"A span-near query should have a slop value of only one number.");
			}
			return ClauseInfoBuilder.build(ClauseInfo.START_OR_END.END, offsetStart, offsetEnd, slop, inOrder);
		}
		throw new ParseException(
				String.format("Failed to parse: %s and its attributes", marker));

	}
	/**
	 * From a full list of clause markers for the string, find
	 * the closing clause marker for the marker at {start}
	 * 
	 * @param clauses
	 * @param start
	 * @return offset in the list of clausemarkers where the match is
	 * @throws ParseException if the matching marker couldn't be found
	 */
	protected int findMatching(List<ClauseInfo> clauses, int start) throws ParseException{
		ClauseInfo startMarker = clauses.get(start);
		int depth = 0;
		for (int i = start; i < clauses.size(); i++){
			if (ClauseInfo.matchOpenClose(startMarker, clauses.get(i))){
				depth++;	
			} else if (startMarker.getType().equals(clauses.get(i).getType())){
				depth--;	
			}

			if (depth == 0)
				return i;

			if (depth > 0)
				throw new ParseException("too many end markers");

		}
		throw new ParseException("couldn't find matching clause markers");
	}

	/**
	 * Extracts terms from a string that may contain regexes but contains no clausal boundaries.
	 * For example, you would pass "foo /bat/ bar" from the larger query
	 * [ pre [ foo /bat/ bar] post]~10
    * This extracts terms from the target span of a full string.
	 * @param s
	 * @param targetSpanStart
	 * @param targetSpanEnd
	 * @param regexes list of regexes within the full string
	 * @param escapedChars set of escaped chars within the full string
	 * @return
	 */
	protected List<String> extractTermStringsBasedOnWhitespace(String s, int targetSpanStart, int targetSpanEnd, 
			List<OffsetAttribute> regexes, Set<Integer> escapedChars){
		//This is meant to extract terms from a string that may contain regexes but contains no clausal boundaries.
		//This extracts Terms from the target span of a full String.
		List<String> terms = new ArrayList<String>();
		
		//end early if start == end
		if (targetSpanStart >= targetSpanEnd){
			return terms;
		}
		int tmpStart = targetSpanStart;
		for (OffsetAttribute regex : regexes){
			if (regex.endOffset() < targetSpanStart){
				continue;
			} else if (regex.startOffset() > targetSpanEnd){
				break;
			}
			if (regex.startOffset()-1 >= 0){
				//extract terms before the regex
				List<String> tmp = extractTermsBasedOnWhitespace(s, tmpStart, (regex.startOffset()-1), escapedChars);
				terms.addAll(tmp);
				//extract regex	
				terms.add(s.substring(regex.startOffset(), regex.endOffset()+1));
			}

			tmpStart = regex.endOffset()+1;
		}
		//extract terms after regex		
		List<String> tmp = extractTermsBasedOnWhitespace(s, tmpStart, targetSpanEnd, escapedChars);
		terms.addAll(tmp);
		return terms;
	}
	
   /**
    * This is meant to extract terms from a string that contains no clausal 
    * boundaries and no regexes.
    * 
    * This extracts Strings from the target span of a full String.
    * This unescapes the strings.
    * 
    * You still need to use an analyzer for non-whitespace languages 
    * to break up the returned strings into tokens
    * 
    * @param s
    * @param targetSpanStart
    * @param targetSpanEnd
    * @param escapedChars
    * @return
    */

	protected List<String> extractTermsBasedOnWhitespace(String s, int targetSpanStart, int targetSpanEnd,
			Set<Integer> escapedChars){
		List<String> termStrings = new ArrayList<String>();
		//stop early if the start and end are ==
		if (targetSpanStart >= targetSpanEnd){
			return termStrings;
		}
		Matcher whiteSpaceSplitter = WHITE_SPACE_PATTERN.matcher(s);
		Matcher unescaper = ESCAPES_PATTERN.matcher("");
		Matcher whiteSpaceOnly = WHITE_SPACE_ONLY_PATTERN.matcher("");
		int start = targetSpanStart;
		int last = start;

		whiteSpaceSplitter = whiteSpaceSplitter.region(targetSpanStart, targetSpanEnd);
		while (whiteSpaceSplitter.find()){
			start = whiteSpaceSplitter.end();
			if (escapedChars.contains(whiteSpaceSplitter.start())){
				continue;
			}
			String tmp = s.substring(last,whiteSpaceSplitter.start());
			if (! whiteSpaceOnly.reset(tmp).find()){
				unescaper.reset(tmp);
				tmp = unescaper.replaceAll("$1");

				termStrings.add(tmp);
			}
			last = whiteSpaceSplitter.end();
		}
		String tmp = s.substring(last,targetSpanEnd);
		if (! whiteSpaceOnly.reset(tmp).find()){
			unescaper.reset(tmp);
			tmp = unescaper.replaceAll("$1");
			termStrings.add(tmp);
		}
		return termStrings;
	}
	/**
	 * Extracts the regex extents within the string
	 * 
	 * @param s
	 * @param escapedChars
	 * @return
	 * @throws ParseException
	 */
	protected List<OffsetAttribute> extractRegexes(String s, Set<Integer> escapedChars) throws ParseException{
		List<OffsetAttribute> offsets = new ArrayList<OffsetAttribute>();
		Matcher m = REGEX_PATTERN.matcher(s);
		boolean inRegex = false;
		int start = -1;
		while (m.find()){
			if (m.group(1).equals("/") && ! escapedChars.contains(m.start())){
				
				if (inRegex == true && testRegexPost(s, m.start(), escapedChars)){
					OffsetAttribute offset = new OffsetAttributeImpl();
					//really, we mean it, leave in the -1
					offset.setOffset(start, m.end()-1);
					offsets.add(offset);
					inRegex = false;
				} else {
					if (testRegexPre(s, m.start(), escapedChars)){
						inRegex = true;
						start = m.start();
					}
				}
			}
		}
		if (inRegex == true){
			throw new ParseException(
				"Unmatched / in regex");
		}

		return offsets;
	}
	/**
	 * test that the character before the regex looks like a regex boundary
	 * @param s
	 * @param i
	 * @param escapedChars
	 * @return
	 */
	private boolean testRegexPre(String s, int i, Set<Integer> escapedChars){
		int pre = i-1;
		if (pre < 0){
			return true;
		} else if (escapedChars.contains(pre)){
			return false;
		} else if (requiredRegexPres.contains(s.substring(pre, pre+1))){
			return true;
		}
		return false;
	}
	/**
	 * test that the character after the regex looks like a regex boundary
	 * @param s
	 * @param i
	 * @param escapedChars
	 * @return
	 */
	private boolean testRegexPost(String s, int i, Set<Integer> escapedChars){
		int post = i+1;
		//if term ends string
		if (post >= s.length()-1){
			return true;
		} else if (escapedChars.contains(post)){
			return false;
		} else if (post+1 < s.length() && requiredRegexPosts.contains(s.substring(post, post+1))){
			return true;
		}
		return false;
	}

	protected Set<Integer> getEscapedExtents(String s){
		Set<Integer> ints = new HashSet<Integer>();
		Matcher m = ESCAPES_PATTERN.matcher(s);

		while (m.find()){
			ints.add(m.start());
			ints.add(m.start()+1);
		}
		return ints;
	}
}
