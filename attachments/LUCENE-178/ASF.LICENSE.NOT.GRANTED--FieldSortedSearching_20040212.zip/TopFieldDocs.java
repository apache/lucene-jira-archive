package org.apache.lucene.search;


/**
 * TopFieldDocs
 *
 * <p>Created: Feb 12, 2004 8:58:46 AM 
 * 
 * @author  tjones
 * @since   1.0
 * @version 1.0
 */
public class TopFieldDocs
extends TopDocs {

	public SortField[] fields;

	TopFieldDocs (int totalHits, ScoreDoc[] scoreDocs, SortField[] fields) {
	  super (totalHits, scoreDocs);
	  this.fields = fields;
	}
}