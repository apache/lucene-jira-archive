package org.apache.lucene.search;


/**
 * Encapsulates sort criteria for returned hits.  The sort criteria can
 * be changed between calls to Searcher#search().  This class is thread safe.
 *
 * <p>Created: Feb 12, 2004 10:53:57 AM 
 * 
 * @author  Tim Jones (Nacimiento Software)
 * @since   lucene 1.4
 * @version $Id$
 */
public class Sort {

	SortField[] fields;

	/** Sorts by field then by index order (doc num) */
	public Sort (String field) {
		setSort (field);
	}

	public Sort (String[] fields) {
		setSort (fields);
	}

	public Sort (SortField field) {
		setSort (field);
	}

	public Sort (SortField[] fields) {
		setSort (fields);
	}

	public void setSort (String field) {
		SortField[] nfields = new SortField[] {
			new SortField (field, SortField.AUTO),
			new SortField (field, SortField.DOC)
		};
		fields = nfields;
	}

	public void setSort (String[] fieldnames) {
		final int n = fieldnames.length;
		SortField[] nfields = new SortField[n];
		for (int i=0; i<n; ++i) {
			nfields[i] = new SortField (fieldnames[i], SortField.AUTO);
		}
		fields = nfields;
	}

	public void setSort (SortField[] fields) {
		this.fields = fields;
	}

	public void setSort (SortField field) {
		this.fields = new SortField[] { field };
	}

}