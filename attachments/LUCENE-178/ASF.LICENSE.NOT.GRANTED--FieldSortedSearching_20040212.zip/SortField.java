package org.apache.lucene.search;


/**
 * SortFields
 *
 * <p>Created: Feb 11, 2004 1:25:29 PM 
 * 
 * @author  tjones
 * @since   1.0
 * @version 1.0
 */
public class SortField {

  /** Sort by score (relevancy).  Sort values are Float and higher values are at the front. */
  public static final int SCORE = 0;     // sort by score

  /** Sort by document number (index order).  Sort values are Integer and lower values are at the front. */
  public static final int DOC = 1;       // sort by doc number

  /** Guess type of sort based on field contents. */
  public static final int AUTO = 2;      // guess type of named field

  /** Sort by String.  Sort values are String and lower values are at the front. */
  public static final int STRING = 3;    // sort by named field as String

  /** Sort by String encoded Integers.  Sort values are Integer and lower values are at the front. */
  public static final int INT = 4;       // sort by named field as int

  /** Sort by String encoded Floats.  Sort values are Float and lower values are at the front. */
  public static final int FLOAT = 5;     // sort by named field as float

  public static final SortField RELEVANCY = new SortField (null, SCORE);
  public static final SortField INDEXORDER = new SortField (null, DOC);
	

  private String field;
  private int type = AUTO;

  public SortField (String field) {
	  this.field = field;
  }

  public SortField (String field, int type) {
	  this.field = field;
	  this.type = type;
  }

  public String getField() {
	  return field;
  }

  public int getType() {
	  return type;
  }
}