package org.apache.lucene.search;


/**
 * FieldDoc
 *
 * <p>Created: Feb 11, 2004 1:23:38 PM 
 * 
 * @author  tjones
 * @since   1.0
 * @version 1.0
 */
public class FieldDoc
extends ScoreDoc {

	public Object[] fields;

	public FieldDoc (int doc, float score) {
		super (doc, score);
	}

	public FieldDoc (int doc, float score, Object[] fields) {
		super (doc, score);
		this.fields = fields;
	}
}