package org.apache.lucene.search;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.store.Directory;
import org.apache.lucene.util.PriorityQueue;

import java.io.IOException;


/**
 * An IndexSearcher which sorts hits by a field containing String terms.
 *
 * <p>Created: Feb 3, 2004 5:50:28 PM 
 * 
 * @see FieldSortedSearcher
 * @author  Tim Jones (Nacimiento Software)
 * @since   lucene 1.4
 * @version $Id$
 */
public class StringSortedSearcher
extends FieldSortedSearcher {

	/**
	 * Searches the index in the named directory using the given
	 * field containing strings as the primary sort.
	 */
    public StringSortedSearcher(String path, String string_field)
    throws IOException {
        this(IndexReader.open(path), string_field);
    }

	/**
	 * Searches the index in the provided directory using the
	 * given field containing strings as the primary sort.
	 */
    public StringSortedSearcher(Directory directory, String string_field)
    throws IOException {
        this(IndexReader.open(directory), string_field);
    }

	/**
	 * Searches the provided index using the given field
	 * containing strings as the primary sort.
	 */
    public StringSortedSearcher(IndexReader r, String string_field) {
        super(r, string_field);
    }

	/** Expert: Returns a sorted hit queue for string fields */
	protected PriorityQueue getHitQueue (IndexReader reader, String string_field, int size)
	throws IOException {
		return new StringSortedHitQueue (reader, string_field, size);
	}
}