package org.apache.lucene.search;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.Directory;
import org.apache.lucene.util.PriorityQueue;

import java.io.IOException;
import java.util.BitSet;

/**
 * Implements search over an IndexReader using the values of terms in
 * one or more fields as the primary sort order.
 *
 * <p>The fields used determine sort order must be carefully chosen.
 * Documents must contain a single term in the field,
 * and the value of the term should indicate the document's relative position in
 * a given sort order.  The field must be indexed, but should not be
 * stored (unless you want it back with the rest of your document data)
 * or tokenized:
 *
 * <dl><dd><code>document.add (new Field ("byNumber", Integer.toString(x), false, true, false));</code>
 * </dd></dl>
 *
 * <p>In other words, the desired order of documents must be encoded
 * at the time they are entered into the index.
 *
 * <p><h3>Valid Types of Values</h3>
 *
 * <p>There are three possible kinds of term values which may be put into
 * sorting fields: Integers, Floats, or Strings.
 *
 * <p>Integer term values should contain only digits and an optional
 * preceeding negative sign.  Values must be base 10 and in the range
 * <code>Integer.MIN_VALUE</code> and <code>Integer.MAX_VALUE</code> inclusive.
 * Documents which should appear first in the sort
 * should have low value integers, later documents high values
 * (i.e. the documents should be numbered <code>1..n</code> where
 * <code>1</code> is the first and <code>n</code> the last).
 *
 * <p>Float term values should conform to values accepted by
 * {@link Float Float.valueOf(String)} (except that <code>NaN</code>
 * and <code>Infinity</code> are not supported).
 * Documents which should appear first in the sort
 * should have low values, later documents high values.
 *
 * <p>String term values can contain any valid String, but should
 * not be tokenized.  The values are sorted according to their
 * {@link Comparable natural order}.
 *
 * <p><h3>Determining Type at Run Time</h3>
 *
 * <p>This class attempts to determine the type of values stored
 * in a sorting field at run time by looking at the first term in the field.
 * First a regular expression is used to see
 * if the term is an Integer, and then if it is a Float.  If neither of these
 * match, the term is assumed to contain a String.
 *
 * <p>If for some reason the pattern matching does not work for
 * a certain field, a subclass of this class may be used to
 * instead to explicitly specify the type.  These also offer
 * slightly better performance by skipping the regular expression
 * step.
 *
 * <p><h3>Sorting by a Single Field</h3>
 *
 * <p>At search time, a field stored with sort information
 * is designated to be used to sort the returned hits:
 *
 * <dl><dd><code>IndexSearcher searcher = new FieldSortedSearcher(indexReader, "byNumber");</code>
 * </dd></dl>
 *
 * <p>or:
 *
 * <dl><dd><code>FieldSortedSearcher searcher = new FieldSortedSearcher(indexReader, "bySomething");
 * <br>Hits hits = searcher.search(query, filter);
 * <br>...
 * <br>searcher.setOrderByField("bySomethingElse");
 * <br>hits = searcher.search(query, filter);
 * <br>...
 * </code></dd></dl>
 *
 * <p>In these cases, the sort is done first according to the given field,
 * then by the order of documents as stored in the index.
 *
 * <p><h3>Sorting by Multiple Fields</h3>
 *
 * <p>A sequence of fields can be used to sort hits:
 *
 * <dl><dd><code>IndexSearcher searcher = new FieldSortedSearcher(indexReader, new String[] {<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;"bySomething", "bySomethingElse" } );</code>
 * </dd></dl>
 *
 * <p>In this case, the sort is done by the first field, then the second, etc.
 *
 * <p>Special variables are used to indicate sorting by relevancy or
 * index order:
 *
 * <dl><dd><code>IndexSearcher searcher = new FieldSortedSearcher(indexReader, new String[] {<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;"bySomething", FieldSortedSearcher.RELEVANCE } );</code>
 * </dd></dl>
 *
 * <p><i>(in this example, results will be sorted by field "bySomething" and then by relevance)</i>
 *
 * <p>Note that the file following three cases will return hits in exactly
 * the same order:
 *
 * <dl><dd><code>searcher1 = new IndexSearcher(indexReader);<br>
 * searcher2 = new FieldSortedSearcher(indexReader, FieldSortedSearcher.RELEVANCE);<br>
 * searcher3 = new FieldSortedSearcher(indexReader, new String[] {<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;FieldSortedSearcher.RELEVANCE, FieldSortedSearcher.INDEX_ORDER });</code>
 * </dd></dl>
 *
 * <p>These are also listed above in order of best performance.
 *
 * <p><h3>Object Reuse</h3>
 *
 * <p>Note, as some of the above examples show, one of these objects can be
 * used multiple times and the sort order changed between usages.  This
 * is the way to achieve maximum performance.
 *
 * <p><h3>Memory Usage</h3>
 *
 * <p>This object is almost identical to the regular IndexSearcher and
 * makes no additional memory requirements on its own.  Every time the
 * <code>search()</code> method is called, however, a new
 * {@link FieldSortedHitQueue FieldSortedHitQueue} object is created.
 * That object is responsible for putting the hits in the correct order,
 * and it maintains a cache of information based on the IndexReader
 * given to it.  See its documentation for more information on its
 * memory usage.
 *
 * <p><h3>Concurrency</h3>
 *
 * <p>This object has the same behavior during concurrent updates to
 * the index as does IndexSearcher.  Namely, in the default
 * implementation using
 * {@link org.apache.lucene.store.FSDirectory FSDirectory}, the index
 * can be updated (deletes, adds) without harm while this object
 * exists, but this object will not see the changes (this
 * behavior is ultimately a result of the
 * {@link org.apache.lucene.index.SegmentReader SegmentReader} class
 * internal to FSDirectory, which caches information about documents
 * in memory).
 *
 * <p>So, in order for FieldSortedSearcher to be kept up to date with
 * changes to the index, new instances must be created instead of the
 * same one used over and over again.  This will result in lower
 * performance than if instances are reused.
 *
 * <p>Created: Dec 8, 2003 12:47:26 PM
 *
 * @author  Tim Jones (Nacimiento Software)
 * @since   lucene 1.4
 * @version $Id$
 * @see IndexSearcher
 */
public class FieldSortedSearcher
extends IndexSearcher {

	/** special string indicating sorting by computed relevance */
	public static final String RELEVANCE = "relevance";

	/** special string indicating sorting by order stored in index */
	public static final String INDEX_ORDER = "index order";


    /** stores the field being used to sort by when only one is used **/
    protected String field;

	/** stores the fields being used to sort by when more than one is used **/
	protected String[] fields;


    /**
     * Searches the index in the named directory using the given
     * field as the primary sort.
     * @see IndexSearcher(java.lang.String,java.lang.String)
     */
    public FieldSortedSearcher(String path, String field)
    throws IOException {
        this(IndexReader.open(path), field);
    }

    /**
     * Searches the index in the provided directory using the
     * given field as the primary sort.
     * @see IndexSearcher(Directory,java.lang.String)
     */
    public FieldSortedSearcher(Directory directory, String field)
    throws IOException {
        this(IndexReader.open(directory), field);
    }

    /**
     * Searches the provided index using the given field as the
     * primary sort.
     * @see IndexSearcher(IndexReader)
     */
    public FieldSortedSearcher(IndexReader r, String field) {
        super(r);
        this.field = field.intern();
    }

    /**
     * Sets the field to order results by.  This can be called
     * multiple times per instance of FieldSortedSearcher.
     * @param fieldname  The field to sort results by.
     */
    public void setOrderByField (String fieldname) {
        this.field = fieldname.intern();
		this.fields = null;
    }

    /**
     * Returns the name of the field currently being used
     * to sort results by.
     * @return  Field name.
     */
    public String getOrderByField() {
        return field;
    }


	/**
	 * Searches the index in the named directory using the given
	 * fields as the primary sort.  The type of content in each
	 * field is determined dynamically by FieldSortedHitQueue.determineComparator().
	 * @see IndexSearcher(java.lang.String,java.lang.String)
	 */
	public FieldSortedSearcher(String path, String[] fields)
	throws IOException {
		this(IndexReader.open(path), fields);
	}

	/**
	 * Searches the index in the provided directory using the
	 * given fields as the primary sort. The type of content in each
	 * field is determined dynamically by FieldSortedHitQueue.determineComparator().
	 * @see IndexSearcher(Directory,java.lang.String)
	 */
	public FieldSortedSearcher(Directory directory, String[] fields)
	throws IOException {
		this(IndexReader.open(directory), fields);
	}

	/**
	 * Searches the provided index using the given fields as the
	 * primary sort. The type of content in each
	 * field is determined dynamically by FieldSortedHitQueue.determineComparator().
	 * @see IndexSearcher(IndexReader)
	 */
	public FieldSortedSearcher(final IndexReader r, final String[] fields) {
		super(r);
		setOrderByFields (fields);
	}

	/**
	 * Sets the fields to order results by.  This can be called
	 * multiple times per instance of FieldSortedSearcher. The type of content in each
	 * field is determined dynamically by FieldSortedHitQueue.determineComparator().
	 * @param fields  The fields to sort results by.
	 */
	public void setOrderByFields (final String[] fields) {
		final String[] interned = new String[fields.length];
		for (int i=0; i<fields.length; ++i)
			interned[i] = fields[i].intern();
		this.fields = interned;
		this.field = null;
	}

	/**
	 * Returns the name of the fields currently being used
	 * to sort results by.
	 * @return  Field names.
	 */
	public String[] getOrderByFields() {
		return fields;
	}


    /**
     * Finds the top <code>nDocs</code>
     * hits for <code>query</code>, applying <code>filter</code> if non-null.
     *
     * Overrides IndexSearcher.search to use a FieldSortedHitQueue instead of the
     * default HitQueue.
     *
     * @see IndexSearcher#search
     */
    public TopDocs search(Query query, Filter filter, final int nDocs)
    throws IOException {

        Scorer scorer = query.weight(this).scorer(reader);
        if (scorer == null) {
            return new TopDocs(0, new ScoreDoc[0]);
        }

        final BitSet bits = filter != null ? filter.bits(reader) : null;
        final PriorityQueue hq = getHitQueue (reader, field, nDocs);
        final int[] totalHits = new int[1];
        scorer.score(
            new HitCollector() {
                public final void collect(int doc, float score) {
                    if (score > 0.0f &&                         // ignore zeroed buckets
                        (bits == null || bits.get(doc))) {      // skip docs not in bits
                        totalHits[0]++;
                        hq.insert(new ScoreDoc(doc, score));
                    }
                }
            });

        ScoreDoc[] scoreDocs = new ScoreDoc[hq.size()];
        for (int i = hq.size() - 1; i >= 0; i--) {              // put docs in array
            scoreDocs[i] = (ScoreDoc) hq.pop();
        }

        return new TopDocs(totalHits[0], scoreDocs);
    }


	/**
	 * Expert: subclasses should override this to return a custom PriorityQueue.
	 * @param reader  Index to use.
	 * @param field   Field to sort by.
	 * @param size    Number of hits to keep.
	 * @return Hit queue.
	 * @throws IOException If an error occurs reading the index.
	 */
	protected PriorityQueue getHitQueue (IndexReader reader, String field, int size)
	throws IOException {
		if (field != null) {
			ScoreDocComparator comparer;
			if (field == RELEVANCE) comparer = ScoreDocComparator.RELEVANCE;
			else if (field == INDEX_ORDER) comparer = ScoreDocComparator.INDEX_ORDER;
			else comparer = FieldSortedHitQueue.getCachedComparator (reader, field);

			return FieldSortedHitQueue.getInstance (comparer, size);
		} else {
			return new MultiFieldSortedHitQueue (reader, fields, size);
		}
	}
}