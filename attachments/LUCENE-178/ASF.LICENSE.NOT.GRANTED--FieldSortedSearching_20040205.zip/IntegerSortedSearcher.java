package org.apache.lucene.search;

/**
 * Copyright 2004 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.store.Directory;
import org.apache.lucene.util.PriorityQueue;

import java.io.IOException;

/**
 * An IndexSearcher which sorts hits by a field containing Integer terms.
 *
 * <p><b>hint:</b>
 *
 * <p>In order to be able to update the index without having to
 * recalculate all the sort numbers, the numbers should be stored with
 * "space" between them.  That is, sort the documents and number them
 * <code>1..n</code>.  Then, as <code>i</code> goes between
 * <code>1</code> and <code>n</code>:
 *
 * <dl><dd><code>document.add(new Field("byAlpha", Integer.toString(i*1000), false, true, false));</code>
 * </dd></dl>
 *
 * <p>Add a new document sorted between position 1 and 2 by:
 *
 * <dl><dd><code>document.add(new Field("byAlpha", Integer.toString(1500), false, true, false));</code>
 * </dd></dl>
 *
 * <p>Be careful not to overun <code>Integer.MAX_VALUE</code>
 * (<code>2147483647</code>).  Periodically a complete reindex should
 * be run so the sort orders can be "normalized".
 *
 * <p>Created: Jan 30, 2004 3:21:47 PM
 *
 * @see FieldSortedSearcher
 * @author  Tim Jones (Nacimiento Software)
 * @since   lucene 1.4
 * @version $Id$
 * @see FieldSortedSearcher
 */
public class IntegerSortedSearcher
extends FieldSortedSearcher {

	/**
	 * Searches the index in the named directory using the given
	 * field containing integers as the primary sort.
	 */
    public IntegerSortedSearcher(String path, String integer_field)
    throws IOException {
        this(IndexReader.open(path), integer_field);
    }


	/**
	 * Searches the index in the provided directory using the
	 * given field containing integers as the primary sort.
	 */
    public IntegerSortedSearcher(Directory directory, String integer_field)
    throws IOException {
        this(IndexReader.open(directory), integer_field);
    }


	/**
	 * Searches the provided index using the given field
	 * containing integers as the primary sort.
	 */
    public IntegerSortedSearcher(IndexReader r, String integer_field) {
        super(r, integer_field);
    }


	/** Expert: Returns a sorted hit queue for integer fields */
	protected PriorityQueue getHitQueue (IndexReader reader, String integer_field, int size)
	throws IOException {
		return new IntegerSortedHitQueue (reader, integer_field, size);
	}
}