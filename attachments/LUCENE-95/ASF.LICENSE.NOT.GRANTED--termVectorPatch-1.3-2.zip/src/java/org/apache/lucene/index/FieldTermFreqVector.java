package org.apache.lucene.index;

/**
 * Created by IntelliJ IDEA.
 * User: Grant Ingersoll
 * Date: Feb 17, 2004
 * Time: 3:14:06 PM
 * $Id:$
 * Copyright 2004.  Center For Natural Language Processing
 */

/**
 *
 *
 **/
public interface FieldTermFreqVector extends TermFreqVector{
  /**
   * 
   * @return The number of the field this vector is associated with
   * 
   * @see FieldInfo
   */ 
  public int getFieldNum();
  
  /**
   * 
   * @param fieldNum The field number of the field for this vector
   * 
   * @see FieldInfo
   */ 
  public void setFieldNum(int fieldNum);
  
}
