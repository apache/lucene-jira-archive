package org.apache.lucene.index;

import org.apache.lucene.store.Directory;
import org.apache.lucene.store.InputStream;

import java.io.IOException;

/** TODO: relax synchro!
 */
final class TermVectorsReader {

  private InputStream tvx;
  private InputStream tvd;
  private InputStream tvf;
  private InputStream tvp;
  private int size;
  //private FieldInfos fieldInfos;

  TermVectorsReader(Directory d, String segment) throws IOException {
    //this.fieldInfos = fieldInfos;

    if (d.fileExists(segment + TermVectorsWriter.TVX_EXTENSION)) {
      tvx = d.openFile(segment + TermVectorsWriter.TVX_EXTENSION);
      tvd = d.openFile(segment + TermVectorsWriter.TVD_EXTENSION);
      tvf = d.openFile(segment + TermVectorsWriter.TVF_EXTENSION);
      tvp = d.openFile(segment + TermVectorsWriter.TVP_EXTENSION);

      size = (int) tvx.length() / 8;
    }
  }

  final synchronized void close() throws IOException {
    // why don't we trap the exception and at least make sure that
    // all streams that we can close are closed?
    if (tvx != null) tvx.close();
    if (tvd != null) tvd.close();
    if (tvf != null) tvf.close();
    if (tvp != null) tvp.close();
  }

  /**
   * 
   * @return The number of documents in the reader
   */
  final int size() {
    return size;
  }

/*
  final SegmentTermVector get(int docNum, String field, boolean getPositions)
  throws IOException
  {
    // Check if no term vectors are available for this segment at all
    if (tvx == null) return null;

    // Check if this field is invalid or has no stored term vector
    FieldInfo fi = fieldInfos.fieldInfo(field);
    if (fi == null || !fi.storeTermVector) return null;

    return get(docNum, fi.number, getPositions);
  }
*/
  /**
   * Retrieve the term vector for the given document and field
   * @param docNum The document number to retrieve the vector for
   * @param fieldNumber The number of the field within the document to retrieve
   * @return The TermFreqVector for the document and field or null
   */ 
  final synchronized TermFreqVector get(int docNum, int fieldNumber) {
    // Check if no term vectors are available for this segment at all
    TermFreqVector result = null;
    if (tvx != null) {
      try {
        tvx.seek(docNum * 8L);
        long position = tvx.readLong();

        tvd.seek(position);
        int fieldCount = tvd.readVInt();
  
        // There are only a few fields per document. We opt for a full scan
        // rather then requiring that they be ordered. We need to read through
        // all of the fields anyway to get to the tvf pointers.
        int number = 0;
        int found = -1;
        for (int i = 0; i < fieldCount; i++) {
          number += tvd.readVInt();
          if (number == fieldNumber) found = i;
        }
  
        // This field, although valid in the segment, was not found in this document
        if (found != -1) {
          // Compute position in the tvf file
          position = 0;
          for (int i = 0; i <= found; i++)
            position += tvd.readVLong();

          result = readTermVector(fieldNumber, position);
        }
      } catch (Exception e) {
        //e.printStackTrace();
      }
    }
    return result;
  }


  /** Return all term vectors stored for this document or null if the could not be read in. */
  final synchronized TermFreqVector[] get(int docNum) {
    TermFreqVector[] result = null;
    // Check if no term vectors are available for this segment at all
    if (tvx != null) {
      try {
        tvx.seek(docNum * 8L);
        long position = tvx.readLong();

        tvd.seek(position);
        int fieldCount = tvd.readVInt();

        // No fields are vectorized for this document
        if (fieldCount != 0) {
          int number = 0;
          int[] fieldNums = new int[fieldCount];

          for (int i = 0; i < fieldCount; i++) {
            number += tvd.readVInt();
            fieldNums[i] = number;
          }
  
          // Compute position in the tvf file
          position = 0;
          long[] tvfPointers = new long[fieldCount];
          for (int i = 0; i < fieldCount; i++) {
            position += tvd.readVLong();
            tvfPointers[i] = position;
          }

          result = readTermVectors(fieldNums, tvfPointers);
        }
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
    return result;
  }


  private final SegmentTermVector[] readTermVectors(int fieldNums[], long tvfPointers[])
          throws IOException {
    SegmentTermVector res[] = new SegmentTermVector[fieldNums.length];
    for (int i = 0; i < fieldNums.length; i++) {
      res[i] = readTermVector(fieldNums[i], tvfPointers[i]);
    }
    return res;
  }


  private final SegmentTermVector readTermVector(int fieldNum, long tvfPointer)
          throws IOException {

    // Now read the data from specified position
    tvf.seek(tvfPointer);

    int numTerms = tvf.readVInt();

    // If no terms - return a constant empty termvector
    if (numTerms == 0) return new SegmentTermVector(fieldNum, null, null, null);

    int length = numTerms + tvf.readVInt();

    String terms[] = new String[numTerms];
    int termFreqs[] = new int[numTerms];

    // read first values
    terms[0] = tvf.readString();
    termFreqs[0] = tvf.readVInt();
    //System.out.println("Term[0]: " + terms[0] + " Freq: " + termFreqs[0]);
    for (int i = 1; i < numTerms; i++) {
      terms[i] = tvf.readString();
      termFreqs[i] = tvf.readVInt();
      //System.out.println("Term[" + i + "]: " + terms[i] + " Freq: " + termFreqs[i]);
    }

    SegmentTermVector tv = new SegmentTermVector(fieldNum, terms, termFreqs, null);
    // if positions are also requested - go get them
    int termProx[][] = new int[numTerms][];

    long proxPointer = tvf.readVLong();
    termProx[0] = readProx(proxPointer, termFreqs[0]);

    for (int i = 1; i < numTerms; i++) {
      proxPointer += tvf.readVLong();
      termProx[i] = readProx(proxPointer, termFreqs[i]);
    }

    tv.termProx = termProx;

    return tv;
  }

  final TermPositionVector [] getTermPositions(int docNum)
  {
    //Can do this b/c we know the internal representation
    return (SegmentTermVector [])get(docNum);
  }
  
  final TermPositionVector getTermPositions(int docNum, int fieldNum) {
    //Can do this, b/c we know the internal representation is a SegmentTermVector
    return (SegmentTermVector)get(docNum, fieldNum);
  }

  private int[] readProx(long position, int count)
          throws IOException {
    int res[] = new int[count];
    if (count == 0) return res;  // should never happen

    tvp.seek(position);
    res[0] = tvp.readVInt();
    for (int i = 1; i < count; i++) {
      res[i] = res[i - 1] + tvp.readVInt();
    }

    return res;
  }

}