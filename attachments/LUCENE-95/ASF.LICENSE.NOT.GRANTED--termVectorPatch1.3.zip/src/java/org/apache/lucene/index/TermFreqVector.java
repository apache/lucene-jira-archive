package org.apache.lucene.index;

import java.io.IOException;

/** Provides access to stored term vector of 
 *  a document field.
 */
public interface TermFreqVector {

  /**
   * 
   * @return The number of the field this vector is associated with
   * 
   * @see FieldInfo
   */ 
  public int getFieldNum();
  
  /**
   * 
   * @param fieldNum The field number of the field for this vector
   * 
   * @see FieldInfo
   */ 
  public void setFieldNum(int fieldNum);
  
  /** 
   * @return The number of terms in the term vector.
   */
  public int size();

  /** 
   * @return An Array of term texts in ascending order.
   */
  public String[] getTerms();


  /** Array of term frequencies. Locations of the array correspond one to one
   *  to the term numbers in the array obtained from <code>getTermNumbers</code>
   *  method. Each location in the array contains the number of times this
   *  term occurs in the document or the document field.
   */
  public int[] getTermFrequencies();


  /** Return a string representation of the vector.
   */
  public String toString();


  /** Return a string representation of the vector, but use the provided IndexReader
   *  to obtain text for each term and include the text instead of term numbers.
   */
  public String toString(IndexReader ir) throws IOException;


  /** Return an index in the term numbers array returned from <code>getTermNumbers</code>
   *  at which the term with the specified <code>termNumber</code> appears. If this
   *  term does not appear in the array, return -1.
   */
  public int indexOf(String term);


  /** Just like <code>indexOf(int)</code> but searches for a number of terms
   *  at the same time. Returns an array that has the same size as the number
   *  of terms searched for, each slot containing the result of searching for
   *  that term number.
   *
   *  @param terms array containing terms to look for
   *  @param start index in the array where the list of terms starts
   *  @param len the number of terms in the list
   */
  public int[] indexesOf(String[] terms, int start, int len);

}