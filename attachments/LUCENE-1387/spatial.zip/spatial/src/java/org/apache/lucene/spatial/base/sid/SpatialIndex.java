/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.sid;

/**
 * Wraps a long-valued spatial index and allows access and manipulation of its
 * bit-encoded fields.
 * <p>
 * The lower 5 bits are the level index.  Proceeding up from there in groups of two
 * are the bits for each level.
 * 
 * <p>
 * Quick ref of bits to hex (because I can't visualize these things like I used to):
 * <pre>
 * 0000 = 0x0
 * 0001 = 0x1
 * 0010 = 0x2
 * 0011 = 0x3
 * 0100 = 0x4
 * 0101 = 0x5
 * 0110 = 0x6
 * 0111 = 0x7
 * 1000 = 0x8
 * 1001 = 0x9
 * 1010 = 0xa
 * 1011 = 0xb
 * 1100 = 0xc
 * 1101 = 0xd
 * 1110 = 0xe
 * 1111 = 0xf
 * </pre>
 * 
 */
public class SpatialIndex {
  private long value;
  private int[] cachedComponents;
  
  public SpatialIndex(long value) {
    this.value=value;
  }
  
  public SpatialIndex(long index, int level) {
    if (level>31) throw new IllegalArgumentException("SpatialIndex has too many levels");
    this.value=(index<<5) | (level&0x1f);
  }
  
  @Override
  public boolean equals(Object otherObj) {
    if (!(otherObj instanceof SpatialIndex)) return false;
    return equals((SpatialIndex)otherObj);
  }
  
  @Override
  public int hashCode() {
    return (int)value;
  }
  
  public boolean equals(SpatialIndex other) {
    return other.value==value;
  }
  
  @Override
  public String toString() {
    return "SpatialIndex(" + getLevel() + "):" + getStringValue();
  }
  
  public long getValue() {
    return value;
  }
  
  /**
   * Return a compact, string encoded representation of the spatial
   * index.
   * <p>
   * Update: We do some bit slicing and encoding here to try to produce
   * a value that lexico-graphically clusters better.  The primary change
   * is that the 5 level bits are moved from the low order to the high
   * order, allowing ids within a level to lexically cluster better.
   * 
   * @return
   */
  public String getStringValue() {
    long level=getLevel();
    long index=getIndex();
    
    long shiftedLevel=(level << (level*2 + 2));
    long composite=shiftedLevel | index;
    return Long.toString(composite, 36);
  }
  
  public int getLevel() {
    return (int)(value & 0x1f);
  }
  
  public long getIndex() {
    return (value) >> 5;
  }
  
  public SpatialIndex subtractLevel(int count) {
    int curLevel=getLevel();
    if (count>curLevel) throw new IllegalArgumentException("Subtracting too many levels");
    
    int bits=count*2;
    long newIndex=value >> (5+bits);  // Increment past 2*levels plus the 5 tag bits
    int newLevel=curLevel-count;
    
    long newValue=newLevel | (newIndex << 5);
    
    return new SpatialIndex(newValue);
  }
  
  public SpatialIndex toLevel(int level) {
    int curLevel=getLevel();
    if (level>curLevel) {
      throw new IllegalArgumentException("Cannot refine a spatial index to a higher level");
    }
    
    return subtractLevel(curLevel-level);
  }
  
  /**
   * Create a spatial index from an array of components, where each item in the array is a number [0..3]
   * @param components
   * @return
   */
  private static SpatialIndex fromComponents(int[] components) {
    long idx=0;
    for (int i=components.length-1; i>=0; i-=1) {
      idx=((idx<<2)|(components[i]&0x3));
    }
    
    return new SpatialIndex(idx, components.length-1);
  }

  /**
   * Returns an array of the quadrants represented in this index.  Index zero is the inner-most
   * quadrant (corresponds to the level on this instance).  Each subsequent index represents a
   * a quadrant up.  Each component of the array will be in the range [0..3]
   * @return an array of length level + 1 (cached - so do not modify)
   */
  protected int[] getComponents() {
    if (cachedComponents==null) {
      int levels=getLevel()+1;
      cachedComponents=new int[levels];
      long index=getIndex();
      for (int i=0; i<levels; i++) {
        cachedComponents[i]=(int)(index&0x3);
        index=index >> 2;
      }
    }
    
    return cachedComponents;
  }
  
  /**
   * Return a spatial index that is directly above this index
   * @return
   */
  public SpatialIndex moveUp() {
    int[] components=getComponents().clone();
    int i=0;
    boolean carry;
    do {
      carry=addUp(components, i);
      i+=1;
    } while (carry);
    
    return SpatialIndex.fromComponents(components);
  }
  

  /**
   * Changes components[i] to be in the quadrant above where it is at.
   * Return carry=true if we overflowed.
   * @param components
   * @param i
   * @return
   */
  private boolean addUp(int[] components, int i) {
    int q=components[i];
    boolean carry;
    if (q==0) {
      q=1;
      carry=false;
    } else if (q==3) {
      q=2;
      carry=false;
    } else if (q==1) {
      q=0;
      carry=true;
    } else if (q==2) {
      q=3;
      carry=true;
    } else {
      throw new IllegalStateException("component quadrant out of range");
    }
    
    components[i]=q;
    return carry;
  }

  public SpatialIndex moveDown() {
    int[] components=getComponents().clone();
    int i=0;
    boolean carry;
    do {
      carry=addDown(components, i);
      i+=1;
    } while (carry);
    
    return SpatialIndex.fromComponents(components);
  }

  /**
   * Changes components[i] to be in the quadrant below where it is at.
   * Return carry=true if we overflowed.
   * @param components
   * @param i
   * @return
   */
  private boolean addDown(int[] components, int i) {
    int q=components[i];
    boolean carry;
    if (q==1) {
      q=0;
      carry=false;
    } else if (q==2) {
      q=3;
      carry=false;
    } else if (q==0) {
      q=1;
      carry=true;
    } else if (q==3) {
      q=2;
      carry=true;
    } else {
      throw new IllegalStateException("component quadrant out of range");
    }
    
    components[i]=q;
    return carry;
  }

  public SpatialIndex moveLeft() {
    int[] components=getComponents().clone();
    int i=0;
    boolean carry;
    do {
      carry=addLeft(components, i);
      i+=1;
    } while (carry);
    
    return SpatialIndex.fromComponents(components);
  }

  /**
   * Changes components[i] to be in the quadrant below where it is at.
   * Return carry=true if we overflowed.
   * @param components
   * @param i
   * @return
   */
  private boolean addLeft(int[] components, int i) {
    int q=components[i];
    boolean carry;
    if (q==2) {
      q=1;
      carry=false;
    } else if (q==3) {
      q=0;
      carry=false;
    } else if (q==0) {
      q=3;
      carry=true;
    } else if (q==1) {
      q=2;
      carry=true;
    } else {
      throw new IllegalStateException("component quadrant out of range");
    }
    
    components[i]=q;
    return carry;
  }

  public SpatialIndex moveRight() {
    int[] components=getComponents().clone();
    int i=0;
    boolean carry;
    do {
      carry=addRight(components, i);
      i+=1;
    } while (carry);
    
    return SpatialIndex.fromComponents(components);
  }

  /**
   * Changes components[i] to be in the quadrant below where it is at.
   * Return carry=true if we overflowed.
   * @param components
   * @param i
   * @return
   */
  private boolean addRight(int[] components, int i) {
    int q=components[i];
    boolean carry;
    if (q==0) {
      q=3;
      carry=false;
    } else if (q==1) {
      q=2;
      carry=false;
    } else if (q==2) {
      q=1;
      carry=true;
    } else if (q==3) {
      q=0;
      carry=true;
    } else {
      throw new IllegalStateException("component quadrant out of range");
    }
    
    components[i]=q;
    return carry;
  }

}
