/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.apache.lucene.search.Filter;
import org.apache.lucene.search.RangeFilter;
import org.apache.lucene.spatial.base.FloatLatLng;
import org.apache.lucene.spatial.base.LatLng;
import org.apache.lucene.spatial.base.geometry.LLRect;
import org.apache.lucene.spatial.utils.projections.CartesianTierPlotter;
import org.apache.lucene.spatial.utils.projections.IProjector;
import org.apache.lucene.spatial.utils.projections.SinusoidalProjector;
import org.apache.solr.util.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 
 */
public class CartesianPolyFilter {
  private static final Logger log=LoggerFactory.getLogger( CartesianPolyFilter.class );

  private IProjector projector = new SinusoidalProjector();
  public RangeFilter boundaryBox (double latitude, double longitude, int miles){
    
    LLRect box = LLRect.createBox( new FloatLatLng( latitude, longitude), miles, miles );
    LatLng lowerLeft = box.getLowerLeft();
    LatLng upperRight = box.getUpperRight();
    
    double latX = lowerLeft.getLat();  //box.getY();
    double latY = upperRight.getLat(); //box.getMaxY();
    
    double longX = lowerLeft.getLng();  //box.getX();
    double longY = upperRight.getLng(); //box.getMaxX();
    
    CartesianTierPlotter ctp = new CartesianTierPlotter(2, projector);
    int bestFit = ctp.bestFit(miles);
    
    log.debug("Best Fit is : " + bestFit);
    ctp = new CartesianTierPlotter(bestFit, projector);
    
    
    double beginAt = ctp.getTierBoxId(latX, longX);
    double endAt = ctp.getTierBoxId(latY, longY);
    String fieldName = ctp.getTierFieldName();
    
    log.debug("RangeFilter is ("+latX+","+longX+") "+"("+latY+","+longY+") "+fieldName+":["+beginAt +" TO "+ endAt+"]");
    
    RangeFilter f = new RangeFilter(fieldName, 
          NumberUtils.double2sortableStr(beginAt),
          NumberUtils.double2sortableStr(endAt),
          true, true);
    
    return f;
    
  }
  
  
  public Shape getBoxShape(double latitude, double longitude, int miles){

    LLRect box = LLRect.createBox( new FloatLatLng( latitude, longitude), miles, miles );
    LatLng lowerLeft = box.getLowerLeft();
    LatLng upperRight = box.getUpperRight();
    
    double latX = lowerLeft.getLat();  //box.getY();
    double latY = upperRight.getLat(); //box.getMaxY();
    
    double longX = lowerLeft.getLng();  //box.getX();
    double longY = upperRight.getLng(); //box.getMaxX();
    
    CartesianTierPlotter ctp = new CartesianTierPlotter(2, projector);
    int bestFit = ctp.bestFit(miles);
    
    log.debug("Best Fit is : " + bestFit);
    ctp = new CartesianTierPlotter(bestFit, projector);
    Shape shape = new Shape(ctp.getTierFieldName());
    
    // generate shape
    // iterate from startX->endX
    //     iterate from startY -> endY
    //      shape.add(currentLat.currentLong);
    
    double beginAt = ctp.getTierBoxId(latX, longX);
    double endAt = ctp.getTierBoxId(latY, longY);
    
    double tierVert = ctp.getTierVerticalPosDivider();
    log.debug(" | "+ beginAt+" | "+ endAt);
    
    double startX = beginAt - (beginAt %1);
    double startY = beginAt - startX ; //should give a whole number
    
    double endX = endAt - (endAt %1);
    double endY = endAt -endX; //should give a whole number
    
    int scale = (int)Math.log10(tierVert);
    endY = new BigDecimal(endY).setScale(scale, RoundingMode.HALF_EVEN).doubleValue();
    startY = new BigDecimal(startY).setScale(scale, RoundingMode.HALF_EVEN).doubleValue();
    log.debug("scale "+scale+" startX "+ startX + " endX "+endX +" startY "+ startY + " endY "+ endY +" tierVert "+ tierVert);
    
    double xInc = 1.0d / tierVert;
    xInc = new BigDecimal(xInc).setScale(scale, RoundingMode.HALF_EVEN).doubleValue();
    
    for (; startX <= endX; startX++){
      
      double itY = startY;
      while (itY <= endY){
        //create a boxId
        // startX.startY
        double boxId = startX + itY ;
        shape.addBox(boxId);
        itY += xInc;
        
        // java keeps 0.0001 as 1.0E-1
        // which ends up as 0.00011111
        itY = new BigDecimal(itY).setScale(scale, RoundingMode.HALF_EVEN).doubleValue();
      }
    }
    
    
    return shape;
  }
  
  public Filter getBoundingArea(double latitude, double longitude, int miles) {

    Shape shape = getBoxShape(latitude, longitude, miles);
    return new CartesianShapeFilter(shape, shape.getTierId());
  }
}
