/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.sid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.lucene.spatial.base.geometry.Geometry2D;
import org.apache.lucene.spatial.base.geometry.IntersectCase;
import org.apache.lucene.spatial.base.geometry.Rectangle;


/**
 * A spatial grid is a rectangular grid of spatial levels centered around
 * some reference level.  The number of rows and columns is always normalized to be odd
 * so that the reference cell is precisely centered.  The SpatialGrid
 * is an approximating device for determining which spatial ids are contained
 * within a shape.
 * <p>
 * The spatial grid will become less precise due to division and rounding error
 * the larger it becomes.  This is ok because the spatial ids are
 * imprecise to begin with.
 * 
 */
public class SpatialGrid {
  /**
   * Number of rows (Y) and number of columns (X)
   */
  private int rowCount, colCount;
  
  /**
   * The reference (mid-point cell)
   */
  private SpatialCell referenceCell;
  
  /**
   * 2d grid cast onto a 1d array.  Cells are stored by row.
   */
  private SpatialCell[] grid;
  
  private int midX, midY;
  
  /**
   * Construct a spatial grid of a given size populated from the given SpatialLevel at the mid-point
   * @param cols
   * @param rows
   */
  public SpatialGrid(int cols, int rows, SpatialLevel referenceLevel) {
    this.colCount=cols=makeOdd(cols);
    this.rowCount=rows=makeOdd(rows);
    
    midX=(cols-1)/2;
    midY=(rows-1)/2;
    
    grid=new SpatialCell[cols*rows];
    
    // We now need to populate the grid, starting at the mid point.
    this.referenceCell=set(referenceLevel, midX, midY);
    
    populateRow(referenceCell);
    SpatialCell prevCell=this.referenceCell;
    for (int y=midY-1; y>=0; y-=1) {
      SpatialLevel thisLevel=prevCell.getLevel().translateUp();
      SpatialCell thisCell=set(thisLevel, midX, y);
      populateRow(thisCell);
      prevCell=thisCell;
    }
    
    prevCell=this.referenceCell;
    for (int y=midY+1; y<rows; y+=1) {
      SpatialLevel thisLevel=prevCell.getLevel().translateDown();
      SpatialCell thisCell=set(thisLevel, midX, y);
      populateRow(thisCell);
      prevCell=thisCell;
    }
  }
  

  /**
   * Populate a row given a cell at the mid-point
   * @param thisCell
   */
  private void populateRow(SpatialCell midCell) {
    SpatialCell prevCell=midCell;
    for (int x=midX-1; x>=0; x-=1) {
      SpatialLevel thisLevel=prevCell.getLevel().translateLeft();
      SpatialCell thisCell=set(thisLevel, x, midCell.getY());
      prevCell=thisCell;
    }
    
    prevCell=midCell;
    for (int x=midX+1; x<colCount; x+=1) {
      SpatialLevel thisLevel=prevCell.getLevel().translateRight();
      SpatialCell thisCell=set(thisLevel, x, midCell.getY());
      prevCell=thisCell;
    }
  }

  private int makeOdd(int i) {
    if ((i&1)==1) return i;
    return i+1;
  }
  
  public SpatialCell get(int x, int y) {
    if (x>=colCount || y>=rowCount) {
      throw new ArrayIndexOutOfBoundsException();
    }
    
    int offset=y*colCount+x;
    return grid[offset];
  }
  
  public void set(SpatialCell cell, int x, int y) {
    if (x>=colCount || y>=rowCount) {
      throw new ArrayIndexOutOfBoundsException();
    }
    
    int offset=y*colCount+x;
    grid[offset]=cell;
  }
  
  public SpatialCell set(SpatialLevel level, int x, int y) {
    SpatialCell cell=new SpatialCell(level, x, y);
    set(cell, x, y);
    return cell;
  }
  
  // Manipulation functions
  /**
   * Performs intersection analysis on all cells against the given shape.  Enables all
   * intersecting cells and disables others
   */
  public void selectIntersecting(Geometry2D shape) {
    for (SpatialCell cell: grid) {
      Rectangle rect=cell.getLevel().getBoundingBox().toRectangle();
      IntersectCase ic=shape.intersect(rect);
      if (ic!=IntersectCase.OUTSIDE) {
        cell.setSelected(true);
      }
    }
  }
  
  public double areaOfSelected() {
    double accum=0;
    for (SpatialCell cell: grid) {
      if (cell.isSelected()) {
        accum+=cell.getLevel().getHeightInMiles() * cell.getLevel().getWidthInMiles();
      }
    }
    return accum;
  }
  
  public Collection<SpatialCell> selectedCells() {
    ArrayList<SpatialCell> list=new ArrayList<SpatialCell>();
    for (SpatialCell cell: grid) {
      if (cell.isSelected()) list.add(cell);
    }
    return list;
  }
  
  /**
   * Reduced all selected cells to a different level spatial index.  Returns the set of unique cells.
   * @param level
   * @return
   */
  public Set<SpatialIndex> reduceSelectedToLevel(int level) {
    HashSet<SpatialIndex> indexes=new HashSet<SpatialIndex>();
    for (SpatialCell cell: grid) {
      if (cell.isSelected()) {
        indexes.add(cell.getLevel().getSpatialIndex().toLevel(level));
      }
    }
    
    return indexes;
  }
  
  public Collection<SpatialCell> getCells() {
    return Arrays.asList(grid);
  }
  
  //// Utility creation functions
  /**
   * Create a spatial grid that it large enough to accomodate the given width and height in miles.
   */
  public static SpatialGrid createBySize(SpatialLevel referenceLevel, double widthMi, double heightMi) {
    double unitWidth=referenceLevel.getWidthInMiles();
    double unitHeight=referenceLevel.getHeightInMiles();
    
    double divWidth=widthMi/unitWidth;
    double divHeight=heightMi/unitHeight;
    
    int countWidth=(int) Math.ceil(divWidth);
    int countHeight=(int) Math.ceil(divHeight);
    
    SpatialGrid ret=new SpatialGrid(countWidth, countHeight, referenceLevel);
    
    return ret;
  }

  /**
   * Creates an "optimally" sized grid given the available levels and the requested width, height and
   * target number of columns.
   * 
   * @param levels
   * @param widthMi
   * @param heightMi
   * @return A spatialgrid or null if the constraints cannot be met
   */
  public static SpatialGrid createOptimalGrid(SpatialLevel[] levels, double widthMi, double heightMi, int targetCols) {
    for (int i=levels.length-1; i>=0; i--) {
      SpatialLevel level=levels[i];
      int colsThis=(int)(widthMi/level.getWidthInMiles());
      if (colsThis<=targetCols) {
        return createBySize(level, widthMi, heightMi);
      }
    }
    
    return null;
  }

  public int getRowCount() {
    return rowCount;
  }
  public int getColCount() {
    return colCount;
  }


  /**
   * Draw the pattern with ascii art
   * @return
   */
  public String drawPattern() {
    StringBuilder sb=new StringBuilder();
    
    for (int y=0; y<rowCount; y++) {
      for (int x=0; x<colCount; x++) {
        SpatialCell cell=get(x, y);
        if (cell.isSelected()) {
          sb.append("*");
        } else {
          sb.append("-");
        }
      }
      sb.append("\n");
    }
    
    return sb.toString();
  }


  public SpatialLevel getReferenceLevel() {
    return referenceCell.getLevel();
  }
}
