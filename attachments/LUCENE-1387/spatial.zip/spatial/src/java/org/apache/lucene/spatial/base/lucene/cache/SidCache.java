/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.cache;

import java.util.Arrays;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.lucene.index.IndexReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Manages a SID cache.
 */
public class SidCache {
  private static final Logger LOG=LoggerFactory.getLogger( SidPartition.class );
  
  private long cacheMax=megaBytes(512);
  
  private WeakHashMap<IndexReader, SidCacheVersion> versionMap=new WeakHashMap<IndexReader, SidCacheVersion>();
  AtomicLong memoryUsage=new AtomicLong();
  
  public SidCache() {
    String sysProp=System.getProperty("sidcache.size");
    if (sysProp!=null) {
      try {
        cacheMax=megaBytes(Long.parseLong(sysProp));
      } catch (NumberFormatException e) {
        LOG.warn("Could not parse sidcache.size sysprop");
      }
    }
    
    LOG.info("SidCache will use " + (cacheMax/1024/1024.0) + "mb");
  }
  
  public boolean isEnabled() {
    return cacheMax>0;
  }
  
  private class ReaperThread extends Thread {
    public ReaperThread() {
      super("SidCache Reaper");
      setDaemon(true);
    }
    
    @Override
    public void run() {
      while( true ) {
        LOG.info("SidCache memory usage: " + (memoryUsage.get()/1024/1024.0) + "mb");
        synchronized (reapMonitor) {
          try {
            reapMonitor.wait(360*1000);
            
            if (doReap) {
              doReap=false;
            } else {
              continue;
            }
          } 
          catch (InterruptedException e) {
            break;
          }
          service();
        }
      }
    }

    private void service() {
      long actualMemory=0;
      
      SidCacheVersion versions[];
      synchronized (SidCache.this) {
        versions=versionMap.values().toArray(new SidCacheVersion[0]);
      }

      // Might lose some allocation here, but it shouldn't be much
      for (int i=0; i<versions.length; i++) {
        actualMemory+=versions[i].memoryUsage.get();
      }
      memoryUsage.set(actualMemory);

      long memoryDelta=actualMemory - cacheMax;
      if (memoryDelta<=0) return;
      
      long freeTarget=cacheMax/8 + memoryDelta;
      Arrays.sort(versions);
      for (int i=versions.length-1; i>=0; i--) {
        if (freeTarget<=0) break;
        SidCacheVersion scv=versions[i];
        long reclaimed=scv.shrinkBy(freeTarget);
        freeTarget-=reclaimed;
        memoryUsage.addAndGet(-reclaimed);
      }
      
      if (freeTarget>0) {
        LOG.info("Unable to free all needed memory.  Cache size=" + memoryUsage.get());
      } else {
        LOG.info("Freed memory.  Cache size=" + memoryUsage.get());
      }
    }
  }
  
  private ReaperThread reaper;
  private boolean doReap;
  private Object reapMonitor=new Object();
  
  public void start() {
    if (reaper!=null) return;
    reaper=new ReaperThread();
    reaper.start();
  }
  
  /**
   * Opens a SidCache version suitable for the given index reader
   * @param reader
   * @return
   */
  public synchronized SidCacheVersion open(IndexReader reader) {
    SidCacheVersion scv=versionMap.get(reader);
    if (scv==null) {
      scv=new SidCacheVersion(this, reader.getVersion());
      versionMap.put(reader, scv);
    }
    
    return scv;
  }

  void addMemoryUsage(long estSize) {
    long newUsage=memoryUsage.addAndGet(estSize);
    if (newUsage>cacheMax) {
      synchronized (reapMonitor) {
        doReap=true;
        reapMonitor.notify();
      }
    }
  }
  
  public static long megaBytes(long count) {
    return count*1024*1024;
  }

  public void setCacheMax(long cacheMax) {
    this.cacheMax=cacheMax;
  }
}
