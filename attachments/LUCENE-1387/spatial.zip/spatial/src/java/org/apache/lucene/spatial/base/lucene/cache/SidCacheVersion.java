/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.cache;

import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.lucene.index.IndexReader;

/**
 * A SidCache dedicated to one IndexReader
 */
public class SidCacheVersion implements Comparable<SidCacheVersion> 
{
  private SidCache owner;
  private LinkedHashMap<String, SidPartition> partitions=new LinkedHashMap<String, SidPartition>(500, (float) 0.7, true);
  AtomicLong memoryUsage=new AtomicLong();
  long version;
  
  public SidCacheVersion(SidCache owner, long version) {
    this.owner=owner;
    this.version=version;
  }
  
  public SidPartition openPartition(String sid, IndexReader reader) throws IOException {
    
    
    SidPartition partition;
    synchronized (partitions) {
      partition=partitions.get(sid);
      if (partition==null) {
        partition=new SidPartition(this, sid);
        partitions.put(sid, partition);
      }
    }
    
    // Now wait for it - May throw an exception here.  If not, it will be addRefed
    boolean success=false;
    try {
      partition.acquire(reader);
      success=true;
    } finally {
      if (!success) {
        synchronized (partitions) {
          partitions.remove(sid);
        }
      }
    }

    long estSize=partition.estimateMemoryUsage();
    memoryUsage.addAndGet(estSize);
    owner.addMemoryUsage(estSize);
    
    return partition;
  }
  
  public long shrinkBy(long memoryDelta) {
    long reclaimed=0;
    
    outer: while (memoryDelta>reclaimed) {
      synchronized (partitions) {
        int index=0;
        if (partitions.isEmpty()) break outer;
        Iterator<SidPartition> iter=partitions.values().iterator();
        inner: while (iter.hasNext()) {
          if (reclaimed>=memoryDelta) break outer;

          // Only do so many ops in a synchronized block
          if (index>20) break inner;
          
          SidPartition p=iter.next();
          
          iter.remove();
          
          reclaimed+=p.estimateMemoryUsage();
          index++;
          
          //System.out.println("Removed sid " + p.sid + ", size=" + p.estimateMemoryUsage() +
          //    " need to remove " + (memoryDelta - reclaimed) + " more");

        }
      }
    }
    
    memoryUsage.addAndGet(-reclaimed);
    return reclaimed;
  }

  public int compareTo(SidCacheVersion o) {
    long lhs=version;
    long rhs=o.version;
    if (lhs>rhs) return 1;
    else if (lhs<rhs) return -1;
    return 0;
  }
}
