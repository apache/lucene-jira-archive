/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.search;

import java.io.IOException;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.Explanation;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Scorer;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Similarity;
import org.apache.lucene.search.Weight;
import org.apache.lucene.spatial.base.MutableFixedLatLng;


public class SpatialCandidateQuery extends Query {
  SidCursor cursorPrototype;
  CandidateScorer candidateScorer;
  float termNormalizationFactor=25;
  private String[] sids;
  
  public SpatialCandidateQuery(SidCursor cursorPrototype, CandidateScorer candidateScorer, String... sids) {
    this.cursorPrototype=cursorPrototype;
    this.candidateScorer=candidateScorer;
    this.sids=sids;
  }
  
  /**
   * Spatial queries do not act like normal term based queries when scoring.  But in order
   * to make scores meaningful, it is useful to fudge the differences.
   * <p>
   * In term based queries, the number of terms in a document is the primary scoring factor.
   * Spatial queries derive a number between 0..1 and need to multiply it by something in
   * the same range as is used by Term based queries if the two will be able to compete
   * together.
   * <p>
   * If you expect that a strong match on other terms in your query would happen if 10 terms
   * matched, then set this to 10.
   * <p>
   * The default value is 25.
   * 
   * @param termNormalizationFactor
   */
  public void setTermNormalizationFactor(float termNormalizationFactor) {
    this.termNormalizationFactor = termNormalizationFactor;
  }
  
  @Override
  protected Weight createWeight(Searcher searcher) throws IOException {
    return new SpatialCandidateWeight(searcher);
  }
  
  @Override
  public String toString(String field) {
    StringBuilder sb=new StringBuilder();
    for (String sid: sids) {
      if (sb.length()>0) sb.append(", ");
      sb.append(sid);
    }
    return String.format("(spatial id in (%s))", sb.toString());
  }
  
  public void close() throws IOException {
    cursorPrototype.close();
  }

  
  class SpatialCandidateWeight implements Weight {
    private Searcher searcher;
    private Similarity similarity;
    private float idf;
    private float queryWeight;
    private float value;
    private float queryNorm;
    
    public SpatialCandidateWeight(Searcher searcher) throws IOException {
      this.searcher=searcher;
      this.similarity=getSimilarity(searcher);

      // Idf communicates a sense of what portion of the index are candidates
      // for this query.  Usually a larger value for rarer terms and a smaller value
      // for more common
      this.idf=similarity.idf(cursorPrototype.cardinality(), searcher.maxDoc());
    }
    
    public Explanation explain(IndexReader reader, int doc)
        throws IOException {
      return new Explanation((float) 1.0, "TODO");
    }

    public Query getQuery() {
      return SpatialCandidateQuery.this;
    }

    public float getValue() {
      return value;
    }

    public void normalize(float queryNorm) {
      this.queryNorm=queryNorm;
      queryWeight *= queryNorm;
      value = queryWeight * idf;
    }

    public Scorer scorer(IndexReader reader) throws IOException {
      return new SpatialCandidateScorer(this, SpatialCandidateQuery.this, getSimilarity(searcher), cursorPrototype.clone());
    }

    public float sumOfSquaredWeights() throws IOException {
      queryWeight=idf * getBoost();
      return queryWeight * queryWeight;
    }
    
  }
}

class SpatialCandidateScorer extends Scorer {
  private SpatialCandidateQuery.SpatialCandidateWeight weight;
  private SpatialCandidateQuery query;
  private SidCursor sidDocs;
  private CandidateInfo info;
  private MutableFixedLatLng latLng;

  private float weightValue;
  private float score;
  
  SpatialCandidateScorer(SpatialCandidateQuery.SpatialCandidateWeight weight, SpatialCandidateQuery query, Similarity similarity, SidCursor sidDocs) {
    super(similarity);
    this.sidDocs=sidDocs;
    this.query=query;
    this.weight=weight;
    this.query=query;
    this.weightValue=weight.getValue();
    
    this.latLng=new MutableFixedLatLng();
    this.info=new CandidateInfo();
    info.latLng=latLng;
  }
  
  @Override
  public int doc() {
    int ret=sidDocs.doc();
    return ret;
  }

  @Override
  public Explanation explain(int doc) throws IOException {
    return new Explanation((float) 1.0, "TODO");
  }

  @Override
  public boolean next() throws IOException {
    for (;;) {
      boolean hasNext=sidDocs.next();
      if (hasNext) {
        //updateScore();
        //if (info.included) return true;
        return true;
      } else {
        return false;
      }
    }
  }

  protected void updateScore() throws IOException {
    // Check it
    latLng.setLat(sidDocs.lat());
    latLng.setLng(sidDocs.lng());
    
    info.reset(sidDocs.doc());
    query.candidateScorer.update(info);
    
    if (info.included) {
      // Note: info.score should be between 0 and 1
      float freq=info.score * query.termNormalizationFactor;
      
      // Lucene's approach to scoring involves counting terms.  Since distance isn't a term,
      // we fake it by saying that it is equivilent to the term appearing 10 times if the
      // distance is 0 (ie. info.score is 1.0).  This value is sqrt'd, so make doubly sure
      // not to have a negative
      if (freq<0) freq=0;
      
      score=getSimilarity().tf(freq) *
        weightValue;
    }
  }
  
  @Override
  public float score() throws IOException {
    return score;
  }

  @Override
  public boolean skipTo(int target) throws IOException {
    if (sidDocs.skipTo(target)) {
      //updateScore();
      //if (!info.included) {
      //  return next();
      //} else {
        return true;
      //}
    } else {
      return false;
    }
  }
}
