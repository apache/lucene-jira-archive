/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.cache;

import java.io.IOException;
import java.lang.ref.WeakReference;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.spatial.base.lucene.search.SidEncoder;


/**
 * Sid-data that lazily gets its lat/lngs when it detects the Integer.MAX_VALUE
 * sentinel value.
 */
public class LazySidData extends SidData {

  private WeakReference<IndexReader> readerReference;
  private SidEncoder encoder;

  public LazySidData(IndexReader reader, SidEncoder encoder, int capacity) {
    super(capacity);
    this.readerReference=new WeakReference<IndexReader>(reader);
    this.encoder=encoder;
  }
  
  @Override
  public int lat(int i) {
    int ret=super.lat(i);
    if (ret==Integer.MAX_VALUE) {
      int[] ll=loadLatLng(i);
      return ll[0];
    } else {
      return ret;
    }
  }
  
  @Override
  public int lng(int i) {
    int ret=super.lng(i);
    if (ret==Integer.MAX_VALUE) {
      int[] ll=loadLatLng(i);
      return ll[1];
    } else {
      return ret;
    }
  }

  private int[] loadLatLng(int i) {
    int doc=docId(i);
    int[] ll=new int[2];
    try {
      IndexReader reader=readerReference.get();
      if (reader==null) {
        throw new IllegalStateException("Attempt to lazily load lat/lng after the IndexReader has gone out of scope");
      }
      encoder.loadPoint(reader, doc, ll);
      setLatLng(i, ll[0], ll[1]);
    } 
    catch (IOException e) {
      throw new RuntimeException("Error lazy loading lat/lng", e);
    }
    return ll;
  }
}
