/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.search;

import java.io.IOException;

import org.apache.lucene.spatial.base.MutableFixedLatLng;
import org.apache.lucene.spatial.base.lucene.cache.SidData;
import org.apache.lucene.spatial.base.lucene.cache.SidDataCursor;



/**
 * A TermDocs like class which iterates over a set of SidData instances
 * instead of a Lucene index.  Otherwise, known as the secret sauce.
 * 
 */
public final class CompositeSidCursor implements SidCursor  {
  
  private int lastDoc=Integer.MIN_VALUE;
  private SidCursor next;
  private SidCursor[] slices;
  
  public CompositeSidCursor(SidCursor... slices) {
    this.slices=slices;
  }
  
  /**
   * For backwards compatibility
   * @param datas
   */
  public CompositeSidCursor(SidData... datas) {
    slices=new SidCursor[datas.length];
    for (int i=0; i<datas.length; i++) {
      slices[i]=new SidDataCursor(datas[i]);
    }
  }

  @Override
  public SidCursor clone() {
    SidCursor nextCopy=null;
    SidCursor[] slicesCopy=new SidCursor[slices.length];
    for (int i=0; i<slicesCopy.length; i++) {
      slicesCopy[i]=slices[i].clone();
      if (slices[i]==next) next=slices[i];
    }
    
    CompositeSidCursor ret=new CompositeSidCursor(slicesCopy);
    ret.next=nextCopy;
    ret.lastDoc=lastDoc;
    return ret;
  }
  
  private void shuffle() throws IOException {
    if (lastDoc==DOC_SENTINEL) return;
    
    int minDoc=DOC_SENTINEL;
    for (int i=0; i<slices.length; i++) {
      SidCursor slice=slices[i];
      while (slice.doc()<=lastDoc) {
        // Need to advance it to avoid dup
        if (!slice.next()) break;
      }
      
      if (slice.doc()<minDoc) {
        // New low doc
        next=slice;
        minDoc=slice.doc();
      }
    }

    if (next!=null) {
      lastDoc=next.doc();
    } else {
      lastDoc=DOC_SENTINEL;
    }
  }
  
  /* (non-Javadoc)
   * @see com.mapquest.gl.solr.search.SidCursor#doc()
   */
  public final int doc() {
    return next.doc();
  }
  
  /* (non-Javadoc)
   * @see com.mapquest.gl.solr.search.SidCursor#lat()
   */
  public final int lat() throws IOException {
    return next.lat();
  }
  
  /* (non-Javadoc)
   * @see com.mapquest.gl.solr.search.SidCursor#lng()
   */
  public final int lng() throws IOException {
    return next.lng();
  }
  
  /* (non-Javadoc)
   * @see com.mapquest.gl.solr.search.SidCursor#skipTo(int)
   */
  public final boolean skipTo(int docId) throws IOException {
    if (docId<lastDoc) {
      throw new IllegalStateException("Attempt to seek backwards");
    }
    
    for (int i=0; i<slices.length; i++) {
      slices[i].skipTo(docId);
    }
    
    shuffle();
    return !next.isEof();
  }
  
  /* (non-Javadoc)
   * @see com.mapquest.gl.solr.search.SidCursor#next()
   */
  public final boolean next() throws IOException {
    if (next==null) {
      // Initialize them all
      for (SidCursor c: slices) {
        c.next();
      }
    }
    shuffle();
    return next!=null && !next.isEof();
  }
  
  public final boolean isEof() {
    return next==null || next.isEof();
  }
  
  public void close() throws IOException {
    for (SidCursor c: slices) c.close();
  }

  public int cardinality() throws IOException {
    int sum=0;
    for (SidCursor c: slices) sum+=c.cardinality();
    return sum;
  }

  public boolean lookupLatLng(int docId, MutableFixedLatLng ll) throws IOException {
    for (SidCursor c: slices) {
      if (c.lookupLatLng(docId, ll)) return true;
    }
    return false;
  }
}
