/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.cache;

import java.io.IOException;

import org.apache.lucene.spatial.base.MutableFixedLatLng;
import org.apache.lucene.spatial.base.lucene.search.SidCursor;


/**
 * A SidCursor over a SidData instance
 */
public class SidDataCursor implements SidCursor {

  private SidData sidData;
  private int doc;
  private int index;
  
  public SidDataCursor(SidData sidData) {
    this.sidData=sidData;
    
    // Initialize
    index=-1;
    doc=Integer.MIN_VALUE;
  }
  
  @Override
  public SidCursor clone() {
    try {
      return (SidCursor) super.clone();
    } catch (CloneNotSupportedException e) {
      return null;  // Can't happen
    }
  }
  
  public boolean next() {
    index++;
    if (index>=sidData.size()) {
      doc=DOC_SENTINEL;
      return false;
    } else {
      doc=sidData.docId(index);
      return true;
    }
  }
  
  public final int doc() {
    return doc;
  }
  
  public final int lat() {
    return sidData.lat(index);
  }
  
  public final int lng() {
    return sidData.lng(index);
  }
  
  public final boolean isEof() {
    return doc==DOC_SENTINEL;
  }

  public final boolean skipTo(int docId) {
    if (doc==DOC_SENTINEL) return false;
    index=sidData.findNextGTE(index, docId);
    if (index>=sidData.size()) {
      // EOF
      doc=DOC_SENTINEL;
      return false;
    } else {
      doc=sidData.docId(index);
      return true;
    }
  }

  public void close() throws IOException {
  }

  public int cardinality() throws IOException {
    return sidData.size();
  }

  public boolean lookupLatLng(int docId, MutableFixedLatLng ll)
      throws IOException {
    int index=sidData.findIndex(docId);
    if (index<0) return false;
    ll.setLat(sidData.lat(index));
    ll.setLng(sidData.lng(index));
    return true;
  }
}
