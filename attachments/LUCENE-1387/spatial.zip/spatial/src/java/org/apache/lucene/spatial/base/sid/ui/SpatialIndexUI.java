/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.sid.ui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.apache.lucene.spatial.base.FloatLatLng;
import org.apache.lucene.spatial.base.sid.SpatialIndexer;
import org.apache.lucene.spatial.base.sid.SpatialLevel;


/**
 * Little swing app to analyze spatial index results
 */
public class SpatialIndexUI extends JFrame {
  
  private JTextField latTextBox;
  private JTextField lngTextBox;
  private JButton showButton;
  private JTable table;

  public SpatialIndexUI() {
    BoxLayout vbox=new BoxLayout(getContentPane(), BoxLayout.Y_AXIS);
    getContentPane().setLayout(vbox);
    
    JPanel queryPanel=new JPanel(new FlowLayout());
    getContentPane().add(queryPanel);
    
    queryPanel.add(new JLabel("Lat: "));
    this.latTextBox=new JTextField("40.71451");
    queryPanel.add(latTextBox);
    
    queryPanel.add(new JLabel("Lng: "));
    this.lngTextBox=new JTextField("-74.00714");
    queryPanel.add(lngTextBox);
    
    this.showButton=new JButton("Show");
    queryPanel.add(showButton);
    
    this.table=new JTable();
    JScrollPane scroller=new JScrollPane(table);
    getContentPane().add(scroller);
    
    showButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        showResults();
      }
    });
  }
  
  protected void showResults() {
    double lat;
    double lng;
    try {
      lat=Double.parseDouble(latTextBox.getText().trim());
      lng=Double.parseDouble(lngTextBox.getText().trim());

      SpatialLevel[] levels=SpatialIndexer.calculateSpatialLevels(new FloatLatLng(lat, lng), SpatialIndexer.MAX_LEVELS);
      table.setModel(createTableModel(levels));
      
      // make the index small...
      table.getColumnModel().getColumn(0).setMaxWidth( 50 );
//      table.getColumnModel().getColumn(1).setMaxWidth( 200 );
//      table.getColumnModel().getColumn(2).setMaxWidth( 200 );
    } 
    catch (NumberFormatException e) {
      // TODO
      return;
    }
    
  }

  private TableModel createTableModel(SpatialLevel[] levels) {
    Object[][] rows=new Object[levels.length][];
    for (int r=0; r<levels.length; r++) {
      SpatialLevel level=levels[r];
      Object[] cols=new Object[] {
        String.valueOf(level.getLevel()),
        level.getSpatialIndex().getStringValue(),
        Long.toString(level.getSpatialIndex().getIndex(), 16),
        milesToString(level.getWidthInMiles()),
        milesToString(level.getHeightInMiles()),
        level.getBoundingBox()
      };
      rows[r]=cols;
    }
    
    Object[] colNames=new Object[] {
      "Level",
      "Spatial Index",
      "Raw Index",
      "Width",
      "Height",
      "Bounding Box"
    };
    return new DefaultTableModel(rows, colNames);
  }

  private String milesToString(double miles) {
    if (miles<1.0) {
      return (miles*5280) + "ft";
    } else {
      return miles + "mi";
    }
  }

  public static void main(String[] args) throws Exception {
    SpatialIndexUI ui=new SpatialIndexUI();
    ui.showResults();
    ui.setSize(1024, 768);
    ui.setVisible(true);
  }
}
