/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.utils;

import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.spatial.base.DistanceUnits;
import org.apache.lucene.spatial.base.FloatLatLng;
import org.apache.lucene.spatial.base.LatLng;


/**
 * Provide a high level access point to distances
 * Used by DistanceSortSource and DistanceQuery
 *  
 */
public class DistanceHandler {
  
  private Map<Integer,Double> distances;
  public enum precision {EXACT, TWOFEET, TWENTYFEET, TWOHUNDREDFEET};
  private precision precise;
  
  public DistanceHandler (Map<Integer,Double> distances, precision precise){
    this.distances = distances;
    this.precise = precise; 
  }
  
  
  public static double getPrecision(double x, precision thisPrecise){
    
    
    if(thisPrecise != null){
      double dif = 0;
      switch(thisPrecise){
      
      case EXACT:
        return x;
      case TWOFEET:
        dif = x % 0.0001;
        
      case TWENTYFEET:
        dif = x % 0.001;
        
      case TWOHUNDREDFEET:
        dif = x % 0.01;
            
      }
      
      return x - dif;
      
    }
    
    return x;
  }
  
  public precision getPrecision() {
    return precise;
  }
  
  public double getDistance(int docid, double centerLat, double centerLng, double lat, double lng)
  {
    LatLng center = new FloatLatLng( centerLat, centerLng );
    LatLng point = new FloatLatLng( lat, lng );
    
    // check to see if we have distances
    // if not calculate the distance
    if(distances == null){
      return center.arcDistance( point, DistanceUnits.MILES );
      // return DistanceUtils.getDistanceMi(centerLat, centerLng, lat, lng);
      //return DistanceUtils.orthodromicDistance(centerLat, centerLng, lat, lng);
    }
    
    // check to see if the doc id has a cached distance
    Double docd = distances.get(docid);
    if (docd != null){
      return docd.doubleValue();
    }
    
    //check to see if we have a precision code
    // and if another lat/long has been calculated at
    // that rounded location
    if (precise != null) {
      double xLat = getPrecision(lat, precise);
      double xLng = getPrecision(lng, precise);
      
      String k = new Double(xLat).toString() +","+ new Double(xLng).toString();
    
      Double d = distances.get(k);
      if (d != null){
        return d.doubleValue();
      }
    }
    
    
    //all else fails calculate the distances    
    // TODO, could use a more accurate distance calculation...
    return center.arcDistance( point, DistanceUnits.MILES );
    //DistanceUtils.getDistanceMi(centerLat, centerLng, lat, lng);
    //return DistanceUtils.orthodromicDistance(centerLat, centerLng, lat, lng);
  }
  

  public static void main(String args[]){
    
    DistanceHandler db = new DistanceHandler(new HashMap<Integer,Double>(), precision.TWOHUNDREDFEET);
    System.out.println(DistanceHandler.getPrecision(-1234.123456789, db.getPrecision()));
  }

  
}
