/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.search;

import java.io.IOException;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermDocs;
import org.apache.lucene.spatial.base.MutableFixedLatLng;


/**
 * Implements SidCursor over TermDocs
 * 
 */
public class TermDocsSidCursor implements SidCursor {
  private SpatialConfig config;
  private IndexReader reader;
  private TermDocs termDocs;
  private String sid;
  
  private boolean eof;
  
  private SidEncoder sidEncoder;
  
  private int[] latLng=new int[2];
  private int latLngDocId=SidCursor.DOC_SENTINEL;
  
  private Term queryTerm;
  
  public TermDocsSidCursor(SpatialConfig config, IndexReader reader, String sid) {
    this.config=config;
    this.reader=reader;
    this.sid=sid;
    this.sidEncoder=new SidEncoder(config);
    this.queryTerm=new Term(config.getSidField(), sid);
  }
  
  @Override
  public SidCursor clone() {
    if (termDocs!=null) {
      throw new IllegalStateException("TermDocsSidCursor can only be closed at the beginning");
    }

    try {
      return (SidCursor) super.clone();
    } catch (CloneNotSupportedException e) {
      return null; // Cannot happen
    }
  }
  
  public int doc() {
    return eof ? DOC_SENTINEL : termDocs.doc();
  }

  public boolean isEof() {
    return eof;
  }

  public int lat() throws IOException {
    loadLatLng();
    return latLng[0];
  }

  public int lng() throws IOException {
    loadLatLng();
    return latLng[1];
  }

  private void loadLatLng() throws IOException {
    int curDoc=doc();
    if (curDoc!=latLngDocId) {
      // Reload it
      if (!sidEncoder.loadPoint(reader, curDoc, latLng)) {
        latLng[0]=Integer.MAX_VALUE;
        latLng[1]=Integer.MAX_VALUE;
      }
      latLngDocId=curDoc;
    }
  }
  
  public boolean next() throws IOException {
    if (termDocs==null) {
      termDocs=reader.termDocs(queryTerm);
      eof=!termDocs.next();
    } else {
      eof=!termDocs.next();
    }

    return !eof;
  }

  public boolean skipTo(int docId) throws IOException {
    eof=!termDocs.skipTo(docId);
    return !eof;
  }

  public void close() throws IOException {
    if (termDocs!=null) termDocs.close();
  }

  public int cardinality() throws IOException {
    return reader.docFreq(queryTerm);
  }

  public boolean lookupLatLng(int docId, MutableFixedLatLng ll) throws IOException {
    int[] llArray=new int[2];
    if (sidEncoder.loadPoint(reader, docId, llArray)) {
      ll.setLat(llArray[0]);
      ll.setLng(llArray[1]);
      return true;
    }
    return false;
  }
}
