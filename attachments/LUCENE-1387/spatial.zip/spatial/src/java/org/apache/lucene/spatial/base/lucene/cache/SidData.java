/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.cache;

import java.util.BitSet;
import java.util.Random;

/**
 * Maintains a cached sid partition.  Each entry contains 3 4byte int fields:
 * <ul>
 * <li>docid
 * <li>lat (fixed point)
 * <li>lng (fixed point)
 * </ul>
 * 
 * Each partition is ordered by docid for efficient searching and maintenance of a companion
 * BitSet which represents the contents.
 */
public class SidData {
  /**
   * Number of fields per entry
   */
  private static final int FIELD_SPAN=3;
  private static final int FIELD_DOCID=0;
  private static final int FIELD_LAT=1;
  private static final int FIELD_LNG=2;
  
  private int[] partition;
  
  /**
   * Partition capacity in units of FIELD_SPAN
   */
  private int capacity;
  
  /**
   * Partition size in units of FIELD_SPAN
   */
  private int size;
  
  public SidData(int capacity) {
    this.capacity=capacity;
    this.partition=new int[capacity*FIELD_SPAN];
  }

  public int size() {
    return size;
  }
  
  public int docId(int i) {
    return partition[i*FIELD_SPAN+FIELD_DOCID];
  }

  public int lat(int i) {
    return partition[i*FIELD_SPAN+FIELD_LAT];
  }

  public int lng(int i) {
    return partition[i*FIELD_SPAN+FIELD_LNG];
  }

  public int maxDocId() {
    if (size==0) return 0;
    return docId(size-1);
  }

  public void fillBitSet(BitSet bs) {
    int max=size*FIELD_SPAN;
    for (int i=FIELD_DOCID; i<max; i+=FIELD_SPAN) {
      bs.set(partition[i]);
    }
  }
  
  /**
   * Sort it and make it ready for use
   */
  public void finish() {
    Random random=new Random();
    quicksort(0, size-1, random);
  }
  
  private void quicksort(int l, int u, Random random) {
    int i, m;
    if (l >= u) return;
    
    swap(l, randint(l, u, random));
    m=l;
    for (i=l+1; i<=u; i++) {
      if (partition[i*3] < partition[l*3]) {
        swap(++m, i);
      }
    }
    swap(l, m);
    quicksort(l, m-1, random);
    quicksort(m+1, u, random);
  }
  
  private int randint(int min, int max, Random random) {
    return random.nextInt(max-min+1) + min;
  }
  
  private void swap(int j, int k) {
    int s;
    for (int i=0; i<FIELD_SPAN; i++) {
      s=partition[j*3+i];
      partition[j*3+i]=partition[k*3+i];
      partition[k*3+i]=s;
    }
  }

  public void add(int docId, int lat, int lng) {
    ensureCapacity(size+1);
    
    int index=indexOf(size);
    partition[index+FIELD_DOCID]=docId;
    partition[index+FIELD_LAT]=lat;
    partition[index+FIELD_LNG]=lng;
    size+=1;
  }

  public void setLatLng(int index, int lat, int lng) {
    partition[index*FIELD_SPAN+FIELD_LAT]=lat;
    partition[index*FIELD_SPAN+FIELD_LNG]=lng;
  }
  
  private int indexOf(int i) {
    return i*FIELD_SPAN;
  }
  
  private void ensureCapacity(int size) {
    if (capacity<=size) {
      // Make it bigger
      int newCapacity=capacity*2;
      int[] newPartition=new int[newCapacity*FIELD_SPAN];
      System.arraycopy(partition, 0, newPartition, 0, partition.length);
      
      capacity=newCapacity;
      partition=newPartition;
      System.out.println("Resized SidData to " + newCapacity);
    }
  }

  public int findIndex(int docId) {
    int high=size;
    int low=-1;
    while (high - low > 1) {
      int probe=(low+high) >>> 1;
      if (docId(probe) > docId) {
        high=probe;
      } else {
        low=probe;
      }
    }
    
    if (low == -1 || docId(low) != docId)
      return -1;
    else
      return low;
  }

  /**
   * Find the index of the next entry that is greater than or equal to docId
   * and whose index is >= to the requested index.
   * @param index The lower bound to search from
   * @param docId The smallest docId to search for
   * @return index of found entry or size() if not found
   * TODO: This implementation sucks.  I've written a btree search before
   * that has guaranteed termination constraints when not found, but this isn't it.
   * It works, but suffers from the "I can't remember how to do it right,
   * so just add some extra checks and fudge it at the end" design approach.
   */
  public int findNextGTE(int index, int docId) {
    //System.out.println("B-Tree " + index + " -> " + size + " for " + docId);
    int high=size;
    int low=index;
    while (high - low > 1) {
      int probe=(low+high) >>> 1;
      if (docId(probe) < docId) {
        low=probe + 1;
      } else {
        high=probe;
      }
    }
    
    if (low == -1 || docId(low) != docId) {
      int lowId=low < 0 ? -1 : docId(low);
      int highId=high<size ? docId(high) : Integer.MAX_VALUE;
      
      //System.out.println("NF: lowId=" + lowId + ", highId=" + highId + ", req docId=" + docId);
      if (lowId<highId && lowId>=docId) return low;
      else return high;
    } else
      return low;
  }

  public int capacity() {
    return capacity;
  }
}
