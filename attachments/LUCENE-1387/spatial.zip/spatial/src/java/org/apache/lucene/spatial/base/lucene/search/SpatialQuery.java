/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.search;

import java.io.IOException;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.Explanation;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Scorer;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Similarity;
import org.apache.lucene.search.Weight;
import org.apache.lucene.spatial.base.MutableFixedLatLng;


/**
 * Does a precise spatial comparison
 */
public class SpatialQuery extends Query {
  private CandidateScorer candidateScorer;
  private Query innerQuery;
  private LatLngResolver latLngResolver;
  
  public SpatialQuery(CandidateScorer candidateScorer, LatLngResolver latLngResolver, Query innerQuery) {
    this.candidateScorer=candidateScorer;
    this.latLngResolver=latLngResolver;
    this.innerQuery=innerQuery;
  }
  
  public void close() {
    
  }
  
  @Override
  public String toString(String field) {
    return "(" + innerQuery.toString(field) + ") constrained to " + candidateScorer;
  }
  
  @Override
  protected Weight createWeight(Searcher searcher) throws IOException {
    final Weight innerWeight=innerQuery.weight(searcher);
    final Similarity similarity = innerQuery.getSimilarity(searcher);
    
    return new Weight() {
      private float value;
      
      public float getValue() { 
        return value; 
      }
      
      public float sumOfSquaredWeights() throws IOException {
        return innerWeight.sumOfSquaredWeights() * getBoost() * getBoost();
      }
      
      public void normalize(float v) {
        innerWeight.normalize(v);
        value = innerWeight.getValue() * getBoost();
      }
      
      public Explanation explain(IndexReader reader, int doc)
          throws IOException {
        return new Explanation((float) 1.0, "TODO");
      }
      
      public Query getQuery() {
        return SpatialQuery.this;
      }
      
      public Scorer scorer(IndexReader indexReader) throws IOException {
        final Scorer innerScorer=innerWeight.scorer(indexReader);
        return new Scorer(similarity) {
          private CandidateInfo info=new CandidateInfo();
          private MutableFixedLatLng latLng=new MutableFixedLatLng();
          private float score;
          
          private void updateScore(int docId) throws IOException {
            // Check it
            latLngResolver.lookupLatLng(docId, latLng);
            
            info.reset(docId);
            info.latLng=latLng;
            candidateScorer.update(info);
            
            if (info.included) {
              // Note: info.score should be between 0 and 1
              //float freq=info.score * query.termNormalizationFactor;
              
              // Lucene's approach to scoring involves counting terms.  Since distance isn't a term,
              // we fake it by saying that it is equivilent to the term appearing 10 times if the
              // distance is 0 (ie. info.score is 1.0).  This value is sqrt'd, so make doubly sure
              // not to have a negative
              //if (freq<0) freq=0;
              
              //score=getSimilarity().tf(freq) *
              //  weightValue;
              score=info.score*15;
            }
          }

          
          @Override
          public int doc() {
            return innerScorer.doc();
          }

          @Override
          public Explanation explain(int doc) throws IOException {
            return new Explanation((float)0.0, "TODO");
          }

          @Override
          public boolean next() throws IOException {
            for (;;) {
              boolean hasNext=innerScorer.next();
              if (!hasNext) return false;
              
              updateScore(innerScorer.doc());
              if (info.included) return true;
            }
          }

          @Override
          public float score() throws IOException {
            return score;
          }

          @Override
          public boolean skipTo(int target) throws IOException {
            if (innerScorer.skipTo(target)) {
              updateScore(innerScorer.doc());
              if (!info.included) {
                return next();
              } else {
                return true;
              }
            } else {
              return false;
            }
          }
          
        };
      }
    };
  }
  
}
