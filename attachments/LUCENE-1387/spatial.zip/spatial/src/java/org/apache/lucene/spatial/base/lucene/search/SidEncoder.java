/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.search;

import java.io.IOException;
import java.util.Arrays;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Index;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.Field.TermVector;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.TermFreqVector;
import org.apache.lucene.spatial.base.FixedLatLng;
import org.apache.lucene.spatial.base.LatLng;


/**
 * Utility class to produce a Field from a Sid and ancillary information
 */
public class SidEncoder {
  public static final SidEncoder DEFAULT=new SidEncoder(SpatialConfig.DEFAULT);
  
  private SpatialConfig config;
  
  public SidEncoder(SpatialConfig config) {
    this.config=config;
  }
  
  public SpatialConfig getSpatialConfig() {
    return config;
  }
  
  /**
   * Create a field representing a point for the given sids.  This field should be
   * added to the document.
   * @param sids
   * @param ll
   * @return
   */
  public void addPointsToDocument(Document document, LatLng... lls) {
    Field field = createPointsField(lls);
    document.add(field);
  }


  /**
   * Create a Lucene field to hold the passed shape points.
   * @param points
   * @return
   */
  public Field createPointsField(LatLng... lls) {
    String[] points = encodePoints(lls);

    Field field=new Field(config.getShapeField(), 
        new ListTokenStream(Arrays.asList(points)),
        TermVector.YES);
    return field;
  }


  /**
   * Encode Lat/Lngs in a list of strings to be stored in a field.
   * @param lls
   * @return
   */
  public String[] encodePoints(LatLng... lls) {
    String[] points=new String[lls.length];
    for (int i=0; i<points.length; i++) {
      points[i]="L" + encodeLatLng(lls[i]);
    }
    return points;
  }
  
  
  
  /**
   * Add spatial ids to the document
   * @param document
   * @param sids
   */
  public void addSidsToDocument(Document document, String... sids) {
    Field field = createSidsField(sids);
    document.add(field);
    
    if (config.isStoreSids()) {
      for (String sid: sids) {
        document.add(new Field(config.getSidField(), sid, Store.YES, Index.NO));
      }
    }
  }


  /**
   * Create a Lucene field for the given sids
   * @param sids
   * @return
   */
  public Field createSidsField(String... sids) {
    Field field=new Field(config.getSidField(), 
        new ListTokenStream(Arrays.asList(sids)));
    return field;
  }
  
  /**
   * Load the latlng point associated with a given document
   * @param docId
   * @param latLng
   * @return
   * @throws IOException 
   */
  public boolean loadPoint(org.apache.lucene.index.IndexReader reader, int docId, int[] latLng) throws IOException {
    TermFreqVector tfv=reader.getTermFreqVector(docId, config.getShapeField());
    if (tfv==null) return false;
    for (String term: tfv.getTerms()) {
      if (term.startsWith("L")) return decodeLatLng(term.substring(1), latLng);
    }
    return false;
  }
  
  /**
   * Loads the point associated with a document and returns it as a LatLng
   * @param reader
   * @param docId
   * @return LatLng or null if not found
   * @throws IOException 
   */
  public LatLng loadPointLatLng(IndexReader reader, int docId) throws IOException {
    int[] coords=new int[2];
    if (loadPoint(reader, docId, coords)) {
      return new FixedLatLng(coords[0], coords[1]);
    }
    return null;
  }
  
  public static String encodeLatLng(LatLng ll) {
    return encodeNumber(ll.getFixedLat()) + '/' + encodeNumber(ll.getFixedLng());
  }

  public static boolean decodeLatLng(String enc, int[] latLng) {
    int slashPos=enc.indexOf('/');
    if (slashPos<=0) return false;
    String latStr=enc.substring(0, slashPos), lngStr=enc.substring(slashPos+1);
    try {
      latLng[0]=Integer.parseInt(latStr, 36);
      latLng[1]=Integer.parseInt(lngStr, 36);
      return true;
    } catch (NumberFormatException e) {
      return false;
    }
  }
  
  private static String encodeNumber(int n) {
    return Integer.toString(n, 36);
  }
}
