/**
 * Copyright 2007 MapQuest, Inc
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific
 * language governing permissions and limitations under the License.
 *
 */
package org.apache.lucene.spatial.base.lucene.search;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.spatial.base.lucene.cache.SidCache;
import org.apache.lucene.spatial.base.lucene.cache.SidCacheVersion;
import org.apache.lucene.spatial.base.lucene.cache.SidData;
import org.apache.lucene.spatial.base.lucene.cache.SidDataCursor;
import org.apache.lucene.spatial.base.lucene.cache.SidPartition;


/**
 * Helper class for assembling a spatial query
 */
public class SpatialQueryBuilder {
  private SpatialConfig config=SpatialConfig.DEFAULT;
  private IndexReader reader;
  private Set<String> spatialIds=new HashSet<String>();
  private CandidateScorer candidateScorer=CandidateScorer.DEFAULT;

  private SidCache cache;
  
  public SpatialQueryBuilder(IndexReader reader) {
    this.reader=reader;
  }

  /**
   * If a cache is set, it will be used.  If not, direct traversal of the
   * Lucene index is used.
   * @param cache
   */
  public void setCache(SidCache cache) {
    this.cache = cache;
  }
  
  public void addSpatialIds(Collection<String> sids) {
    spatialIds.addAll(sids);
  }
  
  public void addSpatialIds(String... sids) {
    addSpatialIds(Arrays.asList(sids));
  }
  
  public void setCandidateScorer(CandidateScorer candidateScorer) {
    this.candidateScorer = candidateScorer;
  }
  
  public CandidateScorer getCandidateScorer() {
    return candidateScorer;
  }
  
  public void setConfig(SpatialConfig config) {
    this.config = config;
  }
  
  public SpatialConfig getConfig() {
    return config;
  }
  
  /**
   * Create a SpatialQuery.  This *must* be close()'d when not in use to avoid
   * resource leaks.
   * @return new SpatialQuery
   * @throws IOException 
   */
  public SpatialQuery create(Query origQuery) throws IOException {
    SidCursor cursors[]=new SidCursor[spatialIds.size()];
    int index=0;
    boolean success=false;
    
    try {
      for (String spatialId: spatialIds) {
        cursors[index++]=allocateSidCursor(spatialId);
      }
    
      success=true;
    } finally {
      if (!success) {
        // Close intermediates
        for (SidCursor c: cursors) if (c!=null) c.close();
      }
    }

    CompositeSidCursor sidCursor=new CompositeSidCursor(cursors);
    SpatialCandidateQuery candidateQuery=new SpatialCandidateQuery(sidCursor, candidateScorer, spatialIds.toArray(new String[spatialIds.size()]));
    // Tack this on as a boolean clause
    BooleanQuery boolQuery;
    boolQuery=new BooleanQuery();
    if (origQuery!=null) {
      boolQuery.add(origQuery, BooleanClause.Occur.MUST);
    }
    
    boolQuery.add(candidateQuery, BooleanClause.Occur.MUST);
    
    
    return new SpatialQuery(candidateScorer, sidCursor, boolQuery);
  }

  /**
   * Allocate a Sid Cursor for a spatial id
   * @param spatialId
   * @return
   * @throws IOException 
   */
  protected SidCursor allocateSidCursor(String spatialId) throws IOException {
    if (cache!=null) {
      SidCacheVersion scv=cache.open(reader);
      SidPartition partition=scv.openPartition(spatialId, reader);
      SidData sidData=partition.getSidData();
        return new SidDataCursor(sidData);
    } else {
      return new TermDocsSidCursor(config, reader, spatialId);
    }
  }
  
}
