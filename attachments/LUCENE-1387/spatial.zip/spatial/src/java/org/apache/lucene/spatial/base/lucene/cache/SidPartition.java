/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.lucene.spatial.base.lucene.cache;

import java.io.IOException;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermDocs;
import org.apache.lucene.spatial.base.lucene.search.SidEncoder;
import org.apache.lucene.spatial.base.lucene.search.SpatialConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class SidPartition {
  private static final Logger LOG=LoggerFactory.getLogger( SidPartition.class );
  
  private static final long PARTITION_OVERHEAD_BYTES=128;
  
  private static SpatialConfig config=SpatialConfig.DEFAULT;
  
  private SidCacheVersion owner;

  private boolean initialized;
  private Throwable initializationError;
  
  SidData sidData;
  String sid;
  
  public SidPartition(SidCacheVersion sidCacheVersion, String sid) {
    this.owner=sidCacheVersion;
    this.sid=sid;
  }

  void acquire(IndexReader reader) throws IOException {
    synchronized (this) {
      boolean isInitializer=false;
      for (;;) {
        if (initialized) {
          if (initializationError!=null) {
            IOException e=new IOException("Error initializing sid partition");
            e.initCause(initializationError);
            throw e;
          }
          
          break;
        } else {
          // Initialize in synchronized block
          initialized=true;
          try {
            initialize(reader);
            isInitializer=true;
          } catch (Throwable t) {
            initializationError=t;
          }
        }
      }
    }
  }

  public SidData getSidData() {
    return sidData;
  }
  
  protected SidData createCachedSid(IndexReader reader, String spatialId) throws IOException {
    long startTime=System.currentTimeMillis();
    
    Term term=new Term(config.getSidField(), spatialId);
    TermDocs td=reader.termDocs(term);
    int capacity=reader.docFreq(term);
    SidData sidData=new LazySidData(reader, new SidEncoder(config), capacity+1);
    int[] docs=new int[1000];
    int[] freqs=new int[1000];
    
    for (;;) {
      int r=td.read(docs, freqs);
      if (r==0) break;
      for (int i=0; i<r; i++) {
        sidData.add(docs[i], Integer.MAX_VALUE, Integer.MAX_VALUE);
      }
    }
    
    // Already sorted, so no need to finish() it
    
    LOG.info("Created sid partition for " + spatialId + " (size=" + sidData.size() + ") in "
        + (System.currentTimeMillis()-startTime) + "ms");
    return sidData;
  }

  private void initialize(IndexReader reader) throws IOException {
    sidData=createCachedSid(reader, sid);
  }

  public long estimateMemoryUsage() {
    return PARTITION_OVERHEAD_BYTES + ((long)sidData.capacity()) * 12;
  }
}
