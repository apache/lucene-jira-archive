/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.examples.poi;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.spatial.base.FloatLatLng;
import org.apache.lucene.spatial.base.LatLng;
import org.apache.lucene.spatial.base.geometry.Ellipse;
import org.apache.lucene.spatial.base.geometry.LLRect;
import org.apache.lucene.spatial.base.geometry.Rectangle;
import org.apache.lucene.spatial.base.lucene.search.DistanceCandidateScorer;
import org.apache.lucene.spatial.base.lucene.search.SidEncoder;
import org.apache.lucene.spatial.base.lucene.search.SpatialQueryBuilder;
import org.apache.lucene.spatial.base.sid.SpatialCell;
import org.apache.lucene.spatial.base.sid.SpatialGrid;
import org.apache.lucene.spatial.base.sid.SpatialIndexer;
import org.apache.lucene.spatial.base.sid.SpatialLevel;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;


/**
 * This class encapsulates POI searching.  It contains a spatial search method
 * which uses the enhanced searching infrastructure and a reference method which
 * iterates over all documents and precisely determines results.
 *
 */
public class POISearcher {
  
  private Directory dir;
  private IndexReader indexReader;
  private IndexSearcher indexSearcher;

  private SidEncoder encoder=SidEncoder.DEFAULT;
  
  public POISearcher(Directory dir) throws CorruptIndexException, IOException {
    this.dir=dir;
    this.indexReader=IndexReader.open(dir);
    this.indexSearcher=new IndexSearcher(indexReader);
  }
  
  /**
   * Perform an exact search over all documents, returning all that are within a given
   * radius (in mi) from the centerPoint.  The list is ordered by distance.
   * @param centerPoint
   * @param radius
   * @return List of results ordered by distance
   * @throws IOException 
   */
  public List<POIResult> referenceRadialSearch(LatLng centerPoint, double radius) throws IOException {
    List<POIResult> ret=new ArrayList<POIResult>();
    for (int i=0; i<indexReader.maxDoc(); i++) {
      POIResult poi=new POIResult(i, indexReader, encoder, centerPoint);
      if (poi.distanceMi<=radius) ret.add(poi);
    }
    
    // Sort it
    Collections.sort(ret, new Comparator<POIResult>() {
      public int compare(POIResult lhsObj, POIResult rhsObj) {
        double lhs=lhsObj.distanceMi, rhs=rhsObj.distanceMi;
        
        if (lhs<rhs) return -1;
        else if (lhs>rhs) return 1;
        return 0;
      }
    });
    
    return ret;
  }
  
  public List<POIResult> stdRadialSearch(LatLng centerPoint, double radius) throws IOException {
    List<POIResult> ret=new ArrayList<POIResult>();
    
    SpatialLevel[] levels=SpatialIndexer.calculateSpatialLevels(centerPoint, 20);
    SpatialGrid grid=SpatialGrid.createOptimalGrid(levels, radius*2.5, radius*2.5, 50);
    Rectangle boundingBox=LLRect.createBox(centerPoint, radius*2.1, radius*2.1).toRectangle();
    Ellipse shape=new Ellipse(boundingBox.getMinPoint(), boundingBox.getMaxPoint(), 0);
    
    grid.selectIntersecting(shape);
    
    System.err.println("Created grid at " + grid.getReferenceLevel() + ": " + grid.getColCount() + ", " + grid.getRowCount() +
        " Area=" + grid.areaOfSelected() + "sq. mi");

    SpatialQueryBuilder queryBuilder=new SpatialQueryBuilder(indexReader);
    for (SpatialCell cell: grid.getCells()) {
      queryBuilder.addSpatialIds(cell.getLevel().getSpatialIndex().getStringValue());
    }
    
    queryBuilder.setCandidateScorer(new DistanceCandidateScorer(centerPoint, radius));
    
    Query query=queryBuilder.create(null);
    TopDocs topDocs=indexSearcher.search(query, null, 500);
    for (ScoreDoc scoreDoc: topDocs.scoreDocs) {
      POIResult poi=new POIResult(scoreDoc.doc, indexReader, encoder, centerPoint);
      ret.add(poi);
    }
    
    return ret;
  }
  
  /**
   * Run side by side radius and ref searches.  To find wifi hotspots within 3mi of the center of
   * San Francisco, use the following arguments:
   *   37.775002 -122.418297 3
   * @param args
   * @throws Exception
   */
  public static void main(String[] args) throws Exception {
    if (args.length<3) {
      System.err.println("Expected: lat lng radius");
      System.exit(3);
    }
    
    String latStr=args[0];
    String lngStr=args[1];
    String radiusStr=args[2];
    
    double lat=Double.parseDouble(latStr), lng=Double.parseDouble(lngStr);
    double radius=Double.parseDouble(radiusStr);
    
    LatLng centerPoint=new FloatLatLng(lat, lng);
    
    Directory dir=new RAMDirectory();
    IndexWriter indexWriter=new IndexWriter(dir, new SimpleAnalyzer());
    POILoader loader=new POILoader(indexWriter);
    loader.indexGarminCSV(POISearcher.class.getResourceAsStream("WiFi_us.csv"));
    indexWriter.close();
    
    POISearcher searcher=new POISearcher(dir);
    
    // Do the ref search
    List<POIResult> refResults=searcher.referenceRadialSearch(centerPoint, radius);
    System.out.println("Ref results (" + refResults.size() + "):");
    for (POIResult result: refResults) {
      System.out.println("  " + result);
    }

    // Do the std search
    List<POIResult> stdResults=searcher.stdRadialSearch(centerPoint, radius);
    System.out.println("Std results (" + stdResults.size() + "):");
    for (POIResult result: stdResults) {
      System.out.println("  " + result);
    }

  }
}
