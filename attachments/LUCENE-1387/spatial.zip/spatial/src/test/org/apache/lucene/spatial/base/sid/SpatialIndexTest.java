/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.sid;

import static org.junit.Assert.*;

import org.apache.lucene.spatial.base.sid.SpatialIndex;
import org.junit.Test;


public class SpatialIndexTest {

  @Test
  public void testExtract1() {
    SpatialIndex si=new SpatialIndex(0xffffff, 0x3);
    assertTrue(0xffffff==si.getIndex());
    assertEquals(3, si.getLevel());
  }
  
  @Test
  public void testExtract2() {
    SpatialIndex si=new SpatialIndex(0xefefef, 0xe);
    assertTrue(0xefefef==si.getIndex());
    assertEquals(14, si.getLevel());
  }

  
  @Test
  public void testSubtractLevels() {
    SpatialIndex si=new SpatialIndex(0xefefef, 0xe);
    si=si.subtractLevel(4);
    assertTrue(10==si.getLevel());
    assertTrue(0xefef==si.getIndex());
  }

  @Test(expected=IllegalArgumentException.class)
  public void testSubtractTooMany() {
    SpatialIndex si=new SpatialIndex(0xefefef, 0xe);
    si=si.subtractLevel(15);
  }
  
  @Test
  public void testDerivedCtor() {
    SpatialIndex si=new SpatialIndex(0xefefef, 3);
    assertTrue(0xefefef==si.getIndex());
    assertTrue(3==si.getLevel());
  }
  
  @Test(expected=IllegalArgumentException.class)
  public void testDerivedCtorError() {
    SpatialIndex si=new SpatialIndex(0xefefef, 32);
  }
}
