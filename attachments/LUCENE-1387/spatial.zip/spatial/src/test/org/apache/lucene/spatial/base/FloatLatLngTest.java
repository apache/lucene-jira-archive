/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base;

import static org.junit.Assert.*;

import org.apache.lucene.spatial.base.FloatLatLng;
import org.apache.lucene.spatial.base.LatLng;
import org.junit.Test;


public class FloatLatLngTest {

  @Test
  public void testConversion() {
    LatLng ll1=new FloatLatLng(74.0, 169.0);
    assertEquals(74000000, ll1.getFixedLat());
    assertEquals(169000000, ll1.getFixedLng());
    assertEquals(74.0, ll1.getLat());
    assertEquals(169.0, ll1.getLng());
    assertFalse(ll1.isFixedPoint());
    assertTrue(ll1.isNormalized());
    
    LatLng ll2=ll1.toFixed();
    assertEquals(74000000, ll2.getFixedLat());
    assertEquals(169000000, ll2.getFixedLng());
    assertEquals(74.0, ll2.getLat());
    assertEquals(169.0, ll2.getLng());
    assertTrue(ll2.isFixedPoint());
    
    LatLng ll3=ll2.toFloat();
    assertFalse(ll3.isFixedPoint());
    assertEquals(74000000, ll3.getFixedLat());
    assertEquals(169000000, ll3.getFixedLng());
    assertEquals(74.0, ll3.getLat());
    assertEquals(169.0, ll3.getLng());
  }
  
  @Test
  public void testNormalization() {
    LatLng ll1=new FloatLatLng(74.0, 181.0);
    assertFalse(ll1.isNormalized());
    
    LatLng ll2=ll1.normalize();
    assertTrue(ll2.isNormalized());
    assertEquals(74000000, ll2.getFixedLat());
    assertEquals(-179000000, ll2.getFixedLng());
    assertEquals(74.0, ll2.getLat());
    assertEquals(-179.0, ll2.getLng());
    
    LatLng ll3=ll2.normalize();
    assertEquals(ll2, ll3);    // Already normalized, so should return same instance
  }
  
  @Test(expected=IllegalArgumentException.class)
  public void testIllegal() {
    new FloatLatLng(92.0, 3.0);
  }

  @Test
  public void testMidpoint() {
    FloatLatLng ll1=new FloatLatLng(30,30);
    FloatLatLng ll2=new FloatLatLng(10,10);
    assertEquals(new FloatLatLng(20,20), ll1.calculateMidpoint(ll2));
  }

}
