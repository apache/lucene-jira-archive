/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.cache;

import java.util.BitSet;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import org.apache.lucene.spatial.base.lucene.cache.SidData;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import static org.junit.Assert.*;

public class CachedSidTest {

  private Set<Integer> docIds;
  private SidData cs;
  
  private long startTime=System.currentTimeMillis();
  
  @Before
  public void setUp() {
    int count=50000;
    docIds=new HashSet<Integer>(count*2);
    cs=new SidData(5000);
    Random random=new Random();
    
    for (int i=0; i<count; i++) {
      int next=random.nextInt(16000000);
      if (docIds.contains(next)) {
        i--;
        continue;
      }
      
      docIds.add(next);
      cs.add(next, next+1, next+2);
    }
    
    cs.finish();
    
    System.out.print("CachedSid init in " + (System.currentTimeMillis()-startTime) + "ms.  ");
  }
  
  @After
  public void after() {
    System.out.println("Test ran in " + (System.currentTimeMillis()-startTime) + "ms");
  }
  
  @Test
  public void testDummy() {
  }

  @Test
  public void testOrder() {
    assertEquals(50000, cs.size());
    int prevDocId=-1;
    for (int i=0; i<cs.size(); i++) {
      int docId=cs.docId(i);
      int lat=cs.lat(i);
      int lng=cs.lng(i);
      assertTrue(docId>prevDocId);
      assertEquals(docId+1, lat);
      assertEquals(docId+2, lng);
    }
  }
  
  @Test
  public void testLookup() {
    for (Integer docId: docIds) {
      int index=cs.findIndex(docId);
      assertTrue(index>=0);

      int docIdCheck=cs.docId(index);
      int lat=cs.lat(index);
      int lng=cs.lng(index);
      assertEquals(docId, docIdCheck);
      assertEquals(docId+1, lat);
      assertEquals(docId+2, lng);
    }
  }
  
  @Test
  public void testFillBitset() {
    BitSet bs=new BitSet(cs.maxDocId());
    cs.fillBitSet(bs);
    assertEquals(cs.size(), bs.cardinality());
    for (int i=0; i<cs.size(); i++) {
      assertTrue(bs.get(cs.docId(i)));
    }
  }
}
