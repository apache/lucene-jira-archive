/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base;

import static org.junit.Assert.*;

import org.apache.lucene.spatial.base.FixedLatLng;
import org.apache.lucene.spatial.base.LatLng;
import org.junit.Test;


public class FixedLatLngTest {
  
  @Test
  public void testConversion() {
    LatLng ll1=new FixedLatLng(74000000, 169000000);
    assertEquals(74.0, ll1.getLat());
    assertEquals(169.0, ll1.getLng());
    assertTrue(ll1.isFixedPoint());
    assertTrue(ll1.isNormalized());
    
    LatLng ll2=ll1.toFloat();
    assertEquals(74.0, ll2.getLat());
    assertEquals(169.0, ll2.getLng());
    assertFalse(ll2.isFixedPoint());
    
    LatLng ll3=ll2.toFixed();
    assertTrue(ll3.isFixedPoint());
    assertEquals(74000000, ll3.getFixedLat());
    assertEquals(169000000, ll3.getFixedLng());
  }
  
  @Test
  public void testNormalization() {
    LatLng ll1=new FixedLatLng(74000000, 181000000);
    assertFalse(ll1.isNormalized());
    
    LatLng ll2=ll1.normalize();
    assertTrue(ll2.isNormalized());
    assertEquals(74000000, ll2.getFixedLat());
    assertEquals(-179000000, ll2.getFixedLng());
    
    LatLng ll3=ll2.normalize();
    assertEquals(ll2, ll3);    // Already normalized, so should return same instance
  }
  
  @Test(expected=IllegalArgumentException.class)
  public void testIllegal() {
    new FixedLatLng(92000000, 3000000);
  }
  
  @Test
  public void testMidpoint() {
    FixedLatLng ll1=new FixedLatLng(30,30);
    FixedLatLng ll2=new FixedLatLng(10,10);
    assertEquals(new FixedLatLng(20,20), ll1.calculateMidpoint(ll2));
  }
}
