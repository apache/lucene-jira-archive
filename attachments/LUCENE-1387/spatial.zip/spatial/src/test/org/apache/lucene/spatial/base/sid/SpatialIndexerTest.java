/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.sid;

import static org.junit.Assert.*;

import org.apache.lucene.spatial.base.FloatLatLng;
import org.apache.lucene.spatial.base.sid.SpatialIndex;
import org.apache.lucene.spatial.base.sid.SpatialIndexer;
import org.apache.lucene.spatial.base.sid.SpatialLevel;
import org.junit.Test;


public class SpatialIndexerTest {

  
  
  @Test
  public void testDiffIndexes() {
    SpatialIndex s1=SpatialIndexer.calculateSpatialIndex(new FloatLatLng(39.745075, -104.98961), 15);
    System.out.println("S1: " + s1.getValue() + " [" + Long.toString(s1.getIndex(), 16) + ", " + s1.getLevel() + "]");
    assertTrue(0x4a73732b==s1.getIndex());
    
    SpatialIndex s2=SpatialIndexer.calculateSpatialIndex(new FloatLatLng(39.382768, -104.843973), 15);
    assertTrue(0x4a733f07==s2.getIndex());
    
    System.out.println("S2: " + s2.getValue() + " [" + Long.toString(s2.getIndex(), 16) + ", " + s2.getLevel() + "]");
    
    // These indexes should not be equal - they are about 40 miles apart
    assertFalse(s1.getValue()==s2.getValue());
    assertEquals(15, s1.getLevel());
    assertEquals(15, s2.getLevel());
    
    // But if we back them both up to level 7, they should be equal
    SpatialIndex s1_back=s1.toLevel(7);
    SpatialIndex s2_back=s2.toLevel(7);
    System.out.println("S1_back: " + s1_back.getValue() + " [" + Long.toString(s1_back.getIndex(), 16) + ", " + s1_back.getLevel() + "]");
    System.out.println("S2_back: " + s2_back.getValue() + " [" + Long.toString(s2_back.getIndex(), 16) + ", " + s2_back.getLevel() + "]");
    
    assertEquals(s1_back.getValue(), s2_back.getValue());
    assertTrue(0x4a73==s1_back.getIndex());
  }
  
  @Test
  public void testLevels() {
    SpatialLevel[] levels=SpatialIndexer.calculateSpatialLevels(new FloatLatLng(40.71451, -74.00714), 28);
    for (SpatialLevel sl: levels) {
      System.out.println("Level " + sl.getLevel() + ": " + Long.toString(sl.getSpatialIndex().getValue(), 35));
      System.out.println("  Bounding Box " + sl.getBoundingBox());
      System.out.println("  Width " + sl.getWidthInMiles() + "mi   " + (sl.getWidthInMiles()*5280) + "ft");
      System.out.println("  Height " + sl.getHeightInMiles() + "mi   " + (sl.getHeightInMiles()*5280) + "ft");
    }
    
  }
}
