/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.cache;

import java.io.IOException;

import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.spatial.base.FixedLatLng;
import org.apache.lucene.spatial.base.lucene.cache.SidCache;
import org.apache.lucene.spatial.base.lucene.cache.SidCacheVersion;
import org.apache.lucene.spatial.base.lucene.cache.SidPartition;
import org.apache.lucene.spatial.base.lucene.search.SidEncoder;
import org.apache.lucene.spatial.base.lucene.search.SpatialConfig;
import org.apache.lucene.store.LockObtainFailedException;
import org.apache.lucene.store.RAMDirectory;
import org.junit.Test;


import static org.junit.Assert.*;

public class SidCacheTest {

  @Test
  public void test() throws CorruptIndexException, LockObtainFailedException, IOException, InterruptedException {
    RAMDirectory d=new RAMDirectory();
    IndexWriter w=new IndexWriter(d, new SimpleAnalyzer());
    SidEncoder sidEncoder=new SidEncoder(SpatialConfig.DEFAULT);
    for (int i=0; i<20; i++) {
      // Each spatial id will be about 20kb and will be "0", "1", ... "19"
      for (int j=0; j<1500; j++) {
        Document doc=new Document();
        sidEncoder.addSidsToDocument(doc, String.valueOf(i));
        sidEncoder.addPointsToDocument(doc, new FixedLatLng(0, 0));
        w.addDocument(doc);
      }
    }
    w.close();
    
    IndexReader r=IndexReader.open(d);
    
    SidCache cache=new SidCache();
    cache.setCacheMax(50*1024);
    cache.start();
    
    
    for (int i=0; i<20; i++) {
      SidCacheVersion scv=cache.open(r);
      
      SidPartition sp=scv.openPartition(String.valueOf(i), r);
      Thread.sleep(50);
      assertTrue(cache.memoryUsage.get() > 0);
    }
    
    Thread.sleep(1000);
    System.out.println("Memory usage: " + cache.memoryUsage.get());
    assertTrue(cache.memoryUsage.get() > 0);
    assertTrue(cache.memoryUsage.get() < 50*1024);
  }
}
