/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.sid;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

import org.apache.lucene.spatial.base.FloatLatLng;
import org.apache.lucene.spatial.base.LatLng;
import org.apache.lucene.spatial.base.sid.SpatialIndex;
import org.apache.lucene.spatial.base.sid.SpatialIndexer;
import org.apache.lucene.spatial.base.sid.SpatialLevel;
import org.apache.lucene.spatial.base.sid.TranslateDirection;
import org.junit.Before;
import org.junit.Test;


public class SpatialIndexTranslationTest {

  SpatialLevel[] referenceLevels;
  
  @Before
  public void setup() {
    referenceLevels=SpatialIndexer.calculateSpatialLevels(new FloatLatLng(40.71451, -74.00714), 20);
  }
  
  @Test
  public void testTranslateUp() {
    for (int l=10; l<referenceLevels.length; l++) {
      //System.out.println("Verifying up level " + l);
      grindDirection(referenceLevels[l], TranslateDirection.UP);
    }
  }

  @Test
  public void testTranslateDown() {
    for (int l=10; l<referenceLevels.length; l++) {
      //System.out.println("Verifying down level " + l);
      grindDirection(referenceLevels[l], TranslateDirection.DOWN);
    }
  }
  
  @Test
  public void testTranslateLeft() {
    for (int l=10; l<referenceLevels.length; l++) {
      //System.out.println("Verifying left level " + l);
      grindDirection(referenceLevels[l], TranslateDirection.LEFT);
    }
  }

  @Test
  public void testTranslateRight() {
    for (int l=10; l<referenceLevels.length; l++) {
      //System.out.println("Verifying right level " + l);
      grindDirection(referenceLevels[l], TranslateDirection.RIGHT);
    }
  }



  private void grindDirection(SpatialLevel start, TranslateDirection dir) {
    SpatialLevel prev=start;

    for (int i=0; i<100; i++) {
      //System.out.println("Verifying translation " + dir + " " + i);
      SpatialLevel orig=prev;
      SpatialLevel level1=prev.translate(dir);
      prev=level1;
      assertFalse("Translated level bbox != prev", level1.getBoundingBox().equals(prev));
      
      SpatialLevel level2=level1.translate(dir.inverse());
      assertEquals(orig.getSpatialIndex(), level2.getSpatialIndex());
      assertFalse(orig.getSpatialIndex().equals(level1.getSpatialIndex()));
      assertEquals(orig.getBoundingBox(), level2.getBoundingBox());
      
      verifyBoundingBox(level1);
      verifyBoundingBox(level2);
    }
    
  }

  private void verifyBoundingBox(SpatialLevel level) {
    // Re-derive the spatial index from the bounding box mid point and verify
    LatLng midpoint=level.getBoundingBox().getMidpoint();
    SpatialIndex cmpIndex=SpatialIndexer.calculateSpatialIndex(midpoint, level.getLevel());
    assertEquals(level.getSpatialIndex().getStringValue(), cmpIndex.getStringValue());
  }
}
