/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.lucene.search;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;
import java.util.TreeSet;

import org.apache.lucene.spatial.base.lucene.cache.SidData;
import org.apache.lucene.spatial.base.lucene.search.CompositeSidCursor;
import org.junit.Test;


import static org.junit.Assert.*;

public class SidDocsTest {
  private CompositeSidCursor sd;
  
  public void fillOddEven(int iterations) {
    SidData[] datas;
    datas=new SidData[4];
    
    SidData data=new SidData(iterations);
    datas[0]=datas[2]=data;
    for (int i=0; i<iterations; i++) {
      int n=i*2;
      data.add(n, n, n);
    }
    data.finish();
    
    datas[1]=datas[3]=data;
    for (int i=0; i<iterations; i++) {
      int n=i*2+1;
      data.add(n, n, n);
    }
    data.finish();
    
    Collections.shuffle(Arrays.asList(datas));
    this.sd=new CompositeSidCursor(datas);
  }

  public TreeSet<Integer> fillRandom() {
    SidData[] datas;
    TreeSet<Integer> ids=new TreeSet<Integer>();
    
    Random random=new Random();
    datas=new SidData[10];
    for (int i=0; i<datas.length; i++) {
      SidData data=new SidData(1000);
      datas[i]=data;
      
      for (int j=0; j<1000; j++) {
        int n=random.nextInt(2000);
        data.add(n, n, n);
        ids.add(n);
      }
      data.finish();
    }

    Collections.shuffle(Arrays.asList(datas));
    this.sd=new CompositeSidCursor(datas);

    return ids;
  }


  @Test
  public void randomTests() throws IOException {
    TreeSet<Integer> ids;
    
    ids=fillRandom();
    verifyRandom(ids);
    
    ids=fillRandom();
    verifySeekTo(ids);
  }
  
  public void verifyRandom(TreeSet<Integer> ids) throws IOException {
    for (Integer id: ids) {
      assertTrue(sd.next());
      assertEquals(id, sd.doc());
    }
    
    assertFalse(sd.next());
  }
  
  @Test
  public void testSequential() throws IOException {
    fillOddEven(10);
    int lastDoc=-1;
    while (sd.next()) {
      int curDoc=sd.doc();
      //System.out.println("curDoc=" + curDoc);
      assertTrue("nextDoc(" + curDoc + ") != lastDoc(" + lastDoc + ") + 1", curDoc==(lastDoc+1));
      lastDoc=curDoc;
    }
    
    System.out.println("lastDoc=" + lastDoc);
  }
  
  public void verifySeekTo(TreeSet<Integer> ids) throws IOException {
    Iterator<Integer> iter=ids.iterator();
    int index=0;
    outer: while (iter.hasNext()) {
      if ((index%10)==0) {
        if ((index%3)==0) {
          // Test type 1 - Exact seek to
          Integer id=0;
          for (int j=0; j<5; j++) {
            if (!iter.hasNext()) break outer;
            id=iter.next();
          }
          
          assertTrue(sd.skipTo(id));
          assertEquals(id, sd.doc());
        } else {
          // Test type 2 - In-Exact seek to
          Integer id=0;
          for (int j=0; j<5; j++) {
            if (!iter.hasNext()) break outer;
            id=iter.next();
          }

          System.out.println("\n=== INEXACT ===");
          assertTrue(sd.skipTo(id-1));
          int doc=sd.doc();
          assertTrue(doc>=id-1);
          if (doc!=id) {
            // Need to skip ahead by one
            System.out.println("Inexact seek to " + id);
            assertTrue(sd.next());
            assertEquals(id, sd.doc());
          }
        }
      } else {
        // Test type 3 - Verify sequential
        Integer id=iter.next();
        assertTrue(sd.next());
        assertEquals(id, sd.doc());
      }
      
      index++;
    }
  }
}
