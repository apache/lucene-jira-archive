/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.lucene.spatial.base.examples.poi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.Index;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.spatial.base.FloatLatLng;
import org.apache.lucene.spatial.base.LatLng;
import org.apache.lucene.spatial.base.lucene.search.SidEncoder;
import org.apache.lucene.spatial.base.lucene.search.SpatialConfig;
import org.apache.lucene.spatial.base.sid.SpatialIndexer;
import org.apache.lucene.spatial.base.sid.SpatialLevel;


/**
 * Simple class to load external files into a Lucene index
 */
public class POILoader {
  private IndexWriter indexWriter;
  private SidEncoder encoder=new SidEncoder(SpatialConfig.DEFAULT);
  
  private int maxLevel=20;
  
  private int id;
  
  public POILoader(IndexWriter w) {
    this.indexWriter=w;
  }
  
  public void addPoi(double lat, double lng, String label) throws CorruptIndexException, IOException {
    LatLng ll=new FloatLatLng(lat, lng);
    Document doc=new Document();
    doc.add(new Field("id", String.valueOf(++id), Store.YES, Index.UN_TOKENIZED));
    doc.add(new Field("label", label, Store.YES, Index.TOKENIZED));
    
    encoder.addPointsToDocument(doc, ll);
    
    // Calculate spatial ids - normally you would only calculate some of these
    SpatialLevel[] levels=SpatialIndexer.calculateSpatialLevels(ll, maxLevel);
    for (SpatialLevel level: levels) {
      encoder.addSidsToDocument(doc, level.getSpatialIndex().getStringValue());
    }
    
    indexWriter.addDocument(doc);
  }
  
  public void indexGarminCSV(InputStream inStream) throws IOException {
    BufferedReader in=new BufferedReader(new InputStreamReader(inStream, "UTF-8"));
    
    // CSV as a specification is remarkably difficult to parse.  The following is
    // good enough for example purposes.
    for (;;) {
      String line=in.readLine();
      if (line==null) break;
      line=line.trim();
      if (line.length()==0) continue;
      
      int comma1=line.indexOf(',');
      int comma2=line.indexOf(',', comma1+1);
      if (comma1<0 || comma2<=comma1) continue;
      
      String lngStr=line.substring(0, comma1).trim();
      String latStr=line.substring(comma1+1, comma2).trim();
      String remainder=line.substring(comma2+1).trim();
      
      if (remainder.startsWith("\"") && remainder.endsWith("\"")) 
        remainder=remainder.substring(1, remainder.length()-1);
      
      try {
        double lat=Double.parseDouble(latStr);
        double lng=Double.parseDouble(lngStr);
        addPoi(lat, lng, remainder);
      } catch (NumberFormatException e) {
        // Ignore
      }
    }
  }
}
