Copyright 2009 www.imdict.net www.ictclas.org
 
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

* 本文件夹中的词典文件和停止词(stop words)文件均以 apache license 2.0 发布，使用时请注意遵循该授权

* stopwords.txt 与 engstopwords.txt两个文件由原来的GBK编码转成了UTF-8编码。

*  连同lucene对索引的optimize，处理速度： 581M/3292s = 176K/s，因为词典中短句较多.
   ChineseAnalyzer对普通文章的长句的分词速度大约是76K/s，ICTCLAS的google group中有人实现了15K/s的速度，
    他认为基本可用，看来我的分词程序可用程度更高：）

* analysis-data下面必须有有bigramdict.dct coredict.dct stopwords_utf8.txt这三个文件。
   bigramdict.mem coredict.mem是上面两个dct文件的内容经过处理得到，
   他们可以直接载入内存，因此节省了每次都解析处理dct的时间（约10s），
   第一次运行时会自动生成mem文件，因此第二次运行时会快很多。