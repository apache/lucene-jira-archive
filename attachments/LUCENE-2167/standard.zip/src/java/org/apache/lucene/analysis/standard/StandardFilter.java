package org.apache.lucene.analysis.standard;

import org.apache.lucene.analysis.TokenStream;

/**
 * @deprecated Use ClassicFilter instead. This class only exists for backwards compatibility.
 */
@Deprecated
public class StandardFilter extends ClassicFilter {
  public StandardFilter(TokenStream in) {
    super(in);
  }
}
