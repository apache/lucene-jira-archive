package com.inperspective.colloc;

import java.util.HashSet;

/**
 * This default implementation uses a stoplist to determine uninteresting words. A more sophisticated 
 * version may use a dictionary eg WordNet to remove non-nouns 
 * @author MAHarwood
 */
public class DefaultTermFilter implements TermFilter
{
    HashSet stopList = new HashSet();
    
    String stops[] = { "a", "and", "are", "as", "at", "be", "but", "by",
            "for", "if", "in", "into", "is", "it", "no", "not", "of", "on",
            "or", "s", "such", "t", "that", "the", "their", "then", "there",
            "these", "they", "this", "to", "was", "will", "with", "how",
            "much", "always", "because", "much", "many", "every", "already",
            "only", "why", "didn", "you", "we", "she", "her", "from", "us",
            "me", "i", "our", "give", "had", "have", "has", "any", "some",
            "who", "what", "when", "on", "also", "can", "which", "where", "an",
            "your", "does", "through", "here", "more", "were", "so", "do",
            "each", "get", "he", "over", "under", "below", "it", "been",
            "about", "includes", "all", "after", "shall", "should", "take",
            "need", "know", "other", "see", "out", "don",//don=don't 
            "please", "other", "would", "become", "became", "most", "just",
            "other", "seem", "gave", "just", "like", "make", "now", "take",
            "than", "those", "try", "won", //won't
            "would", "them", "welcome", "around", "best", "new" };

    static int DEFAULT_MIN_TERM_LENGTH = 3;
    int minTermLength = DEFAULT_MIN_TERM_LENGTH;
    
    public DefaultTermFilter()
    {
        for (int i = 0; i < stops.length; i++)
        {
            stopList.add(stops[i]);
        }        
    }
    
    public boolean processTerm(String term)
    {
        if ((term.length() < minTermLength)
                || (stopList.contains(term)))
        {
            return false;
        }
        
        
        return true;
    }

}
