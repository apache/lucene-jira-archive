package com.inperspective.colloc;

import java.io.IOException;

/**
 * @author MAHarwood
 */
public interface CollocationLogger
{
    void logCollocation(Collocation collocation) throws IOException;     
}
