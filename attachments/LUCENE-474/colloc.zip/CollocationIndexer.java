package com.inperspective.colloc;

import java.io.IOException;


import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.store.FSDirectory;


/**
 * @author MAHarwood
 */
public class CollocationIndexer implements CollocationLogger
{
    FSDirectory dir;
    IndexWriter writer;
    public CollocationIndexer(String newIndexDir, Analyzer analyzer) throws IOException
    {
        dir=FSDirectory.getDirectory(newIndexDir,true);
        writer=new IndexWriter(dir, analyzer,true);
        setMaxBufferedDocs(10000);
    }
    
    public void setMaxBufferedDocs(int numDocs)
    {
        writer.setMaxBufferedDocs(numDocs);
    }
    public int getMaxBufferedDocs()
    {
        return writer.getMaxBufferedDocs();
    }

    /* (non-Javadoc)
     * @see com.inperspective.colloc.CollocationLogger#logCollocation(com.inperspective.colloc.Collocation)
     */
    public void logCollocation(Collocation collocation) throws IOException
    {
        Document doc=new Document();
        doc.add(new Field("term",collocation.term,Field.Store.NO,Field.Index.UN_TOKENIZED,Field.TermVector.NO));
        doc.add(new Field("coincidentalTerm",collocation.coincidentalTerm,Field.Store.YES,Field.Index.UN_TOKENIZED,Field.TermVector.NO));
        doc.setBoost(collocation.getScore()*100f);
        writer.addDocument(doc);    
        System.out.println(collocation.term+":"+collocation.coincidentalTerm);
    } 
    public void close() throws IOException
    {
        dir.close();
        writer.optimize();
        writer.close();
    }
}
