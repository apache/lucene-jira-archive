package com.inperspective.colloc;

/**
 * Records the total number of coincidences of two terms
 * @author MAHarwood
 */
public class Collocation
{
    String term;
    String coincidentalTerm;

    // the number of shared references ie num docs "fast" coincides with
    // "food".
    int coIncidenceDocCount = 0;

    int termADocFreq;

    private int termBDocFreq;

    /**
     * @param coincidentalTerm
     *            the coincidental term eg "fast" (found next to
     *            term "food")
     * @param termADocFreq
     *            the document frequency of this term eg "fast"
     * @param termBDocFreq
     *            the document frequency of the other term eg "food"
     */
    public Collocation(String term,String coincidentalTerm, int termADocFreq, int termBDocFreq)
    {
        this.term = term;
        this.coincidentalTerm = coincidentalTerm;
        this.termADocFreq = termADocFreq;
        this.termBDocFreq = termBDocFreq;
    }

    public float getScore()
    {
        float overallIntersectionPercent = coIncidenceDocCount
                / (float) (termADocFreq + termBDocFreq);
        float termBIntersectionPercent = coIncidenceDocCount
                / (float) (termBDocFreq);

        //using just the termB intersection favours common words as
        // coincidents eg "new" food
        //      return termBIntersectionPercent;
        //using just the overall intersection favours rare words as
        // coincidents eg "scezchuan" food
        //        return overallIntersectionPercent;
        // so here we take an average of the two:
        return (termBIntersectionPercent + overallIntersectionPercent) / 2;
    }
}
