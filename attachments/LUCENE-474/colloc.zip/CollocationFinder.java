package com.inperspective.colloc;

import java.io.IOException;
import java.util.Arrays;
import java.util.BitSet;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermDocs;
import org.apache.lucene.index.TermEnum;
import org.apache.lucene.index.TermPositionVector;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.PriorityQueue;

import com.inperspective.lucene.analysis.StandardEnglishAnalyzer;


/** Class used to find collocated terms in an index created with TermVector support
 * @author MAHarwood
 */
public class CollocationFinder
{
    static int DEFAULT_MAX_NUM_DOCS_TO_ANALYZE = 150;
    static int maxNumDocsToAnalyze = DEFAULT_MAX_NUM_DOCS_TO_ANALYZE;
    String fieldName = "contents";
    static float DEFAULT_MIN_TERM_POPULARITY=0.0002f;
    float minTermPopularity=DEFAULT_MIN_TERM_POPULARITY;
    static float DEFAULT_MAX_TERM_POPULARITY=0.1f;
    float maxTermPopularity=DEFAULT_MAX_TERM_POPULARITY;    
    int numCollocatedTermsPerTerm=20;
    IndexReader reader;
    int slopSize = 5;
    
    TermFilter filter=new DefaultTermFilter();

    public CollocationFinder(IndexReader reader)
    {
        this.reader=reader;
    }


    //Example usage
    public static void main(String[] args) throws Exception
    {
        String indexDirName=args[0];
        Directory dir = FSDirectory.getDirectory(indexDirName,false);
        IndexReader reader = IndexReader.open(dir);
        CollocationFinder collocFinder=new CollocationFinder(reader);        
        CollocationIndexer indexer=new CollocationIndexer(indexDirName+"/collocs",new StandardEnglishAnalyzer());
        collocFinder.find(indexer);
        indexer.close();
        reader.close();
    }
    
    
    private void find(CollocationLogger logger) throws IOException
    {
        Term term = null;
        TermEnum te = reader.terms(new Term(fieldName, ""));
        while (te.next())
        {
            term = te.term();
            if (!fieldName.equals(term.field()))
            {
                break;
            }
            processTerm(term, logger, slopSize);
        }        
    }


    //called for every term in the index
    void processTerm(Term term, CollocationLogger logger, int slop) throws IOException
    {
        if(!filter.processTerm(term.text()))
        {
            return;
        }
        TermEnum te = reader.terms(term);
        int numDocsForTerm = Math.min(te.docFreq(), maxNumDocsToAnalyze);
        int totalNumDocs = reader.numDocs();
        float percent = (float) numDocsForTerm / (float) totalNumDocs;

        //check term is not too rare or frequent
        if (percent < minTermPopularity)
        {
            return;
        }
        if (percent > maxTermPopularity)
        {
//            System.out.println(term.text() + " too popular");
            return;
        }


        //get a list of all the docs with this term
        TermDocs td = reader.termDocs(term);

        HashMap phraseTerms = new HashMap();
        int MAX_TERMS_PER_DOC = 10000;
        BitSet termPos = new BitSet(MAX_TERMS_PER_DOC);

        int numDocsAnalyzed = 0;
        //for all docs that contain this term
        while (td.next())
        {
            numDocsAnalyzed++;
            if (numDocsAnalyzed > maxNumDocsToAnalyze)
            {
                break;
            }
            int docId = td.doc();

            //get TermPositions for matching doc
            TermPositionVector tpv = (TermPositionVector) reader.getTermFreqVector(docId, fieldName);
            String[] terms = tpv.getTerms();
            termPos.clear();
            //first record all of the positions of the term in a bitset which
            // represents terms in the current doc.
            int index = Arrays.binarySearch(terms, term.text());
            if (index >= 0)
            {
                int[] pos = tpv.getTermPositions(index);
                //remember all positions of the term in this doc
                for (int j = 0; j < pos.length; j++)
                {
                    termPos.set(pos[j]);
                }
            }

            //now look at all OTHER terms in this doc and see if they are
            // positioned in a pre-defined
            //sized window around the current term
            for (int j = 0; j < terms.length; j++)
            {
                if (j == index)
                {
                    continue;
                }
                if (!filter.processTerm(terms[j]))
                {
                    continue;
                }

                
                int[] pos = tpv.getTermPositions(j);
                boolean matchFound = false;
                for (int k = 0; ((k < pos.length) && (!matchFound)); k++)
                {
                    int startpos = Math.max(0, pos[k] - slop);
                    int endpos = pos[k] + slop;
                    for (int prevpos = startpos; (prevpos <= endpos)
                            && (!matchFound); prevpos++)
                    {
                        if (termPos.get(prevpos))
                        {
                            //Add term to hashmap containing co-occurence
                            // counts for this term
                            Collocation pt = (Collocation) phraseTerms.get(terms[j]);
                            if (pt == null)
                            {
                                TermEnum otherTe = reader.terms(new Term(fieldName, terms[j]));
                                int numDocsForOtherTerm = Math.min(otherTe.docFreq(), maxNumDocsToAnalyze);
                                float otherPercent = (float) numDocsForOtherTerm / (float) totalNumDocs;

                                //check other term is not too rare or frequent
                                if (otherPercent < minTermPopularity)
                                {
                                    matchFound=true;
                                    continue;
                                }
                                if (otherPercent > maxTermPopularity)
                                {
//                                    System.out.println(term.text() + " too popular");
                                    matchFound=true;
                                    continue;
                                }
                                
                                pt = new Collocation(term.text(),terms[j],numDocsForOtherTerm, numDocsForTerm);
                                phraseTerms.put(pt.coincidentalTerm, pt);
                            }
                            pt.coIncidenceDocCount++;
                            matchFound = true;
                        }
                    }
                }
            }
        }//end docs loop

        //now sort and dump the top terms associated with this term.
        TopTerms topTerms = new TopTerms(numCollocatedTermsPerTerm);
        for (Iterator iter = phraseTerms.values().iterator(); iter.hasNext();)
        {
            Collocation pt = (Collocation) iter.next();
            topTerms.insert(pt);
        }
        Collocation[] tops = new Collocation[topTerms.size()];
        int tp = tops.length - 1;
        while (topTerms.size() > 0)
        {
            Collocation top = (Collocation) topTerms.pop();
            tops[tp--] = top;
        }
        for (int j = 0; j < tops.length; j++)
        {
            logger.logCollocation(tops[j]);
        }
    }


    static class TopTerms extends PriorityQueue
    {
        public TopTerms(int size)
        {
            initialize(size);
        }

        protected boolean lessThan(Object a, Object b)
        {
            Collocation pta = (Collocation) a;
            Collocation ptb = (Collocation) b;
            return pta.getScore() < ptb.getScore();
        }
    }
    
    public static int getMaxNumDocsToAnalyze()
    {
        return maxNumDocsToAnalyze;
    }
    public static void setMaxNumDocsToAnalyze(int maxNumDocsToAnalyze)
    {
        CollocationFinder.maxNumDocsToAnalyze = maxNumDocsToAnalyze;
    }
    public String getFieldName()
    {
        return fieldName;
    }
    public void setFieldName(String fieldName)
    {
        this.fieldName = fieldName;
    }
    public float getMaxTermPopularity()
    {
        return maxTermPopularity;
    }
    public void setMaxTermPopularity(float maxTermPopularity)
    {
        this.maxTermPopularity = maxTermPopularity;
    }
    public float getMinTermPopularity()
    {
        return minTermPopularity;
    }
    public void setMinTermPopularity(float minTermPopularity)
    {
        this.minTermPopularity = minTermPopularity;
    }
    public int getNumCollocatedTermsPerTerm()
    {
        return numCollocatedTermsPerTerm;
    }
    public void setNumCollocatedTermsPerTerm(int numCollocatedTermsPerTerm)
    {
        this.numCollocatedTermsPerTerm = numCollocatedTermsPerTerm;
    }
    public int getSlopSize()
    {
        return slopSize;
    }
    public void setSlopSize(int slopSize)
    {
        this.slopSize = slopSize;
    }
}
