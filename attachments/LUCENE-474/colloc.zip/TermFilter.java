package com.inperspective.colloc;


/**
 * Provides a hook to allow filtering of "uninteresting" words
 * @author MAHarwood
 */
public interface TermFilter
{
    //returns true if the term should be considered for collocation 
    boolean processTerm(String term);

}
