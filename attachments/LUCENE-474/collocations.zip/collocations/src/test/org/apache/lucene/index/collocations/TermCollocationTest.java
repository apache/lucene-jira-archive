package org.apache.lucene.index.collocations;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @author iprovalov
 */

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.lucene.analysis.SimpleAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.DefaultSimilarity;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;
import org.junit.Before;
import org.junit.Test;

public class TermCollocationTest {
	private String indexDir = "data/index";
	private String dataDir = "data/content";
	private String collocsDir = "data/collocs";

	@Before
	public void setup() throws Exception {
		indexContent();
		extractCollocations();
	}

	@Test
	public void testIndexing() throws Exception {
		Searcher searcher = new IndexSearcher(FSDirectory.open(new File(
				indexDir)));
		QueryParser parser = new QueryParser(Version.LUCENE_30, "contents",
				new SimpleAnalyzer());
		Query query = parser.parse("gold	silver	truck");
		TopDocs hits = searcher.search(query, 10);
		ScoreDoc match = hits.scoreDocs[0];
		Document doc = searcher.doc(match.doc);
		assertEquals("D2", doc.get("id"));
	}

	@Test
	public void testTermCollocationFinding() throws Exception {
		Map<String, Float> expectedResults = new LinkedHashMap<String, Float>();
		expectedResults.put("shipment", 144.17683f);
		expectedResults.put("fire", 90.11052f);
		expectedResults.put("damaged", 90.11052f);
		expectedResults.put("arrived", 72.08842f);
		expectedResults.put("truck", 72.08842f);

		CollocationSearcher collocationsSearcher = new CollocationSearcher(
				"data/collocs", 10);
		Map<String, Float> matches = collocationsSearcher.getBestMatch("gold");
		
		assertEquals(expectedResults, matches);
	}

	private void extractCollocations() throws IOException,
			CorruptIndexException {
		Directory dir = FSDirectory.open(new File(indexDir));
		IndexReader reader = IndexReader.open(dir);
		CollocationExtractor collocationExtractor = new CollocationExtractor(
				reader);
		CollocationIndexer collocationIndexer = new CollocationIndexer(
				collocsDir, new StandardAnalyzer(Version.LUCENE_30));
		collocationExtractor.extract(collocationIndexer);
		collocationIndexer.close();
		reader.close();
	}

	private void indexContent() throws Exception, IOException {
		DataIndexer indexer = new DataIndexer(indexDir,
				new DefaultSimilarity(),
				new StandardAnalyzer(Version.LUCENE_30));
		indexer.index(dataDir);
		indexer.close();
	}

}
