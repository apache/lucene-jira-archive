package org.apache.lucene.index.collocations;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * @author iprovalov 
 * 
 */


import java.io.File;
import java.io.IOException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.Field.TermVector;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.Similarity;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class DataIndexer {
	private IndexWriter writer;

	public DataIndexer(String indexDirName, Similarity sim,
			Analyzer analyser) throws Exception {
		Directory dir = FSDirectory.open(new File(indexDirName));
		writer = new IndexWriter(dir, analyser, true,
				IndexWriter.MaxFieldLength.UNLIMITED);
		writer.setSimilarity(sim);
	}

	public void close() throws IOException {
		writer.close();
	}

	public void index(String dataDirName) throws Exception {
		File[] files = new File(dataDirName).listFiles();
		if (files != null) {
			for (File f : files) {
				PlainFileParser plainFileParser = new PlainFileParser(f
						.getAbsolutePath(), f.getName());
				indexDoc(plainFileParser);
			}
		}

	}

	private int indexDoc(PlainFileParser plainFileParser) throws Exception {
		Document doc = new Document();
		String docId = plainFileParser.getDocId();
		doc.add(new Field("id", docId, Field.Store.YES,
				Field.Index.NOT_ANALYZED));
		doc.add(new Field("contents", plainFileParser.getDocument(),
				Field.Store.YES, Field.Index.ANALYZED,
				TermVector.WITH_POSITIONS_OFFSETS));
		writer.addDocument(doc);
		return writer.numDocs();
	}

}