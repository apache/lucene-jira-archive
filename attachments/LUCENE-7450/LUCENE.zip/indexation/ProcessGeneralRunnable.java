/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package indexationLucene;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

/**
 * Le Runnable associé aux threads dans le cas de l'indexation de toutes les
 * armoires (multitache)
 *
 * @author mael
 */
public class ProcessGeneralRunnable implements Runnable {

	protected IndexationLucene testIndex;
	protected InteractionJDBC inter;

	public ProcessGeneralRunnable(IndexationLucene testIndex, InteractionJDBC inter) {
		super();
		this.testIndex = new IndexationLucene(testIndex);
		this.inter = new InteractionJDBC(inter);
	}

	@Override
	public void run() {
		try {
			HashMap<String, String> pass = null;
			Boolean armoireOk = inter.getArmoireInfos(testIndex.ID_ARMOIRE);
			if (armoireOk) {
				testIndex.NOM_ARMOIRE = inter.gedArmoire.getNomArmoire().toUpperCase();
				testIndex.IMAGE_ARMOIRE = inter.gedArmoire.getCheminImage();
				testIndex.OCR_ARMOIRE = inter.gedArmoire.getCheminOcr();
				testIndex.PATH_LOGS = testIndex.PATH_LOGS.replaceFirst("Serveur", testIndex.NOM_ARMOIRE);
				File logs = new File(testIndex.PATH_LOGS);
				logs.getParentFile().mkdirs();
				logs.createNewFile();
				testIndex.PATH_INDEX = testIndex.PATH_INDEX + "\\" + testIndex.NOM_ARMOIRE;
				testIndex.PATH_CONFIG = testIndex.PATH_INDEX + "\\config" + testIndex.NOM_ARMOIRE + ".txt";

				testIndex.MODE_ARMOIRE = inter.gedArmoire.getMode();

				inter.testIndex = testIndex;

				FileWriter fw = new FileWriter(testIndex.CSV_OUT, true);
				try (BufferedWriter output = new BufferedWriter(fw)) {
					output.write(testIndex.NOM_ARMOIRE + ";" + (testIndex.CREATE_INDEX ? "totale" : "incrémentale") + ";");
					output.flush();
					output.close();
				}

				switch (testIndex.MODE_ARMOIRE) {
					case 1:
						pass = inter.getPasswords(testIndex.NOM_ARMOIRE);
						break;
					case 0:
						pass = new HashMap<>();
						pass.put(testIndex.IMAGE_ARMOIRE, inter.getPassword(testIndex.ID_ARMOIRE));
						break;
				}

				testIndex.writeLog("[" + testIndex.NOM_ARMOIRE + "] " + "Indexation " + (testIndex.CREATE_INDEX ? "totale" : "incrémentale") + " de l'armoire", 0);

				//Récupération de la date de dernière indexation si on est en mode incrémental
				Properties props = null;
				Date lastIndex = new Date(0);//Si mode total alors on prend tous les docs, donc date la plus vieille possible :D
				if (!testIndex.CREATE_INDEX) {
					if (!new File(testIndex.PATH_CONFIG).exists()) {
						Properties propss = new Properties();
						testIndex.createProperties(propss);
					}
					props = testIndex.loadProperties(testIndex.PATH_CONFIG);
					String stringDate = props.getProperty("LAST_DATE_MAJ");
					lastIndex = testIndex.DATE_FORMAT.parse(stringDate);

					//On récupère les potentiels fichiers supprimés depuis la dernière indexation
					List list = inter.getDeletions(lastIndex);

					if (testIndex.MODE_DEBUG > 1) {
						testIndex.writeLog("[" + testIndex.NOM_ARMOIRE + "] " + list.size() + " fichiers supprimés depuis la dernière indexation", 0);
					}

					for (int i = 0; i < list.size(); i++) {
						testIndex.deleteDoc((String) list.get(i));
					}
				} else {
					props = testIndex.createProperties(props);
				}

				ResultSet res = inter.getDocsForIndex(testIndex.CREATE_INDEX, testIndex.DATE_FORMAT.format(lastIndex));

				if (testIndex.MODE_DEBUG > 1) {
					res.last();
					testIndex.writeLog("[" + testIndex.NOM_ARMOIRE + "] " + res.getRow() + " fichiers à indexer", 1);
					res.beforeFirst();
				}
				Directory dir = FSDirectory.open(new File(testIndex.PATH_INDEX).toPath());

				Integer motsIndexes = testIndex.indexDocsReal(dir, res, lastIndex, pass);

				if (motsIndexes >= 0) {
					testIndex.writeLog("[" + testIndex.NOM_ARMOIRE + "] " + motsIndexes + " mots indexés", 0);
				}

				testIndex.updatePropreties(props);
				try (IndexReader reader = DirectoryReader.open(FSDirectory.open(new File(testIndex.PATH_INDEX).toPath()))) {
					testIndex.writeLog("[" + testIndex.NOM_ARMOIRE + "] " + reader.maxDoc() + " fichiers dans l'index", 0);
				}
				FileWriter fw2 = new FileWriter(testIndex.CSV_OUT, true);
				try (BufferedWriter output = new BufferedWriter(fw2)) {
					output.write("indexation terminée avec succès" + ";");
					output.flush();
					output.close();
				}
			} else {
				try (FileWriter fw = new FileWriter(testIndex.CSV_OUT, true); BufferedWriter output = new BufferedWriter(fw)) {
					output.write("Erreur l'armoire est introuvable" + ";");
					output.flush();
					output.close();
				} catch (IOException ex) {
				}
			}
		} catch (NullPointerException | IOException | ParseException | SQLException e) {
			testIndex.writeLog(e.getClass() + e.getMessage(), 3);

			try (FileWriter fw = new FileWriter(testIndex.CSV_OUT, true); BufferedWriter output = new BufferedWriter(fw)) {
				output.write("erreur lors de l'indexation" + ";");
				output.flush();
				output.close();
			} catch (IOException ex) {
			}
		}
		try (FileWriter fw = new FileWriter(testIndex.CSV_OUT, true); BufferedWriter output = new BufferedWriter(fw)) {
			output.write(new File(testIndex.PATH_LOGS).getName() + "\r\n");
			output.flush();
			output.close();
		} catch (IOException ex) {
		}
	}
}
