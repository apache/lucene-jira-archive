/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package indexationLucene;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * InteractionJDBC est la classe permettant les échanges avec la base de donnée MySQL
 *
 * @author mael
 * @version 1.0
 */

public class InteractionJDBC {

	/**
	 * La table concernée, indiquée par son chemin complet
	 * ex : jdbc:mysql://localhost/test
	 */
	protected String table;
	/**
	 * L'identifiant d'accès à la base
	 */
	protected String username;

	/**
	 * le mot de passe pour l'accès à la base
	 */
	protected String password;

	/**
	 * La connexion avec la base
	 */
	protected Connection con;

	/**
	 * La connexion avec la base
	 */
	protected GedArmoire gedArmoire;

	/**
	 * L'instance d'indexation associée
	 */
	protected IndexationLucene testIndex;

	public InteractionJDBC(String table, String username, String password, IndexationLucene testIndex){
		try {
			this.table = table;
			this.username = username;
			this.password = password;
			this.testIndex=testIndex;

			Class.forName("com.mysql.jdbc.Driver");
			this.con = DriverManager.getConnection(this.table, this.username,this.password);
		}
		catch (ClassNotFoundException ex) {
			testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getCause(), 3);
		}
		catch (SQLException ex) {
			testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getSQLState(), 3);
		}
	}

	InteractionJDBC(InteractionJDBC inter) {
		this.table = inter.table;
		this.username = inter.username;
		this.password = inter.password;
		this.testIndex= inter.testIndex;
		this.con= inter.con;
		this.gedArmoire= inter.gedArmoire;
	}

	public Boolean getArmoireInfos(int idArmoire){
		this.gedArmoire = new GedArmoire(this, idArmoire);

		return (this.gedArmoire.getIDA()==null?false:true);
	}

	/**
	 * Collecte les tous les ID des armoire présentes en base
	 * @return une liste des ID des armoires présentes dans la BDD
	 */
	public List<Integer> getAllIdArmoires(){
		List<Integer> retour = new ArrayList<>();
		try {
			java.sql.Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("SELECT IDA FROM appli");

			while (res.next())
				retour.add(res.getInt("IDA"));
		}
		catch (SQLException ex) {
			testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getSQLState(), 3);
		}
		return retour;
	}

	/**
	 * Collecte les tous les noms des armoire présentes en base
	 * @return une liste des noms des armoires présentes dans la BDD
	 */
	public List<String> getAllNameArmoires(){
		List<String> retour = new ArrayList<>();
		try {
			java.sql.Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("SELECT nomtable FROM appli");

			while (res.next())
				retour.add(res.getString("nomtable").toUpperCase());
		}
		catch (SQLException ex) {
			testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getSQLState(), 3);
		}
		return retour;
	}

	/**
	 * Utile pour le mode dossier, collecte les mots de passe en les associant à leur SD
	 * @param nomArmoire le nom de l'armoire concernée
	 * @return une map liant nom du SD et mot de passe associé
	 */
	public HashMap<String,String> getPasswords(String nomArmoire){
		HashMap<String,String> retour = new HashMap<>();
		try {
			java.sql.Statement stm = con.createStatement();
			String sql = "SELECT libelle,mp "
					+ "FROM "+nomArmoire + "_sdext "
					+ "WHERE idp=-1 "
					+ "AND doc=0 "
					+ "AND substring(flag,3,1)=1";
			ResultSet res = stm.executeQuery(sql);

			while (res.next())
				retour.put(res.getString("libelle"), res.getString("mp"));
		}
		catch (SQLException ex) {
			testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getSQLState(), 3);
		}
		return retour;
	}

	/**
	 * Utile pour le mode fichier, collecte le mots de passe de l'armoire
	 * @param idArmoire l'ID de l'armoire concernée
	 * @return le mot de passe de l'armoire, vide si rien
	 */
	public String getPassword(int idArmoire){
		String pass="";
		try {
			java.sql.Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("SELECT mp_pdf "
					+ "FROM appli "
					+ "WHERE IDA="+idArmoire);

			//On se met au premier resultat
			res.first();

			pass = res.getString("mp_pdf");
		}
		catch (SQLException ex) {
			testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getSQLState(), 3);
		}
		return pass;

	}

	/**
	 * Collecte les IDDOCS des fichiers supprimés depuis la dernière indexation
	 * @param lastIndex la date de dernière indexation de l'armoire
	 * @return les IDDocs des fichiers à supprimer de l'index
	 */
	public List<String> getDeletions(Date lastIndex){
		List<String> retour = new ArrayList<>();
		try {
			java.sql.Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("SELECT IDDOC "
					+ "FROM "+testIndex.NOM_ARMOIRE+"_evtdocs "
					+ "WHERE EVENT='S3' "
					+ "AND EVT_DATE>'"+testIndex.DATE_FORMAT.format(lastIndex)+"'");

			while (res.next())
				retour.add(res.getString("IDDOC"));
		}
		catch (SQLException ex) {
			testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getSQLState(), 3);
		}
		return retour;
	}

	/**
	 * Collecte les fichiers à indexer
	 * @param createIndex dertermine le mode d'indexation : totale ou incrémentale
	 * @param dateLastIndex la date de dernière indexation de l'armoire
	 * @return un set comprennant les fichiers à indexer
	 */
	public ResultSet getDocsForIndex(Boolean createIndex,String dateLastIndex){
		ResultSet res = null;
		try {
			java.sql.Statement stm = con.createStatement();

			String sqlQuery;
			if (createIndex){
				sqlQuery = "SELECT IDDOC,ID,SD,SSD,FILE,EXT "
						+ "FROM "+testIndex.NOM_ARMOIRE+"_docs "
						+ "WHERE EXT NOT IN ('none','') "
						+ "AND LENGTH(TRIM(CONCAT(SD,SSD,FILE)))>0 "
						+ "ORDER BY ID,SD,SSD,FILE";
				res = stm.executeQuery( sqlQuery );
			}
			else{
				sqlQuery = "SELECT IDDOC,ID,SD,SSD,FILE,EXT "
						+ "FROM "+testIndex.NOM_ARMOIRE+"_docs "
						+ "WHERE EXT NOT IN ('none','') "
						+ "AND LENGTH(TRIM(CONCAT(SD,SSD,FILE)))>0 "
						+ "AND ("
						+ " IF(DATENUM='0000-00-00 00:00:00', 1, DATENUM > '" + dateLastIndex + "')"
						+ " OR IF(DATECREA='0000-00-00 00:00:00', 1, DATECREA > '" + dateLastIndex + "')"
						+ " OR IF(DATEREV='0000-00-00 00:00:00', 1, DATEREV > '" + dateLastIndex + "')"
						+ " )"
						+ "ORDER BY ID,SD,SSD,FILE";
				res = stm.executeQuery( sqlQuery );
			}
			testIndex.writeLog(sqlQuery, 4);
		}
		catch (SQLException ex) {
			testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getSQLState(), 3);
		}
		return res;
	}

	/**
	 * Ferme la connection à la base
	 */
	public void close(){
		try {
			con.close();
		}
		catch (SQLException ex) {
			testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getSQLState(), 3);
		}
	}
}
