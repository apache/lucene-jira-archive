/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package indexationLucene;

import javax.mail.*;
/**
 * 
 * @author mael
 */
public class showEml {
	protected String content = "";

	public void dumpPart(Part p) throws Exception {
		/*
		 * Using isMimeType to determine the content type avoids
		 * fetching the actual content data until we need it.
		 */
		if (p.isMimeType("text/plain")) {
			content = (String)p.getContent();
		}
		else if (p.isMimeType("multipart/*")) {
			Multipart mp = (Multipart)p.getContent();
			int count = mp.getCount();
			for (int i = 0; i < count; i++)
			dumpPart(mp.getBodyPart(i));
		}
		else if (p.isMimeType("message/rfc822")) {
			dumpPart((Part)p.getContent());
		}
	}
}
