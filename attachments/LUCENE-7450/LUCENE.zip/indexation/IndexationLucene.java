package indexationLucene;

import com.cybozu.labs.langdetect.Detector;
import com.cybozu.labs.langdetect.DetectorFactory;
import com.cybozu.labs.langdetect.LangDetectException;
import com.jmupdf.xps.XpsDocument;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;

import java.net.Socket;

import java.sql.ResultSet;
import java.sql.SQLException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

import javax.mail.Part;
import javax.mail.internet.MimeMessage;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.ar.ArabicAnalyzer;
import org.apache.lucene.analysis.core.WhitespaceAnalyzer;
import org.apache.lucene.analysis.de.GermanAnalyzer;
import org.apache.lucene.analysis.en.EnglishAnalyzer;
import org.apache.lucene.analysis.es.SpanishAnalyzer;
import org.apache.lucene.analysis.it.ItalianAnalyzer;
import org.apache.lucene.analysis.pt.PortugueseAnalyzer;
import org.apache.lucene.analysis.ru.RussianAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.StandardDecryptionMaterial;
import org.apache.pdfbox.util.PDFTextStripper;

import org.apache.poi.POITextExtractor;
import org.apache.poi.hslf.extractor.PowerPointExtractor;
import org.apache.poi.hssf.extractor.ExcelExtractor;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.xslf.XSLFSlideShow;
import org.apache.poi.xssf.extractor.XSSFExcelExtractor;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xslf.extractor.XSLFPowerPointExtractor;
import org.apache.poi.hsmf.extractor.OutlookTextExtactor;
import org.apache.poi.hdgf.extractor.VisioTextExtractor;

import org.ini4j.Ini;

/**
 * @author mael
 */
public class IndexationLucene {

	/**
	 * Le contexte local
	 */
	protected Locale LOCALE = Locale.getDefault();

	/**
	 * Le modèle de formatage de date
	 */
	protected DateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	/**
	 * L'ID de l'armoire en cours d'indexation
	 */
	protected Integer ID_ARMOIRE = 0;

	/**
	 * Le nom de l'armoire en cours d'indexation
	 */
	protected String NOM_ARMOIRE = null;

	/**
	 * Le mode de l'armoire en cours d'indexation
	 */
	protected Integer MODE_ARMOIRE = null;

	/**
	 * Le chemin d'accès aux images de l'armoire en cours d'indexation
	 */
	protected String IMAGE_ARMOIRE = "";

	/**
	 * Le chemin d'accès aux ocr de l'armoire en cours d'indexation
	 */
	protected String OCR_ARMOIRE = "";

	/**
	 * Le chemin d'accès au fichier de configuration de l'armoire
	 */
	protected String PATH_CONFIG = "";

	/**
	 * Le chemin d'accès à l'index de l'armoire
	 */
	protected String PATH_INDEX = "index";

	/**
	 * Indique le type d'indexation
	 */
	protected Boolean CREATE_INDEX = false;

	/**
	 * Le chemin d'accès aux logs
	 */
//	protected String PATH_LOGS = "G:\\DEVE\\sourcesWEB\\Multigest\\nef\\logs";
	protected String PATH_LOGS = "logs";

	/**
	 * Le mode de debugage issu de automate.ini
	 */
	protected Integer MODE_DEBUG = 0;

	/**
	 * Le csv de sortie
	 */
	protected String CSV_OUT;

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) throws LangDetectException {
		IndexationLucene ide = new IndexationLucene();

		Date start = new Date();

		// Récupération des arguments passés
		try {
			for (int i = 0; i < args.length; i++) {
				switch (args[i]) {
					case "-type":
						switch (args[i + 1]) {
							case "T":
								ide.CREATE_INDEX = true;
								break;
							case "I":
								ide.CREATE_INDEX = false;
								break;
						}
						i++;
						break;
					case "-idArmoire":
						ide.ID_ARMOIRE = Integer.parseInt(args[i + 1]);
						i++;
						break;
				}
			}

			//On récupère les infos nécessaires pour se connecter au serveur de GED et le mode de debug
			Ini ini = new Ini(new File("..//bin//automate.ini"));
//			Ini ini = new Ini(new File("G:\\DEVE\\sourcesWEB\\Multigest\\bin\\automate.ini"));
			Integer port = Integer.parseInt(ini.get("COMMUNICATION", "PORT"));
			String ip = ini.get("COMMUNICATION", "SERVEUR");
			String modeDebug = ini.get("DEBUG", "TRACER");
			ide.MODE_DEBUG = Integer.parseInt(modeDebug);

			//On crée le fichier de log général
			File docLogs = new File(ide.PATH_LOGS);
			docLogs.mkdirs();
			String today = ide.DATE_FORMAT.format(new Date());
			String[] date = today.split(" ");
			String[] time = date[1].split(":");
			File csv = new File(ide.PATH_LOGS + "/indexations_" + date[0].substring(5, 7) + "_" + date[0].substring(0, 4) + ".csv");
			ide.CSV_OUT = csv.getAbsolutePath();
			if (!csv.exists()) {
				//On créé et initialise avec l'en tête
				FileWriter fw = new FileWriter(ide.CSV_OUT, true);
				try (BufferedWriter output = new BufferedWriter(fw)) {
					output.write("Jour;Heure;armoire;type indexation;resultat;fichier logs\r\n");
					output.flush();
					output.close();
				}
			}
			FileWriter fw = new FileWriter(ide.CSV_OUT, true);
			try (BufferedWriter output = new BufferedWriter(fw)) {
				output.write(date[0] + ";" + time[0] + ":" + time[1] + ":" + time[2] + ";");
				output.flush();
				output.close();
			}

			// Création du répertoire de log Serveur
			File subDir = new File(ide.PATH_LOGS + "/Serveur");
			subDir.mkdirs();
			ide.PATH_LOGS = subDir.getPath() + "//";
			File fileLog = new File(ide.PATH_LOGS + "/" + (ide.CREATE_INDEX ? "it_" : "ii_") + date[0] + "_" + time[0] + "-" + time[1] + "-" + time[2] + ".txt");
			fileLog.createNewFile();
			ide.PATH_LOGS = fileLog.getPath();

			//On se connecte au serveur
			Socket socket;
			ide.writeLog("Connection au serveur...", 0);

			socket = new Socket(ip, port);
			List params;
			String stringTable;
			// Si la connexion est OK
			if (socket.isConnected()) {
				ide.writeLog("Connecté !", 0);

				//On récupère les identifiants de la BDD
				params = ide.getIdBase(socket);
				socket.close();

				//jdbc:mysql://host:port/table
				stringTable = "jdbc:mysql://" + params.get(0) + ":" + params.get(4) + "/" + params.get(1);
				//Instance d'interaction avec la BDD MySQL
				InteractionJDBC inter = new InteractionJDBC(stringTable, (String) params.get(2), (String) params.get(3), ide);

				// Si un identifiant d'armoire est passé
				if (ide.ID_ARMOIRE != 0) {
					ProcessGeneralRunnable pr = new ProcessGeneralRunnable(ide, inter);
					Thread th = new Thread(pr);
					th.start();

					while (th.isAlive()) {
					}
					inter.close();
				} else {
					//Installation client, on indexe toutes les armoires.
					List allId = inter.getAllIdArmoires();
					Thread th1 = null;
					Thread th2 = null;

					ProcessGeneralRunnable pr;
					int i = 0;
					while (i < allId.size()) {
						if (i == 0) {
							//La premiere fois on lance
							ide.ID_ARMOIRE = (Integer) allId.get(i++);
							ide.PATH_INDEX = "index";
							pr = new ProcessGeneralRunnable(ide, inter);
							th1 = new Thread(pr);
							th1.start();
						} else if (!th1.isAlive()) {
							// ensuite on lance seulement si il est terminé
							ide.ID_ARMOIRE = (Integer) allId.get(i++);
							ide.PATH_INDEX = "index";
							pr = new ProcessGeneralRunnable(ide, inter);
							th1 = new Thread(pr);
							th1.start();
						}

						if (i == allId.size()) //Si on a lancé avec 0 mais qu'il n'y a qu'une armoire
						{
							break;
						}

						if (i == 1) {
							//La premiere fois on lance
							ide.ID_ARMOIRE = (Integer) allId.get(i++);
							ide.PATH_INDEX = "index";
							pr = new ProcessGeneralRunnable(ide, inter);
							th2 = new Thread(pr);
							th2.start();
						} else if (!th2.isAlive()) {
							// ensuite on lance seulement si il est terminé
							ide.ID_ARMOIRE = (Integer) allId.get(i++);
							ide.PATH_INDEX = "index";
							pr = new ProcessGeneralRunnable(ide, inter);
							th2 = new Thread(pr);
							th2.start();
						}
					}
					if (allId.size() > 1) {
						while (th1.isAlive() | th2.isAlive()) {
						} //Ne pas fermer la connexion a la base trop tot
						inter.close();
					} else if (allId.size() == 1) {
						while (th1.isAlive()) {
						} //Ne pas fermer la connexion a la base trop tot
						inter.close();
					} else //0 mais pas d'armoire
					{
						inter.close();
					}
				}

			} else {
				ide.writeLog("Connection échouée, vérifiez votre fichier automate.ini", 0);
			}
		} catch (NumberFormatException | IOException e) {
			ide.writeLog(e.getMessage(), 3);
		}
		Date end = new Date();
		Long millis = end.getTime() - start.getTime();

		long second = (millis / 1000) % 60;
		long minute = (millis / (1000 * 60)) % 60;
		long hour = (millis / (1000 * 60 * 60)) % 24;
		String time = String.format("%02d:%02d:%02d:%d", hour, minute, second, millis);

		ide.writeLog("Tache terminée, temps approximatif (h:m:s:ms) : " + time + "", 0);
	}

	//Constructor
	public IndexationLucene() throws LangDetectException {
		DetectorFactory.loadProfile("profiles");
	}

	//Copy constructor
	public IndexationLucene(IndexationLucene testIndex) {
		this.CREATE_INDEX = testIndex.CREATE_INDEX;
		this.DATE_FORMAT = testIndex.DATE_FORMAT;
		this.ID_ARMOIRE = testIndex.ID_ARMOIRE;
		this.IMAGE_ARMOIRE = testIndex.IMAGE_ARMOIRE;
		this.OCR_ARMOIRE = testIndex.OCR_ARMOIRE;
		this.LOCALE = testIndex.LOCALE;
		this.MODE_ARMOIRE = testIndex.MODE_ARMOIRE;
		this.MODE_DEBUG = testIndex.MODE_DEBUG;
		this.NOM_ARMOIRE = testIndex.NOM_ARMOIRE;
		this.PATH_CONFIG = testIndex.PATH_CONFIG;
		this.PATH_INDEX = testIndex.PATH_INDEX;
		this.PATH_LOGS = testIndex.PATH_LOGS;
		this.CSV_OUT = testIndex.CSV_OUT;
	}

	/**
	 * Detecte la langue d'un texte
	 *
	 * @param text Le texte à analyser
	 * @return un indicateur de la langue détectée
	 */
	public String langDetect(String text) {
		String retour = "fr";
		try {
			Detector detector = DetectorFactory.create();
			detector.append(text);
			retour = detector.detect();
		} catch (LangDetectException ex) {
			writeLog("[ERROR] " + ex.getMessage(), 3);
		}
		return retour;
	}

	/**
	 * Edite le fichier de logs
	 *
	 * @param log la ligne à inscrire dans le fichier de logs
	 */
	public void writeLog(String log, Integer type) {
		try {
			if (type <= MODE_DEBUG) {
				FileWriter fw = new FileWriter(PATH_LOGS, true);
				try (BufferedWriter output = new BufferedWriter(fw)) {
					output.write(DATE_FORMAT.format(new Date()) + " => " + log + "\r\n");
					output.flush();
					output.close();
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * Interroge l'automate pour connaitre les identifiants d'accès à la BDD
	 *
	 * @param socket la socket connectée à l'automate
	 * @return les identifiants d'accès à la base de donnée
	 */
	public List getIdBase(Socket socket) {
		List<String> retour = new ArrayList<>();
		try (PrintWriter out = new PrintWriter(socket.getOutputStream())) {
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			char[] chars = new char[32];
			//A1=>cheminBase A2=>nomBase A3=>login A4=>pass A5=>portBase
			for (int i = 0; i < 6; i++) {
				out.print("MYSQL_A" + (i + 1));
				out.flush();
				in.read(chars);
				retour.add(new String(chars).trim());
				chars = new char[32];
			}
		} catch (Exception e) {
			writeLog("[ERROR] " + e.getMessage(), 3);
		} finally {
			return retour;
		}

	}

	/**
	 * Récupère les propriétés
	 *
	 * @param pathConfig le chemin d'accès au fichier de propriétés
	 * @return les propriétés
	 */
	public Properties loadProperties(String pathConfig) {
		Properties properties = new Properties();
		try (FileInputStream fr = new FileInputStream(pathConfig)) {
			properties.load(fr);
			fr.close();
		} catch (Exception e) {
			writeLog("[ERROR] " + e.getMessage(), 3);
		}
		return properties;
	}

	/**
	 * Met à jour les propriétés
	 *
	 * @param props les propriétés à mettre à jour
	 */
	public void updatePropreties(Properties props) {
		props.setProperty("LAST_DATE_MAJ", DATE_FORMAT.format(new Date()));
		try (OutputStream out = new FileOutputStream(PATH_CONFIG)) {
			props.store(out, "Fichier de config de l'index de l'armoire " + NOM_ARMOIRE);
			out.flush();
			out.close();
		} catch (Exception e) {
			writeLog("[ERROR] " + e.getMessage(), 3);
		}
	}

	/**
	 * Créé un fichier de propriétés
	 *
	 * @param props l'instance de propriétés à créer
	 * @return les propriétés
	 */
	public Properties createProperties(Properties props) {
		File rep = new File(PATH_INDEX);
		rep.mkdirs();
		File file = new File(PATH_CONFIG);
		try {
			file.createNewFile();
		} catch (IOException ex) {
			writeLog("[ERROR] " + ex.getMessage(), 3);
		}

		props = new Properties();
		props.setProperty("LAST_DATE_MAJ", DATE_FORMAT.format(new Date()));
		try (OutputStream out = new FileOutputStream(PATH_CONFIG)) {
			props.store(out, "Fichier de config de l'index de l'armoire " + NOM_ARMOIRE);
			out.flush();
			out.close();
		} catch (Exception e) {
			writeLog("[ERROR] " + e.getMessage(), 3);
		}
		return props;
	}

	/**
	 * Extrait le contenu d'un fichier
	 *
	 * @param file le fichier dont on veut extraire le texte
	 * @param ext l'extension du fichier
	 * @param mdp les mots de passe de cette armoire
	 * @return Contenu du fichier
	 */
	public String extractContent(File file, String ext, HashMap mdp) {
		String retour = "";
		if (file.exists()) {
			try {
				POIFSFileSystem fs;
				POITextExtractor extractor;
				switch (ext) {
					case "txt":
					case "html":
					case "htm":
					case "xml":
					case "csv":
					case "rtf":
						InputStream ips = new FileInputStream(file.getPath());
						InputStreamReader ipsr = new InputStreamReader(ips);
						BufferedReader br = new BufferedReader(ipsr);
						String ligne;
						while ((ligne = br.readLine()) != null) {
							retour += ligne + "\n";
						}
						br.close();
						ips.close();
						ipsr.close();
						break;

					//Type document PDF
					case "pdf":
						PDDocument cd = PDDocument.load(file);
						PDFTextStripper stripper = new PDFTextStripper();
						try {
							//On regarde si il est protégé par un MDP
							final boolean isOriginalDocEncrypted = cd.isEncrypted();
							if (isOriginalDocEncrypted) {
								String password = rechercheBonPass(file, mdp);
								if (password != null) {
									cd.openProtection(new StandardDecryptionMaterial(password));
								} else // On a pas reussi à ouvrir le PDF
								{
									return null;
								}
							}

							retour = stripper.getText(cd);
						} finally {
							if (cd != null) {
								cd.close();
							}
						}
						break;

					case "doc":
					case "dot":
						try {
							fs = new POIFSFileSystem(new FileInputStream(file.getPath()));
							extractor = new WordExtractor(fs);
							retour = extractor.getText();
							break;
						} catch (org.apache.poi.poifs.filesystem.OfficeXmlFileException e) {
						}

					case "docx":
					case "docm":
					case "dotm":
					case "dotx":
						XWPFDocument word;
						word = new XWPFDocument(new FileInputStream(file));
						extractor = new XWPFWordExtractor(word);
						retour = extractor.getText();
						break;

					case "odt":
					case "ods":
					case "odp":
						retour = new OpenOfficeParser().getText(file.getPath());
						break;

					//Type classeur Excel
					case "xls":
					case "xlt":
						try {
							fs = new POIFSFileSystem(new FileInputStream(file.getPath()));
							extractor = new ExcelExtractor(fs);
							retour = extractor.getText();
							break;
						} catch (org.apache.poi.poifs.filesystem.OfficeXmlFileException e) {
						} //mauvaise extension par rapport aux données

					case "xltm":
					case "xltx":
					case "xlsx":
					case "xlsm":
						XSSFWorkbook excel;
						excel = new XSSFWorkbook(new FileInputStream(file));
						extractor = new XSSFExcelExtractor(excel);
						retour = extractor.getText();
						break;

					//Type presentation PowerPoint
					case "ppt":
					case "pps":
						try {
							fs = new POIFSFileSystem(new FileInputStream(file.getPath()));
							extractor = new PowerPointExtractor(fs);
							retour = extractor.getText();
							break;
						} catch (org.apache.poi.poifs.filesystem.OfficeXmlFileException e) {
						}

					case "pptx":
					case "ppsx":
						XSLFSlideShow power;
						power = new XSLFSlideShow(file.getPath());
						extractor = new XSLFPowerPointExtractor(power);
						retour = extractor.getText();
						break;

					case "xps":
						XpsDocument xps = new XpsDocument(file.getPath());
						for (int i = 1; i <= xps.getPageCount(); i++) {
							retour += xps.getPage(i).getText();
						}
						break;

					//Type mail Outlook .msg
					case "msg":
						fs = new POIFSFileSystem(new FileInputStream(file.getPath()));
						extractor = new OutlookTextExtactor(fs);
						retour = extractor.getText();
						break;

					case "eml":
						showEml instance = new showEml();
						InputStream is = new FileInputStream(file.getPath());
						MimeMessage mime = new MimeMessage(null, is);
						instance.dumpPart((Part) mime);
						retour = instance.content;
						is.close();
						break;

					//Type MS Visio
					case "vsd":
						fs = new POIFSFileSystem(new FileInputStream(file.getPath()));
						extractor = new VisioTextExtractor(fs);
						retour = extractor.getText();
						break;
				}
			} catch (Exception e) {
				writeLog("[ERROR] " + e.getMessage(), 3);
			}
		}

		System.gc();

		//On vire les fichiers images (les docs desquels on extrait qqch mais pas de "vrai texte"
		if (retour.replaceAll(" +", " ").trim().length() == 0) {
			return null;
		} else {
			return retour.replaceAll(" +", " ").trim();
		}
	}

	/**
	 * Indexation des documents
	 *
	 * @param dir le chemin de l'index
	 * @param res les fichiers à indexer
	 * @param derniereIndexation la dernière indexation de cette armoire
	 * @param pass les mots de passe de l'armoire
	 * @return le nombre de mots indexés
	 */
	public Integer indexDocsReal(Directory dir, ResultSet res, Date derniereIndexation, HashMap pass) {
		Integer nbmots = 0;
		Boolean first = true;
		try {
			//On recupere le nombre de docs presents en base à indexer
			res.last();
			Integer nbDocs = res.getRow();
			res.beforeFirst();

			IndexWriter writer;
			IndexWriterConfig iwc;
			if (dir.listAll().length == 1) {
				//On doit initialiser l'index si il n'existe pas
				iwc = new IndexWriterConfig(new StandardAnalyzer());
				iwc.setOpenMode(OpenMode.CREATE);
				writer = new IndexWriter(dir, iwc);
				writer.commit();
				writer.close();
			}

			while (res.next()) {
				//On reconstitue le chemin du fichier
				String filePath = "";
				Integer rupture = (Integer) res.getInt("ID") / 500;
				filePath += "\\" + Integer.toString(rupture);
				if (MODE_ARMOIRE == 1) {
					filePath += "\\" + res.getLong("ID");
					if (!res.getString("SD").isEmpty()) {
						filePath += "\\" + res.getString("SD");
					}
					if (!res.getString("SSD").isEmpty()) {
						filePath += "\\" + res.getString("SSD");
					}
				}
				if (!res.getString("FILE").isEmpty()) {
					filePath += "\\" + res.getString("FILE");
				}

				//On recupere l'extension pour extraire le contenu correctement
				String ext = res.getString("EXT");
				ext = ext.toLowerCase();
				File file = new File(OCR_ARMOIRE + filePath);
				if (!file.exists()) {
					// Test si le fichier est au format pdf dans le dossier OCR (cas des fichiers images)
					File filePDF = new File(OCR_ARMOIRE + filePath.replace("." + res.getString("EXT"), ".pdf"));
					if (filePDF.exists()) {
						file = filePDF;
						ext = "pdf";
					} else {
						file = new File(IMAGE_ARMOIRE + filePath);
						if (!file.exists()) {
							writeLog("[INFO] " + file.getPath() + " n'existe pas sur le disque", 3);
							file = null;
							continue;
						}
					}
				}

				writeLog("[INFO] Indexation de " + file.getPath(), 2);

				if (file.canRead()) {
					Analyzer analyzer;
					Integer idDoc = res.getInt("IDDOC");
					Integer id = res.getInt("ID");
					String SD = res.getString("SD");
					String SSD = res.getString("SSD");
					String extBase = res.getString("EXT");
					String nom = res.getString("FILE");
					nom = nom.substring(0, nom.lastIndexOf("."));
					Document doc;
					Boolean nouveau = null;
					Term termIdDoc = new Term("idDoc", Integer.toString(idDoc));

					if (CREATE_INDEX) // Indexation totale
					{
						doc = new Document();
					} else {
						// Incrementale donc on cherche si le fichier est nouveau ou doit être mis a jour
						IndexSearcher searcher = new IndexSearcher(DirectoryReader.open(FSDirectory.open(new File(PATH_INDEX).toPath())));

						TermQuery query = new TermQuery(termIdDoc);
						TopDocs hits = searcher.search(query, 10);

						if (hits.scoreDocs.length == 0) {
							//aucun doc ne match
							doc = new Document();
							nouveau = true;
						} else {
							doc = searcher.doc(hits.scoreDocs[0].doc);
							doc.removeFields("idDoc");
							doc.removeFields("id");
							doc.removeFields("path");
							doc.removeFields("contents");
							nouveau = false;
						}
					}
					//On ajoute le contenu
					String contents = extractContent(file, ext, pass);

					if (contents != null && contents.length() > 0) {
						String lang = langDetect(contents);
						// Ajoute un espace entre le mot et les caractères . ou ,
						String pattern = "(\\w)([\\.,;\\?!:])";
						contents = contents.replaceAll(pattern, "$1 $2");
						String[] mots = contents.split(" ");
						writeLog("[INFO] > Mots trouvés : " + mots.length, 2);
						nbmots += mots.length;

						//On ajoute le contenu du fichier
						doc.add(new TextField("contents", contents, Field.Store.NO));
						//Ajout IDDOC
						doc.add(new StringField("idDoc", idDoc.toString(), Field.Store.YES));
						//Ajout ID
						doc.add(new StringField("id", id.toString(), Field.Store.YES));
						//Ajout SD
						doc.add(new StringField("sd", SD, Field.Store.YES));
						//Ajout SSD
						doc.add(new StringField("ssd", SSD, Field.Store.YES));
						//Ajout extension
						doc.add(new StringField("ext", extBase, Field.Store.YES));
						//Ajout nom
						doc.add(new StringField("nom", nom, Field.Store.YES));
						//Ajout path
						doc.add(new StringField("path", file.getPath(), Field.Store.YES));

						switch (lang) {
							case "fr":
//								analyzer = new WhitespaceAnalyzer();
								analyzer = new StandardAnalyzer();
							case "en":
								analyzer = new EnglishAnalyzer();
							case "ar":
								analyzer = new ArabicAnalyzer();
							case "es":
								analyzer = new SpanishAnalyzer();
							case "it":
								analyzer = new ItalianAnalyzer();
							case "de":
								analyzer = new GermanAnalyzer();
							case "pt":
								analyzer = new PortugueseAnalyzer();
							case "ru":
								analyzer = new RussianAnalyzer();
							default:
								analyzer = new StandardAnalyzer();
						}

						iwc = new IndexWriterConfig(analyzer);

						// Indexation totale
						if (CREATE_INDEX) { //On remplace
							if (first) {
								iwc.setOpenMode(OpenMode.CREATE);
								first = false;
							} else {
								iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);
							}
							writer = new IndexWriter(dir, iwc);

							writeLog("[INFO] > Ajouté à l'index", 2);

							writer.addDocument(doc);
						} else { //On prend celui qui existe déjà
							iwc.setOpenMode(OpenMode.CREATE_OR_APPEND);
							writer = new IndexWriter(dir, iwc);

							if (nouveau) {
								writeLog("[INFO] > Ajouté à l'index", 2);
								writer.addDocument(doc);
							} else {
								writeLog("[INFO] > Mis à jour", 2);
								writer.updateDocument(termIdDoc, doc);
							}
						}
						writer.close();
					} else {
						writeLog("[INFO] > Ne contient pas de texte exploitable", 2);
					}
					contents = null;
				} else {
					writeLog("[ERROR] > Fichier illisible ou inexistant", 2);
				}
				file = null;
			}
		} catch (SQLException | IOException e) {
			writeLog("[ERROR] " + e.getMessage(), 3);
		}
		return nbmots;
	}

	/**
	 * Supprime un document de l'index
	 *
	 * @param idDoc l'ID du document à supprimer
	 */
	public void deleteDoc(String idDoc) {
		try {
			Analyzer analyzer = new StandardAnalyzer();
			IndexWriterConfig iwc = new IndexWriterConfig(analyzer);
			try (IndexWriter writer = new IndexWriter(FSDirectory.open(new File(PATH_INDEX).toPath()), iwc)) {
				Term term = new Term("idDoc", idDoc);
				writer.deleteDocuments(term);
				writeLog("[INFO] " + idDoc + " supprimé", 2);
			}
		} catch (IOException ex) {
			writeLog("[ERROR] " + ex.getMessage(), 3);
		}
	}

	/**
	 * Détermine le mot de passe associé au fichier en fonction de son SD
	 *
	 * @param file le fichier dont on souhaite trouver le mot de passe
	 * @param map les mots de passe de cette armoire
	 * @return le mot de passe
	 */
	public String rechercheBonPass(File file, HashMap map) {
		Set listKey = map.keySet();
		Iterator it = listKey.iterator();

		while (it.hasNext()) {
			String key = (String) it.next();
			if (file.getPath().contains(key)) {
				return (String) map.get(key);
			}
		}
		return null;
	}
}
