/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package indexationLucene;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author jeremy
 */
public class GedArmoire {
	/**
	 * 
	 */
	private Integer IDA;
	/**
	 * 
	 */
	private String NomArmoire;
	/**
	 * 
	 */
	private String CheminImage;
	/**
	 * 
	 */
	private String CheminOcr;
	/**
	 * 
	 */
	private Integer Mode;
	
	
	/**
	 *
	 * @param inter
	 * @param idArmoire l'ID de l'armoire concernée
	 * @return La récupération des informations a reussie
	 */
	public GedArmoire(InteractionJDBC inter, Integer idArmoire){
		try {
			java.sql.Statement stm = inter.con.createStatement();
			ResultSet res = stm.executeQuery("select * from appli where IDA="+idArmoire);

			//On se met au premier resultat
			res.first();
			
			// Si une ligne est retournée
			if( res.getRow()==1 ){
				this.IDA			= res.getInt("IDA");
				this.NomArmoire		= res.getString("nomtable");
				this.CheminImage	= res.getString("image");
				this.CheminOcr		= res.getString("ocr");
				this.Mode			= res.getInt("mode");
			}
		}
		catch (SQLException ex) {
			inter.testIndex.writeLog(ex.getMessage() + " SQLState Code : " + ex.getSQLState(), 3);
		}
	}
	
	public Integer getIDA(){
		return this.IDA;
	}
	public String getNomArmoire(){
		return this.NomArmoire;
	}
	public String getCheminImage(){
		return this.CheminImage;
	}
	public String getCheminOcr(){
		return this.CheminOcr;
	}
	public Integer getMode(){
		return this.Mode;
	}
}
