/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package rechercheLucene;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.text.SimpleDateFormat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.PhraseQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.WildcardQuery;
import org.apache.lucene.store.FSDirectory;

/**
 *
 * @author mael
 */
public class RechercheLucene {

	/**
	 * Le chemin d'accès à l'index
	 */
	protected String PATH_INDEX;

	/**
	 * Le numéro unique relatifs aux fichiers de résultats
	 */
	protected String NUM_FILE_OUT;

	/**
	 * Le mode de la query
	 */
	protected String MODE_QUERY;

	/**
	 * Debugage actif
	 */
	protected int MODE_DEBUG = 0;

	/**
	 * Debugage actif
	 */
	protected int MAX_RESULT = 1000;

	protected List<String> listIdOut = new ArrayList<>();
	protected List<String> listIdDocOut = new ArrayList<>();

	protected String DEBUG_FOLDER = "";
//	protected String DEBUG_FOLDER = "G:\\DEVE\\sourcesWEB\\Multigest\\nef\\";

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) throws IOException, ParseException {
		RechercheLucene test = new RechercheLucene();
		test.recherche(args);
	}

	public RechercheLucene() {
		this.MODE_QUERY = "0";
		this.NUM_FILE_OUT = "0";
		this.PATH_INDEX = this.DEBUG_FOLDER + "index\\";
	}

	public void writeLogFile(String typeMSG, String textMSG) throws IOException {
		if (this.MODE_DEBUG == 1) {
			String today = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
			String[] date = today.split(" ");
			String[] time = date[1].split(":");
			File csvLogFile = new File(this.DEBUG_FOLDER + "index//logs_" + date[0] + ".csv");
			if (!csvLogFile.exists()) {
				csvLogFile.createNewFile();
			}
			FileWriter fw = new FileWriter(this.DEBUG_FOLDER + "index//logs_" + date[0] + ".csv", true);
			try (BufferedWriter output = new BufferedWriter(fw)) {
				output.write(date[0] + ";" + time[0] + ":" + time[1] + ":" + time[2] + ";" + typeMSG + ";" + textMSG + "\r\n");
				output.flush();
				output.close();
			}
		}
	}

	/**
	 * Collecte les ID des SD concernés par la recherche
	 *
	 * @return Une liste contenant les ID des SD concernés
	 */
	public List readId() {
		List retour = null;
		String chaine = "";
		String fichier = this.DEBUG_FOLDER + NUM_FILE_OUT + "_ids.txt";
		try {
			File id = new File(fichier);
			id.deleteOnExit();

			InputStream ips = new FileInputStream(fichier);
			InputStreamReader ipsr = new InputStreamReader(ips);
			try (BufferedReader br = new BufferedReader(ipsr)) {
				String ligne;
				while ((ligne = br.readLine()) != null) {
					chaine += ligne;
				}
			}
			String[] ids = chaine.split(",");
			retour = Arrays.asList(ids);
		} catch (Exception e) {
		}
		return retour;
	}

	/**
	 * La méthode principale de recherche
	 *
	 * @param args Les arguments passés lors de l'appel au programme
	 * @throws IOException Si des problèmes d'écriture dans les fichiers de
	 * sortie surviennent
	 * @throws ParseException Si l'utilisation du QueryParser est défectueuse
	 */
	public List<String> recherche(String[] args) throws IOException, ParseException {
		List<String> retour = new ArrayList<>();
		Boolean testId = true;
		String queryString = "";
		for (int i = 0; i < args.length; i++) {
			switch (args[i]) {
				case "-mode":
					MODE_QUERY = args[++i];
					break;
				case "-nomArmoire":
					PATH_INDEX += args[++i].toUpperCase();
					break;
				case "-numFile":
					NUM_FILE_OUT = args[++i];
					break;
				case "-query":
					queryString = args[++i];
					break;
				case "-debug":
					MODE_DEBUG = Integer.parseInt(args[++i]);
					break;
				case "-maxResult":
					MAX_RESULT = Integer.parseInt(args[++i]);
					break;
			}
		}
		this.writeLogFile("INFO", "################################");
		for (String st : args) {
			this.writeLogFile("INFO", "args " + st);
		}

		File IdFile = new File(this.DEBUG_FOLDER + NUM_FILE_OUT + "_ids.txt");
		if (!IdFile.exists() || IdFile.length() == 0) {
			testId = false;
		}
		File outId = null;
		File outIdDocs = null;
		File outRel = null;
		List listIds = null;
		try {
			if (testId) {
				listIds = readId();
			}

			//Le fichier de sortie contenant les ID des SD
			outId = new File(this.DEBUG_FOLDER + NUM_FILE_OUT + "_idSD.txt");
			outId.createNewFile();

			//Le fichier de sortie contenant les IDDOCS
			outIdDocs = new File(this.DEBUG_FOLDER + NUM_FILE_OUT + "_idDocs.txt");
			outIdDocs.createNewFile();

			//Le fichier de sortie contenant les IDDOCS associés aux SD
			outRel = new File(this.DEBUG_FOLDER + NUM_FILE_OUT + "_idRel.txt");
			outRel.createNewFile();
		} catch (IOException e) {
			this.writeLogFile("ERROR", "IOException " + e.getMessage());
		}

		String searchField = "contents";
		String filterField = "id";

		try (IndexReader reader = DirectoryReader.open(FSDirectory.open(new File(PATH_INDEX).toPath()))) {
			IndexSearcher searcher = new IndexSearcher(reader);
			Query query;
			TopDocs results = null;
			Analyzer analyzer = new StandardAnalyzer();
//			Analyzer analyzer = new WhitespaceAnalyzer();
			QueryParser parser = new QueryParser(searchField, analyzer);

			FileWriter fw = new FileWriter(outId);
			FileWriter fwDocs = new FileWriter(outIdDocs);
			FileWriter fwRel = new FileWriter(outRel);
			BufferedWriter out = new BufferedWriter(fwRel);

			long beginGlobal = System.currentTimeMillis();
			if (testId) {
				// Découpe par lot des id à tester
				Integer maxlot = 1024;
				// Calcul le nombre de lots à passer
				// 2648 = 3 lots (0-1024, 1024-2048, 2048-2648)
				Double nbLot = Math.ceil(new Double(listIds.size()) / maxlot);
				this.writeLogFile("INFO", "Liste des ID : " + listIds);
				this.writeLogFile("INFO", "Nombre ID : " + listIds.size());
				this.writeLogFile("INFO", "Nombre de lots : " + nbLot);
				QueryParser parser2 = null;
				Query queryFilter = null;
				String strListId = null;

				for (int numLot = 0; numLot < nbLot; numLot++) {
					// Filtre la recherche uniquement sur les dossiers concernés
					strListId = "";

					int _plageStart = (maxlot * numLot);
					int _plageEnd = (maxlot * (numLot + 1));
					if (_plageEnd > listIds.size()) {
						_plageEnd = listIds.size();
					}
					this.writeLogFile("INFO", "Traitement : lot : " + numLot + " [" + _plageStart + "," + _plageEnd + "]");

					for (int _id = _plageStart; _id < _plageEnd; _id++) {
						if (listIds.get(_id).toString().trim().length() != 0) { // On enlève les espaces en trop (si deux au lieu d'un)
							if (_id > _plageStart && _id < _plageEnd) {
								strListId += " OR " + listIds.get(_id).toString();
							} else {
								strListId += listIds.get(_id).toString();
							}
						}
					}
					strListId = strListId.trim();
					parser2 = new QueryParser(filterField, analyzer);
					// Default Max clauses = 1024
//					BooleanQuery.setMaxClauseCount(listIds.size());
					BooleanQuery.setMaxClauseCount(maxlot);
					queryFilter = parser2.parse(strListId);
					this.writeLogFile("INFO", "   Filtre " + queryFilter.toString());

					long begin = System.currentTimeMillis();
					results = _request(queryString, parser, searcher);
					long end = System.currentTimeMillis();
					float time = ((float) (end - begin)) / 1000f;
					this.writeLogFile("INFO", "   Temps recherche " + time + " s");
					_results(results, out, testId, listIds, searcher);
				}
			} else {
				results = _request(queryString, parser, searcher);
				_results(results, out, testId, listIds, searcher);
			}
			long endGlobal = System.currentTimeMillis();
			float timeGlobal = ((float) (endGlobal - beginGlobal)) / 1000f;
			this.writeLogFile("INFO", "Temps recherche global " + timeGlobal + " s");

			BufferedWriter output = new BufferedWriter(fw);
			BufferedWriter outputDocs = new BufferedWriter(fwDocs);
			// Remplissage du doc contenant les  ID des SD
			for (int k = 0; k < this.listIdOut.size(); k++) {
				if (k == 0) {
					output.write(this.listIdOut.get(k));
				} else {
					output.write("," + this.listIdOut.get(k));
				}
			}
			// Remplissage du doc contenant les idDocs
			for (int k = 0; k < this.listIdDocOut.size(); k++) {
				if (k == 0) {
					outputDocs.write(this.listIdDocOut.get(k));
				} else {
					outputDocs.write("," + this.listIdDocOut.get(k));
				}
			}
			output.flush();
			outputDocs.flush();

			reader.close();
		} catch (IOException e) {
			this.writeLogFile("ERROR", "IOException " + e.getMessage());
		} catch (ParseException e) {
			this.writeLogFile("ERROR", "ParseException " + e.getMessage());
		}
		return retour;
	}

	public TopDocs _request(String queryString, QueryParser parser, IndexSearcher searcher) throws IOException, ParseException {
		Query query;
		TopDocs results = null;

		this.writeLogFile("INFO", "   mode de recherche " + MODE_QUERY);
		switch (MODE_QUERY) {
			// Tous les mots
			case "0"://eric AND archivage
				String[] mots0 = queryString.split("\\s+");
				String line0 = "";
				for (int i = 0; i < mots0.length; i++) {
					if (mots0[i].trim().length() != 0) { // On enlève les espaces en trop (si deux au lieu d'un)
						if (i != mots0.length - 1) {
							line0 += mots0[i] + " AND ";
						} else {
							line0 += mots0[i];
						}
					}
				}
				line0 = line0.trim();
				line0 = QueryParser.escape(line0);
				query = parser.parse(line0);
				this.writeLogFile("INFO", "   Requete " + query.toString());
				results = searcher.search(query, MAX_RESULT);
				break;

			// Au moins un des mots
			case "1"://eric OR archivage
				String[] mots1 = queryString.split("\\s+");
				String line1 = "";
				for (int i = 0; i < mots1.length; i++) {
					if (mots1[i].trim().length() != 0) { // On enlève les espaces en trop (si deux au lieu d'un)
						if (i != mots1.length - 1) {
							line1 += mots1[i] + " OR ";
						} else {
							line1 += mots1[i];
						}
					}
				}
				line1 = line1.trim();
				line1 = QueryParser.escape(line1);
				query = parser.parse(line1);
				this.writeLogFile("INFO", "   Requete " + query.toString());
				results = searcher.search(query, MAX_RESULT);
				break;

			// Contient la chaine
			case "2"://*eric* Attention si * en début : plus long car recherche sur tout les mots de l'index
				query = new WildcardQuery(new Term("contents", "*" + parser.parse(queryString).toString("contents") + "*"));
				this.writeLogFile("INFO", "   Requete " + query.toString());
				results = searcher.search(query, MAX_RESULT);
				break;

			// Contient la phrase
			case "3": //"eric archivage"
				String[] mots3 = queryString.split("\\s+");
				PhraseQuery.Builder query3 = new PhraseQuery.Builder();
				query3.setSlop(0);
				for (int i = 0; i < mots3.length; i++) {
					Query temp = parser.parse(mots3[i]);
					query3.add(new Term("contents", temp.toString("contents")));
				}
				this.writeLogFile("INFO", "   Requete " + query3.build().toString());
				results = searcher.search(query3.build(), MAX_RESULT);
				break;
		}

		return results;
	}

	public void _results(TopDocs results, BufferedWriter out, Boolean testId, List listIds, IndexSearcher searcher) throws IOException {
		try {
			// Liste des fichiers matchant la recherche
			ScoreDoc[] hits = results.scoreDocs;
			this.writeLogFile("INFO", "   NB resultats " + results.totalHits);
			if (results.totalHits > 0) {
				// Pour chaque fichier
				for (int j = 0; j < hits.length; j++) {
					org.apache.lucene.document.Document doc = searcher.doc(hits[j].doc);
					String id = doc.get("id");
					String idDoc = doc.get("idDoc");

					this.writeLogFile("INFO", "      [" + j + "][ID=" + id + "][IDDOC=" + idDoc + "][SD=" + doc.get("sd") + "][SSD=" + doc.get("ssd") + "][FILE=" + doc.get("nom") + "][EXT=." + doc.get("ext") + "][PATH=" + doc.get("path") + "]");

					// Uniquement les dossiers matchés dans la requete de recherche en ged
					if (testId) {
						if (listIds.contains(id.trim())) {
							//ID|SD|SSD|FILE|EXT|IDDOC
							out.write(id + "|" + doc.get("sd") + "|" + doc.get("ssd") + "|" + doc.get("nom") + "|." + doc.get("ext") + "|" + idDoc + "\r\n");
							if (!this.listIdOut.contains(id)) {
								this.listIdOut.add(id);
							}
							this.listIdDocOut.add(idDoc);
						}
					} else {
						//ID|SD|SSD|FILE|EXT|IDDOC
						out.write(id + "|" + doc.get("sd") + "|" + doc.get("ssd") + "|" + doc.get("nom") + "|." + doc.get("ext") + "|" + idDoc + "\r\n");
						if (!this.listIdOut.contains(id)) {
							this.listIdOut.add(id);
						}
						this.listIdDocOut.add(idDoc);
					}
				}
				out.flush();
			}
		} catch (IOException e) {
			this.writeLogFile("ERROR", "IOException " + e.getMessage());
		}
	}
}
