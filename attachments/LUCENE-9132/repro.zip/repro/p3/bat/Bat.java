
package bat;

import baz.*;

public class Bat {
  Baz baz;
}