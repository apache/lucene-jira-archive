package baz;

import bar.Bar;

@Bar
public class Baz {
}