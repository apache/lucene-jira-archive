
module foo {
  exports foo;
}