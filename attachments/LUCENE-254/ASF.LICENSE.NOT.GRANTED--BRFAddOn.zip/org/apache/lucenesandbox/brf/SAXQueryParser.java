package org.apache.lucenesandbox.brf;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Parses the sampleQuery.xml file.
 * 
 * @author Rene Hackl
 * 
 */
public class SAXQueryParser extends DefaultHandler {
    public StringBuffer queryBuffer = new StringBuffer();

    public SAXQueryParser(File xmlFile) throws ParserConfigurationException,
            SAXException, IOException {
        SAXParserFactory spf = SAXParserFactory.newInstance();
        SAXParser parser = spf.newSAXParser();

        parser.parse(xmlFile, this);
    }

    public void startElement(String uri, String localName, String qName,
            Attributes attributes) {
        if (qName.equalsIgnoreCase("query")) {
            queryBuffer.setLength(0);
        } else {
        }
    }

    public void characters(char[] text, int start, int length) {
        queryBuffer.append(text, start, length);
    }

    public void endElement(String uri, String localName, String qName) {

    }
}