package org.apache.lucenesandbox.brf;

import java.io.IOException;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;

import org.apache.lucene.index.Term;
import org.apache.lucene.index.TermFreqVector;
import org.apache.lucene.search.BRFIndexSearcher;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Searcher;

/**
 * Class Blind Relevance Feedback
 * 
 * This class carries out Blind Relevance Feedback (BRF).
 * 
 * @author Rene Hackl
 * @version 1.0
 *  
 */

public class BlindRelevanceFeedback {
    private int relDocs, expTerms;

    public BlindRelevanceFeedback() {
    }

    /**
     * Performs Blind Relevance Feedback for a query. The algorithm for weighing
     * terms can be seen in {@link #computeWeightRSV(int, int, int, int)}.
     * 
     * @param s
     *            instance of an BRFIndexSearcher
     * @param hits
     *            hits object for the current search
     * @param relDocs
     *            the number of top documents assumed to be relevant
     * @param expTerms
     *            the number of expansion terms for the query
     * @return a StringBuffer containing the best descriptors
     * @throws IOException
     */
    public StringBuffer blindRelevanceFeedback(Searcher s, Hits hits,
            int relDocs, int expTerms) throws IOException {
        BRFIndexSearcher is = (BRFIndexSearcher) s;
        Hashtable termsInRelDocsHT = new Hashtable();
        HashMap docFrequenciesHMap = new HashMap();
        HashMap termsPerDocMemoryHMap = new HashMap();

        // take the hits and get the terms to find out in how many of the
        // relevant assumed documents a term t exists
        for (int i = 0; i < relDocs; i++) {
            /**
             * the docNumber of the first relevant and highest scoring document
             * from the initial query
             */
            int docNumber = hits.id(i);
            /**
             * the corresponding TermFreqVector
             */
            TermFreqVector[] termsV = is.getTermsInDoc(docNumber);

            /**
             * now run through the Vector's elements
             */
            for (int xy = 0; xy < termsV.length; xy++) {
                /**
                 * and get the Terms for each field
                 */
                String[] termArr = termsV[xy].getTerms();

                /**
                 * look at each term
                 */
                for (int termsInArray = 0; termsInArray < termArr.length; termsInArray++) {
                    /**
                     * find out from which field the term stems
                     */
                    String currentField = termsV[xy].getField();
                    /**
                     * using that field, construct a new Term and get the term's
                     * documentFrequency.
                     * 
                     * There's a bit of redundancy here because docFreq(Term)
                     * might be called multiple times for the same term, but
                     * here is the only point in this process at which a term's
                     * field is known.
                     */
                    int documentFrequency = is.docFreq(new Term(currentField,
                            termArr[termsInArray]));

                    /**
                     * put the term and the document frequency as a
                     * key-value-pair in the HashMap
                     */
                    docFrequenciesHMap.put(termArr[termsInArray], ""
                            + documentFrequency);

                    /**
                     * if the term shows up for the first time in this document
                     */
                    if (termsInRelDocsHT.get(termArr[termsInArray]) == null) {
                        /**
                         * put it in the hashtable with a value of '1'
                         */
                        termsInRelDocsHT.put(termArr[termsInArray], "" + 1);
                        /**
                         * put it also in the memory map to make sure this term
                         * counts only once per document
                         */
                        termsPerDocMemoryHMap.put(termArr[termsInArray], null);
                    }
                    /**
                     * if the term is already in the hashtable (from a earlier
                     * document) and if it has not been seen yet for the present
                     * document
                     */
                    else if (termsInRelDocsHT.get(termArr[termsInArray]) != null
                            && !termsPerDocMemoryHMap
                                    .containsKey(termArr[termsInArray])) {
                        /**
                         * get this term's occurrences until now
                         */
                        int termCount = Integer.parseInt(termsInRelDocsHT.get(
                                termArr[termsInArray]).toString());
                        /**
                         * add 1 :-)
                         */
                        termCount++;
                        /**
                         * and put it back inside
                         */
                        termsInRelDocsHT.put(termArr[termsInArray], ""
                                + termCount);
                    }
                }
            }
            /**
             * clear the memory map for a new document
             */
            termsPerDocMemoryHMap.clear();
        }

        /**
         * get all the terms from the relevant documents
         */
        Enumeration termEn = termsInRelDocsHT.keys();
        Hashtable weightedTermsHT = new Hashtable();

        /**
         * look at every term and compute it's usefulness
         */
        for (int l = 0; l < termsInRelDocsHT.size(); l++) {
            /**
             * now there's the term
             */
            String key = termEn.nextElement().toString();

            /**
             * At this stage the term's field is unknown. If you want to take
             * into account only one field anyway, you can proceed like
             * 
             * int documentFrequency = is.docFreq(new Term("fieldname", key));
             * 
             * and get rid of the docFrequenciesHMap and the calls to docFreq
             * from above
             */

            /**
             * here's the term's document frequency
             */
            int documentFrequency = Integer.parseInt(docFrequenciesHMap
                    .get(key).toString());
            /**
             * the number of all documents in the index
             */
            int numOfDocsInIndex = is.numOfDocs();
            /**
             * and in how many of the relevant documents the term occurs in
             */
            int relDocFrequency = Integer.parseInt(termsInRelDocsHT.get(key)
                    .toString());

            /**
             * with those four integer values calculate the term's weight
             */
            float termWeight = computeWeightRSV(relDocs, numOfDocsInIndex,
                    relDocFrequency, documentFrequency);
            /**
             * stash the term and its weight in a hashtable
             */
            weightedTermsHT.put(key, "" + termWeight);
        }

        /**
         * all the weights go into an array
         */
        float[] termWeightArray = new float[weightedTermsHT.size()];
        Enumeration tEn = weightedTermsHT.keys();
        for (int m = 0; tEn.hasMoreElements(); m++) {

            termWeightArray[m] = Float.parseFloat(weightedTermsHT.get(
                    tEn.nextElement()).toString());
        }
        /**
         * sort that array to have high values first
         */
        Arrays.sort(termWeightArray);

        StringBuffer bestDescriptors = new StringBuffer();
        /**
         * a variable to match the number of expansion terms
         */
        int expTMatch = 0;
        /**
         * run through the array
         */
        for (int n = 0; n < termWeightArray.length; n++) {
            /**
             * if the number of expected expansion terms is matched you're done
             */
            if (expTMatch == expTerms)
                break;
            /**
             * if not, start with the highest values
             */
            float f = termWeightArray[termWeightArray.length - 1 - n];
            
            /**
             * now find out to which term the value belongs
             */
            Enumeration jAEn = weightedTermsHT.keys();
            while (jAEn.hasMoreElements()) {
                String term = jAEn.nextElement().toString();
                float thatFloat = Float.parseFloat(weightedTermsHT.get(term)
                        .toString());
                if (f == thatFloat) {
                    /**
                     * only terms longer than 2 characters shall be allowed 
                     */
                    if (term.length() > 2) {
                        bestDescriptors.append(term + " ");
                        expTMatch++;
                        /**
                         * remove the term so it won't be able to show up again
                         */
                        weightedTermsHT.remove(term); 
                    } else {
                    }
                    /**
                     * you found term and weight --> bottle up and go
                     */
                    break;
                } else {
                }
            }
        }
        /**
         * return a StringBuffer with the best descriptors
         */
        return bestDescriptors;
    }

    /**
     * method computeWeightRSV calculates the weight for a given term applying
     * the Robertson/Sparck Jones weight: ( r(i) + 0.5 ) ( N - n(i) - R + r(i) +
     * 0.5) rw(i) = log ---------------------------------------------- ( n(i) -
     * r(i) + 0.5) ( R - r(i) + 0.5 )
     * 
     * 
     * where R = the total number of relevant documents N = the total number of
     * documents r(i)= the number of relevant documents containing term i n(i)=
     * the total number of documents containing term i
     * 
     * and then calculating the Robertson Selection Value(rsv)
     * 
     * rsv(i) = r(i) * rw(i)
     * 
     * 
     * @param capital_N
     * @param capital_R
     * @param small_n
     * @param small_r
     * @return rsv
     */
    private float computeWeightRSV(int capital_R, int capital_N, int small_r,
            int small_n) {
        float rsv;

        double rw = Math.log(((small_r + 0.5) * (capital_N - small_n
                - capital_R + small_r + 0.5))
                / ((small_n - small_r + 0.5) * (capital_R - small_r + 0.5)));

        rsv = (float) (small_r * rw);

        return rsv;
    }
}