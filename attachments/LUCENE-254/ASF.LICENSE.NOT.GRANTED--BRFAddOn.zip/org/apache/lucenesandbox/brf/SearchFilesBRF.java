package org.apache.lucenesandbox.brf;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.BRFIndexSearcher;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.TermQuery;
import org.xml.sax.SAXException;

/**
 * startup class for blind relevance feedback
 * 
 * @author Rene Hackl
 */

public class SearchFilesBRF {

    public SearchFilesBRF(String pathToQueries, boolean brf, int relDocs,
            int expTerms) throws IOException, ParserConfigurationException,
            SAXException {
        startTheAction(pathToQueries, brf, relDocs, expTerms);
    }

    public static void main(String[] args) throws IOException,
            ParserConfigurationException, SAXException {
        /**
         * default to not performing brf
         */
        boolean brf = false;
        if (args.length == 1) {
            SearchFilesBRF searchBRF = new SearchFilesBRF(args[0], brf, 0, 0);
        } else if (args.length == 2) {
            if (args[1].equals("-brf")) {
                System.out.println(" Please provide two integer parameters ");
            }
        } else if (args.length == 4) {
            if (args[1].equals("-brf")) {
                try {
                    int relDocs = Integer.parseInt(args[2]);
                    int expTerms = Integer.parseInt(args[3]);

                    if ((relDocs > 0) && (expTerms > 0)) {
                        brf = true;
                        SearchFilesBRF searchBRF = new SearchFilesBRF(args[0],
                                brf, relDocs, expTerms);
                    } else
                        System.out.println("parameters must be positive");

                } catch (NumberFormatException e) {
                    System.out.println("Please use integer values only");
                }
            }
        } else {
            System.out
                    .println("\nUsage: SearchFilesBRF [pathToQueries] [-brf] [relDocs] [expTerms] \n");
            System.out.println("Options:\n");
            System.out.println(" -brf :\t carry out blind relevance feedback");
            System.out.println(" relDocs :\t number of relevant Docs");
            System.out
                    .println(" expterms :\t number of desired terms for query expansion ");
        }
    }

    private void startTheAction(String pathToQueries, boolean brf, int relDocs,
            int expTerms) throws IOException, ParserConfigurationException,
            SAXException {
        Date beginRun = new Date();
        File queryFile = new File(pathToQueries);
        SAXQueryParser saxQueryParser = new SAXQueryParser(queryFile);
        Query query = null;
        /**
         * the parser's queryBuffer contains the query terms
         */
        StringBuffer queryBufPreBRF = saxQueryParser.queryBuffer;
        /**
         * build a query
         */
        query = buildQueries(queryBufPreBRF);

        /**
         * specify the index to search in
         */
        Searcher searcher = new BRFIndexSearcher("index");

        if (query != null) {
            Hits hits = searcher.search(query);
            System.out.println(hits.length() + " total matching documents");

            if (brf != false) {
                BlindRelevanceFeedback blindRelFB = new BlindRelevanceFeedback();

                StringBuffer brfTerms = blindRelFB.blindRelevanceFeedback(
                        searcher, hits, relDocs, expTerms);
                /**
                 * append the original query terms and the expansion terms
                 */
                StringBuffer allTerms = queryBufPreBRF.append(brfTerms);
                /**
                 * build a query again
                 */
                query = buildQueries(allTerms);

                hits = searcher.search(query);
                System.out.println("BRF: " + hits.length()
                        + " total matching documents");
            }
        }
        searcher.close();
    }

    /**
     * constructs a Lucene query
     * 
     * @param queryBuf
     *            a StringBuffer with terms to include in a query
     * @return a proper Lucene query
     */
    private Query buildQueries(StringBuffer queryBuf) {

        String[] queryTerms = queryBuf.toString().trim().split("\\s");
        /**
         * build a BooleanQuery
         */
        BooleanQuery bq = new BooleanQuery();
        Term trm;
        Query query = null;

        for (int t = 0; t < queryTerms.length; t++) {
            /**
             * search in fulltext fields
             */
            trm = new Term("fulltext", queryTerms[t]);
            query = new TermQuery(trm);
            /**
             * concatenate with OR
             */
            bq.add(query, false, false);
        }
        System.out.println("query before analyzer: " + bq.toString());

        Analyzer analyzer = new StandardAnalyzer();
        try {
            query = QueryParser.parse(bq.toString(), "fulltext", analyzer);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        System.out.println("QUERY: " + query.toString());
        return query;
    }

}