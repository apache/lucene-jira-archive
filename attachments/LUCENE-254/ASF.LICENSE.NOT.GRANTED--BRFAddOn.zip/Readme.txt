Lucene Add-on Blind Relevance Feedback
Author: Rene Hackl 
Tested for Lucene-1.4-final

----------------------------------------------
|                Quick Start                 |
----------------------------------------------

1. Extract the archive
	Assuming you have a freshly built Lucene, extract the archive to 
		
		$path\build\classes\java\
		
		The sources will then be in your classes folder, too. This 
		is really a quick hack.

2. Search
	A sample call might be
	
		java org.apache.lucenesandbox.brf.SearchFilesBRF sampleQuery.xml -brf 2 3

	prompting the app to take the 2 top documents to perform blind relevance feedback and
	expand the query by 3 terms.


----------------------------------------------
|       What's Blind Relevance Feedback      |
----------------------------------------------

Blind Relevance Feedback (BRF, also referred to as pseudo-relevance feedback) can be
employed to automatically expand queries. Coming from an initial user query, the system
assumes the top X documents to be relevant and ranks the terms from these documents. 
Top ranked terms add most to the discrimination of relevant documents from the rest of
the collection.

As a starting point you might want to consider a presentation by James Allan which 
can be found at

http://ciir.cs.umass.edu/cmpsci646/Slides/ir12%20relfeedback.pdf
(approx. 430 KB, last checked 2004/07/30)


----------------------------------------------
|       Changes to Lucene core classes       |
----------------------------------------------

--- org.apache.lucene.search.IndexSearcher ---

copied to org.apache.lucene.search.BRFIndexSearcher
and added the methods numOfDocs() and getTermsInDoc(int docNumber)


----------------------------------------------
|      Changes to Lucene sandbox classes     |
----------------------------------------------

--- org.apache.lucenesandbox.xmlindexingdemo.IndexFiles ---

copied to org.apache.lucenesandbox.xmlindexingdemo.IndexXMLFiles
and added 

		writer.setUseCompoundFile(false); 
		
to main-method. In indexDocs(IndexWriter, File) added 

		if (file.getName().endsWith(".xml"))

to get only XML files from the specified directory and added
while loop

		while (hdlr.getDocument(i) != null) {
    	writer.addDocument(hdlr.getDocument(i));
      i++; }
      
to get all "real life" documents from a file. This takes us to

--- org.apache.lucenesandbox.xmlindexingdemo.XMLDocumentHandlerSAX ---

copied to org.apache.lucenesandbox.xmlindexingdemo.XMLMultiDocumentHandlerSAX
and added 

		private Vector documentVector = new Vector();
		
a Vector to store documents in. In startDocument() commented

		// mDocument = new Document();
		
because now a new Document will be created when a specified element shows up.
Method startElement(...)

		if (qualifiedName.equalsIgnoreCase("DOC")) {
            mDocument = new Document(); }
            
When the same element shows up at endElement(...)

		if (qualifiedName.equalsIgnoreCase("DOC")) {
            int vectorSize = documentVector.size();
            documentVector.add(vectorSize, mDocument);
            elementBuffer.setLength(0); }
            
the document is added to the vector. Fields do store TermVectors now 
(third param = 'true') and there's an extra Field of type UnStored to store
all of a documents' content.

		mDocument.add(Field.Text(eName, elementBuffer.toString(), true));
    mDocument.add(Field.UnStored("fulltext", elementBuffer.toString(), true));
    
Finally, there's the getDocument(int) method which IndexXMLFiles calls.

----------------------------------------------
|              Rather new classes            |
----------------------------------------------

The SAXQueryParser is only there for reading the sampleQuery.xml file.

The SearchFilesBRF class is the starting point for brf-style searches. It accepts
four parameters - a sample call could be

	>	$path.SearchFilesBRF sampleQuery.xml -brf 2 3
	(as seen above)
	
This would cause the program to assume the top 2 found documents as relevant and
add 3 expansion terms to the original query. 

In the class BlindRelevanceFeedback terms are ranked according to their RSV 
(Robertson Selection Value).

--- EOF ---