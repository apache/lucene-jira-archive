package org.apache.lucene.search.trie;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.IOException;
import java.util.BitSet;

import org.apache.lucene.search.Filter;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.search.DocIdSet;

abstract class AbstractTrieRangeFilter extends Filter {

  AbstractTrieRangeFilter(AbstractTrieRangeQuery query) {
    this.query = query;
  }

  //@Override
  public String toString() {
    // query.toString() should not print the boost, as fixed to 1.0f
    return query.toString();
  }

  //@Override
  public final boolean equals(final Object o) {
    if (o==this) return true;
    if (o==null) return false;
    if (this.getClass().equals(o.getClass())) {
      return this.query.equals( ((AbstractTrieRangeFilter)o).query );
    }
    return false;
  }

  //@Override
  public final int hashCode() {
    return query.hashCode();
  }
  
  /**
   * Expert: Return the number of unique terms visited during execution of the filter.
   * If there are many of them, you may consider using another filter type
   * or optimize your total term count in index.
   * <p>This method is not thread safe, be sure to only call it when no filter is running!
   * If you re-use the same filter instance for another
   * search, be sure to first reset the term counter
   * with {@link #clearTotalNumberOfTerms}.
   * @see #clearTotalNumberOfTerms
   */
  public int getTotalNumberOfTerms() {
    return query.getTotalNumberOfTerms();
  }
  
  /**
   * Expert: Resets the counting of unique terms.
   * Do this before executing the filter.
   * @see #getTotalNumberOfTerms
   */
  public void clearTotalNumberOfTerms() {
    query.clearTotalNumberOfTerms();
  }
  
  public BitSet bits(IndexReader reader) throws IOException {
    return query.getFilter().bits(reader);
  }
  
  public DocIdSet getDocIdSet(IndexReader reader) throws IOException {
    return query.getFilter().getDocIdSet(reader);
  }
      
  // members
  final AbstractTrieRangeQuery query;
}
