import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.queryParser.QueryParser;
import org.apache.lucene.search.Hits;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.store.RAMDirectory;

//import ;

public class Test {

	public static void main(String[] args)
	{
		RAMDirectory dir = new RAMDirectory();
		IndexWriter indexWriter = null;
		try{
			indexWriter = new IndexWriter(dir, new TestAnalyzer(), true);
		}catch(Exception e){e.printStackTrace();}
		
		Document doc = new Document();
		doc.add(Field.Text("0", "1234"));
		try{
			indexWriter.addDocument(doc);
			indexWriter.optimize();
			indexWriter.close();
		}catch(Exception e){e.printStackTrace();}
		IndexSearcher searcher = null;
		try{
			searcher = new IndexSearcher(dir);
		}catch(Exception e){e.printStackTrace();}
		
		QueryParser queryParser = new QueryParser("0", new TestAnalyzer());
		
		try{
			Query query1 = queryParser.parse("123*");
			Query query2 = queryParser.parse("\"123*\"");
			
			Hits hits = null;
			hits = searcher.search(query1);
			System.out.println("number of hits for query 1: " + hits.length());
			
			hits = searcher.search(query2);
			System.out.println("number of hits for query 2: " + hits.length());
			
		}catch(Exception e){e.printStackTrace();}
		
	}
}