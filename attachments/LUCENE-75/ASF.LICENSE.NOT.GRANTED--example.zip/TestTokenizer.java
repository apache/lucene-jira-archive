
import java.io.Reader;

import org.apache.lucene.analysis.CharTokenizer;

public class TestTokenizer extends CharTokenizer{
	
	public TestTokenizer(Reader reader)
	{
		super(reader);
	}

	/**
	 * @see org.apache.lucene.analysis.CharTokenizer#isTokenChar(char)
	 */
	protected boolean isTokenChar(char arg0) {
		return true;
	}

}
