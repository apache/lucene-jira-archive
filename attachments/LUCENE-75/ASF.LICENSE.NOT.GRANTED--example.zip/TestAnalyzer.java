
import java.io.Reader;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;

public class TestAnalyzer extends Analyzer {

	public TokenStream tokenStream(String arg0, Reader reader) {
		return new TestTokenizer(reader);
	}

}
