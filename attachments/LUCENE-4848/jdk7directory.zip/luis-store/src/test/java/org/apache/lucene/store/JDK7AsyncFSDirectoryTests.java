package org.apache.lucene.store;

import java.io.IOException;
import java.nio.file.Path;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.AfterClass;
import org.junit.BeforeClass;

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class JDK7AsyncFSDirectoryTests extends AbstractJDK7FSDirectoryTests {
  
  private static ExecutorService TEST_THREAD_POOL;
  
  public void testWriteThreadInterrupt() throws Exception {
    //Tests that interrupt does not cause unexpected exceptions on write
    final JDK7FSDirectory dir = implementation(createStoreDirectory(description() + ":testWriiteThreadInterrupt"));
    
    final byte[] writtenBytes = new byte[LARGE_BUFFER_SIZE];
    random().nextBytes(writtenBytes);

    final CountDownLatch thread2Done = new CountDownLatch(1);
    final AtomicBoolean threadWasInterrupted = new AtomicBoolean(false);
    final AtomicReference<Exception> exception = new AtomicReference<>();
    final Thread t1 = new Thread(new Runnable() {
      @Override
      public void run() {
        try {
          //Try writes in a loop until we get a notification that the current thread was interrupted
          while(true) {
            try(IndexOutput output = dir.createOutput("test", IOContext.DEFAULT)) {
              output.writeBytes(writtenBytes, writtenBytes.length);
              if (Thread.interrupted()) {
                threadWasInterrupted.set(true);
                break;
              }
            }
          }
          
          //Wait for thread 2 to stop spamming us with interrupts
          while(true) {
            try {
              thread2Done.await();
              break;
            } catch (InterruptedException e) {
            }
          }
          //Clear the interrupted flag if set
          Thread.interrupted();
          
          //Make sure we can do a write after the interruption
          try(IndexOutput output = dir.createOutput("test", IOContext.DEFAULT)) {
            output.writeBytes(writtenBytes, writtenBytes.length);
          }
        } catch (Exception e) {
          exception.set(e);
        }
        threadWasInterrupted.set(true);
      }
    });
    t1.setPriority(Thread.MIN_PRIORITY);
    
    Thread t2 = new Thread(new Runnable() {
      @Override
      public void run() {
        while(!threadWasInterrupted.get()) {
          t1.interrupt();
        }
        thread2Done.countDown();
      }
    });
    t2.setPriority(Thread.MAX_PRIORITY);
    
    t1.start();
    t2.start();
    
    t1.join();
    t2.join();
    
    if(exception.get() != null) {
      throw exception.get();
    }
  }
  
  public void testReadThreadInterrupt() throws Exception {
    //Tests that interrupt does not cause unexpected exceptions on read
    final JDK7FSDirectory dir = implementation(createStoreDirectory(description() + ":testReadThreadInterrupt"));
    
    final byte[] writtenBytes = new byte[LARGE_BUFFER_SIZE];
    random().nextBytes(writtenBytes);
    
    try(IndexOutput output = dir.createOutput("test", IOContext.DEFAULT)) {
      output.writeBytes(writtenBytes, writtenBytes.length);
    }
    
    final CountDownLatch thread2Done = new CountDownLatch(1);
    final AtomicBoolean threadWasInterrupted = new AtomicBoolean(false);
    final AtomicReference<Exception> exception = new AtomicReference<>();
    final Thread t1 = new Thread(new Runnable() {
      @Override
      public void run() {
        try {
          //Try reads in a loop until we get a notification that the current thread was interrupted
          while(true) {
            try(IndexInput input = dir.openInput("test", IOContext.DEFAULT)) {  
              byte[] readBytes = new byte[LARGE_BUFFER_SIZE];
              input.readBytes(readBytes, 0, LARGE_BUFFER_SIZE);
              if (Thread.interrupted()) {
                threadWasInterrupted.set(true);
                break;
              }
              assertArrayEquals(writtenBytes, readBytes);
            }
          }
          
          //Wait for thread 2 to stop spamming us with interrupts
          while(true) {
            try {
              thread2Done.await();
              break;
            } catch (InterruptedException e) {
            }
          }
          //Clear the interrupted flag if set
          Thread.interrupted();
          
          //Make sure we can do a read after the interruption
          try(IndexInput input = dir.openInput("test", IOContext.DEFAULT)) {  
            byte[] readBytes = new byte[LARGE_BUFFER_SIZE];
            input.readBytes(readBytes, 0, LARGE_BUFFER_SIZE);
            assertArrayEquals(writtenBytes, readBytes);
          }
        } catch (Exception e) {
          exception.set(e);
        }
        threadWasInterrupted.set(true);
      }
    });
    t1.setPriority(Thread.MIN_PRIORITY);
    
    Thread t2 = new Thread(new Runnable() {
      @Override
      public void run() {
        while(!threadWasInterrupted.get()) {
          t1.interrupt();
        }
        thread2Done.countDown();
      }
    });
    t2.setPriority(Thread.MAX_PRIORITY);
    
    t1.start();
    t2.start();
    
    t1.join();
    t2.join();
    
    if(exception.get() != null) {
      throw exception.get();
    }
  }
  
  @Override
  protected JDK7FSDirectory implementation(Path path) throws IOException {
    return new JDK7AsyncFSDirectory(path, null, TEST_THREAD_POOL);
  }
  
  @Override
  protected String description() {
    return "JDK7AsyncFSDirectory";
  }
  
  @BeforeClass
  public static void createDefaultThreadPool() throws Exception {
    TEST_THREAD_POOL = JDK7AsyncFSDirectory.createDefaultThreadPool();
  }
  
  @AfterClass
  public static void destroyThreadPool() throws Exception {
    TEST_THREAD_POOL.shutdown();
  }
}
