package org.apache.lucene.store;

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

/**
 * Copy of {@link NIOFSDirectory} that uses JDK7 API's to 
 * open file channels so that the files will be opened with
 * FILE_SHARE_DELETE on windows.
 * 
 * See {@link NIOFSDirectory} for a full description of the
 * restrictions and limitations of using this class.
 * 
 * There is one major behavioral change between this class and 
 * {@link NIOFSDirectory}.  {@link NIOFSDirectory} is safe to 
 * use on an interrupted thread for writes (but not for reads).
 * This class is safe for neither:  If accessed from an interrupted
 * thread, the underlying channel will be closed and all future 
 * operations will throw an exception.
 * 
 * @author mpoindexter
 *
 */
public class JDK7NIOFSDirectory extends JDK7FSDirectory {
  
  /** Create a new JDK7NIOFSDirectory for the named location.
   * 
   * @param path the path of the directory
   * @param lockFactory the lock factory to use, or null for the default
   * ({@link NativeFSLockFactory});
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7NIOFSDirectory(Path path, LockFactory lockFactory) throws IOException {
    super(path, lockFactory);
  }
  
  /** Create a new JDK7NIOFSDirectory for the named location and {@link NativeFSLockFactory}.
   *
   * @param path the path of the directory
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7NIOFSDirectory(Path path) throws IOException {
    super(path, null);
  }
  
  /** Create a new JDK7NIOFSDirectory for the named location.
   * 
   * @param path the path of the directory
   * @param lockFactory the lock factory to use, or null for the default
   * ({@link NativeFSLockFactory});
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7NIOFSDirectory(File path, LockFactory lockFactory) throws IOException {
    this(path.toPath(), lockFactory);
  }
  
  /** Create a new JDK7NIOFSDirectory for the named location and {@link NativeFSLockFactory}.
   *
   * @param path the path of the directory
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7NIOFSDirectory(File path) throws IOException {
    this(path.toPath(), null);
  }
  
  /** Creates an IndexInput for the file with the given name. */
  @Override
  public IndexInput openInput(String name, IOContext context) throws IOException {
    ensureOpen();
    return new JDK7NIOFSIndexInput(getDirectory().resolve(name), context, getReadChunkSize());
  }
  
  @Override
  public IndexInputSlicer createSlicer(final String name,
      final IOContext context) throws IOException {
    ensureOpen();
    final Path path = getDirectory().resolve(name);
    final FileChannel channel = FileChannel.open(path, StandardOpenOption.READ);
    return new Directory.IndexInputSlicer() {
      
      @Override
      public void close() throws IOException {
        channel.close();
      }
      
      @Override
      public IndexInput openSlice(String sliceDescription, long offset, long length) {
        return new JDK7NIOFSIndexInput(sliceDescription, path, channel, offset,
            length, BufferedIndexInput.bufferSize(context), getReadChunkSize());
      }
      
      @Override
      public IndexInput openFullSlice() {
        try {
          return openSlice("full-slice", 0, channel.size());
        } catch (IOException ex) {
          throw new RuntimeException(ex);
        }
      }
    };
  }
  
  /**
   * Reads bytes with {@link FileChannel#read(ByteBuffer, long)}
   */
  protected static class JDK7NIOFSIndexInput extends JDK7FSIndexInput<FileChannel> {
    
    private ByteBuffer byteBuf; // wraps the buffer for NIO
    
    public JDK7NIOFSIndexInput(Path path, IOContext context, int chunkSize) throws IOException {
      super("JDK7NIOFSIndexInput(path=\"" + path + "\")", new FileChannelAdapter(FileChannel.open(path, StandardOpenOption.READ)), context, chunkSize);
    }
    
    public JDK7NIOFSIndexInput(String sliceDescription, Path path, FileChannel fc, long off, long length, int bufferSize, int chunkSize) {
      super("JDK7NIOFSIndexInput(" + sliceDescription + " in path=\"" + path + "\" slice=" + off + ":" + (off+length) + ")", new FileChannelAdapter(fc), off, length, bufferSize, chunkSize);
      isClone = true;
    }
    
    @Override
    protected void newBuffer(byte[] newBuffer) {
      super.newBuffer(newBuffer);
      byteBuf = ByteBuffer.wrap(newBuffer);
    }
    
    @Override
    protected void readInternal(byte[] b, int offset, int len) throws IOException {
      
      final ByteBuffer bb;
      
      // Determine the ByteBuffer we should use
      if (b == buffer && 0 == offset) {
        // Use our own pre-wrapped byteBuf:
        assert byteBuf != null;
        byteBuf.clear();
        byteBuf.limit(len);
        bb = byteBuf;
      } else {
        bb = ByteBuffer.wrap(b, offset, len);
      }
      
      int readOffset = bb.position();
      int readLength = bb.limit() - readOffset;
      assert readLength == len;
      
      long pos = getFilePointer() + off;
      
      if (pos + len > end) {
        throw new EOFException("read past EOF: " + this);
      }
      
      try {
        while (readLength > 0) {
          final int limit;
          if (readLength > chunkSize) {
            // LUCENE-1566 - work around JVM Bug by breaking
            // very large reads into chunks
            limit = readOffset + chunkSize;
          } else {
            limit = readOffset + readLength;
          }
          bb.limit(limit);
          int i = channelAdapter.getChannel().read(bb, pos);
          pos += i;
          readOffset += i;
          readLength -= i;
        }
      } catch (OutOfMemoryError e) {
        // propagate OOM up and add a hint for 32bit VM Users hitting the bug
        // with a large chunk size in the fast path.
        final OutOfMemoryError outOfMemoryError = new OutOfMemoryError(
            "OutOfMemoryError likely caused by the Sun VM Bug described in "
                + "https://issues.apache.org/jira/browse/LUCENE-1566; try calling FSDirectory.setReadChunkSize "
                + "with a value smaller than the current chunk size (" + chunkSize + ")");
        outOfMemoryError.initCause(e);
        throw outOfMemoryError;
      } catch (IOException ioe) {
        throw new IOException(ioe.getMessage() + ": " + this, ioe);
      }
    }
    
    @Override
    protected void seekInternal(long pos) throws IOException {}
  }
  
  private static class FileChannelAdapter implements ChannelAdapter<FileChannel> {
    private final FileChannel channel;
    
    public FileChannelAdapter(FileChannel channel) {
      this.channel = channel;
    }
    
    @Override
    public FileChannel getChannel() {
      return channel;
    }
    
    @Override
    public long getSize() throws IOException {
      return channel.size();
    }
    
    @Override
    public boolean isOpen() throws IOException {
      return channel.isOpen();
    }
    
    @Override
    public void close() throws IOException {
      channel.close();
    }
  }
}

