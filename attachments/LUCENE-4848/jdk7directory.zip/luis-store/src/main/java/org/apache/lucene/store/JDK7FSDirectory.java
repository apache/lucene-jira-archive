package org.apache.lucene.store;

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import static java.util.Collections.synchronizedSet;

import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.Channel;
import java.nio.channels.FileChannel;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.lucene.util.Constants;
import org.apache.lucene.util.ThreadInterruptedException;

public abstract class JDK7FSDirectory extends Directory {
  
  /**
   * Default read chunk size.  This is a conditional default: on 32bit JVMs, it defaults to 100 MB.  On 64bit JVMs, it's
   * <code>Integer.MAX_VALUE</code>.
   *
   * @see #setReadChunkSize
   */
  public static final int DEFAULT_READ_CHUNK_SIZE = Constants.JRE_IS_64BIT ? Integer.MAX_VALUE : 100 * 1024 * 1024;
  
  protected final Path directory; // The underlying filesystem directory
  protected final Set<String> staleFiles = synchronizedSet(new HashSet<String>()); // Files written, but not yet sync'ed
  private int chunkSize = DEFAULT_READ_CHUNK_SIZE; // LUCENE-1566
  
  /** Create a new JDK7FSDirectory for the named location (ctor for subclasses).
   * @param path the path of the directory
   * @param lockFactory the lock factory to use, or null for the default
   * ({@link NativeFSLockFactory});
   * @throws IOException if there is a low-level I/O error
   */
  protected JDK7FSDirectory(Path path, LockFactory lockFactory) throws IOException {
    // new ctors use always NativeFSLockFactory as default:
    if (lockFactory == null) {
      lockFactory = new NativeFSLockFactory();
    }
    directory = path.toRealPath();
    
    if (Files.exists(directory) && !Files.isDirectory(directory))
      throw new NoSuchDirectoryException("file '" + directory + "' exists but is not a directory");
    
    setLockFactory(lockFactory);
  }
  
  /** Creates an JDK7FSDirectory instance, trying to pick the
   *  best implementation given the current environment.
   *  The directory returned uses the {@link NativeFSLockFactory}.
   *
   *  <p>Currently this returns {@link JDK7MMapDirectory} for most Solaris
   *  and Windows 64-bit JREs, {@link JDK7NIOFSDirectory} for other
   *  non-Windows JREs, and {@link JDK7AsyncFSDirectory} for other
   *  JREs on Windows. It is highly recommended that you consult the
   *  implementation's documentation for your platform before
   *  using this method.
   *
   * <p><b>NOTE</b>: this method may suddenly change which
   * implementation is returned from release to release, in
   * the event that higher performance defaults become
   * possible; if the precise implementation is important to
   * your application, please instantiate it directly,
   * instead. For optimal performance you should consider using
   * {@link JDK7MMapDirectory} on 64 bit JVMs.
   *
   * <p>See <a href="#subclasses">above</a> */
  public static JDK7FSDirectory open(Path path) throws IOException {
    return open(path, null);
  }
  
  public static JDK7FSDirectory open(File path) throws IOException {
    return open(path.toPath(), null);
  }
  
  /** Just like {@link #open(Path)}, but allows you to
   *  also specify a custom {@link LockFactory}. */
  public static JDK7FSDirectory open(Path path, LockFactory lockFactory) throws IOException {
    if ((Constants.WINDOWS || Constants.SUN_OS || Constants.LINUX || Constants.MAC_OS_X)
        && Constants.JRE_IS_64BIT && JDK7MMapDirectory.UNMAP_SUPPORTED) {
      return new JDK7MMapDirectory(path, lockFactory);
    } else if (Constants.WINDOWS) {
      return new JDK7AsyncFSDirectory(path, lockFactory);
    } else {
      return new JDK7NIOFSDirectory(path, lockFactory);
    }
  }
  
  public static JDK7FSDirectory open(File path, LockFactory lockFactory) throws IOException {
    return open(path.toPath(), lockFactory);
  }
  
  @Override
  public void setLockFactory(LockFactory lockFactory) throws IOException {
    super.setLockFactory(lockFactory);
    
    // for filesystem based LockFactory, delete the lockPrefix, if the locks are placed
    // in index dir. If no index dir is given, set ourselves
    if (lockFactory instanceof FSLockFactory) {
      final FSLockFactory lf = (FSLockFactory) lockFactory;
      final File dir = lf.getLockDir();
      // if the lock factory has no lockDir set, use the this directory as lockDir
      if (dir == null) {
        lf.setLockDir(directory.toFile());
        lf.setLockPrefix(null);
      } else if (Files.isSameFile(dir.toPath(), directory)) {
        lf.setLockPrefix(null);
      }
    }
    
  }
  
  /** Lists all files (not subdirectories) in the
   *  directory.  This method never returns null (throws
   *  {@link IOException} instead).
   *
   *  @throws NoSuchDirectoryException if the directory
   *   does not exist, or does exist but is not a
   *   directory.
   *  @throws IOException if list() returns null */
  public static String[] listAll(Path dir) throws IOException {
    if (!Files.exists(dir))
      throw new NoSuchDirectoryException("directory '" + dir + "' does not exist");
    else if (!Files.isDirectory(dir))
      throw new NoSuchDirectoryException("file '" + dir + "' exists but is not a directory");
    
    List<String> result = new LinkedList<>();
    try(DirectoryStream<Path> ls = Files.newDirectoryStream(dir)) {
      for(Path p : ls) {
        if(!Files.isDirectory(p)) {
          result.add(p.getFileName().toString());
        }
      }
    }
    
    return result.toArray(new String[result.size()]);
  }
  
  public static String[] listAll(File dir) throws IOException {
    return listAll(dir.toPath());
  }
  
  /** Lists all files (not subdirectories) in the
   * directory.
   */
  @Override
  public String[] listAll() throws IOException {
    ensureOpen();
    return listAll(directory);
  }
  
  /** Returns true iff a file with the given name exists. */
  @Override
  public boolean fileExists(String name) {
    ensureOpen();
    return Files.exists(directory.resolve(name));
  }
  
  /** Returns the time the named file was last modified. */
  public static long fileModified(Path directory, String name) throws IOException {
    return Files.getLastModifiedTime(directory.resolve(name)).toMillis();
  }
  
  /** Returns the length in bytes of a file in the directory. */
  @Override
  public long fileLength(String name) throws IOException {
    ensureOpen();
    return Files.size(directory.resolve(name));
  }
  
  /** Removes an existing file in the directory. */
  @Override
  public void deleteFile(String name) throws IOException {
    ensureOpen();
    Files.delete(directory.resolve(name));
    staleFiles.remove(name);
  }
  
  /** Creates an IndexOutput for the file with the given name. */
  @Override
  public IndexOutput createOutput(String name, IOContext context) throws IOException {
    ensureOpen();
    
    ensureCanWrite(name);
    return new JDK7FSIndexOutput(this, name);
  }
  
  protected void ensureCanWrite(String name) throws IOException {
    if (!Files.exists(directory))
      Files.createDirectories(directory);
  }
  
  protected void onIndexOutputClosed(String name) {
    staleFiles.add(name);
  }
  
  @Override
  public void sync(Collection<String> names) throws IOException {
    ensureOpen();
    Set<String> toSync = new HashSet<String>(names);
    toSync.retainAll(staleFiles);
    
    for (String name : toSync)
      fsync(name);
    
    staleFiles.removeAll(toSync);
  }
  
  @Override
  public String getLockID() {
    ensureOpen();
    String dirName = directory.toString();
    
    int digest = 0;
    for(int charIDX=0;charIDX<dirName.length();charIDX++) {
      final char ch = dirName.charAt(charIDX);
      digest = 31 * digest + ch;
    }
    return "lucene-" + Integer.toHexString(digest);
  }
  
  /** Closes the store to future operations. */
  @Override
  public synchronized void close() {
    isOpen = false;
  }
  
  /** @return the underlying filesystem directory */
  public Path getDirectory() {
    ensureOpen();
    return directory;
  }
  
  /** For debug output. */
  @Override
  public String toString() {
    return this.getClass().getName() + "@" + directory + " lockFactory=" + getLockFactory();
  }
  
  /**
   * Sets the maximum number of bytes read at once from the
   * underlying file during {@link IndexInput#readBytes}.
   * The default value is {@link #DEFAULT_READ_CHUNK_SIZE};
   *
   * <p> This was introduced due to <a
   * href="http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6478546">Sun
   * JVM Bug 6478546</a>, which throws an incorrect
   * OutOfMemoryError when attempting to read too many bytes
   * at once.  It only happens on 32bit JVMs with a large
   * maximum heap size.</p>
   *
   * <p>Changes to this value will not impact any
   * already-opened {@link IndexInput}s.  You should call
   * this before attempting to open an index on the
   * directory.</p>
   *
   * <p> <b>NOTE</b>: This value should be as large as
   * possible to reduce any possible performance impact.  If
   * you still encounter an incorrect OutOfMemoryError,
   * trying lowering the chunk size.</p>
   */
  public final void setReadChunkSize(int chunkSize) {
    // LUCENE-1566
    if (chunkSize <= 0) {
      throw new IllegalArgumentException("chunkSize must be positive");
    }
    if (!Constants.JRE_IS_64BIT) {
      this.chunkSize = chunkSize;
    }
  }
  
  /**
   * The maximum number of bytes to read at once from the
   * underlying file during {@link IndexInput#readBytes}.
   * @see #setReadChunkSize
   */
  public final int getReadChunkSize() {
    // LUCENE-1566
    return chunkSize;
  }
  
  /** Base class for reading input from a RandomAccessFile */
  protected abstract static class JDK7FSIndexInput<T extends Channel> extends BufferedIndexInput {
    /** the underlying Channel */
    protected final ChannelAdapter<T> channelAdapter;
    
    boolean isClone = false;
    /** maximum read length on a 32bit JVM to prevent incorrect OOM, see LUCENE-1566 */ 
    protected final int chunkSize;
    /** start offset: non-zero in the slice case */
    protected final long off;
    /** end offset (start+length) */
    protected final long end;
    
    /** Create a new FSIndexInput, reading the entire file from <code>path</code> */
    protected JDK7FSIndexInput(String resourceDesc, ChannelAdapter<T> channelAdapter, IOContext context, int chunkSize) throws IOException {
      super(resourceDesc, context);
      this.channelAdapter = channelAdapter;
      this.chunkSize = chunkSize;
      this.off = 0L;
      try {
        this.end = channelAdapter.getSize();
      } catch (IOException e) {
        try {
          channelAdapter.close();
        } catch (Exception e1) { //Ignored so the original exception will be thrown
        }
        throw e;
      }
    }
    
    /** Create a new FSIndexInput, representing a slice of an existing open <code>file</code> */
    protected JDK7FSIndexInput(String resourceDesc, ChannelAdapter<T> channelAdapter, long off, long length, int bufferSize, int chunkSize) {
      super(resourceDesc, bufferSize);
      this.channelAdapter = channelAdapter;
      this.chunkSize = chunkSize;
      this.off = off;
      this.end = off + length;
      this.isClone = true; // well, we are sorta?
    }
    
    @Override
    public void close() throws IOException {
      // only close the file if this is not a clone
      if (!isClone) {
        channelAdapter.close();
      }
    }
    
    @Override
    public JDK7FSIndexInput<T> clone() {
      @SuppressWarnings("unchecked")
      JDK7FSIndexInput<T> clone = (JDK7FSIndexInput<T>)super.clone();
      clone.isClone = true;
      return clone;
    }
    
    @Override
    public final long length() {
      return end - off;
    }
    
    /** Method used for testing. Returns true if the underlying
     *  file descriptor is valid.
     */
    boolean isFDValid() throws IOException {
      return channelAdapter.isOpen();
    }
  }
  
  /**
   * Writes output with {@link FileChannel#write(ByteBuffer)}
   */
  protected static class JDK7FSIndexOutput extends BufferedIndexOutput {
    private final JDK7FSDirectory parent;
    private final String name;
    private final FileChannel file;
    private volatile boolean isOpen; // remember if the file is open, so that we don't try to close it more than once
    
    public JDK7FSIndexOutput(JDK7FSDirectory parent, String name) throws IOException {
      this.parent = parent;
      this.name = name;
      file = FileChannel.open(parent.directory.resolve(name), StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE, StandardOpenOption.READ);
      isOpen = true;
    }
    
    /** output methods: */
    @Override
    public void flushBuffer(byte[] b, int offset, int size) throws IOException {
      assert isOpen;
      ByteBuffer bb = ByteBuffer.wrap(b, offset, size);
      while (bb.remaining() > 0) {
        file.write(bb);
      }
    }
    
    @Override
    public void close() throws IOException {
      parent.onIndexOutputClosed(name);
      // only close the file if it has not been closed yet
      if (isOpen) {
        boolean success = false;
        try {
          super.close();
          success = true;
        } finally {
          isOpen = false;
          if (!success) {
            try {
              file.close();
            } catch (Throwable t) {
              // Suppress so we don't mask original exception
            }
          } else {
            file.close();
          }
        }
      }
    }
    
    /** Random-access methods */
    @Override
    public void seek(long pos) throws IOException {
      super.seek(pos);
      file.position(pos);
    }
    
    @Override
    public long length() throws IOException {
      return file.size();
    }
    
    @Override
    public void setLength(long length) throws IOException {
      file.truncate(length);
    }
  }
  
  protected void fsync(String name) throws IOException {
    Path fullFile = directory.resolve(name);
    boolean success = false;
    int retryCount = 0;
    IOException exc = null;
    while (!success && retryCount < 5) {
      retryCount++;
      FileChannel file = null;
      try {
        try {
          file = FileChannel.open(fullFile, StandardOpenOption.READ, StandardOpenOption.WRITE);
          file.force(true);
          success = true;
        } finally {
          if (file != null)
            file.close();
        }
      } catch (IOException ioe) {
        if (exc == null)
          exc = ioe;
        try {
          // Pause 5 msec
          Thread.sleep(5);
        } catch (InterruptedException ie) {
          throw new ThreadInterruptedException(ie);
        }
      }
    }
    if (!success)
      // Throw original exception
      throw exc;
  }
  
  /**
   * Abstracts a channel for the various subclasses of JDK7FSIndexInput 
   * since FileChannel and AsynchronousFileChannel do not share an interface.
   */
  protected static interface ChannelAdapter<T extends Channel> extends Closeable {
    public T getChannel();
    public long getSize() throws IOException;
    public boolean isOpen() throws IOException;
  }
}
