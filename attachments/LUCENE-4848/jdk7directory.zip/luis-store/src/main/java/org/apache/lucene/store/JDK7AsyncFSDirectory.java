package org.apache.lucene.store;

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousFileChannel;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.FileAttribute;
import java.util.EnumSet;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * An implementation of Directory supported by a NIO2 AsynchronousFileChannel.
 * 
 * This implementation operates entirely synchronously, but uses an 
 * AsynchronousFileChannel as it's underlying access method to avoid
 * synchronization on position on Windows platforms, as well as closing
 * the channel on thread interruption.
 * 
 */
public class JDK7AsyncFSDirectory extends JDK7FSDirectory {
  
  /**
   * The default thread pool used for asynchronous I/O completion notifications.
   */
  public static final ExecutorService DEFAULT_EXECUTOR_SERVICE = createDefaultThreadPool();
  
  static final ExecutorService createDefaultThreadPool() {
    return new ThreadPoolExecutor(
        1,                                    //Core Threads 
        1,                                    //Max Threads
        0L, TimeUnit.MILLISECONDS,            //Keep alive time
        new LinkedBlockingQueue<Runnable>(),
        new ThreadFactory() {                 
          @Override
          public Thread newThread(Runnable r) {
            Thread t = new Thread(r);
            t.setName("JDK7AsyncFSDirectory-IOCompletionThread");
            t.setDaemon(true);
            return t;
          }
        });
  }
  
  private static final FileAttribute<?>[] NO_ATTRIBUTES = new FileAttribute[0];
  
  private final ExecutorService executor;
  
  /** Create a new JDK7AsyncFSDirectory for the named location.
   *
   * @param path the path of the directory
   * @param lockFactory the lock factory to use, or null for the default
   * ({@link NativeFSLockFactory});
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7AsyncFSDirectory(Path path, LockFactory lockFactory, ExecutorService executor) throws IOException {
    super(path, lockFactory);
    this.executor = executor;
  }
  
  /** Create a new JDK7AsyncFSDirectory for the named location.
   *
   * @param path the path of the directory
   * @param lockFactory the lock factory to use, or null for the default
   * ({@link NativeFSLockFactory});
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7AsyncFSDirectory(Path path, LockFactory lockFactory) throws IOException {
    this(path, lockFactory, DEFAULT_EXECUTOR_SERVICE);
  }
  
  /** Create a new JDK7AsyncFSDirectory for the named location and {@link NativeFSLockFactory}.
   *
   * @param path the path of the directory
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7AsyncFSDirectory(Path path) throws IOException {
    this(path, null, DEFAULT_EXECUTOR_SERVICE);
  }
  
  /** Create a new JDK7AsyncFSDirectory for the named location.
   *
   * @param path the path of the directory
   * @param lockFactory the lock factory to use, or null for the default
   * ({@link NativeFSLockFactory});
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7AsyncFSDirectory(File path, LockFactory lockFactory, ExecutorService executor) throws IOException {
    this(path.toPath(), lockFactory, executor);
  }
  
  /** Create a new JDK7AsyncFSDirectory for the named location.
   *
   * @param path the path of the directory
   * @param lockFactory the lock factory to use, or null for the default
   * ({@link NativeFSLockFactory});
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7AsyncFSDirectory(File path, LockFactory lockFactory) throws IOException {
    this(path.toPath(), lockFactory);
  }
  
  /** Create a new JDK7AsyncFSDirectory for the named location and {@link NativeFSLockFactory}.
   *
   * @param path the path of the directory
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7AsyncFSDirectory(File path) throws IOException {
    this(path.toPath(), null);
  }
  
  @Override
  public IndexOutput createOutput(String name, IOContext context)
      throws IOException {
    ensureOpen();
    
    ensureCanWrite(name);
    return new JDK7AsyncFSIndexOutput(this, name);
  }
  
  /** Creates an IndexInput for the file with the given name. */
  @Override
  public IndexInput openInput(String name, IOContext context) throws IOException {
    ensureOpen();
    final Path path = directory.resolve(name);
    return new JDK7AsyncFSIndexInput(path, context, getReadChunkSize());
  }
  
  @Override
  public IndexInputSlicer createSlicer(final String name,
      final IOContext context) throws IOException {
    ensureOpen();
    final Path path = getDirectory().resolve(name);
    final AsynchronousFileChannel channel = AsynchronousFileChannel.open(
        path, 
        EnumSet.of(StandardOpenOption.READ), 
        executor, 
        NO_ATTRIBUTES);
    return new IndexInputSlicer() {
      
      @Override
      public void close() throws IOException {
        channel.close();
      }
      
      @Override
      public IndexInput openSlice(String sliceDescription, long offset, long length) {
        return new JDK7AsyncFSIndexInput(sliceDescription, path, channel, offset,
            length, BufferedIndexInput.bufferSize(context), getReadChunkSize());
      }
      
      @Override
      public IndexInput openFullSlice() {
        try {
          return openSlice("full-slice", 0, channel.size());
        } catch (IOException ex) {
          throw new RuntimeException(ex);
        }
      }
    };
  }
  
  /**
   * Writes output with {@link AsynchronousFileChannel#write(ByteBuffer, long)}
   */
  protected static class JDK7AsyncFSIndexOutput extends BufferedIndexOutput {
    private final JDK7AsyncFSDirectory parent;
    private final String name;
    private final AsynchronousFileChannel file;
    private long fpos = 0;
    
    private volatile boolean isOpen; // remember if the file is open, so that we don't try to close it more than once
    
    public JDK7AsyncFSIndexOutput(JDK7AsyncFSDirectory parent, String name) throws IOException {
      this.parent = parent;
      this.name = name;
      file = AsynchronousFileChannel.open(
          parent.directory.resolve(name), 
          EnumSet.of(StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE, StandardOpenOption.READ),
          parent.executor,
          NO_ATTRIBUTES);
      isOpen = true;
    }
    
    /** output methods: */
    @Override
    public void flushBuffer(byte[] b, int offset, int size) throws IOException {
      assert isOpen;
      if (size == 0) {
        return; //Avoid creating a ByteBuffer if we don't need to. 
      }
      
      ByteBuffer bb = ByteBuffer.wrap(b, offset, size);
      boolean interrupted = false;
      try {
        while (bb.remaining() > 0) {
          try {
            int written = file.write(bb, fpos).get();
            fpos += written;
          } catch (ExecutionException ee) {
            throw new IOException(ee.getCause());
          } catch (InterruptedException ie) {
            interrupted = true;
          }
        }
      } finally {
        if (interrupted)
          Thread.currentThread().interrupt();
      }
    }
    
    @Override
    public void close() throws IOException {
      parent.onIndexOutputClosed(name);
      // only close the file if it has not been closed yet
      if (isOpen) {
        boolean success = false;
        try {
          super.close();
          success = true;
        } finally {
          isOpen = false;
          if (!success) {
            try {
              file.close();
            } catch (Throwable t) {
              // Suppress so we don't mask original exception
            }
          } else {
            file.close();
          }
        }
      }
    }
    
    /** Random-access methods */
    @Override
    public void seek(long pos) throws IOException {
      super.seek(pos);
      fpos = pos;
    }
    
    @Override
    public long length() throws IOException {
      return file.size();
    }
    
    @Override
    public void setLength(long length) throws IOException {
      file.truncate(length);
    }
  }
  /**
   * Reads bytes with {@link RandomAccessFile#seek(long)} followed by
   * {@link RandomAccessFile#read(byte[], int, int)}.  
   */
  protected class JDK7AsyncFSIndexInput extends JDK7FSIndexInput<AsynchronousFileChannel> {
    
    private ByteBuffer byteBuf; // wraps the buffer for NIO
    
    public JDK7AsyncFSIndexInput(Path path, IOContext context, int chunkSize) throws IOException {
      super("JDK7AsyncFSIndexInput(path=\"" + path + "\")", new AsyncFileChannelAdapter(
          AsynchronousFileChannel.open(path, EnumSet.of(StandardOpenOption.READ), executor, NO_ATTRIBUTES)), context, chunkSize);
    }
    
    public JDK7AsyncFSIndexInput(String sliceDescription, Path path, AsynchronousFileChannel fc, long off, long length, int bufferSize, int chunkSize) {
      super("JDK7AsyncFSIndexInput(" + sliceDescription + " in path=\"" + path + "\" slice=" + off + ":" + (off+length) + ")", new AsyncFileChannelAdapter(fc), off, length, bufferSize, chunkSize);
      isClone = true;
    }
    
    @Override
    protected void newBuffer(byte[] newBuffer) {
      super.newBuffer(newBuffer);
      byteBuf = ByteBuffer.wrap(newBuffer);
    }
    
    @Override
    protected void readInternal(byte[] b, int offset, int len) throws IOException {
      
      final ByteBuffer bb;
      
      // Determine the ByteBuffer we should use
      if (b == buffer && 0 == offset) {
        // Use our own pre-wrapped byteBuf:
        assert byteBuf != null;
        byteBuf.clear();
        byteBuf.limit(len);
        bb = byteBuf;
      } else {
        bb = ByteBuffer.wrap(b, offset, len);
      }
      
      int readOffset = bb.position();
      int readLength = bb.limit() - readOffset;
      assert readLength == len;
      
      long pos = getFilePointer() + off;
      
      if (pos + len > end) {
        throw new EOFException("read past EOF: " + this);
      }
      
      AsynchronousFileChannel fc = channelAdapter.getChannel();
      try {
        boolean interrupted = false;
        try {
          while (readLength > 0) {
            final int limit;
            if (readLength > chunkSize) {
              // LUCENE-1566 - work around JVM Bug by breaking
              // very large reads into chunks
              limit = readOffset + chunkSize;
            } else {
              limit = readOffset + readLength;
            }
            bb.limit(limit);
            Future<Integer> future = fc.read(bb, pos);
            
            //We have to read in a loop here since future.get() could
            //throw InterruptedException.
            while (true) {
              try {
                int i = future.get();
                if (i < 0) {
                  throw new EOFException("Attempt to read past end of file");
                }
                pos += i;
                readOffset += i;
                readLength -= i;
                break;
              } catch (ExecutionException ee) {
                throw new IOException(ee.getCause());
              } catch (InterruptedException ie) {
                interrupted = true;
              }
            }
          }
        } finally {
          if (interrupted) {
            Thread.currentThread().interrupt();
          }
        }
      } catch (OutOfMemoryError e) {
        // propagate OOM up and add a hint for 32bit VM Users hitting the bug
        // with a large chunk size in the fast path.
        final OutOfMemoryError outOfMemoryError = new OutOfMemoryError(
            "OutOfMemoryError likely caused by the Sun VM Bug described in "
                + "https://issues.apache.org/jira/browse/LUCENE-1566; try calling FSDirectory.setReadChunkSize "
                + "with a value smaller than the current chunk size (" + chunkSize + ")");
        outOfMemoryError.initCause(e);
        throw outOfMemoryError;
      } catch (IOException ioe) {
        throw new IOException(ioe.getMessage() + ": " + this, ioe);
      }
    }
    
    @Override
    protected void seekInternal(long pos) throws IOException {}
  }
  
  private static class AsyncFileChannelAdapter implements ChannelAdapter<AsynchronousFileChannel> {
    private final AsynchronousFileChannel channel;
    
    public AsyncFileChannelAdapter(AsynchronousFileChannel channel) {
      super();
      this.channel = channel;
    }
    
    @Override
    public void close() throws IOException {
      channel.close();
    }
    
    @Override
    public AsynchronousFileChannel getChannel() {
      return channel;
    }
    
    @Override
    public long getSize() throws IOException {
      return channel.size();
    }
    
    @Override
    public boolean isOpen() throws IOException {
      return channel.isOpen();
    }
  }
}
