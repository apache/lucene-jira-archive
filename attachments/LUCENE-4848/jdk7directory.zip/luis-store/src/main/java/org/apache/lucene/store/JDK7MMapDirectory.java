package org.apache.lucene.store;

/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;

import org.apache.lucene.util.Constants;

/**
 * Copy of {@link MMapDirectory} that uses JDK7 API's to 
 * open file channels so that the files will be opened with
 * FILE_SHARE_DELETE on windows.
 * 
 * See {@link MMapDirectory} for a full description of the usage
 * restrictions and limitations of this class.
 * 
 * There is one major behavioral change between this class and 
 * {@link MMapDirectory}.  {@link MMapDirectory} is safe to 
 * use on an interrupted thread for writes (but not for reads).
 * This class is safe for neither:  If accessed from an interrupted
 * thread, the underlying channel will be closed and all future 
 * operations will throw an exception.
 *
 */
public class JDK7MMapDirectory extends JDK7FSDirectory {
  private boolean useUnmapHack = UNMAP_SUPPORTED;
  /** 
   * Default max chunk size.
   * @see #JDK7MMapDirectory(Path, LockFactory, int)
   */
  public static final int DEFAULT_MAX_BUFF = Constants.JRE_IS_64BIT ? (1 << 30) : (1 << 28);
  final int chunkSizePower;
  
  /** Create a new JDK7MMapDirectory for the named location.
   *
   * @param path the path of the directory
   * @param lockFactory the lock factory to use, or null for the default
   * ({@link NativeFSLockFactory});
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7MMapDirectory(Path path, LockFactory lockFactory) throws IOException {
    this(path, lockFactory, DEFAULT_MAX_BUFF);
  }
  
  /** Create a new JDK7MMapDirectory for the named location and {@link NativeFSLockFactory}.
   *
   * @param path the path of the directory
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7MMapDirectory(Path path) throws IOException {
    this(path, null);
  }
  
  /**
   * Create a new JDK7MMapDirectory for the named location, specifying the 
   * maximum chunk size used for memory mapping.
   * 
   * @param path the path of the directory
   * @param lockFactory the lock factory to use, or null for the default
   * ({@link NativeFSLockFactory});
   * @param maxChunkSize maximum chunk size (default is 1 GiBytes for
   * 64 bit JVMs and 256 MiBytes for 32 bit JVMs) used for memory mapping.
   * <p>
   * Especially on 32 bit platform, the address space can be very fragmented,
   * so large index files cannot be mapped. Using a lower chunk size makes 
   * the directory implementation a little bit slower (as the correct chunk 
   * may be resolved on lots of seeks) but the chance is higher that mmap 
   * does not fail. On 64 bit Java platforms, this parameter should always 
   * be {@code 1 << 30}, as the address space is big enough.
   * <p>
   * <b>Please note:</b> The chunk size is always rounded down to a power of 2.
   * @throws IOException if there is a low-level I/O error
   */
  public JDK7MMapDirectory(Path path, LockFactory lockFactory, int maxChunkSize) throws IOException {
    super(path, lockFactory);
    if (maxChunkSize <= 0) {
      throw new IllegalArgumentException("Maximum chunk size for mmap must be >0");
    }
    this.chunkSizePower = 31 - Integer.numberOfLeadingZeros(maxChunkSize);
    assert this.chunkSizePower >= 0 && this.chunkSizePower <= 30;
  }
  
  /** Create a new JDK7MMapDirectory for the named location.
  *
  * @param path the path of the directory
  * @param lockFactory the lock factory to use, or null for the default
  * ({@link NativeFSLockFactory});
  * @throws IOException if there is a low-level I/O error
  */
 public JDK7MMapDirectory(File path, LockFactory lockFactory) throws IOException {
   this(path.toPath(), lockFactory, DEFAULT_MAX_BUFF);
 }
 
 /** Create a new JDK7MMapDirectory for the named location and {@link NativeFSLockFactory}.
  *
  * @param path the path of the directory
  * @throws IOException if there is a low-level I/O error
  */
 public JDK7MMapDirectory(File path) throws IOException {
   this(path.toPath(), null);
 }
 
 /**
  * Create a new JDK7MMapDirectory for the named location, specifying the 
  * maximum chunk size used for memory mapping.
  * 
  * @param path the path of the directory
  * @param lockFactory the lock factory to use, or null for the default
  * ({@link NativeFSLockFactory});
  * @param maxChunkSize maximum chunk size (default is 1 GiBytes for
  * 64 bit JVMs and 256 MiBytes for 32 bit JVMs) used for memory mapping.
  * <p>
  * Especially on 32 bit platform, the address space can be very fragmented,
  * so large index files cannot be mapped. Using a lower chunk size makes 
  * the directory implementation a little bit slower (as the correct chunk 
  * may be resolved on lots of seeks) but the chance is higher that mmap 
  * does not fail. On 64 bit Java platforms, this parameter should always 
  * be {@code 1 << 30}, as the address space is big enough.
  * <p>
  * <b>Please note:</b> The chunk size is always rounded down to a power of 2.
  * @throws IOException if there is a low-level I/O error
  */
 public JDK7MMapDirectory(File path, LockFactory lockFactory, int maxChunkSize) throws IOException {
   this(path.toPath(), lockFactory, maxChunkSize);
 }
  
  /**
   * <code>true</code>, if this platform supports unmapping mmapped files.
   */
  public static final boolean UNMAP_SUPPORTED;
  static {
    boolean v;
    try {
      Class.forName("sun.misc.Cleaner");
      Class.forName("java.nio.DirectByteBuffer")
      .getMethod("cleaner");
      v = true;
    } catch (Exception e) {
      v = false;
    }
    UNMAP_SUPPORTED = v;
  }
  
  /**
   * This method enables the workaround for unmapping the buffers
   * from address space after closing {@link IndexInput}, that is
   * mentioned in the bug report. This hack may fail on non-Sun JVMs.
   * It forcefully unmaps the buffer on close by using
   * an undocumented internal cleanup functionality.
   * <p><b>NOTE:</b> Enabling this is completely unsupported
   * by Java and may lead to JVM crashes if <code>IndexInput</code>
   * is closed while another thread is still accessing it (SIGSEGV).
   * @throws IllegalArgumentException if {@link #UNMAP_SUPPORTED}
   * is <code>false</code> and the workaround cannot be enabled.
   */
  public void setUseUnmap(final boolean useUnmapHack) {
    if (useUnmapHack && !UNMAP_SUPPORTED)
      throw new IllegalArgumentException("Unmap hack not supported on this platform!");
    this.useUnmapHack=useUnmapHack;
  }
  
  /**
   * Returns <code>true</code>, if the unmap workaround is enabled.
   * @see #setUseUnmap
   */
  public boolean getUseUnmap() {
    return useUnmapHack;
  }
  
  /**
   * Returns the current mmap chunk size.
   * @see #JDK7MMapDirectory(Path, LockFactory, int)
   */
  public final int getMaxChunkSize() {
    return 1 << chunkSizePower;
  }
  
  /** Creates an IndexInput for the file with the given name. */
  @Override
  public IndexInput openInput(String name, IOContext context) throws IOException {
    ensureOpen();
    Path f = getDirectory().resolve(name);
    try(FileChannel ch = FileChannel.open(f, StandardOpenOption.READ)) {
      return new MMapIndexInput("MMapIndexInput(path=\"" + f + "\")", ch);
    }
  }
  
  @Override
  public IndexInputSlicer createSlicer(String name, IOContext context) throws IOException {
    final MMapIndexInput full = (MMapIndexInput) openInput(name, context);
    return new IndexInputSlicer() {
      @Override
      public IndexInput openSlice(String sliceDescription, long offset, long length) throws IOException {
        ensureOpen();
        return full.slice(sliceDescription, offset, length);
      }
      
      @Override
      public IndexInput openFullSlice() throws IOException {
        ensureOpen();
        return full.clone();
      }
      
      @Override
      public void close() throws IOException {
        full.close();
      }
    };
  }
  
  private final class MMapIndexInput extends ByteBufferIndexInput {
    private final boolean useUnmapHack;
    
    MMapIndexInput(String resourceDescription, FileChannel ch) throws IOException {
      super(resourceDescription, map(ch, 0, ch.size()), ch.size(), chunkSizePower, getUseUnmap());
      this.useUnmapHack = getUseUnmap();
    }
    
    /**
     * Try to unmap the buffer, this method silently fails if no support
     * for that in the JVM. On Windows, this leads to the fact,
     * that mmapped files cannot be modified or deleted.
     */
    @Override
    protected void freeBuffer(final ByteBuffer buffer) throws IOException {
      if (useUnmapHack) {
        try {
          AccessController.doPrivileged(new PrivilegedExceptionAction<Void>() {
            @Override
            public Void run() throws Exception {
              final Method getCleanerMethod = buffer.getClass()
                .getMethod("cleaner");
              getCleanerMethod.setAccessible(true);
              final Object cleaner = getCleanerMethod.invoke(buffer);
              if (cleaner != null) {
                cleaner.getClass().getMethod("clean")
                  .invoke(cleaner);
              }
              return null;
            }
          });
        } catch (PrivilegedActionException e) {
          final IOException ioe = new IOException("unable to unmap the mapped buffer");
          ioe.initCause(e.getCause());
          throw ioe;
        }
      }
    }
  }
  
  /** Maps a file into a set of buffers */
  ByteBuffer[] map(FileChannel ch, long offset, long length) throws IOException {
    if ((length >>> chunkSizePower) >= Integer.MAX_VALUE)
      throw new IllegalArgumentException("Path too big for chunk size");
    
    final long chunkSize = 1L << chunkSizePower;
    
    // we always allocate one more buffer, the last one may be a 0 byte one
    final int nrBuffers = (int) (length >>> chunkSizePower) + 1;
    
    ByteBuffer buffers[] = new ByteBuffer[nrBuffers];
    
    long bufferStart = 0L;
    for (int bufNr = 0; bufNr < nrBuffers; bufNr++) { 
      int bufSize = (int) ( (length > (bufferStart + chunkSize))
          ? chunkSize
              : (length - bufferStart)
          );
      buffers[bufNr] = ch.map(MapMode.READ_ONLY, offset + bufferStart, bufSize);
      bufferStart += bufSize;
    }
    
    return buffers;
  }
}
