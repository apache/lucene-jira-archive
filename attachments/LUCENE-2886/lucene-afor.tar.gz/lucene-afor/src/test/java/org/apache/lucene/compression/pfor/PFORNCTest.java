/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.pfor;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Random;

import org.apache.lucene.compression.CodecTest;
import org.apache.lucene.compression.afor.ForIndexInput;
import org.apache.lucene.compression.afor.ForIndexOutput;
import org.apache.lucene.index.codecs.sep.IntIndexInput.Reader;
import org.apache.lucene.store.RAMDirectory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class PFORNCTest extends CodecTest {

  /**
   * @throws java.lang.Exception
   */
  @Before
  public void setUp()
  throws Exception {}

  /**
   * @throws java.lang.Exception
   */
  @After
  public void tearDown()
  throws Exception {}

  @Override
  public void doTest(final int[] values, final int blockSize) throws IOException {
    final RAMDirectory dir = new RAMDirectory();
    final String filename = PFORNC.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, blockSize, new PFORNC());

    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, blockSize, new PFORNC());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();
  }

  @Test
  public void testIntegerRange() throws IOException {
    this.doTestIntegerRange(1, 31, new int[] {32, 256, 2048});
  }

  @Test
  public void testPFOR() throws IOException {
    final RAMDirectory dir = new RAMDirectory();
    final String filename = PFORNC.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, 32, new PFORNC());

    final int[] values = {0,1,0,0,1,16,2,4,1,1,2,32,0,1,1,0,
                          33,1,0,1,0,1,2,2,1,2,8,8,1,3,2,3};
    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, 32, new PFORNC());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();

  }

  @Test
  public void testPFORWithException() throws IOException {
    final RAMDirectory dir = new RAMDirectory();
    final String filename = PFORNC.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, 32, new PFORNC());

    final int[] values = {32,1,0,0,1,1,1,1,1,1,1,1,0,1,1,0,
                          1,1,0,1,0,1,1,1,1,2,1,1,1,1,1,1};
    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, 32, new PFORNC());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();

  }

  @Test
  public void testPFORWithExceptionAtFirstPosition() throws IOException {
    final RAMDirectory dir = new RAMDirectory();
    final String filename = PFORNC.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, 32, new PFORNC());

    final int[] values = {32,1,0,0,1,1,1,1,1,1,1,1,0,1,1,0,
                          1,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1,
                          0,1,0,0,1,1,1,1,1,1,1,1,0,1,1,0,
                          1,1,0,1,0,1,1,1,1,1,1,1,1,1,1,1};
    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, 32, new PFORNC());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();

  }

  @Test
  public void testPFORWithFewExceptions() throws IOException {
    final RAMDirectory dir = new RAMDirectory();
    final String filename = PFORNC.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, 1024, new PFORNC());

    final int[] values = new int[1024];
    for (int i = 0; i < 1024; i++) {
      values[i] = 1;
    }
    final Random r = new Random();
    for (int i = 0; i < 9; i++) {
      values[r.nextInt(1024)] = 1112;
    }

    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, 1024, new PFORNC());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();

  }

  @Test
  public void testPFORWithFirstExceptionAfter256() throws IOException {
    final RAMDirectory dir = new RAMDirectory();
    final String filename = PFORNC.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, 1024, new PFORNC());

    final int[] values = new int[1024];
    for (int i = 0; i < 1024; i++) {
      values[i] = 1;
    }
    values[514] = 105154;

    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, 1024, new PFORNC());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();

  }

}
