/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.afor;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

import org.apache.lucene.compression.CodecTest;
import org.apache.lucene.index.codecs.sep.IntIndexInput.Reader;
import org.apache.lucene.store.RAMDirectory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AFOR2Test extends CodecTest {

  /**
   * @throws java.lang.Exception
   */
  @Before
  public void setUp()
  throws Exception {}

  /**
   * @throws java.lang.Exception
   */
  @After
  public void tearDown()
  throws Exception {}

  @Test
  public void testNonHomogenDistrib() throws IOException {
    final int blockSize = 1024;
    final RAMDirectory dir = new RAMDirectory();
    final String filename = AFOR2.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, blockSize, new AFOR2());
    final int[] values = new int[10240];
    final Random r = new Random(2012);

    for (int i = 0; i < 10240; i += 32) {
      Arrays.fill(values, i, i + 32, r.nextInt(6));
      values[i + r.nextInt(32)] = (int) (Math.random() * 100000);
    }

    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, blockSize, new AFOR2());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();
  }

  @Test
  public void testDouble16Config() throws IOException {
    final int blockSize = 64;
    final RAMDirectory dir = new RAMDirectory();
    final String filename = AFOR2.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, blockSize, new AFOR2());
    final int[] values = { 0, 0, 0, 0, 0, 0, 32, 0, 0, 421, 0, 0, 0, 0, 0, 0,
                           0, 0, 422, 0, 0, 22, 0, 0, 0, 479, 0, 0, 0, 0, 12, 0,
                           0, 0, 0, 0, 0, 0, -32, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                           1, 0, 0, 0, 0, 0, 0, 0, 0, 44779, 0, 0, 0, 0, 0, 0};

    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, blockSize, new AFOR2());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();
  }

  @Test
  public void test32Config() throws IOException {
    final int blockSize = 32;
    final RAMDirectory dir = new RAMDirectory();
    final String filename = AFOR2.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, blockSize, new AFOR2());
    final int[] values = { 0, 0, 0, 0, 0, 0, 44779, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                           0, 0, 0, 0, 0, 0, 0, 0, 0, 44779, 0, 0, 0, 0, 0, 0};

    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, blockSize, new AFOR2());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();
  }

  @Override
  public void doTest(final int[] values, final int blockSize) throws IOException {
    final RAMDirectory dir = new RAMDirectory();
    final String filename = AFOR2.class.toString();
    final ForIndexOutput output = new ForIndexOutput(dir, filename, blockSize, new AFOR2());

    for (final int element : values) {
      output.write(element);
    }
    output.close();

    final ForIndexInput input = new ForIndexInput(dir, filename, blockSize, new AFOR2());
    final Reader reader = input.reader();
    for (int i = 0; i < values.length; i++) {
      assertEquals("Error at record " + i, values[i], reader.next());
    }
    input.close();
    dir.close();
  }

  @Test
  public void testIntegerRange32() throws IOException {
		this.doTestIntegerRange(1, 32);
  }

}
