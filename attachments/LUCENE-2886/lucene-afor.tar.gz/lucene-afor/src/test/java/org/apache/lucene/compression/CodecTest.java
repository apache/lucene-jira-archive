/**
 * @project siren [0.3-1458]
 * @author Renaud Delbru [ 21 Feb 2010 ]
 * @link http://renaud.delbru.fr/
 * @copyright Copyright (C) 2009 by Renaud Delbru, All rights reserved.
 */
package org.apache.lucene.compression;

import java.io.IOException;

import org.apache.commons.math.random.RandomDataImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

public abstract class CodecTest {

  private static final int LIST_SIZE = 32768;

  /**
   * The different block sizes to test
   */
  protected static final int[] BLOCK_SIZES = {32, 256, 512, 2048};

  protected static final Logger logger = LoggerFactory.getLogger(CodecTest.class);

  public void doTestIntegerRange(final int minBits, final int maxBits, final int[] blockSizes) throws IOException {
    final int[] input = new int[LIST_SIZE];

    for (int i = minBits; i <= maxBits; i++) {
      final RandomDataImpl r = new RandomDataImpl();
      r.reSeed(42);

      final long min = i == 1 ? 0 : (1L << (i - 1));
      final long max = ((1L << i) - 1);

      for (int j = 0; j < LIST_SIZE; j++) {
        input[j] = (int) r.nextLong(min, max);
      }

      for (final int blockSize : blockSizes) {
        logger.debug("Perform Integer Range Test: bits = {}, block size = {}",
          new Object[]{i, blockSize});
        this.doTest(input, blockSize);
      }
    }
  }

  public void doTestIntegerRange(final int minBits, final int maxBits) throws IOException {
    this.doTestIntegerRange(minBits, maxBits, BLOCK_SIZES);
  }

  protected abstract void doTest(int[] input, int blockSize) throws IOException;

}
