/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.pfor;

import static org.junit.Assert.assertEquals;

import java.io.IOException;

import org.apache.lucene.compression.CodecTest;
import org.apache.lucene.compression.afor.ForIndexInput;
import org.apache.lucene.compression.afor.ForIndexOutput;
import org.apache.lucene.index.codecs.sep.IntIndexInput.Reader;
import org.apache.lucene.store.RAMDirectory;
import org.junit.Test;


public class FORTest extends CodecTest {

	  @Override
	  public void doTest(final int[] values, final int blockSize) throws IOException {
	    final RAMDirectory dir = new RAMDirectory();
	    final String filename = FOR.class.toString();
	    final ForIndexOutput output = new ForIndexOutput(dir, filename, blockSize, new FOR());

	    for (final int element : values) {
	      output.write(element);
	    }
	    output.close();

	    final ForIndexInput input = new ForIndexInput(dir, filename, blockSize, new FOR());
	    final Reader reader = input.reader();
	    for (int i = 0; i < values.length; i++) {
	      assertEquals("Error at record " + i, values[i], reader.next());
	    }
	    input.close();
	    dir.close();
	  }

	  @Test
	  public void testIntegerRange32() throws IOException {
			this.doTestIntegerRange(1, 32);
	  }

}
