package org.apache.lucene.compression.afor;

/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/** Naive int block API that writes vInts.  This is
 *  expected to give poor performance; it's really only for
 *  testing the pluggability.  One should typically use pfor instead. */

import java.io.IOException;
import java.nio.ByteBuffer;

import org.apache.lucene.compression.ObservableIntBlockIndexInput;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.util.CodecUtil;

/**
 * Encode a fixed size block of integer using "Frame of Reference".
 **/
public class ForIndexInput extends ObservableIntBlockIndexInput {

  final AbstractFrameOfRef codec;

  public ForIndexInput(final Directory dir, final String fileName,
                       final int readBufferSize, final AbstractFrameOfRef codec)
  throws IOException {
    final IndexInput in = dir.openInput(fileName, readBufferSize);
    CodecUtil.checkHeader(in, ForIndexOutput.CODEC, ForIndexOutput.VERSION_START);
    this.codec = codec;
    this.init(in);
  }

  private static class BlockReader extends ObservableBlockReader {

    private final IndexInput in;
    private final int[] buffer;
    private final AbstractFrameOfRef decompressor;
    private final byte[] input;

    public BlockReader(final IndexInput in, final int[] buffer,
                       final int blockSize, final AbstractFrameOfRef codec) {
      super();
      this.in = in;
      this.buffer = buffer;
      decompressor = codec;
      final ByteBuffer byteBuffer = ByteBuffer.allocate(codec.getByteBufferSize(blockSize));
      input = byteBuffer.array();
      decompressor.setCompressedBuffer(byteBuffer);
    }

    public void readBlock() throws IOException {
      final int numBytes = in.readVInt();
      in.readBytes(input, 0, numBytes);
      decompressor.setUnCompressedData(buffer, 0, buffer.length);
      decompressor.decompress();
      this.notifyObserver(numBytes);
    }
  }

  @Override
  protected BlockReader getBlockReader(final IndexInput in, final int[] buffer) {
    AbstractFrameOfRef clone = null;
    try {
      clone = codec.getClass().newInstance();
    } catch (final Exception e) {
      throw new RuntimeException(e);
    }
    return new BlockReader(in, buffer, blockSize, clone);
  }
}

