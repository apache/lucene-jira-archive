/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.util;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

import org.apache.lucene.compression.afor.AFOR1;
import org.apache.lucene.compression.afor.AbstractFrameOfRef;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.store.IndexInput;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IntBlockDebugger {

  private Directory dir;
  private IndexInput input;
  private int blockSize;
  private AbstractFrameOfRef codec;

  private int blockIndex = 0;
  private int[] unCompressedData;
  private ByteBuffer buffer;
  private int numBytes;

  final Logger logger = LoggerFactory.getLogger(IntBlockDebugger.class);

  public IntBlockDebugger(final File path, final String filename) throws IOException {
    this.openSegmentFile(path, filename);
  }

  public void close() throws IOException {
    this.input.close();
    this.dir.close();
  }

  public void setDecompressor(final AbstractFrameOfRef codec) {
    this.codec = codec;
  }

  protected void openSegmentFile(final File path, final String filename) throws IOException {
    this.dir = FSDirectory.open(path);
    this.input = dir.openInput(filename, 1024);
    this.skipHeader();
    this.blockSize = input.readVInt();
    this.buffer = ByteBuffer.allocate(blockSize * 4 + blockSize * 5);
    unCompressedData = new int[blockSize];
  }

  public void skipHeader() throws IOException {
    // skip actual header
    input.readInt();
    // skip actual codec
    input.readString();
    // skip actual version
    input.readInt();
  }

  public byte[] skipTo(final int blockIndex) throws IOException {
    byte[] bytes = null;
    while (this.blockIndex < blockIndex) {
      bytes = this.readBlock();
    }
    return bytes;
  }

  public byte[] readBlock() throws IOException {
    numBytes = input.readVInt();
    input.readBytes(buffer.array(), 0, numBytes);
    blockIndex++;
    return buffer.array();
  }

  public int[] decodeBlock(final byte[] block) {
    codec.setCompressedBuffer(buffer);
    codec.setUnCompressedData(unCompressedData, 0, unCompressedData.length);
    codec.decompress();
    return unCompressedData;
  }

  public void displayBlock(final byte[] block) {
    final int[] values = this.decodeBlock(block);
    final StringBuilder builder = new StringBuilder();
    builder.append("[");
    for (final int value : values) {
      builder.append(value);
      builder.append(',');
    }
    builder.setCharAt(builder.length() - 1, ']');
    logger.info("blockIndex = {}, values = {}", blockIndex, builder.toString());
  }

  public void displayBlockInformation(final byte[] block) {
    logger.info("blockIndex = {}, numBytes = {}", blockIndex, numBytes);
  }

  /**
   * @param args
   * @throws IOException
   */
  public static void main(final String[] args) throws IOException {
    final IntBlockDebugger debugger = new IntBlockDebugger(new File(args[0]), args[1]);
    if (args[2].equals("afor")) {
      debugger.setDecompressor(new AFOR1());
    }
    final byte[] block = debugger.skipTo(Integer.parseInt(args[3]));
    debugger.displayBlockInformation(block);
    debugger.displayBlock(block);
    System.exit(0);
  }

}
