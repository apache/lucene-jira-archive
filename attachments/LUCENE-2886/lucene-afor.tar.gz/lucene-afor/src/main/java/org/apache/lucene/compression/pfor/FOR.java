/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.pfor;

import org.apache.lucene.compression.afor.AbstractFrameOfRef;
import org.apache.lucene.compression.afor.FORCompressor;
import org.apache.lucene.compression.afor.FORCompressor.FrameCompressor;
import org.apache.lucene.compression.afor.FORDecompressor;
import org.apache.lucene.compression.afor.FORDecompressor.FrameDecompressor;

/** Frame of Reference lossless integer compression/decompression.
 * For positive integers, the compression is done by leaving out
 * the most significant bits, and storing all numbers with a fixed number of bits
 * contiguously in a buffer of bits. This buffer is called the frame, and it
 * can store positive numbers in a range from 0 to a constant maximum fitting in
 * the number of bits available for a single compressed number.
 * <p>
 * This implementation uses 0 as the lower bound reference for the frame,
 * so small positive integers can be most effectively compressed.
 * <p>
 * Optimized code is used for decompression, see class ForDecompress and its subclasses.
 * <br>Use of the -server option helps performance for the Sun 1.6 jvm under Linux.
 * <p>
 * This class does not provide delta coding because the Lucene index
 * structures already have that.
 * <p>
 * To be done:
 * <ul>
 * <li>
 * Optimize compression code by specializing for number of frame bits.
 * <li>
 * IntBuffer.get() is somewhat faster that IntBuffer.get(index), adapt (de)compression to
 * use the relative get() method.
 * <li>
 * Check javadoc generation and generated javadocs. Add javadoc code references.
 * </ul>
 */
public class FOR extends AbstractFrameOfRef {

  /** Number of frame bits. 2**numFrameBits - 1 is the maximum compressed value. */
  protected int numFrameBits;

  /** Index of header in int buffer */
  protected final int HEADER_INDEX = 0;
  protected int HEADER_SIZE = 1; // one byte in byte array

  /** Start index in byte array integers each compressed to numFrameBits. */
  protected int BLOCK_INDEX = HEADER_INDEX + HEADER_SIZE;

  /** Create a Frame of Reference integer compressor/decompressor. */
  public FOR() {
    super();
  }

  /** As compress(), using the result of frameBitsForCompression() as the number of frame bits. */
  @Override
  public void compress() {
    this.compress(this.frameBitsForCompression());
  }

  protected static final FrameCompressor[] compressors = FORCompressor.compressors;
  protected static final int[] frameSizes = FORCompressor.frameSizes;

  /**
   * Compress the uncompressed data into the byte array using the given number of
   * frame bits, storing only this number of least significant bits of the
   * uncompressed integers in the compressed buffer.
   * Should only be used after setUnCompressedData().
   * <br>
   * A header is stored as a first integer into the buffer, encoding
   * the compression method, the number of frame bits and the number of compressed integers.
   * All uncompressed integers are stored sequentially in compressed form
   * in the buffer after the header.
   *
   * @param numFrameBits        The number of frame bits. Should be between 1 and 32.
   *                            Note that when this value is 32, no compression occurs.
   *
   * TODO: One other implementation might be faster is for loop in inlined within
   * the compressor.
   */
  public void compress(final int numFrameBits) {
    this.numFrameBits = numFrameBits;
    this.encodeHeader();
    final FrameCompressor compressor = FOR.compressors[numFrameBits - 1];
    int outputOffset = BLOCK_INDEX;
    for (int i = 0; i < unComprSize; i += 32) {
      compressor.compress(unCompressedData, i + offset, compressedArray, outputOffset);
      outputOffset += FOR.frameSizes[numFrameBits - 1];
    }
  }

  /** Return the number of bytes used in the byte array.
   *  Only valid after compress() or decompress().
   */
  @Override
  public int compressedSize() {
    return HEADER_SIZE + (unComprSize * numFrameBits) / 8;
  }

  /** The 1 byte header contains:
   *  <ul>
   *  <li>5 bits for (numFrameBits-1),
   *  <li>3 bits unused
   *  </ul>
   */
  private void encodeHeader() {
    compressedArray[HEADER_INDEX] = (byte) ((numFrameBits - 1) << 3);
  }

  protected void decodeHeader() {
    numFrameBits = ((compressedArray[HEADER_INDEX] >>> 3) & 31) + 1;
  }

  /** Decompress from the buffer into output from a given offset. */
  @Override
  public void decompress() {
    this.decodeHeader();
    this.decompressFrame();
  }

  private static final FrameDecompressor[] decompressors = FORDecompressor.decompressors;

  /** For performance, this delegates to classes with fixed numFrameBits. */
  private void decompressFrame() {
    this.index = BLOCK_INDEX;
    int unComprSize = this.unComprSize;
    final int inSkip = numFrameBits * 4;
    final FrameDecompressor dec = FOR.decompressors[numFrameBits - 1];

    while (unComprSize >= 32) {
      dec.decompress(this);
      unComprSize -= 32;
      this.offset += 32;
      this.index += inSkip;
    }
  }

  /** Determine the number of frame bits to be used for compression.
   * Use only after setUnCompressedData().
   * @return The number of bits needed to encode the maximum positive uncompressed value.
   * Negative uncompressed values have no influence on the result.
   */
  public int frameBitsForCompression() {
    int maxNonNegVal = 0;
    for (int i = offset; i < (offset + unComprSize); i++) {
      if (unCompressedData[i] < 0){
        return 32;
      }
      if (unCompressedData[i] > maxNonNegVal) {
        maxNonNegVal = unCompressedData[i];
      }
    }
    return this.logNextHigherPowerOfTwo(maxNonNegVal) + 1;
  }


  @Override
  public int getByteBufferSize(final int blockSize) {
    return (blockSize << 2) + (blockSize >> 5);
  }

}
