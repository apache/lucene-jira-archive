/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.afor;

import java.nio.ByteBuffer;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

/**
 * Abstract class for all the compression algorithms of the Frame Of Reference
 * family, i.e., FOR, AFOR, PFOR.
 */
public abstract class AbstractFrameOfRef {

  /** Number of bytes used in the ByteBuffer */
  protected int compressedSize = 0;
  /** The byte array that backs the buffer */
  protected byte[] compressedArray;
  /** The position in the array */
  protected int index;

  /** Uncompressed data */
  protected int[] unCompressedData;
  /** Offset into unCompressedData */
  protected int offset;
  /** Size of unCompressedData, -1 when not available. */
  protected int unComprSize = -1;

  /** Create a Frame of Reference integer compressor/decompressor. */
  public AbstractFrameOfRef() {
  }

  /** Integer buffer to hold the compressed data.<br>
   *  Compression and decompression do not affect the current buffer position,
   *  and the beginning of the compressed data should be or will be at the current
   *  buffer position.<br>
   *  When the buffer is not large enough, ArrayIndexOutOfBoundExceptions will occur
   *  during compression/decompression.<br>
   *  Without a buffer for compressed data, compress() will only determine the number
   *  of integers needed in the buffer, see compress().<br>
   *  Without a valid buffer, decompress() will throw a NullPointerException.<br>
   *  For optimal speed when the IntBuffer is a view on a ByteBuffer,
   *  the IntBuffer should have a byte offset of a  multiple of 4 bytes, possibly 0. <br>
   *  An IntBuffer is used here because 32 bits can efficiently accessed in the buffer
   *  on all current processors, and a positive int is normally large enough
   *  for various purposes in a Lucene index.
   *
   * @param compressedBuffer    The buffer to hold the compressed integers.
   *
   */
  public void setCompressedBuffer(final ByteBuffer compressedBuffer) {
    this.compressedArray = compressedBuffer.array();
  }

  /** Array with offset holding uncompressed data.
   * @param unCompressedData The array holding uncompressed integers.
   * @param offset offset in unCompressedData.
   * @param unComprSize The number of uncompressed integers, should be at least 1.
   */
  public void setUnCompressedData(final int[] unCompressedData, final int offset, final int unComprSize) {
    this.unCompressedData = unCompressedData;
    this.offset = offset;
    this.unComprSize = unComprSize;
  }

  /**
   * Compress the uncompressed data into the byte array using the given number of
   * frame bits, storing only this number of least significant bits of the
   * uncompressed integers in the compressed buffer.
   * Should only be used after setUnCompressedData().
   * <br>
   * A header is stored as a first integer into the buffer, encoding
   * the compression method, the number of frame bits and the number of compressed integers.
   * All uncompressed integers are stored sequentially in compressed form
   * in the buffer after the header.
   *
   * @param numFrameBits        The number of frame bits. Should be between 1 and 32.
   *                            Note that when this value is 32, no compression occurs.
   *
   * TODO: One other implementation might be faster is for loop in inlined within
   * the compressor.
   */
  public abstract void compress();

  /**
   * Return the number of bytes used in the byte array.
   * Only valid after compress() or decompress().
   */
  public abstract int compressedSize();

  /** Decompress from the buffer into output from a given offset. */
  public abstract void decompress();

  public int getByteBufferSize(final int blockSize) {
    throw new NotImplementedException();
  }

  /** Returns the smallest non negative p such that a given value < (2**(p+1))
   * This differs from (63 - java.lang.Long.numberOfLeadingZeros(v))
   * for non positive given values.
   */
  protected final int logNextHigherPowerOfTwo(long v) {
    int p = 0;
    while (v >= (1 << 8)) {
      v >>= 8;
      p += 8;
    }
    while (v >= (1 << 1)) {
      v >>= 1;
      p++;
    }
    return p;
  }

}
