/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.simple;

import java.io.IOException;
import java.nio.ByteBuffer;

import org.apache.lucene.compression.ObservableIntBlockIndexInput;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.util.CodecUtil;

public class Simple64IndexInput extends ObservableIntBlockIndexInput {

	final Simple64 decomp;

	public Simple64IndexInput(final Directory dir, final String fileName,
			final int readBufferSize, final Simple64 d) throws IOException {
		decomp = d;
		final IndexInput in = dir.openInput(fileName, readBufferSize);
		CodecUtil.checkHeader(in, Simple64IndexOutput.CODEC, Simple64IndexOutput.VERSION_START);
		this.init(in);
	}

	private static class BlockReader extends ObservableBlockReader {
		private final IndexInput in;
		private final int[] buffer;
		private final Simple64 decompressor;
		private final byte[] input;

		public BlockReader(final IndexInput in, final int[] buffer,
				final int blockSize, final Simple64 d) {
			this.in = in;
			this.buffer = buffer;

			decompressor = d;
			final ByteBuffer byteBuffer = ByteBuffer.allocate(blockSize * 8);
			input = byteBuffer.array();
			decompressor.setCompressedBuffer(byteBuffer.asLongBuffer());
		}

		public void readBlock() throws IOException {
			final int numBytes = in.readVInt();
      in.readBytes(input, 0, numBytes);
			decompressor.setUnCompressedData(buffer, 0, buffer.length);
			decompressor.decompress();
			this.notifyObserver(numBytes);
		}
	}

	@Override
	protected BlockReader getBlockReader(final IndexInput in, final int[] buffer) {
    Simple64 clone = null;
    try {
      clone = decomp.getClass().newInstance();
    } catch (final Exception e) {
      throw new RuntimeException(e);
    }
		return new BlockReader(in, buffer, blockSize, clone);
	}

}
