/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.afor;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FORDecompressorGenerator {

  private FileWriter writer;

  public FORDecompressorGenerator() throws IOException {
  }

  public void generate(final File file) throws IOException {
    writer = new FileWriter(file);
    writer.append(FILE_HEADER); writer.append('\n');
    this.generateClass();
    writer.close();
  }

  protected void generateClass() throws IOException {
    writer.append("public class FORDecompressor {\n\n");
    this.generateTable();
    this.generateAbstractInnerClass();
    for (int i = 1; i <= 32; i++) {
      this.generateInnerClass(i);
    }
    writer.append("}\n");
  }

  protected void generateTable() throws IOException {
    writer.append("  public static final FrameDecompressor[] decompressors = new FrameDecompressor[] {\n");
    for (int i = 1; i <= 32; i++) {
      writer.append("    new FrameDecompressor"+i+"()");
      if (i != 32) writer.append(",");
      writer.append('\n');
    }
    writer.append("  };\n\n");
  }

  protected void generateAbstractInnerClass() throws IOException {
    writer.append("  public static abstract class FrameDecompressor {\n");
    writer.append("    public abstract void decompress(final AbstractFrameOfRef frameOfRef);\n");
    writer.append("  }\n\n");
  }

  protected void generateInnerClass(final int numFramebits) throws IOException {
    writer.append("  public static final class FrameDecompressor" + Integer.toString(numFramebits) + " extends FrameDecompressor {\n");
    this.generateMethod(numFramebits);
    writer.append("  }\n\n");
  }

  protected void generateMethod(final int numFrameBits) throws IOException {
    writer.append("    public final void decompress(final AbstractFrameOfRef frameOfRef) {\n");
    this.generateMethodHeader(numFrameBits);
    this.generateInstructions(numFrameBits);
    this.generateMethodFooter(numFrameBits);
    writer.append("    }\n");
  }

  protected void generateMethodHeader(final int numFrameBits) throws IOException {
    writer.append("      ");
    writer.append("final int[] unCompressedData = frameOfRef.unCompressedData;\n");
    writer.append("      ");
    writer.append("final byte[] compressedArray = frameOfRef.compressedArray;\n");
    writer.append("      ");
    writer.append("int inOffset = frameOfRef.index;\n");
    writer.append("      ");
    writer.append("int outOffset = frameOfRef.offset;\n");
    this.generateIntValuesAssignment(numFrameBits);
  }

  protected void generateIntValuesAssignment(final int numFrameBits) throws IOException {
    for (int i = 0, j = 0; i < numFrameBits; i++, j += 4) {
      writer.append("      ");
      writer.append("int i"+i+" = ((compressedArray[inOffset + "+j+"] & 0xFF) << 24) | ");
      writer.append("((compressedArray[inOffset + "+(j+1)+"] & 0xFF) << 16) | ");
      writer.append("((compressedArray[inOffset + "+(j+2)+"] & 0xFF) << 8) | ");
      writer.append("((compressedArray[inOffset + "+(j+3)+"] & 0xFF));\n");
    }
    writer.append("\n");
  }

  protected void generateMethodFooter(final int numFrameBits) throws IOException {
  }

  protected void generateInstructions(final int numFrameBits) throws IOException {
    final int mask = (1 << numFrameBits) - 1;
    int shift = 32;
    int bytePtr = 0, intPtr = 0;

    while (intPtr != 32) { // while we didn't process 32 integers
      while (shift >= numFrameBits) {
        shift -= numFrameBits;
        writer.append("      ");
        if (shift == 0 && mask != 0) {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = i"+bytePtr+" & "+mask+";\n");
        }
        else if (shift == 0 && mask == 0) {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = i"+bytePtr+";\n");
        }
        else if (shift + numFrameBits == 32) {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = (i"+bytePtr+" >>> "+shift+");\n");
        }
        else {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = (i"+bytePtr+" >>> "+shift+") & "+mask+";\n");
        }
        intPtr++;
      }

      if (shift > 0) {
        writer.append("      ");
//        writer.append("unCompressedData[outOffset + "+intPtr+"] = ((i"+bytePtr+" & "+((1 << shift) - 1)+") << "+(numFrameBits - shift)+")");
        writer.append("unCompressedData[outOffset + "+intPtr+"] = ((i"+bytePtr+" << "+(numFrameBits - shift)+")");
        bytePtr++;
        shift = 32 - (numFrameBits - shift);
//         writer.append(" | (i"+bytePtr+" >>> "+shift+") & "+((1 << (32 - shift)) - 1)+";\n");
        writer.append(" | (i"+bytePtr+" >>> "+shift+")) & "+mask+";\n");
        intPtr++;
      }
      else {
        bytePtr++;
        shift = 32;
      }
    }
  }

  private static final String FILE_HEADER = "package org.apache.lucene.compression.afor;\n" +
  "/**\n" +
  " * Copyright 2009, Renaud Delbru\n" +
  " *\n" +
  " * Licensed under the Apache License, Version 2.0 (the \"License\");\n" +
  " * you may not use this file except in compliance with the License.\n" +
  " * You may obtain a copy of the License at\n" +
  " *\n" +
  " *    http://www.apache.org/licenses/LICENSE-2.0\n" +
  " *\n" +
  " * Unless required by applicable law or agreed to in writing,\n" +
  " * software distributed under the License is distributed on an\n" +
  " * \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n" +
  " * KIND, either express or implied.  See the License for the\n" +
  " * specific language governing permissions and limitations\n" +
  " * under the License.\n" +
  " */\n" +
  "/* This program is generated, do not modify. See FORDecompressorGenerator.java */\n";

  /**
   * @param args
   * @throws IOException
   */
  public static void main(final String[] args) throws IOException {
    final File file = new File("./src/main/java/org/apache/lucene/compression/afor",
                         "FORDecompressor.java");
    final FORDecompressorGenerator generator = new FORDecompressorGenerator();
    generator.generate(file);
  }

}
