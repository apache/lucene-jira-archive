/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.afor;

import org.apache.lucene.compression.afor.FORCompressor.FrameCompressor;
import org.apache.lucene.compression.afor.FORDecompressor.FrameDecompressor;

/** Frame of Reference lossless integer compression/decompression.
 * For positive integers, the compression is done by leaving out
 * the most significant bits, and storing all numbers with a fixed number of bits
 * contiguously in a buffer of bits. This buffer is called the frame, and it
 * can store positive numbers in a range from 0 to a constant maximum fitting in
 * the number of bits available for a single compressed number.
 * <p>
 * This implementation uses 0 as the lower bound reference for the frame,
 * so small positive integers can be most effectively compressed.
 * <p>
 * Optimized code is used for decompression, see class ForDecompress and its subclasses.
 * <br>Use of the -server option helps performance for the Sun 1.6 jvm under Linux.
 * <p>
 * This class does not provide delta coding because the Lucene index
 * structures already have that.
 * <p>
 * To be done:
 * <ul>
 * <li>
 * Optimize compression code by specializing for number of frame bits.
 * <li>
 * IntBuffer.get() is somewhat faster that IntBuffer.get(index), adapt (de)compression to
 * use the relative get() method.
 * <li>
 * Check javadoc generation and generated javadocs. Add javadoc code references.
 * </ul>
 */
public class AFOR1 extends AbstractFrameOfRef {

  protected int[] bitsFrames;

  /** Index of header in int buffer */
  protected final int HEADER_INDEX = 0;
  protected int HEADER_SIZE = 0; // two bytes in byte array

  /** Start index in byte array integers each compressed to numFrameBits. */
  protected int BLOCK_INDEX = HEADER_INDEX + HEADER_SIZE;

  /** Create a Frame of Reference integer compressor/decompressor. */
  public AFOR1() {
    super();
  }

  @Override
  public void setUnCompressedData(final int[] unCompressedData, final int offset, final int unComprSize) {
    super.setUnCompressedData(unCompressedData, offset, unComprSize);
    bitsFrames = new int[unComprSize / 32];
  }

  protected final FrameCompressor[] compressors = FORCompressor.compressors;
  protected final int[] frameSizes = FORCompressor.frameSizes;

  /**
   * Compress the uncompressed data into the byte array using the given number of
   * frame bits, storing only this number of least significant bits of the
   * uncompressed integers in the compressed buffer.
   * Should only be used after setUnCompressedData().
   * <br>
   * A header is stored as a first integer into the buffer, encoding
   * the compression method, the number of frame bits and the number of compressed integers.
   * All uncompressed integers are stored sequentially in compressed form
   * in the buffer after the header.
   *
   * @param numFrameBits        The number of frame bits. Should be between 1 and 32.
   *                            Note that when this value is 32, no compression occurs.
   */
  @Override
  public void compress() {
    this.encodeHeader();
    index = BLOCK_INDEX;

    for (int i = 0, j = 0; i < unComprSize; i += 32, j++) {
      bitsFrames[j] = this.frameBitsForCompression(i + offset);
      compressedArray[index] = (byte) (bitsFrames[j] - 1);
      this.compressors[bitsFrames[j] - 1].compress(unCompressedData, i + offset, compressedArray, index + 1);
      index += this.frameSizes[bitsFrames[j] - 1] + 1;
    }
  }

  /** Return the number of bytes used in the byte array.
   *  Only valid after compress() or decompress().
   */
  @Override
  public int compressedSize() {
    return index;
  }

  /** The 2 byte header contains:
   *  <ul>
   *  <li>10 bits for (numFrameBits-1) * 4,
   *  <li>6 bits unused
   *  </ul>
   */
  private void encodeHeader() {}

  protected void decodeHeader() {}

  /** Decompress from the buffer into output from a given offset. */
  @Override
  public void decompress() {
    this.decodeHeader();
    this.decompressFrame();
  }

  protected final FrameDecompressor[] decompressors = FORDecompressor.decompressors;

  /** For performance, this delegates to classes with fixed numFrameBits. */
  protected void decompressFrame() {
    this.index = BLOCK_INDEX;

    int numFrameBits = 0;
    for (int i = 0, j = 0; i < unComprSize; i += 32, j++) {
      numFrameBits = bitsFrames[j] = 1 + compressedArray[index++];
      this.decompressors[numFrameBits - 1].decompress(this);
      this.offset += 32;
      this.index += numFrameBits << 2; // numFrameBits * 4
    }
  }

  /** Determine the number of frame bits to be used for compression.
   * Use only after setUnCompressedData().
   * @return The number of bits needed to encode the maximum positive uncompressed value.
   * Negative uncompressed values have no influence on the result.
   */
  public int frameBitsForCompression(final int offset) {
    int maxNonNegVal = 0;
    for (int i = offset; i < (offset + 32); i++) {
      if (unCompressedData[i] < 0){
        return 32;
      }
      if (unCompressedData[i] > maxNonNegVal) {
        maxNonNegVal = unCompressedData[i];
      }
    }
    return this.logNextHigherPowerOfTwo(maxNonNegVal) + 1;
  }

  @Override
  public int getByteBufferSize(final int blockSize) {
    return (blockSize << 2) + (blockSize >> 5);
  }

}
