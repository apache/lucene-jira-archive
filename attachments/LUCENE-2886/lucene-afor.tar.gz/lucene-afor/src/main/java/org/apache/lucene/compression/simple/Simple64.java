/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.simple;

import java.nio.LongBuffer;

public class Simple64 {

  protected int compressedSize = 0;
  protected int[] compressedArray;

  protected LongBuffer compressedBuffer;

  /** Index of header in buffer */
  protected final int HEADER_INDEX = 0;
  protected final int HEADER_SIZE = 0;

  /** Start index in buffer of stripped integers */
  protected final int BLOCK_INDEX = HEADER_INDEX + HEADER_SIZE;

  /** Uncompressed data */
  protected int[] unCompressedData;
  /** Offset into unCompressedData */
  protected int offset;
  /** Size of unCompressedData, -1 when not available. */
  protected int unComprSize = -1;

  /** The position in the current data block */
  protected int blockPosition;

  public Simple64() {
  }

  public void setCompressedBuffer(final LongBuffer compressedBuffer) {
    this.compressedBuffer = compressedBuffer;
  }

  public void setUnCompressedData(final int[] unCompressedData,
      final int offset, final int unComprSize) {
    this.unCompressedData = unCompressedData;
    this.offset = offset;
    this.unComprSize = unComprSize;
  }

  public int compressedSize() {
    return this.compressedSize;
  }

  private final int NUM_DATA_BITS = 60;
  private final long BITS_60_MASK = (1L << 60) - 1;
  private final long BITS_30_MASK = (1 << 30) - 1;
  private final long BITS_20_MASK = (1 << 20) - 1;
  private final long BITS_15_MASK = (1 << 15) - 1;
  private final long BITS_12_MASK = (1 << 12) - 1;
  private final long BITS_11_MASK = (1 << 11) - 1;
  private final long BITS_10_MASK = (1 << 10) - 1;
  private final long BITS_8_MASK = (1 << 8) - 1; // 4 bits unused, then the last value take them
  private final long BITS_7_MASK = (1 << 7) - 1; // 4 bits unused, then the last value take them
  private final long BITS_6_MASK = (1 << 6) - 1;
  private final long BITS_5_MASK = (1 << 5) - 1;
  private final long BITS_4_MASK = (1 << 4) - 1;
  private final long BITS_3_MASK = (1 << 3) - 1;
  private final long BITS_2_MASK = (1 << 2) - 1;
  private final long BITS_1_MASK = (1 << 1) - 1;

  private final int STATUS_1NUM_60BITS = 14;
  private final int STATUS_2NUM_30BITS = 13;
  private final int STATUS_3NUM_20BITS = 12;
  private final int STATUS_4NUM_15BITS = 11;
  private final int STATUS_5NUM_12BITS = 10;
  private final int STATUS_6NUM_10BITS = 9;
  private final int STATUS_7NUM_8BITS = 8;
  private final int STATUS_8NUM_7BITS = 7;
  private final int STATUS_10NUM_6BITS = 6;
  private final int STATUS_12NUM_5BITS = 5;
  private final int STATUS_15NUM_4BITS = 4;
  private final int STATUS_20NUM_3BITS = 3;
  private final int STATUS_30NUM_2BITS = 2;
  private final int STATUS_60NUM_1BITS = 1;

  public int compressSingle(final int[] uncompressed, final int inOffset, final int inSize, final LongBuffer compressedBuffer, final int outOffset) {
    if (inSize < 1) {
      throw new IllegalArgumentException("Cannot compress input with non positive size " + inSize);
    }
    int inputCompressable = 1;
    int minBits = 1;
    long maxFitPlus1 = (1 << minBits);
    long nextData;

    do {
      nextData = uncompressed[inOffset + inputCompressable - 1] & 0xFFFFFFFFL;
      if (nextData < 0) {
        throw new IllegalArgumentException("Cannot compress negative input " + nextData + " (at index " + (inOffset+inputCompressable-1) + ")");
      }
      while ((nextData >= maxFitPlus1) && (minBits < NUM_DATA_BITS))
      {
        if ((minBits == 7) && (inputCompressable == 8) && (nextData < (maxFitPlus1 << 4))) {
          break;
        } else if ((minBits == 8) && (inputCompressable == 7) && (nextData < (maxFitPlus1 << 4))) {
          break;
        } else {
          minBits++;
          maxFitPlus1 <<= 1;
          if ((inputCompressable * minBits) > NUM_DATA_BITS) {
            inputCompressable--;
            break;
          }
        }
      }
      inputCompressable++;
    } while (((inputCompressable * minBits) <= NUM_DATA_BITS) && (inputCompressable <= inSize));

    inputCompressable--;
    if (inputCompressable == 0) {
      throw new IllegalArgumentException("Cannot compress input " + nextData + " with more than " + NUM_DATA_BITS + " bits (at offSet " + inOffset + ")");
    }

    // Check whether a bigger number of bits can be used:
    while ((inputCompressable * (minBits+1)) <= NUM_DATA_BITS) {
      minBits++;
    }

    if (((inputCompressable+1) * minBits) <= NUM_DATA_BITS) {
      // not enough input available for minBits
      minBits++;
      // do not compress all available input
      inputCompressable = NUM_DATA_BITS / minBits;
    }

    // Put compression method in status bits and encode input data
    long s9;
    switch (minBits) { // add status bits and later input values
    case 60:
      s9 = STATUS_1NUM_60BITS;
      s9 |= (long) (uncompressed[inOffset]) << 4;
      compressedBuffer.put(outOffset, s9);
      return 1;
    case 30:
      s9 = STATUS_2NUM_30BITS;
      s9 |= (long) (uncompressed[inOffset]) << 4;
      s9 |= (long) (uncompressed[inOffset+1]) << 34;
      compressedBuffer.put(outOffset, s9);
      return 2;
    case 20:
      s9 = STATUS_3NUM_20BITS;
      s9 |= (long) (uncompressed[inOffset]) << 4;
      s9 |= (long) (uncompressed[inOffset+1]) << 24;
      s9 |= (long) (uncompressed[inOffset+2]) << 44;
      compressedBuffer.put(outOffset, s9);
      return 3;
    case 15:
      s9 = STATUS_4NUM_15BITS;
      s9 |= ((long) (uncompressed[inOffset]) << 4);
      s9 |= (long) (uncompressed[inOffset+1]) << 19;
      s9 |= (long) (uncompressed[inOffset+2]) << 34;
      s9 |= (long) (uncompressed[inOffset+3]) << 49;
      compressedBuffer.put(outOffset, s9);
      return 4;
    case 12:
      s9 = STATUS_5NUM_12BITS;
      s9 |= ((long) (uncompressed[inOffset]) << 4);
      s9 |= (long) (uncompressed[inOffset+1]) << 16;
      s9 |= (long) (uncompressed[inOffset+2]) << 28;
      s9 |= (long) (uncompressed[inOffset+3]) << 40;
      s9 |= (long) (uncompressed[inOffset+4]) << 52;
      compressedBuffer.put(outOffset, s9);
      return 5;
    case 10:
      s9 = STATUS_6NUM_10BITS;
      s9 |= ((long) (uncompressed[inOffset]) << 4);
      s9 |= (long) (uncompressed[inOffset+1]) << 14;
      s9 |= (long) (uncompressed[inOffset+2]) << 24;
      s9 |= (long) (uncompressed[inOffset+3]) << 34;
      s9 |= (long) (uncompressed[inOffset+4]) << 44;
      s9 |= (long) (uncompressed[inOffset+5]) << 54;
      compressedBuffer.put(outOffset, s9);
      return 6;
    case 8:
      s9 = STATUS_7NUM_8BITS;
      s9 |= ((long) (uncompressed[inOffset]) << 4);
      s9 |= (long) (uncompressed[inOffset+1]) << 12;
      s9 |= (long) (uncompressed[inOffset+2]) << 20;
      s9 |= (long) (uncompressed[inOffset+3]) << 28;
      s9 |= (long) (uncompressed[inOffset+4]) << 36;
      s9 |= (long) (uncompressed[inOffset+5]) << 44;
      s9 |= (long) (uncompressed[inOffset+6]) << 52; // 4 more bits
      compressedBuffer.put(outOffset, s9);
      return 7;
    case 7:
      s9 = STATUS_8NUM_7BITS;
      s9 |= ((long) (uncompressed[inOffset]) << 4);
      s9 |= (long) (uncompressed[inOffset+1]) << 11;
      s9 |= (long) (uncompressed[inOffset+2]) << 18;
      s9 |= (long) (uncompressed[inOffset+3]) << 25;
      s9 |= (long) (uncompressed[inOffset+4]) << 32;
      s9 |= (long) (uncompressed[inOffset+5]) << 39;
      s9 |= (long) (uncompressed[inOffset+6]) << 46;
      s9 |= (long) (uncompressed[inOffset+7]) << 53; // 4 more bits
      compressedBuffer.put(outOffset, s9);
      return 8;
    case 6:
      s9 = STATUS_10NUM_6BITS;
      s9 |= (long) (uncompressed[inOffset]) << 4;
      s9 |= (long) (uncompressed[inOffset+1]) << 10;
      s9 |= (long) (uncompressed[inOffset+2]) << 16;
      s9 |= (long) (uncompressed[inOffset+3]) << 22;
      s9 |= (long) (uncompressed[inOffset+4]) << 28;
      s9 |= (long) (uncompressed[inOffset+5]) << 34;
      s9 |= (long) (uncompressed[inOffset+6]) << 40;
      s9 |= (long) (uncompressed[inOffset+7]) << 46;
      s9 |= (long) (uncompressed[inOffset+8]) << 52;
      s9 |= (long) (uncompressed[inOffset+9]) << 58;
      compressedBuffer.put(outOffset, s9);
      return 10;
    case 5:
      s9 = STATUS_12NUM_5BITS;
      s9 |= (long) (uncompressed[inOffset]) << 4;
      s9 |= (long) (uncompressed[inOffset+1]) << 9;
      s9 |= (long) (uncompressed[inOffset+2]) << 14;
      s9 |= (long) (uncompressed[inOffset+3]) << 19;
      s9 |= (long) (uncompressed[inOffset+4]) << 24;
      s9 |= (long) (uncompressed[inOffset+5]) << 29;
      s9 |= (long) (uncompressed[inOffset+6]) << 34;
      s9 |= (long) (uncompressed[inOffset+7]) << 39;
      s9 |= (long) (uncompressed[inOffset+8]) << 44;
      s9 |= (long) (uncompressed[inOffset+9]) << 49;
      s9 |= (long) (uncompressed[inOffset+10]) << 54;
      s9 |= (long) (uncompressed[inOffset+11]) << 59;
      compressedBuffer.put(outOffset, s9);
      return 12;
    case 4:
      s9 = STATUS_15NUM_4BITS;
      s9 |= (long) (uncompressed[inOffset]) << 4;
      s9 |= (long) (uncompressed[inOffset+1]) << 8;
      s9 |= (long) (uncompressed[inOffset+2]) << 12;
      s9 |= (long) (uncompressed[inOffset+3]) << 16;
      s9 |= (long) (uncompressed[inOffset+4]) << 20;
      s9 |= (long) (uncompressed[inOffset+5]) << 24;
      s9 |= (long) (uncompressed[inOffset+6]) << 28;
      s9 |= (long) (uncompressed[inOffset+7]) << 32;
      s9 |= (long) (uncompressed[inOffset+8]) << 36;
      s9 |= (long) (uncompressed[inOffset+9]) << 40;
      s9 |= (long) (uncompressed[inOffset+10]) << 44;
      s9 |= (long) (uncompressed[inOffset+11]) << 48;
      s9 |= (long) (uncompressed[inOffset+12]) << 52;
      s9 |= (long) (uncompressed[inOffset+13]) << 56;
      s9 |= (long) (uncompressed[inOffset+14]) << 60;
      compressedBuffer.put(outOffset, s9);
      return 15;
    case 3:
      s9 = STATUS_20NUM_3BITS;
      s9 |= (long) (uncompressed[inOffset]) << 4;
      s9 |= (long) (uncompressed[inOffset+1]) << 7;
      s9 |= (long) (uncompressed[inOffset+2]) << 10;
      s9 |= (long) (uncompressed[inOffset+3]) << 13;
      s9 |= (long) (uncompressed[inOffset+4]) << 16;
      s9 |= (long) (uncompressed[inOffset+5]) << 19;
      s9 |= (long) (uncompressed[inOffset+6]) << 22;
      s9 |= (long) (uncompressed[inOffset+7]) << 25;
      s9 |= (long) (uncompressed[inOffset+8]) << 28;
      s9 |= (long) (uncompressed[inOffset+9]) << 31;
      s9 |= (long) (uncompressed[inOffset+10]) << 34;
      s9 |= (long) (uncompressed[inOffset+11]) << 37;
      s9 |= (long) (uncompressed[inOffset+12]) << 40;
      s9 |= (long) (uncompressed[inOffset+13]) << 43;
      s9 |= (long) (uncompressed[inOffset+14]) << 46;
      s9 |= (long) (uncompressed[inOffset+15]) << 49;
      s9 |= (long) (uncompressed[inOffset+16]) << 52;
      s9 |= (long) (uncompressed[inOffset+17]) << 55;
      s9 |= (long) (uncompressed[inOffset+18]) << 58;
      s9 |= (long) (uncompressed[inOffset+19]) << 61;
      compressedBuffer.put(outOffset, s9);
      return 20;
    case 2:
      s9 = STATUS_30NUM_2BITS;
      s9 |= (long) (uncompressed[inOffset]) << 4;
      s9 |= (long) (uncompressed[inOffset+1]) << 6;
      s9 |= (long) (uncompressed[inOffset+2]) << 8;
      s9 |= (long) (uncompressed[inOffset+3]) << 10;
      s9 |= (long) (uncompressed[inOffset+4]) << 12;
      s9 |= (long) (uncompressed[inOffset+5]) << 14;
      s9 |= (long) (uncompressed[inOffset+6]) << 16;
      s9 |= (long) (uncompressed[inOffset+7]) << 18;
      s9 |= (long) (uncompressed[inOffset+8]) << 20;
      s9 |= (long) (uncompressed[inOffset+9]) << 22;
      s9 |= (long) (uncompressed[inOffset+10]) << 24;
      s9 |= (long) (uncompressed[inOffset+11]) << 26;
      s9 |= (long) (uncompressed[inOffset+12]) << 28;
      s9 |= (long) (uncompressed[inOffset+13]) << 30;
      s9 |= (long) (uncompressed[inOffset+14]) << 32;
      s9 |= (long) (uncompressed[inOffset+15]) << 34;
      s9 |= (long) (uncompressed[inOffset+16]) << 36;
      s9 |= (long) (uncompressed[inOffset+17]) << 38;
      s9 |= (long) (uncompressed[inOffset+18]) << 40;
      s9 |= (long) (uncompressed[inOffset+19]) << 42;
      s9 |= (long) (uncompressed[inOffset+20]) << 44;
      s9 |= (long) (uncompressed[inOffset+21]) << 46;
      s9 |= (long) (uncompressed[inOffset+22]) << 48;
      s9 |= (long) (uncompressed[inOffset+23]) << 50;
      s9 |= (long) (uncompressed[inOffset+24]) << 52;
      s9 |= (long) (uncompressed[inOffset+25]) << 54;
      s9 |= (long) (uncompressed[inOffset+26]) << 56;
      s9 |= (long) (uncompressed[inOffset+27]) << 58;
      s9 |= (long) (uncompressed[inOffset+28]) << 60;
      s9 |= (long) (uncompressed[inOffset+29]) << 62;
      compressedBuffer.put(outOffset, s9);
      return 30;
    case 1:
      s9 = STATUS_60NUM_1BITS;
      s9 |= (long) (uncompressed[inOffset]) << 4;
      s9 |= (long) (uncompressed[inOffset+1]) << 5;
      s9 |= (long) (uncompressed[inOffset+2]) << 6;
      s9 |= (long) (uncompressed[inOffset+3]) << 7;
      s9 |= (long) (uncompressed[inOffset+4]) << 8;
      s9 |= (long) (uncompressed[inOffset+5]) << 9;
      s9 |= (long) (uncompressed[inOffset+6]) << 10;
      s9 |= (long) (uncompressed[inOffset+7]) << 11;
      s9 |= (long) (uncompressed[inOffset+8]) << 12;
      s9 |= (long) (uncompressed[inOffset+9]) << 13;
      s9 |= (long) (uncompressed[inOffset+10]) << 14;
      s9 |= (long) (uncompressed[inOffset+11]) << 15;
      s9 |= (long) (uncompressed[inOffset+12]) << 16;
      s9 |= (long) (uncompressed[inOffset+13]) << 17;
      s9 |= (long) (uncompressed[inOffset+14]) << 18;
      s9 |= (long) (uncompressed[inOffset+15]) << 19;
      s9 |= (long) (uncompressed[inOffset+16]) << 20;
      s9 |= (long) (uncompressed[inOffset+17]) << 21;
      s9 |= (long) (uncompressed[inOffset+18]) << 22;
      s9 |= (long) (uncompressed[inOffset+19]) << 23;
      s9 |= (long) (uncompressed[inOffset+20]) << 24;
      s9 |= (long) (uncompressed[inOffset+21]) << 25;
      s9 |= (long) (uncompressed[inOffset+22]) << 26;
      s9 |= (long) (uncompressed[inOffset+23]) << 27;
      s9 |= (long) (uncompressed[inOffset+24]) << 28;
      s9 |= (long) (uncompressed[inOffset+25]) << 29;
      s9 |= (long) (uncompressed[inOffset+26]) << 30;
      s9 |= (long) (uncompressed[inOffset+27]) << 31;
      s9 |= (long) (uncompressed[inOffset+28]) << 32;
      s9 |= (long) (uncompressed[inOffset+29]) << 33;
      s9 |= (long) (uncompressed[inOffset+30]) << 34;
      s9 |= (long) (uncompressed[inOffset+31]) << 35;
      s9 |= (long) (uncompressed[inOffset+32]) << 36;
      s9 |= (long) (uncompressed[inOffset+33]) << 37;
      s9 |= (long) (uncompressed[inOffset+34]) << 38;
      s9 |= (long) (uncompressed[inOffset+35]) << 39;
      s9 |= (long) (uncompressed[inOffset+36]) << 40;
      s9 |= (long) (uncompressed[inOffset+37]) << 41;
      s9 |= (long) (uncompressed[inOffset+38]) << 42;
      s9 |= (long) (uncompressed[inOffset+39]) << 43;
      s9 |= (long) (uncompressed[inOffset+40]) << 44;
      s9 |= (long) (uncompressed[inOffset+41]) << 45;
      s9 |= (long) (uncompressed[inOffset+42]) << 46;
      s9 |= (long) (uncompressed[inOffset+43]) << 47;
      s9 |= (long) (uncompressed[inOffset+44]) << 48;
      s9 |= (long) (uncompressed[inOffset+45]) << 49;
      s9 |= (long) (uncompressed[inOffset+46]) << 50;
      s9 |= (long) (uncompressed[inOffset+47]) << 51;
      s9 |= (long) (uncompressed[inOffset+48]) << 52;
      s9 |= (long) (uncompressed[inOffset+49]) << 53;
      s9 |= (long) (uncompressed[inOffset+50]) << 54;
      s9 |= (long) (uncompressed[inOffset+51]) << 55;
      s9 |= (long) (uncompressed[inOffset+52]) << 56;
      s9 |= (long) (uncompressed[inOffset+53]) << 57;
      s9 |= (long) (uncompressed[inOffset+54]) << 58;
      s9 |= (long) (uncompressed[inOffset+55]) << 59;
      s9 |= (long) (uncompressed[inOffset+56]) << 60;
      s9 |= (long) (uncompressed[inOffset+57]) << 61;
      s9 |= (long) (uncompressed[inOffset+58]) << 62;
      s9 |= (long) (uncompressed[inOffset+59]) << 63;
      compressedBuffer.put(outOffset, s9);
      return 60;
    default:
      throw new Error("S98b.compressSingle internal error: unknown minBits: " + minBits);
    }
  }


  public int decompressSingle(final long s9, final int[] decompressed, final int outOffset) {
    switch ((int) (s9 & 15)) {
    case STATUS_1NUM_60BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_60_MASK); // The value can't be bigger than 2^32-1
      return 1;
    case STATUS_2NUM_30BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_30_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 34) & BITS_30_MASK);
      return 2;
    case STATUS_3NUM_20BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_20_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 24) & BITS_20_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 44) & BITS_20_MASK);
      return 3;
    case STATUS_4NUM_15BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_15_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 19) & BITS_15_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 34) & BITS_15_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 49) & BITS_15_MASK);
      return 4;
    case STATUS_5NUM_12BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_12_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 16) & BITS_12_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 28) & BITS_12_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 40) & BITS_12_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 52) & BITS_12_MASK);
      return 5;
    case STATUS_6NUM_10BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_10_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 14) & BITS_10_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 24) & BITS_10_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 34) & BITS_10_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 44) & BITS_10_MASK);
      decompressed[outOffset+5] = (int) ((s9 >>> 54) & BITS_10_MASK);
      return 6;
    case STATUS_7NUM_8BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_8_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 12) & BITS_8_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 20) & BITS_8_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 28) & BITS_8_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 36) & BITS_8_MASK);
      decompressed[outOffset+5] = (int) ((s9 >>> 44) & BITS_8_MASK);
      decompressed[outOffset+6] = (int) ((s9 >>> 52) & BITS_12_MASK);
      return 7;
    case STATUS_8NUM_7BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_7_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 11) & BITS_7_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 18) & BITS_7_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 25) & BITS_7_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 32) & BITS_7_MASK);
      decompressed[outOffset+5] = (int) ((s9 >>> 39) & BITS_7_MASK);
      decompressed[outOffset+6] = (int) ((s9 >>> 46) & BITS_7_MASK);
      decompressed[outOffset+7] = (int) ((s9 >>> 53) & BITS_11_MASK);
      return 8;
    case STATUS_10NUM_6BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_6_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 10) & BITS_6_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 16) & BITS_6_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 22) & BITS_6_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 28) & BITS_6_MASK);
      decompressed[outOffset+5] = (int) ((s9 >>> 34) & BITS_6_MASK);
      decompressed[outOffset+6] = (int) ((s9 >>> 40) & BITS_6_MASK);
      decompressed[outOffset+7] = (int) ((s9 >>> 46) & BITS_6_MASK);
      decompressed[outOffset+8] = (int) ((s9 >>> 52) & BITS_6_MASK);
      decompressed[outOffset+9] = (int) ((s9 >>> 58) & BITS_6_MASK);
      return 10;
    case STATUS_12NUM_5BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_5_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 9) & BITS_5_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 14) & BITS_5_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 19) & BITS_5_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 24) & BITS_5_MASK);
      decompressed[outOffset+5] = (int) ((s9 >>> 29) & BITS_5_MASK);
      decompressed[outOffset+6] = (int) ((s9 >>> 34) & BITS_5_MASK);
      decompressed[outOffset+7] = (int) ((s9 >>> 39) & BITS_5_MASK);
      decompressed[outOffset+8] = (int) ((s9 >>> 44) & BITS_5_MASK);
      decompressed[outOffset+9] = (int) ((s9 >>> 49) & BITS_5_MASK);
      decompressed[outOffset+10] = (int) ((s9 >>> 54) & BITS_5_MASK);
      decompressed[outOffset+11] = (int) ((s9 >>> 59) & BITS_5_MASK);
      return 12;
    case STATUS_15NUM_4BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_4_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 8) & BITS_4_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 12) & BITS_4_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 16) & BITS_4_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 20) & BITS_4_MASK);
      decompressed[outOffset+5] = (int) ((s9 >>> 24) & BITS_4_MASK);
      decompressed[outOffset+6] = (int) ((s9 >>> 28) & BITS_4_MASK);
      decompressed[outOffset+7] = (int) ((s9 >>> 32) & BITS_4_MASK);
      decompressed[outOffset+8] = (int) ((s9 >>> 36) & BITS_4_MASK);
      decompressed[outOffset+9] = (int) ((s9 >>> 40) & BITS_4_MASK);
      decompressed[outOffset+10] = (int) ((s9 >>> 44) & BITS_4_MASK);
      decompressed[outOffset+11] = (int) ((s9 >>> 48) & BITS_4_MASK);
      decompressed[outOffset+12] = (int) ((s9 >>> 52) & BITS_4_MASK);
      decompressed[outOffset+13] = (int) ((s9 >>> 56) & BITS_4_MASK);
      decompressed[outOffset+14] = (int) ((s9 >>> 60) & BITS_4_MASK);
      return 15;
    case STATUS_20NUM_3BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_3_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 7) & BITS_3_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 10) & BITS_3_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 13) & BITS_3_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 16) & BITS_3_MASK);
      decompressed[outOffset+5] = (int) ((s9 >>> 19) & BITS_3_MASK);
      decompressed[outOffset+6] = (int) ((s9 >>> 22) & BITS_3_MASK);
      decompressed[outOffset+7] = (int) ((s9 >>> 25) & BITS_3_MASK);
      decompressed[outOffset+8] = (int) ((s9 >>> 28) & BITS_3_MASK);
      decompressed[outOffset+9] = (int) ((s9 >>> 31) & BITS_3_MASK);
      decompressed[outOffset+10] = (int) ((s9 >>> 34) & BITS_3_MASK);
      decompressed[outOffset+11] = (int) ((s9 >>> 37) & BITS_3_MASK);
      decompressed[outOffset+12] = (int) ((s9 >>> 40) & BITS_3_MASK);
      decompressed[outOffset+13] = (int) ((s9 >>> 43) & BITS_3_MASK);
      decompressed[outOffset+14] = (int) ((s9 >>> 46) & BITS_3_MASK);
      decompressed[outOffset+15] = (int) ((s9 >>> 49) & BITS_3_MASK);
      decompressed[outOffset+16] = (int) ((s9 >>> 52) & BITS_3_MASK);
      decompressed[outOffset+17] = (int) ((s9 >>> 55) & BITS_3_MASK);
      decompressed[outOffset+18] = (int) ((s9 >>> 58) & BITS_3_MASK);
      decompressed[outOffset+19] = (int) ((s9 >>> 61) & BITS_3_MASK);
      return 20;
    case STATUS_30NUM_2BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_2_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 6) & BITS_2_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 8) & BITS_2_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 10) & BITS_2_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 12) & BITS_2_MASK);
      decompressed[outOffset+5] = (int) ((s9 >>> 14) & BITS_2_MASK);
      decompressed[outOffset+6] = (int) ((s9 >>> 16) & BITS_2_MASK);
      decompressed[outOffset+7] = (int) ((s9 >>> 18) & BITS_2_MASK);
      decompressed[outOffset+8] = (int) ((s9 >>> 20) & BITS_2_MASK);
      decompressed[outOffset+9] = (int) ((s9 >>> 22) & BITS_2_MASK);
      decompressed[outOffset+10] = (int) ((s9 >>> 24) & BITS_2_MASK);
      decompressed[outOffset+11] = (int) ((s9 >>> 26) & BITS_2_MASK);
      decompressed[outOffset+12] = (int) ((s9 >>> 28) & BITS_2_MASK);
      decompressed[outOffset+13] = (int) ((s9 >>> 30) & BITS_2_MASK);
      decompressed[outOffset+14] = (int) ((s9 >>> 32) & BITS_2_MASK);
      decompressed[outOffset+15] = (int) ((s9 >>> 34) & BITS_2_MASK);
      decompressed[outOffset+16] = (int) ((s9 >>> 36) & BITS_2_MASK);
      decompressed[outOffset+17] = (int) ((s9 >>> 38) & BITS_2_MASK);
      decompressed[outOffset+18] = (int) ((s9 >>> 40) & BITS_2_MASK);
      decompressed[outOffset+19] = (int) ((s9 >>> 42) & BITS_2_MASK);
      decompressed[outOffset+20] = (int) ((s9 >> 44) & BITS_2_MASK);
      decompressed[outOffset+21] = (int) ((s9 >>> 46) & BITS_2_MASK);
      decompressed[outOffset+22] = (int) ((s9 >>> 48) & BITS_2_MASK);
      decompressed[outOffset+23] = (int) ((s9 >>> 50) & BITS_2_MASK);
      decompressed[outOffset+24] = (int) ((s9 >>> 52) & BITS_2_MASK);
      decompressed[outOffset+25] = (int) ((s9 >>> 54) & BITS_2_MASK);
      decompressed[outOffset+26] = (int) ((s9 >>> 56) & BITS_2_MASK);
      decompressed[outOffset+27] = (int) ((s9 >>> 58) & BITS_2_MASK);
      decompressed[outOffset+28] = (int) ((s9 >>> 60) & BITS_2_MASK);
      decompressed[outOffset+29] = (int) ((s9 >>> 62) & BITS_2_MASK);
      return 30;
    case STATUS_60NUM_1BITS:
      decompressed[outOffset] = (int) ((s9 >>> 4) & BITS_1_MASK);
      decompressed[outOffset+1] = (int) ((s9 >>> 5) & BITS_1_MASK);
      decompressed[outOffset+2] = (int) ((s9 >>> 6) & BITS_1_MASK);
      decompressed[outOffset+3] = (int) ((s9 >>> 7) & BITS_1_MASK);
      decompressed[outOffset+4] = (int) ((s9 >>> 8) & BITS_1_MASK);
      decompressed[outOffset+5] = (int) ((s9 >>> 9) & BITS_1_MASK);
      decompressed[outOffset+6] = (int) ((s9 >>> 10) & BITS_1_MASK);
      decompressed[outOffset+7] = (int) ((s9 >>> 11) & BITS_1_MASK);
      decompressed[outOffset+8] = (int) ((s9 >>> 12) & BITS_1_MASK);
      decompressed[outOffset+9] = (int) ((s9 >>> 13) & BITS_1_MASK);
      decompressed[outOffset+10] = (int) ((s9 >>> 14) & BITS_1_MASK);
      decompressed[outOffset+11] = (int) ((s9 >>> 15) & BITS_1_MASK);
      decompressed[outOffset+12] = (int) ((s9 >>> 16) & BITS_1_MASK);
      decompressed[outOffset+13] = (int) ((s9 >>> 17) & BITS_1_MASK);
      decompressed[outOffset+14] = (int) ((s9 >>> 18) & BITS_1_MASK);
      decompressed[outOffset+15] = (int) ((s9 >>> 19) & BITS_1_MASK);
      decompressed[outOffset+16] = (int) ((s9 >>> 20) & BITS_1_MASK);
      decompressed[outOffset+17] = (int) ((s9 >>> 21) & BITS_1_MASK);
      decompressed[outOffset+18] = (int) ((s9 >>> 22) & BITS_1_MASK);
      decompressed[outOffset+19] = (int) ((s9 >>> 23) & BITS_1_MASK);
      decompressed[outOffset+20] = (int) ((s9 >> 24) & BITS_1_MASK);
      decompressed[outOffset+21] = (int) ((s9 >>> 25) & BITS_1_MASK);
      decompressed[outOffset+22] = (int) ((s9 >>> 26) & BITS_1_MASK);
      decompressed[outOffset+23] = (int) ((s9 >>> 27) & BITS_1_MASK);
      decompressed[outOffset+24] = (int) ((s9 >>> 28) & BITS_1_MASK);
      decompressed[outOffset+25] = (int) ((s9 >>> 29) & BITS_1_MASK);
      decompressed[outOffset+26] = (int) ((s9 >>> 30) & BITS_1_MASK);
      decompressed[outOffset+27] = (int) ((s9 >>> 31) & BITS_1_MASK);
      decompressed[outOffset+28] = (int) ((s9 >>> 32) & BITS_1_MASK);
      decompressed[outOffset+29] = (int) ((s9 >>> 33) & BITS_1_MASK);
      decompressed[outOffset+30] = (int) ((s9 >> 34) & BITS_1_MASK);
      decompressed[outOffset+31] = (int) ((s9 >>> 35) & BITS_1_MASK);
      decompressed[outOffset+32] = (int) ((s9 >>> 36) & BITS_1_MASK);
      decompressed[outOffset+33] = (int) ((s9 >>> 37) & BITS_1_MASK);
      decompressed[outOffset+34] = (int) ((s9 >>> 38) & BITS_1_MASK);
      decompressed[outOffset+35] = (int) ((s9 >>> 39) & BITS_1_MASK);
      decompressed[outOffset+36] = (int) ((s9 >>> 40) & BITS_1_MASK);
      decompressed[outOffset+37] = (int) ((s9 >>> 41) & BITS_1_MASK);
      decompressed[outOffset+38] = (int) ((s9 >>> 42) & BITS_1_MASK);
      decompressed[outOffset+39] = (int) ((s9 >>> 43) & BITS_1_MASK);
      decompressed[outOffset+40] = (int) ((s9 >>> 44) & BITS_1_MASK);
      decompressed[outOffset+41] = (int) ((s9 >>> 45) & BITS_1_MASK);
      decompressed[outOffset+42] = (int) ((s9 >>> 46) & BITS_1_MASK);
      decompressed[outOffset+43] = (int) ((s9 >>> 47) & BITS_1_MASK);
      decompressed[outOffset+44] = (int) ((s9 >>> 48) & BITS_1_MASK);
      decompressed[outOffset+45] = (int) ((s9 >>> 49) & BITS_1_MASK);
      decompressed[outOffset+46] = (int) ((s9 >>> 50) & BITS_1_MASK);
      decompressed[outOffset+47] = (int) ((s9 >>> 51) & BITS_1_MASK);
      decompressed[outOffset+48] = (int) ((s9 >>> 52) & BITS_1_MASK);
      decompressed[outOffset+49] = (int) ((s9 >>> 53) & BITS_1_MASK);
      decompressed[outOffset+50] = (int) ((s9 >> 54) & BITS_1_MASK);
      decompressed[outOffset+51] = (int) ((s9 >>> 55) & BITS_1_MASK);
      decompressed[outOffset+52] = (int) ((s9 >>> 56) & BITS_1_MASK);
      decompressed[outOffset+53] = (int) ((s9 >>> 57) & BITS_1_MASK);
      decompressed[outOffset+54] = (int) ((s9 >>> 58) & BITS_1_MASK);
      decompressed[outOffset+55] = (int) ((s9 >>> 59) & BITS_1_MASK);
      decompressed[outOffset+56] = (int) ((s9 >>> 60) & BITS_1_MASK);
      decompressed[outOffset+57] = (int) ((s9 >>> 61) & BITS_1_MASK);
      decompressed[outOffset+58] = (int) ((s9 >>> 62) & BITS_1_MASK);
      decompressed[outOffset+59] = (int) ((s9 >>> 63) & BITS_1_MASK);
      return 60;
    default:
      throw new IllegalArgumentException("Unknown Simple9 status: " + (s9 >>> NUM_DATA_BITS));
    }
  }

  public void compress() {
    int encoded;

    compressedSize = 0;
    while (unComprSize > 0) {
      encoded = this.compressSingle(unCompressedData, offset, unComprSize, compressedBuffer, compressedSize);
      offset += encoded;
      unComprSize -= encoded;
      compressedSize++;
    }
    compressedSize <<= 3;
  }

  public void decompress() {
    int totalOut = 0;

    blockPosition = 0;
    while (unComprSize > 0) {
      final int decoded = this.decompressSingle(compressedBuffer.get(blockPosition), unCompressedData, totalOut);
      blockPosition += 1;
      unComprSize -= decoded;
      totalOut += decoded;
    }
  }

}
