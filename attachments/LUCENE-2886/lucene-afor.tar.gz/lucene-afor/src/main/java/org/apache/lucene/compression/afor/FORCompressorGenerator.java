/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.afor;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FORCompressorGenerator {

  private FileWriter writer;

  public FORCompressorGenerator() throws IOException {
  }

  public void generate(final File file) throws IOException {
    writer = new FileWriter(file);
    writer.append(FILE_HEADER); writer.append('\n');
    this.generateClass();
    writer.close();
  }

  protected void generateClass() throws IOException {
    writer.append("public class FORCompressor {\n\n");
    this.generateFrameSizeTable();
    this.generateTable();
    this.generateAbstractInnerClass();
    for (int i = 1; i <= 32; i++) {
      this.generateInnerClass(i);
    }
    writer.append("}\n");
  }

  protected void generateFrameSizeTable() throws IOException {
    writer.append("  public static final int[] frameSizes = new int[] { ");
    int frameSize = 0;
    for (int i = 0; i < 32; i++) {
      frameSize += 4;
      writer.append(Integer.toString(frameSize));
      if (i != 31) writer.append(",");
    }
    writer.append("  };\n\n");
  }

  protected void generateTable() throws IOException {
    writer.append("  public static final FrameCompressor[] compressors = new FrameCompressor[] {\n");
    for (int i = 1; i <= 32; i++) {
      writer.append("    new FrameCompressor"+i+"()");
      if (i != 32) writer.append(",");
      writer.append('\n');
    }
    writer.append("  };\n\n");
  }

  protected void generateAbstractInnerClass() throws IOException {
    writer.append("  public static abstract class FrameCompressor {\n");
    writer.append("    public abstract void compress(int[] unCompressedData, int offset, byte[] compressedArray, int outputOffset);\n");
    writer.append("  }\n\n");
  }

  protected void generateInnerClass(final int numFramebits) throws IOException {
    writer.append("  public static final class FrameCompressor" + Integer.toString(numFramebits) + " extends FrameCompressor {\n");
    this.generateMethod(numFramebits);
    writer.append("  }\n\n");
  }

  protected void generateMethod(final int numFrameBits) throws IOException {
    writer.append("    public final void compress(int[] unCompressedData, int offset, byte[] compressedArray, int outputOffset) {\n");
    this.generateIntValues();
    if (numFrameBits <= 8) {
      this.generateInstructions1to8(numFrameBits);
    }
    else {
      this.generateInstructions9to32(numFrameBits);
    }
    writer.append("    }\n");
  }

  protected void generateIntValues() throws IOException {
    for (int i = 0; i < 32; i += 2) {
      writer.append("      ");
      writer.append("int intValues"+i+" = unCompressedData[offset + "+i+"], ");
      writer.append("intValues"+(i+1)+" = unCompressedData[offset + "+(i+1)+"];\n");
    }
    writer.append("\n");
  }

  protected void generateInstructions1to8(final int numFrameBits) throws IOException {
    int intPtr = 0;
    int bytePtr = 0;
    boolean first = true;
    int shift = 8;

    while (intPtr != 32) { // while we didn't process 32 integers
      while (shift >= numFrameBits) { // while shift is inferior to numFrameBits,
        shift -= numFrameBits;
        if (!first) { // if not first instruction, just add indentation and logic or
          writer.append("\n                                                | ");
        }
        else { // if first instruction, add byte array assignment
          writer.append("      compressedArray[outputOffset + "+bytePtr+"] = (byte) (");
          first = false;
        }
        if (shift == 0) { // if shift == 0, we do not have to add it
          writer.append("(intValues"+intPtr+" & "+((1 << numFrameBits) - 1)+")");
        }
        else {
          writer.append("((intValues"+intPtr+" & "+((1 << numFrameBits) - 1)+") << "+shift+")");
        }
        intPtr++;
      }

      if (shift > 0) { // when shift is inferior to numFrameBits and not equal to 0, special case.
        final int remainingBits = numFrameBits - shift;
        writer.append("\n                                                | ");
        writer.append("((intValues"+intPtr+" >>> "+remainingBits+") & 0xFF));\n");
        bytePtr++;
        shift = 8 - remainingBits;
        writer.append("      compressedArray[outputOffset + "+bytePtr+"] = (byte) (");
        writer.append("((intValues"+intPtr+" & "+((1 << remainingBits) - 1)+") << "+shift+")");
        intPtr++;
      }
      else {
        writer.append(");\n");
        bytePtr++;
        shift = 8;
        first = true;
      }
    }
  }

  protected void generateInstructions9to32(final int numFrameBits) throws IOException {
    int intPtr = 0;
    int bytePtr = 0;
    int shift = numFrameBits;

    while (intPtr != 32) { // while we didn't process 32 integers
      while (shift > 8) { // while the shift is superior to the size of a byte
        shift -= 8;
        writer.append("      compressedArray[outputOffset + "+bytePtr+"] = (byte) ((intValues"+intPtr+" >>> "+shift+") & 0xFF);\n");
        bytePtr++; // increment the byte pointer
      }
      // if shift == 8, we just have to copy the less significant byte of the integer
      if (shift == 8) {
        writer.append("      compressedArray[outputOffset + "+bytePtr+"] = (byte) (intValues"+intPtr+" & 0xFF);\n");
        bytePtr++;
        intPtr++;
        shift = numFrameBits;
      }
      else {
        // If the shift is less than 8 (size of byte), special case with two
        // integers.
        writer.append("      compressedArray[outputOffset + "+bytePtr+"] = (byte) ((intValues"+intPtr+" & "+((1 << shift) - 1)+") << "+(8 - shift)+"\n");
        intPtr++; // increment the integer pointer for the next instruction
        writer.append("                                                | ");
        writer.append("(intValues"+intPtr+" >>> "+(numFrameBits - (8 - shift))+") & 0xFF);\n");
        bytePtr++; // increment byte pointer
        shift = numFrameBits - (8 - shift); // set shift to numFrameBits minus the number of bits shifted in the last instruction
      }
    }
  }

  private static final String FILE_HEADER = "package org.apache.lucene.compression.afor;\n" +
  "/**\n" +
  " * Copyright 2009, Renaud Delbru\n" +
  " *\n" +
  " * Licensed under the Apache License, Version 2.0 (the \"License\");\n" +
  " * you may not use this file except in compliance with the License.\n" +
  " * You may obtain a copy of the License at\n" +
  " *\n" +
  " *    http://www.apache.org/licenses/LICENSE-2.0\n" +
  " *\n" +
  " * Unless required by applicable law or agreed to in writing,\n" +
  " * software distributed under the License is distributed on an\n" +
  " * \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n" +
  " * KIND, either express or implied.  See the License for the\n" +
  " * specific language governing permissions and limitations\n" +
  " * under the License.\n" +
  " */\n" +
  "/* This program is generated, do not modify. See FORCompressorGenerator.java */\n";

  /**
   * @param args
   * @throws IOException
   */
  public static void main(final String[] args) throws IOException {
    final File file = new File("./src/main/java/org/apache/lucene/compression/afor",
                         "FORCompressor.java");
    final FORCompressorGenerator generator = new FORCompressorGenerator();
    generator.generate(file);
  }

}
