/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.afor;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class AFOR2DecompressorGenerator {

  private FileWriter writer;
  public static final int[] frameSizes = new int[96];
  private final int[] MASK = { 0x00000000, 0x00000001, 0x00000003, 0x00000007, 0x0000000f, 0x0000001f, 0x0000003f,
                               0x0000007f, 0x000000ff, 0x000001ff, 0x000003ff, 0x000007ff, 0x00000fff, 0x00001fff,
                               0x00003fff, 0x00007fff, 0x0000ffff, 0x0001ffff, 0x0003ffff, 0x0007ffff, 0x000fffff,
                               0x001fffff, 0x003fffff, 0x007fffff, 0x00ffffff, 0x01ffffff, 0x03ffffff, 0x07ffffff,
                               0x0fffffff, 0x1fffffff, 0x3fffffff, 0x7fffffff, 0xffffffff };

  public AFOR2DecompressorGenerator() throws IOException {
    this.generateFrameSizeTable();
  }

  protected void generateFrameSizeTable() throws IOException {
    int frameSize = 0;
    for (int i = 0; i < 32; i++) {
      frameSize += 4;
      frameSizes[i] = frameSize;
    }
    frameSize = 0;
    for (int i = 0; i < 32; i++) {
      frameSize += 2;
      frameSizes[i+32] = frameSize;
    }
    frameSize = 0;
    for (int i = 0; i < 32; i++) {
      frameSizes[i+64] = i + 1;
    }
  }

  public void generate(final File file) throws IOException {
    writer = new FileWriter(file);
    writer.append(FILE_HEADER); writer.append('\n');
    this.generateClass();
    writer.close();
  }

  protected void generateClass() throws IOException {
    writer.append("public class AFOR2Decompressor {\n\n");
    this.generateTable();
    this.generateAbstractInnerClass();
    for (int i = 1; i <= 96; i++) {
      this.generateInnerClass(i);
    }
    writer.append("}\n");
  }

  protected void generateTable() throws IOException {
    writer.append("  public static final FrameDecompressor[] decompressors = new FrameDecompressor[] {\n");
    for (int i = 1; i <= 96; i++) {
      writer.append("    new FrameDecompressor"+i+"(),\n");
    }
    writer.append("  };\n\n");
  }

  protected void generateAbstractInnerClass() throws IOException {
    writer.append("  public static abstract class FrameDecompressor {\n");
    writer.append("    public abstract void decompress(final AbstractFrameOfRef frameOfRef);\n");
    writer.append("  }\n\n");
  }

  protected void generateInnerClass(final int numFramebits) throws IOException {
    writer.append("  public static final class FrameDecompressor" + Integer.toString(numFramebits) + " extends FrameDecompressor {\n");
    this.generateMethod(numFramebits);
    writer.append("  }\n\n");
  }

  private void generate1To7Routines(final int numFrameBits)
  throws IOException {
    final int mask = (1 << numFrameBits) - 1;
    int shift = 8;
    int bytePtr = 0, intPtr = 0;

    this.generateByteValues(numFrameBits*2);

    while (intPtr != 16) { // while we didn't process 16 integers
      while (shift >= numFrameBits) {
        shift -= numFrameBits;
        writer.append("      ");
        if (shift == 0) {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = i"+bytePtr+" & "+mask+";\n");
        }
        else {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = (i"+bytePtr+" >>> "+shift+") & "+mask+";\n");
        }
        intPtr++;
      }

      if (shift > 0) {
        writer.append("      ");
        writer.append("unCompressedData[outOffset + "+intPtr+"] = ((i"+bytePtr+" & "+((1 << shift) - 1)+") << "+(numFrameBits - shift)+")");
        bytePtr++;
        shift = 8 - (numFrameBits - shift);
        writer.append(" | (i"+bytePtr+" >>> "+shift+") & "+((1 << (8 - shift)) - 1)+";\n");
        intPtr++;
      }
      else {
        bytePtr++;
        shift = 8;
      }
    }
    this.generateMethodFooter(numFrameBits + 32);
  }

  private void generate816Routines(final int numFrameBits) throws IOException {
    for (int i = 0, j = 0; j < 16; ) {
      if (i == 0)
        writer.append("      unCompressedData[outOffset] = " + (numFrameBits == 8 ? "compressedArray[inOffset] & 0xFF" :
                                                                                      "((compressedArray[inOffset] & 0xFF) << 8) | (compressedArray[inOffset + 1] & 0xFF)") + ";\n");
      else
        writer.append("      unCompressedData[outOffset + " + j + "] = " + (numFrameBits == 8 ? "compressedArray[inOffset + " + i + "] & 0xFF" :
                                                                                                  "((compressedArray[inOffset + " + i + "] & 0xFF) << 8) | (compressedArray[inOffset + " + (i+1) +"] & 0xFF)") + ";\n");
      if (numFrameBits == 16)
          i += 2;
      else
          i++;
      j++;
    }
    this.generateMethodFooter(numFrameBits + 32);
    writer.append("    }\n");
  }

  protected void generateMethod(final int numFrameBits) throws IOException {
    writer.append("    public final void decompress(final AbstractFrameOfRef frameOfRef) {\n");
    this.generateMethodHeader(numFrameBits);
    // for bits < 7, use byte variables
    if (numFrameBits <= 39 && numFrameBits > 32) {
      this.generate1To7Routines(numFrameBits - 32);
      writer.append("    }\n");
      return;
    }
    // 8 and 16 BFS special case
    if (numFrameBits == 40 || numFrameBits == 48) {
      this.generate816Routines(numFrameBits - 32);
      return;
    }
    if (numFrameBits <= 32)
      this.generateIntValues(numFrameBits);
    else if (numFrameBits <= 64)
      this.generateShortValues(numFrameBits - 32);
    else
      this.generateByteValues(numFrameBits-64);
    if (numFrameBits <= 32)
      this.generateInstructions32(numFrameBits);
    else if (numFrameBits <= 64)
      this.generateInstructions16(numFrameBits - 32);
    else
      this.generateInstructions8(numFrameBits - 64);
    this.generateMethodFooter(numFrameBits);
    writer.append("    }\n");
  }

  protected void generateMethodFooter(final int numFrameBits) throws IOException {
    writer.append("      ");
    writer.append("frameOfRef.index += " + (1 + frameSizes[numFrameBits - 1]) + ";\n");
    writer.append("      ");
    if (numFrameBits <= 32)
      writer.append("frameOfRef.offset += 32;\n");
    else if (numFrameBits <= 64)
      writer.append("frameOfRef.offset += 16;\n");
    else
      writer.append("frameOfRef.offset += 8;\n");
  }

  protected void generateMethodHeader(final int numFrameBits) throws IOException {
    writer.append("      ");
    writer.append("final int[] unCompressedData = frameOfRef.unCompressedData;\n");
    writer.append("      ");
    writer.append("final byte[] compressedArray = frameOfRef.compressedArray;\n");
    writer.append("      ");
    writer.append("final int inOffset = frameOfRef.index + 1;\n");
    writer.append("      ");
    writer.append("final int outOffset = frameOfRef.offset;\n");
  }

  protected void generateIntValues(final int numFrameBits) throws IOException {
    for (int i = 0, j = 0; i < numFrameBits; i++, j += 4) {
      writer.append("      ");
      writer.append("final int i"+i+" = ((compressedArray[inOffset + "+j+"] & 0xFF) << 24) | ");
      writer.append("((compressedArray[inOffset + "+(j+1)+"] & 0xFF) << 16) | ");
      writer.append("((compressedArray[inOffset + "+(j+2)+"] & 0xFF) << 8) | ");
      writer.append("((compressedArray[inOffset + "+(j+3)+"] & 0xFF));\n");
    }
    writer.append("\n");
  }

  protected void generateByteValues(final int numFrameBits) throws IOException {
    for (int i = 0; i < numFrameBits; i++) {
      writer.append("      final byte i" + i + " = compressedArray[inOffset + " + i + "];\n");
    }
    writer.append("\n");
  }

  protected void generateShortValues( final int numFrameBits )
  throws IOException
  {
    for ( int i = 0, j = 0; i < numFrameBits; i++, j += 2 )
    {
      writer.append( "      " );
      writer.append( "final short i" + i + " = (short) (((compressedArray[inOffset + " + j + "] & 0xFF) << 8) | " );
      writer.append( "((compressedArray[inOffset + " + ( j + 1 ) + "] & 0xFF)));\n" );
    }
    writer.append( "\n" );
  }

  protected void generateInstructions32(final int numFrameBits) throws IOException {
    final int mask = (1 << numFrameBits) - 1;
    int shift = 32;
    int bytePtr = 0, intPtr = 0;

    while (intPtr != 32) { // while we didn't process 32 integers
      while (shift >= numFrameBits) {
        shift -= numFrameBits;
        writer.append("      ");
        if (shift == 0 && mask != 0) {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = i"+bytePtr+" & "+mask+";\n");
        }
        else if (shift == 0 && mask == 0) {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = i"+bytePtr+";\n");
        }
        else if (shift + numFrameBits == 32) {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = (i"+bytePtr+" >>> "+shift+");\n");
        }
        else {
          writer.append("unCompressedData[outOffset + "+intPtr+"] = (i"+bytePtr+" >>> "+shift+") & "+mask+";\n");
        }
        intPtr++;
      }

      if (shift > 0) {
        writer.append("      ");
//        writer.append("unCompressedData[outOffset + "+intPtr+"] = ((i"+bytePtr+" & "+((1 << shift) - 1)+") << "+(numFrameBits - shift)+")");
        writer.append("unCompressedData[outOffset + "+intPtr+"] = ((i"+bytePtr+" << "+(numFrameBits - shift)+")");
        bytePtr++;
        shift = 32 - (numFrameBits - shift);
//         writer.append(" | (i"+bytePtr+" >>> "+shift+") & "+((1 << (32 - shift)) - 1)+";\n");
        writer.append(" | (i"+bytePtr+" >>> "+shift+")) & "+mask+";\n");
        intPtr++;
      }
      else {
        bytePtr++;
        shift = 32;
      }
    }
  }

  protected void generateInstructions8(final int numFrameBits) throws IOException {
    final int mask = (1 << numFrameBits) - 1;
    int shift = 8;
    int bytePtr = 0, intPtr = 0;

    while (intPtr < 8) {
      while (shift >= numFrameBits) {
        shift -= numFrameBits;
        writer.append("      ");
        if (shift == 0 && mask != 0) {
          writer.append("unCompressedData[outOffset + " + intPtr + "] = i" + bytePtr + " & " + mask + ";\n");
        } else if (shift == 0 && mask == 0) {
          writer.append("unCompressedData[outOffset + " + intPtr + "] = i" + bytePtr + ";\n");
        }
        else {
          writer.append("unCompressedData[outOffset + " + intPtr + "] = (i" + bytePtr + " >>> " + shift + ") & " + mask + ";\n");
        }
        intPtr++;
      }

      if (shift > 0) {
        writer.append("      ");
        writer.append("unCompressedData[outOffset + " + intPtr + "] = ((i" + bytePtr + " << " + (numFrameBits - shift) + ")");
        bytePtr++;
        shift = 8 - (numFrameBits - shift);
        if (shift >= 0) {
          if (mask == 0)
            writer.append(" | (i" + bytePtr + " >>> " + shift + " & " + MASK[8 - shift] + "));\n");
          else
            writer.append(" | (i" + bytePtr + " >>> " + shift + " & " + MASK[8 - shift] + ")) & " + mask + ";\n");
        }
        else {
          writer.append(" | (i" + bytePtr + " << " + (-shift) + " & " + MASK[8 - shift] + ")");
          while (shift + 8 < 0) {
            writer.append(" | (i" + (++bytePtr) + " << " + (-8 - shift) + " & " + MASK[-shift] + ")");
            shift += 8;
          }
          if (mask == 0)
            writer.append(" | (i" + (bytePtr + 1) + " >>> " + (8 + shift) + " & " + MASK[-shift] + "));\n");
          else
            writer.append(" | (i" + (bytePtr + 1) + " >>> " + (8 + shift) + " & " + MASK[-shift] +  ")) & " + mask + ";\n");
        }
        intPtr++;
      } else {
        bytePtr++;
        shift += 8;
      }
    }
  }

  protected void generateInstructions16(final int numFrameBits) throws IOException {
    final int mask = ( 1 << numFrameBits ) - 1;
    int shift = 16;
    int bytePtr = 0, intPtr = 0;

    while ( intPtr < 16 ) {
      while ( shift >= numFrameBits ) {
        shift -= numFrameBits;
        writer.append( "      " );
        if ( shift == 0 && mask != 0 )
        {
          writer.append( "unCompressedData[outOffset + " + intPtr + "] = i" + bytePtr + " & " + mask + ";\n" );
        }
        else if ( shift == 0 && mask == 0 )
        {
          writer.append( "unCompressedData[outOffset + " + intPtr + "] = i" + bytePtr + ";\n" );
        }
        else {
          writer.append( "unCompressedData[outOffset + " + intPtr + "] = (i" + bytePtr + " >>> " + shift + ") & " + mask + ";\n" );
        }
        intPtr++;
      }

      if ( shift > 0 ) {
        writer.append( "      " );
        writer.append( "unCompressedData[outOffset + " + intPtr + "] = ((i" + bytePtr + " << " + ( numFrameBits - shift ) + ")" );
        bytePtr++;
        shift = 16 - ( numFrameBits - shift );
        if ( shift >= 0 )
        {
          if ( mask == 0 )
            writer.append( " | (i" + bytePtr + " >>> " + shift + " & " + MASK[16 - shift] + "));\n" );
          else
            writer.append( " | (i" + bytePtr + " >>> " + shift + " & " + MASK[16 - shift] + ")) & " + mask + ";\n" );
        }
        else {
          if ( mask == 0 )
            writer.append( " | (i" + bytePtr + " << " + ( -shift ) + " & " + MASK[16 - shift] + ") | (i" + ( bytePtr + 1 ) + " >>> " + ( 16 + shift ) + " & " + MASK[-shift] + "));\n" );
          else
            writer.append( " | (i" + bytePtr + " << " + ( -shift ) + " & " + MASK[16 - shift] + ") | (i" + ( bytePtr + 1 ) + " >>> " + ( 16 + shift ) + " & " + MASK[-shift] + ")) & " + mask + ";\n" );
        }
        intPtr++;
      }
      else {
        bytePtr++;
        shift += 16;
      }
    }
  }

  private static final String FILE_HEADER = "package org.apache.lucene.compression.afor;\n" +
  "/**\n" +
  " * Copyright 2010, Renaud Delbru\n" +
  " *\n" +
  " * Licensed under the Apache License, Version 2.0 (the \"License\");\n" +
  " * you may not use this file except in compliance with the License.\n" +
  " * You may obtain a copy of the License at\n" +
  " *\n" +
  " *    http://www.apache.org/licenses/LICENSE-2.0\n" +
  " *\n" +
  " * Unless required by applicable law or agreed to in writing,\n" +
  " * software distributed under the License is distributed on an\n" +
  " * \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n" +
  " * KIND, either express or implied.  See the License for the\n" +
  " * specific language governing permissions and limitations\n" +
  " * under the License.\n" +
  " */\n" +
  "/* This program is generated, do not modify. See AFOR2DecompressorGenerator.java */\n";

  /**
   * @param args
   * @throws IOException
   */
  public static void main(final String[] args) throws IOException {
    final File file = new File("./src/main/java/org/apache/lucene/compression/afor", "AFOR2Decompressor.java");
    final AFOR2DecompressorGenerator generator = new AFOR2DecompressorGenerator();
    generator.generate(file);
  }

}
