/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.simple;

import java.io.IOException;
import java.nio.ByteBuffer;

import org.apache.lucene.index.codecs.intblock.FixedIntBlockIndexOutput;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.util.CodecUtil;

public class Simple64IndexOutput extends FixedIntBlockIndexOutput {

	public final static String CODEC = "Simple98b";
	public final static int VERSION_START = 0;
	public final static int VERSION_CURRENT = VERSION_START;
	private final Simple64 compressor;
	private final byte[] output;

	public Simple64IndexOutput(final Directory dir, final String fileName,
			final int blockSize, final Simple64 c) throws IOException {
		final IndexOutput out = dir.createOutput(fileName);
		CodecUtil.writeHeader(out, CODEC, VERSION_CURRENT);
		this.init(out, blockSize);

		compressor = c;
		final ByteBuffer byteBuffer = ByteBuffer.allocate(blockSize * 8);
		output = byteBuffer.array();
		compressor.setCompressedBuffer(byteBuffer.asLongBuffer());
	}

	@Override
	protected void flushBlock(final int[] buffer, final IndexOutput out)
	throws IOException {
    compressor.setUnCompressedData(buffer, 0, buffer.length);
    compressor.compress();
    final int numBytes = compressor.compressedSize();
    out.writeVInt(numBytes);
    out.writeBytes(output, numBytes);
	}

}
