/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.pfor;

import org.apache.lucene.compression.afor.FORCompressor.FrameCompressor;

/**
 * Patched Frame of Reference PFOR compression/decompression.
 * <p>
 * As defined in:<br>
 * Super-Scalar RAM-CPU Cache Compression<br>
 * Marcin Zukowski, Sándor Héman, Niels Nes, Peter Boncz, 2006.<br>
 * with extensions from:<br>
 * Performance of Compressed Inverted List Caching in Search Engines<br>
 * Jiangong Zhang, Xiaohui Long, Torsten Suel, 2008.<br>
 * <p>
 * This class does not provide delta coding because the lucene index structures
 * already have that.
 * <p>
 * The implementation uses 0 as lower bound for the frame, so small positive
 * integers will be most effectively compressed.
 * <p>
 * Some optimized code is used for decompression, see class ForDecompress and
 * its subclasses. <br>
 * Good decompression performance will depend on the performance of
 * java.nio.IntBuffer indexed get() methods. <br>
 * Use of the -server option helps performance for the Sun 1.6 jvm under Linux.
 * <p>
 * The start point of first exception is at its natural boundary: 2 byte
 * exceptions at even byte position, 4 byte at quadruple.
 * <p>
 * To be done:
 * <ul>
 * <li>Optimize compression code.
 * <li>IntBuffer.get() is somewhat faster that IntBuffer.get(index), adapt
 * (de)compression for to use the relative get() method.
 * <li>Check javadoc generation and generated javadocs. Add javadoc code
 * references.
 * </ul>
 */
public class PFORNC extends FOR {

  /** How to encode PFor exceptions: 0: byte, 1: short, 2:int, unused: 3: long */
  private int exceptionCode = -1;

  /** Total number of exception values */
  private int numExceptions;

  /** Create a PFor compressor/decompressor. */
  public PFORNC() {
    super();
    HEADER_SIZE = 4;
    BLOCK_INDEX = HEADER_INDEX + HEADER_SIZE;
  }

  /**
   * Compress the decompressed data into the buffer. Should only be used after
   * setUnCompressedData(). <br>
   * When setCompressBuffer() was not done, no actual compression is done.
   * Regardless of the use of setCompressBuffer(), bufferByteSize() will return
   * a valid value after calling compress().
   * <p>
   * When a buffer is available, the following is done. A header is stored into
   * the buffer, encoding a.o. numFrameBits and unComprSize. All ints <
   * 2**numFrameBits are stored sequentially in compressed form in the buffer.
   * All other ints are stored in the buffer as exceptions after the compressed
   * sequential ints, using 1, 2 or 4 bytes per exception, starting at the first
   * byte after the compressed sequential ints. <br>
   * The index of the first exception is encoded in the header in the buffer,
   * all later exceptions have the offset to the next exception as their value,
   * the last one offset to just after the available input size. After the first
   * exception, when the next exception index does not fit in numFrameBits bits,
   * an exception after 2**numFrameBits inputs is forced and inserted. <br>
   * Exception values are stored in the order of the exceptions. The number of
   * bytes used for an exception is also encoded in the header. This depends on
   * the maximum exception value and does not vary between the exceptions.
   */
  @Override
  public void compress(final int numFrameBits) {
    this.numFrameBits = numFrameBits;

    final int maxCode = (int) ((1L << numFrameBits) - 1);
    final int[] data = new int[unComprSize];
    final int[] miss = new int[unComprSize];

    // LOOP1: Find exceptions
    int j = 0;
    for (int i = 0; i < unComprSize; i++) {
      final int v = unCompressedData[i + offset];
      data[i] = v;
      miss[j] = i;
      j += v > maxCode ? 1 : 0;
    }

    // Only the first j-1 exception index in miss are valid, the last one is
    // not an exception index
    final int[] exceptions = new int[j];

    // LOOP2: Create patchlist
    for (int i = 0; i < j; i++) {
      // TODO: Use the empty exception slot to store the lower bits of the exception
//      exceptions[i] = data[miss[i]] >> numFrameBits;
//      data[miss[i]] = data[miss[i]] & MASK[numFrameBits];
      exceptions[i] = data[miss[i]];
      data[miss[i]] = 0;
    }

    // Compress Data
    final FrameCompressor compressor = FOR.compressors[numFrameBits - 1];
    int outputOffset = BLOCK_INDEX;
    for (int i = 0; i < unComprSize; i += 32) {
      compressor.compress(data, i, compressedArray, outputOffset);
      outputOffset += FOR.frameSizes[numFrameBits - 1];
    }

    // Encode the exceptions
    this.encodeExceptions(exceptions, miss);

    // Encode information in the header the first value of data contains the first exception index
    this.encodeHeader(unComprSize);
  }

  /**
   * Return the number of exceptions. Only valid after compress() or
   * decompress().
   */
  public int getNumExceptions() {
    return numExceptions;
  }

  private int compressedArrayByteSize() {
    final int compressedArrayBits = unComprSize * numFrameBits;
    return (compressedArrayBits + 7) >> 3;
  }

  /**
   * Return the number of bytes used in the byte array. Only valid after
   * compress() or decompress().
   */
  @Override
  public int compressedSize() {
    return compressedSize;
  }

  /**
   * Store the Exception according to the exception code, and the index delta on 2 bytes
   * @param exceptionValues
   * @param exceptionIndexes
   */
  private final void encodeExceptions(final int[] exceptionValues, final int[] exceptionIndexes) {
    if ((numExceptions = exceptionValues.length) == 0) {
      this.compressedSize = BLOCK_INDEX + this.compressedArrayByteSize();
      return;
    }
    int excByteOffset = this.compressedArrayByteSize();
    int lastMiss = 0;
    exceptionCode = this.getExceptionCode(exceptionValues);

    switch (exceptionCode) {
      case 0: { // 1 byte exceptions
        int i = 0;
        do {
          final int excOffset = BLOCK_INDEX + excByteOffset;
          final int delta = exceptionIndexes[i] - lastMiss;
          compressedArray[excOffset] = (byte) exceptionValues[i];
          compressedArray[excOffset + 1] = (byte) ((delta >>> 8) & 0xFF);
          compressedArray[excOffset + 2] = (byte) (delta & 0xFF);
          lastMiss = exceptionIndexes[i];
          excByteOffset += 3;
        } while (++i < numExceptions);
      }
      break;

      case 1: { // 2 byte exceptions
        int i = 0;
        do {
          final int excOffset = BLOCK_INDEX + excByteOffset;
          final int delta = exceptionIndexes[i] - lastMiss;
          compressedArray[excOffset] = (byte) ((exceptionValues[i] >> 8) & 0xFF);
          compressedArray[excOffset + 1] = (byte) (exceptionValues[i] & 0xFF);
          compressedArray[excOffset + 2] = (byte) ((delta >>> 8) & 0xFF);
          compressedArray[excOffset + 3] = (byte) (delta & 0xFF);
          lastMiss = exceptionIndexes[i];
          excByteOffset += 4;
        } while (++i < numExceptions);
      }
      break;

      case 2: { // 4 byte exceptions
        int i = 0;
        do {
          final int excOffset = BLOCK_INDEX + excByteOffset;
          final int delta = exceptionIndexes[i] - lastMiss;
          compressedArray[excOffset] = (byte) ((exceptionValues[i] >>> 24) & 0xFF);
          compressedArray[excOffset + 1] = (byte) ((exceptionValues[i] >>> 16) & 0xFF);
          compressedArray[excOffset + 2] = (byte) ((exceptionValues[i] >>> 8) & 0xFF);
          compressedArray[excOffset + 3] = (byte) (exceptionValues[i] & 0xFF);
          compressedArray[excOffset + 4] = (byte) ((delta >>> 8) & 0xFF);
          compressedArray[excOffset + 5] = (byte) (delta & 0xFF);
          lastMiss = exceptionIndexes[i];
          excByteOffset += 6;
        } while (++i < numExceptions);
      }
      break;
    }
    this.compressedSize = excByteOffset + BLOCK_INDEX;
  }

  private final int getExceptionCode(final int[] exceptions) {
    int maxException = 0;
    int code = 0;
    for (final int exception : exceptions) {
      maxException = (exception > maxException) ? exception : maxException;
    }
    if (maxException < (1 << 8)) { // exceptions as byte
      code = 0;
    }
    else if (maxException < (1 << 16)) { // exceptions as 2 bytes
      code = 1;
    }
    else /* if (maxException < (1L << 32)) */{ // exceptions as 4 bytes
      code = 2;
    }
    return code;
  }

  /**
   * Decode the exception values while going through the exception chain. <br>
   * For performance, delegate/subclass this to classes with fixed
   * exceptionCode. <br>
   * Also, decoding exceptions is preferably done from an int border instead of
   * from a random byte directly after the compressed array. This will allow
   * faster decoding of exceptions, at the cost of at most 3 bytes. <br>
   * When ((numFrameBits * unComprSize) % 32) == 0, this cost will always be
   * zero bytes so specialize for these cases.
   */
  private void patchExceptions() {
    if (numExceptions == 0) {
      return;
    }
    int excByteOffset = this.compressedArrayByteSize();
    int lastMiss = 0;

    switch (exceptionCode) {
      case 0: { // 1 byte exceptions
        for (int i = 0; i < numExceptions; i++) {
          final int excOffset = BLOCK_INDEX + excByteOffset;
          lastMiss += (((compressedArray[excOffset + 1] & 0xFF) << 8)
                      | (compressedArray[excOffset + 2] & 0xFF));
          unCompressedData[lastMiss] = (compressedArray[excOffset] & 0xFF);
          excByteOffset += 3;
        }
      }
      break;

      case 1: { // 2 byte exceptions
        for (int i = 0; i < numExceptions; i++) {
          final int excOffset = BLOCK_INDEX + excByteOffset;
          lastMiss += (((compressedArray[excOffset + 2] & 0xFF) << 8)
                      | (compressedArray[excOffset + 3] & 0xFF));
          unCompressedData[lastMiss] = (((compressedArray[excOffset] & 0xFF) << 8) |
                                          (compressedArray[excOffset + 1] & 0xFF));
          excByteOffset += 4;
        }
      }
      break;

      case 2: // 4 byte exceptions
        for (int i = 0; i < numExceptions; i++) {
          final int excOffset = BLOCK_INDEX + excByteOffset;
          lastMiss += (((compressedArray[excOffset + 4] & 0xFF) << 8)
                      | (compressedArray[excOffset + 5] & 0xFF));
          unCompressedData[lastMiss] = (((compressedArray[excOffset] & 0xFF) << 24) |
                                        ((compressedArray[excOffset + 1] & 0xFF) << 16) |
                                        ((compressedArray[excOffset + 2] & 0xFF) << 8) |
                                        (compressedArray[excOffset + 3] & 0xFF));
          excByteOffset += 6;
        }
        break;
    }
  }

  /**
   * The 4 byte header (32 bits) contains: - 16 bits unused - 5 bits for
   * (numFrameBits-1) - 2 bits for the exception code: 0b00: byte, 0b01: short,
   * 0b10: int, 0b11: long (unused). - 1 bit unused - 8 bits for the index of
   * the first exception + 1, (0 when no exceptions)
   */
  private void encodeHeader(final int unComprSize) {
    // TODO: When polishing the code, just use 1 byte to store numFrameBits and exceptionCode
//    compressedArray[HEADER_INDEX] = (byte) ((numFrameBits - 1) | (exceptionCode << 5));
    compressedArray[HEADER_INDEX] = (byte) (exceptionCode);
    compressedArray[HEADER_INDEX + 1] = (byte) (numFrameBits - 1);
    compressedArray[HEADER_INDEX + 2] = (byte) ((numExceptions >>> 8) & 0xFF);
    compressedArray[HEADER_INDEX + 3] = (byte) (numExceptions & 0xFF);
  }

  @Override
  protected void decodeHeader() {
//    exceptionCode = (compressedArray[HEADER_INDEX] >> 5) & 3;
//    numFrameBits = (compressedArray[HEADER_INDEX] & 31) + 1;
    exceptionCode = compressedArray[HEADER_INDEX];
    numFrameBits = (compressedArray[HEADER_INDEX + 1] & 31) + 1;
    numExceptions = (((compressedArray[HEADER_INDEX + 2] & 0xFF) << 8)
                    | (compressedArray[HEADER_INDEX + 3] & 0xFF));
  }

  /** Decompress from the buffer into output from a given offset. */
  @Override
  public void decompress() {
    // LOOP1: decode frame - bit-unpack the values
    super.decompress();
    // Decode exceptions

    // LOOP2: Patch
    this.patchExceptions();
  }

  /**
   * Determine the number of frame bits to be used for compression. Use only
   * after setUnCompressedData(). This is done by taking a copy of the input,
   * sorting it and using this to determine the compressed size for each
   * possible numbits in a single pass, ignoring forced exceptions. Finally an
   * estimation of the number of forced exceptions is reduced to less than 1 in
   * 32 input numbers by increasing the number of frame bits. This
   * implementation works by determining the total number of bytes needed for
   * the compressed data, but does take into account alignment of exceptions at
   * 2 or 4 byte boundaries.
   */
  @Override
  public int frameBitsForCompression() {
    long avgNonNegVal = 0;
    int minNonNegVal = Integer.MAX_VALUE, maxNonNegVal = Integer.MIN_VALUE;
    for (int i = offset; i < (offset + unComprSize); i++) {
      final int v = unCompressedData[i];
      avgNonNegVal += v;
      if (v > maxNonNegVal) {
        maxNonNegVal = v;
      }
      if (v < minNonNegVal) {
        minNonNegVal = v;
      }
    }
    avgNonNegVal = avgNonNegVal >> 5; // division by 32

    final int avgFrameBits = this.logNextHigherPowerOfTwo(avgNonNegVal) + 1;
    final int minFrameBits = this.logNextHigherPowerOfTwo(minNonNegVal) + 1;
    final int maxFrameBits = this.logNextHigherPowerOfTwo(maxNonNegVal) + 1;

    return this.getBestFrameBits(offset, minFrameBits, maxFrameBits, avgFrameBits);
  }

  protected int getTotalBytes(final int offset, final int frameBits) {
    final int bytesForFrame = (32 * frameBits + 7) / 8;
    int totalBytes = bytesForFrame;
    final int maxCode = (1 << frameBits);
    for (int i = offset; i < (offset + 32); i++) {
      totalBytes += (unCompressedData[i] >= maxCode) ? 1 : 0;
    }
    return totalBytes;
  }

  protected int getBestFrameBits(final int offset, final int minFrameBits,
                                 final int maxFrameBits, final int avgFrameBits) {
    final int nFrameBits = maxFrameBits - minFrameBits + 1;
    final int[] totalBytes = new int[nFrameBits];
    final int[] maxCodes = new int[nFrameBits];
    final int bytesPerException = (maxFrameBits < 8) ? 1 : (maxFrameBits < 16) ? 2 : 4;

    for (int i = 0, frameBits = minFrameBits; frameBits <= maxFrameBits; i++, frameBits++) {
      totalBytes[i] = (32 * frameBits + 7) / 8; // compute bytesForFrame
      maxCodes[i] = (1 << frameBits);
    }

    for (int i = offset; i < (offset + 32); i++) {
      for (int j = 0; j < nFrameBits; j++) {
        totalBytes[j] += (unCompressedData[i] >= maxCodes[j]) ? 2 + bytesPerException : 0;
      }
    }

    int bestFrameBits = minFrameBits;
    int minBytes = totalBytes[0];
    for (int i = 1; i < nFrameBits; i++) {
      if (totalBytes[i] < minBytes) {
        bestFrameBits = minFrameBits + i;
        minBytes = totalBytes[i];
      }
    }

    return bestFrameBits;
  }

  @Override
  public int getByteBufferSize(final int blockSize) {
    return blockSize * 10;
  }

}
