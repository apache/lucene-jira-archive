/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression.afor;

import org.apache.lucene.compression.afor.AFOR2Compressor.FrameCompressor;
import org.apache.lucene.compression.afor.AFOR2Decompressor.FrameDecompressor;

/** Frame of Reference lossless integer compression/decompression.
 * For positive integers, the compression is done by leaving out
 * the most significant bits, and storing all numbers with a fixed number of bits
 * contiguously in a buffer of bits. This buffer is called the frame, and it
 * can store positive numbers in a range from 0 to a constant maximum fitting in
 * the number of bits available for a single compressed number.
 * <p>
 * This implementation uses 0 as the lower bound reference for the frame,
 * so small positive integers can be most effectively compressed.
 * <p>
 * Optimized code is used for decompression, see class ForDecompress and its subclasses.
 * <br>Use of the -server option helps performance for the Sun 1.6 jvm under Linux.
 * <p>
 * This class does not provide delta coding because the Lucene index
 * structures already have that.
 * <p>
 * To be done:
 * <ul>
 * <li>
 * Optimize compression code by specializing for number of frame bits.
 * <li>
 * IntBuffer.get() is somewhat faster that IntBuffer.get(index), adapt (de)compression to
 * use the relative get() method.
 * <li>
 * Check javadoc generation and generated javadocs. Add javadoc code references.
 * </ul>
 */
public class AFOR2 extends AbstractFrameOfRef {

  private final int                 precision               = 8;
  private final long[][]            maxFrames               = new long[6][];

  private final int                 NB_CONFIGS              = 6;

  private final int[]               LogTable256             = new int[256];

  /** Index of header in int buffer */
  protected final int HEADER_INDEX = 0;
  protected int HEADER_SIZE = 0; // two bytes in byte array

  /** Start index in byte array integers each compressed to numFrameBits. */
  protected int BLOCK_INDEX = HEADER_INDEX + HEADER_SIZE;

  /** Create a Frame of Reference integer compressor/decompressor. */
  public AFOR2() {
    super();
    LogTable256[0] = LogTable256[1] = 0;
    for (int i = 2; i < 256; i++)
    {
      LogTable256[i] = 1 + LogTable256[i / 2];
    }
    maxFrames[0] = new long[4];
    maxFrames[1] = new long[3];
    maxFrames[2] = new long[3];
    maxFrames[3] = new long[3];
    maxFrames[4] = new long[2];
    maxFrames[5] = new long[1];
  }

  @Override
  public void setUnCompressedData(final int[] unCompressedData, final int offset, final int unComprSize) {
    super.setUnCompressedData(unCompressedData, offset, unComprSize);
  }

  protected final FrameCompressor[] compressors = AFOR2Compressor.compressors;

  /**
   * Compress the uncompressed data into the byte array using the given number of
   * frame bits, storing only this number of least significant bits of the
   * uncompressed integers in the compressed buffer.
   * Should only be used after setUnCompressedData().
   * <br>
   * A header is stored as a first integer into the buffer, encoding
   * the compression method, the number of frame bits and the number of compressed integers.
   * All uncompressed integers are stored sequentially in compressed form
   * in the buffer after the header.
   *
   * @param numFrameBits        The number of frame bits. Should be between 1 and 32.
   *                            Note that when this value is 32, no compression occurs.
   */
  @Override
  public void compress() {
    index = BLOCK_INDEX;
    while (offset < unComprSize) {
      for (final long frameBits : this.frameBitsForCompression()) {
        compressedArray[index] = (byte) frameBits;
        this.compressors[(int) frameBits].compress(this);
      }
    }
  }

  /** Return the number of bytes used in the byte array.
   *  Only valid after compress() or decompress().
   */
  @Override
  public int compressedSize() {
    return index;
  }

  /** Decompress from the buffer into output from a given offset. */
  @Override
  public void decompress() {
    this.index = BLOCK_INDEX;
    while (this.offset < unComprSize) {
      this.decompressors[compressedArray[index]].decompress(this);
    }
  }

  protected final FrameDecompressor[] decompressors = AFOR2Decompressor.decompressors;

  private int getSize(final int config) {
    switch (config) {
      case 0:
        return (int) (((maxFrames[0][0] + maxFrames[0][1] + maxFrames[0][2] + maxFrames[0][3] - 252) << 3) + 32);

      case 1:
        maxFrames[1][0] = maxFrames[0][0];
        maxFrames[1][1] = maxFrames[0][1];
        maxFrames[1][2] = maxFrames[0][2] > maxFrames[0][3] ? maxFrames[0][2] - 32 : maxFrames[0][3] - 32;
        return (int) (((maxFrames[1][0] + maxFrames[1][1] - 126) << 3) + ((maxFrames[1][2] - 31) << 4) + 24);

      case 2:
        maxFrames[2][0] = maxFrames[0][0] > maxFrames[0][1] ? maxFrames[0][0] - 32 : maxFrames[0][1] - 32;
        maxFrames[2][1] = maxFrames[0][2];
        maxFrames[2][2] = maxFrames[0][3];
        return (int) (((maxFrames[2][1] + maxFrames[2][2] - 126) << 3) + ((maxFrames[2][0] - 31) << 4) + 24);

      case 3:
        maxFrames[3][0] = maxFrames[0][0];
        maxFrames[3][1] = maxFrames[0][1] > maxFrames[0][2] ? maxFrames[0][1] - 32 : maxFrames[0][2] - 32;
        maxFrames[3][2] = maxFrames[0][3];
        return (int) (((maxFrames[3][0] + maxFrames[3][2] - 126) << 3) + ((maxFrames[3][1] - 31) << 4) + 24);

      case 4:
        maxFrames[4][0] = maxFrames[2][0];
        maxFrames[4][1] = maxFrames[1][2];
        return (int) (((maxFrames[4][0] + maxFrames[4][1] - 62) << 4) + 16);

      case 5:
        maxFrames[5][0] = maxFrames[4][0] > maxFrames[4][1] ? maxFrames[4][0] - 32: maxFrames[4][1] - 32;
        return (int) (((maxFrames[5][0] + 1) << 5) + 8);

      default:
        throw new Error("HybridAFor: Unknown config");
    }
  }

  /** For performance, this delegates to classes with fixed numFrameBits. */

  /** Determine the number of frame bits to be used for compression.
   * Use only after setUnCompressedData().
   * @return The number of bits needed to encode the maximum positive uncompressed value.
   * Negative uncompressed values have no influence on the result.
   */
  private long[] frameBitsForCompression() {
    long max = 0;
    // get the max for each precision block
    for (int i = 0; i < maxFrames[0].length; i++) {
      max = 0;
      for (int j = precision * i + offset; j < precision * i + precision + offset; j++) {
        max = max >= (unCompressedData[j] & 0xFFFFFFFFL) ? max : (unCompressedData[j] & 0xFFFFFFFFL);
      }
      maxFrames[0][i] = this.logNextHigherPowerOf2(max) + 64;
    }
    // Choose the best config according to the compressed size
    int bestSize = this.getSize(0);
    int bestConfig = 0;
    int size;
    for (int i = 1; i < NB_CONFIGS; i++) {
      size = this.getSize(i);
      if (size <= bestSize) {
        bestSize = size;
        bestConfig = i;
      }
    }
    return maxFrames[bestConfig];
  }

  private int logNextHigherPowerOf2(final long v) {
    int r;
    long t, tt;

    tt = v >> 16;
    if (tt > 0) {
      r = (t = tt >> 8) > 0 ? 24 + LogTable256[(int) t] : 16 + LogTable256[(int) tt];
    } else {
      r = (t = v >> 8) > 0 ? 8 + LogTable256[(int) t] : LogTable256[(int) v];
    }
    return r;
  }


  @Override
  public int getByteBufferSize(final int blockSize) {
    return (blockSize << 2) + (blockSize >> 3);
  }

}
