package org.apache.lucene.compression.afor;
/**
 * Copyright 2009, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
/* This program is generated, do not modify. See ForDecompressorGenerator.java */

public class FORDecompressor {

  public static final FrameDecompressor[] decompressors = new FrameDecompressor[] {
    new FrameDecompressor1(),
    new FrameDecompressor2(),
    new FrameDecompressor3(),
    new FrameDecompressor4(),
    new FrameDecompressor5(),
    new FrameDecompressor6(),
    new FrameDecompressor7(),
    new FrameDecompressor8(),
    new FrameDecompressor9(),
    new FrameDecompressor10(),
    new FrameDecompressor11(),
    new FrameDecompressor12(),
    new FrameDecompressor13(),
    new FrameDecompressor14(),
    new FrameDecompressor15(),
    new FrameDecompressor16(),
    new FrameDecompressor17(),
    new FrameDecompressor18(),
    new FrameDecompressor19(),
    new FrameDecompressor20(),
    new FrameDecompressor21(),
    new FrameDecompressor22(),
    new FrameDecompressor23(),
    new FrameDecompressor24(),
    new FrameDecompressor25(),
    new FrameDecompressor26(),
    new FrameDecompressor27(),
    new FrameDecompressor28(),
    new FrameDecompressor29(),
    new FrameDecompressor30(),
    new FrameDecompressor31(),
    new FrameDecompressor32()
  };

  public static abstract class FrameDecompressor {
    public abstract void decompress(final AbstractFrameOfRef frameOfRef);
  }

  public static final class FrameDecompressor1 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 31);
      unCompressedData[outOffset + 1] = (i0 >>> 30) & 1;
      unCompressedData[outOffset + 2] = (i0 >>> 29) & 1;
      unCompressedData[outOffset + 3] = (i0 >>> 28) & 1;
      unCompressedData[outOffset + 4] = (i0 >>> 27) & 1;
      unCompressedData[outOffset + 5] = (i0 >>> 26) & 1;
      unCompressedData[outOffset + 6] = (i0 >>> 25) & 1;
      unCompressedData[outOffset + 7] = (i0 >>> 24) & 1;
      unCompressedData[outOffset + 8] = (i0 >>> 23) & 1;
      unCompressedData[outOffset + 9] = (i0 >>> 22) & 1;
      unCompressedData[outOffset + 10] = (i0 >>> 21) & 1;
      unCompressedData[outOffset + 11] = (i0 >>> 20) & 1;
      unCompressedData[outOffset + 12] = (i0 >>> 19) & 1;
      unCompressedData[outOffset + 13] = (i0 >>> 18) & 1;
      unCompressedData[outOffset + 14] = (i0 >>> 17) & 1;
      unCompressedData[outOffset + 15] = (i0 >>> 16) & 1;
      unCompressedData[outOffset + 16] = (i0 >>> 15) & 1;
      unCompressedData[outOffset + 17] = (i0 >>> 14) & 1;
      unCompressedData[outOffset + 18] = (i0 >>> 13) & 1;
      unCompressedData[outOffset + 19] = (i0 >>> 12) & 1;
      unCompressedData[outOffset + 20] = (i0 >>> 11) & 1;
      unCompressedData[outOffset + 21] = (i0 >>> 10) & 1;
      unCompressedData[outOffset + 22] = (i0 >>> 9) & 1;
      unCompressedData[outOffset + 23] = (i0 >>> 8) & 1;
      unCompressedData[outOffset + 24] = (i0 >>> 7) & 1;
      unCompressedData[outOffset + 25] = (i0 >>> 6) & 1;
      unCompressedData[outOffset + 26] = (i0 >>> 5) & 1;
      unCompressedData[outOffset + 27] = (i0 >>> 4) & 1;
      unCompressedData[outOffset + 28] = (i0 >>> 3) & 1;
      unCompressedData[outOffset + 29] = (i0 >>> 2) & 1;
      unCompressedData[outOffset + 30] = (i0 >>> 1) & 1;
      unCompressedData[outOffset + 31] = i0 & 1;
    }
  }

  public static final class FrameDecompressor2 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 30);
      unCompressedData[outOffset + 1] = (i0 >>> 28) & 3;
      unCompressedData[outOffset + 2] = (i0 >>> 26) & 3;
      unCompressedData[outOffset + 3] = (i0 >>> 24) & 3;
      unCompressedData[outOffset + 4] = (i0 >>> 22) & 3;
      unCompressedData[outOffset + 5] = (i0 >>> 20) & 3;
      unCompressedData[outOffset + 6] = (i0 >>> 18) & 3;
      unCompressedData[outOffset + 7] = (i0 >>> 16) & 3;
      unCompressedData[outOffset + 8] = (i0 >>> 14) & 3;
      unCompressedData[outOffset + 9] = (i0 >>> 12) & 3;
      unCompressedData[outOffset + 10] = (i0 >>> 10) & 3;
      unCompressedData[outOffset + 11] = (i0 >>> 8) & 3;
      unCompressedData[outOffset + 12] = (i0 >>> 6) & 3;
      unCompressedData[outOffset + 13] = (i0 >>> 4) & 3;
      unCompressedData[outOffset + 14] = (i0 >>> 2) & 3;
      unCompressedData[outOffset + 15] = i0 & 3;
      unCompressedData[outOffset + 16] = (i1 >>> 30);
      unCompressedData[outOffset + 17] = (i1 >>> 28) & 3;
      unCompressedData[outOffset + 18] = (i1 >>> 26) & 3;
      unCompressedData[outOffset + 19] = (i1 >>> 24) & 3;
      unCompressedData[outOffset + 20] = (i1 >>> 22) & 3;
      unCompressedData[outOffset + 21] = (i1 >>> 20) & 3;
      unCompressedData[outOffset + 22] = (i1 >>> 18) & 3;
      unCompressedData[outOffset + 23] = (i1 >>> 16) & 3;
      unCompressedData[outOffset + 24] = (i1 >>> 14) & 3;
      unCompressedData[outOffset + 25] = (i1 >>> 12) & 3;
      unCompressedData[outOffset + 26] = (i1 >>> 10) & 3;
      unCompressedData[outOffset + 27] = (i1 >>> 8) & 3;
      unCompressedData[outOffset + 28] = (i1 >>> 6) & 3;
      unCompressedData[outOffset + 29] = (i1 >>> 4) & 3;
      unCompressedData[outOffset + 30] = (i1 >>> 2) & 3;
      unCompressedData[outOffset + 31] = i1 & 3;
    }
  }

  public static final class FrameDecompressor3 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 29);
      unCompressedData[outOffset + 1] = (i0 >>> 26) & 7;
      unCompressedData[outOffset + 2] = (i0 >>> 23) & 7;
      unCompressedData[outOffset + 3] = (i0 >>> 20) & 7;
      unCompressedData[outOffset + 4] = (i0 >>> 17) & 7;
      unCompressedData[outOffset + 5] = (i0 >>> 14) & 7;
      unCompressedData[outOffset + 6] = (i0 >>> 11) & 7;
      unCompressedData[outOffset + 7] = (i0 >>> 8) & 7;
      unCompressedData[outOffset + 8] = (i0 >>> 5) & 7;
      unCompressedData[outOffset + 9] = (i0 >>> 2) & 7;
      unCompressedData[outOffset + 10] = ((i0 << 1) | (i1 >>> 31)) & 7;
      unCompressedData[outOffset + 11] = (i1 >>> 28) & 7;
      unCompressedData[outOffset + 12] = (i1 >>> 25) & 7;
      unCompressedData[outOffset + 13] = (i1 >>> 22) & 7;
      unCompressedData[outOffset + 14] = (i1 >>> 19) & 7;
      unCompressedData[outOffset + 15] = (i1 >>> 16) & 7;
      unCompressedData[outOffset + 16] = (i1 >>> 13) & 7;
      unCompressedData[outOffset + 17] = (i1 >>> 10) & 7;
      unCompressedData[outOffset + 18] = (i1 >>> 7) & 7;
      unCompressedData[outOffset + 19] = (i1 >>> 4) & 7;
      unCompressedData[outOffset + 20] = (i1 >>> 1) & 7;
      unCompressedData[outOffset + 21] = ((i1 << 2) | (i2 >>> 30)) & 7;
      unCompressedData[outOffset + 22] = (i2 >>> 27) & 7;
      unCompressedData[outOffset + 23] = (i2 >>> 24) & 7;
      unCompressedData[outOffset + 24] = (i2 >>> 21) & 7;
      unCompressedData[outOffset + 25] = (i2 >>> 18) & 7;
      unCompressedData[outOffset + 26] = (i2 >>> 15) & 7;
      unCompressedData[outOffset + 27] = (i2 >>> 12) & 7;
      unCompressedData[outOffset + 28] = (i2 >>> 9) & 7;
      unCompressedData[outOffset + 29] = (i2 >>> 6) & 7;
      unCompressedData[outOffset + 30] = (i2 >>> 3) & 7;
      unCompressedData[outOffset + 31] = i2 & 7;
    }
  }

  public static final class FrameDecompressor4 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 28);
      unCompressedData[outOffset + 1] = (i0 >>> 24) & 15;
      unCompressedData[outOffset + 2] = (i0 >>> 20) & 15;
      unCompressedData[outOffset + 3] = (i0 >>> 16) & 15;
      unCompressedData[outOffset + 4] = (i0 >>> 12) & 15;
      unCompressedData[outOffset + 5] = (i0 >>> 8) & 15;
      unCompressedData[outOffset + 6] = (i0 >>> 4) & 15;
      unCompressedData[outOffset + 7] = i0 & 15;
      unCompressedData[outOffset + 8] = (i1 >>> 28);
      unCompressedData[outOffset + 9] = (i1 >>> 24) & 15;
      unCompressedData[outOffset + 10] = (i1 >>> 20) & 15;
      unCompressedData[outOffset + 11] = (i1 >>> 16) & 15;
      unCompressedData[outOffset + 12] = (i1 >>> 12) & 15;
      unCompressedData[outOffset + 13] = (i1 >>> 8) & 15;
      unCompressedData[outOffset + 14] = (i1 >>> 4) & 15;
      unCompressedData[outOffset + 15] = i1 & 15;
      unCompressedData[outOffset + 16] = (i2 >>> 28);
      unCompressedData[outOffset + 17] = (i2 >>> 24) & 15;
      unCompressedData[outOffset + 18] = (i2 >>> 20) & 15;
      unCompressedData[outOffset + 19] = (i2 >>> 16) & 15;
      unCompressedData[outOffset + 20] = (i2 >>> 12) & 15;
      unCompressedData[outOffset + 21] = (i2 >>> 8) & 15;
      unCompressedData[outOffset + 22] = (i2 >>> 4) & 15;
      unCompressedData[outOffset + 23] = i2 & 15;
      unCompressedData[outOffset + 24] = (i3 >>> 28);
      unCompressedData[outOffset + 25] = (i3 >>> 24) & 15;
      unCompressedData[outOffset + 26] = (i3 >>> 20) & 15;
      unCompressedData[outOffset + 27] = (i3 >>> 16) & 15;
      unCompressedData[outOffset + 28] = (i3 >>> 12) & 15;
      unCompressedData[outOffset + 29] = (i3 >>> 8) & 15;
      unCompressedData[outOffset + 30] = (i3 >>> 4) & 15;
      unCompressedData[outOffset + 31] = i3 & 15;
    }
  }

  public static final class FrameDecompressor5 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 27);
      unCompressedData[outOffset + 1] = (i0 >>> 22) & 31;
      unCompressedData[outOffset + 2] = (i0 >>> 17) & 31;
      unCompressedData[outOffset + 3] = (i0 >>> 12) & 31;
      unCompressedData[outOffset + 4] = (i0 >>> 7) & 31;
      unCompressedData[outOffset + 5] = (i0 >>> 2) & 31;
      unCompressedData[outOffset + 6] = ((i0 << 3) | (i1 >>> 29)) & 31;
      unCompressedData[outOffset + 7] = (i1 >>> 24) & 31;
      unCompressedData[outOffset + 8] = (i1 >>> 19) & 31;
      unCompressedData[outOffset + 9] = (i1 >>> 14) & 31;
      unCompressedData[outOffset + 10] = (i1 >>> 9) & 31;
      unCompressedData[outOffset + 11] = (i1 >>> 4) & 31;
      unCompressedData[outOffset + 12] = ((i1 << 1) | (i2 >>> 31)) & 31;
      unCompressedData[outOffset + 13] = (i2 >>> 26) & 31;
      unCompressedData[outOffset + 14] = (i2 >>> 21) & 31;
      unCompressedData[outOffset + 15] = (i2 >>> 16) & 31;
      unCompressedData[outOffset + 16] = (i2 >>> 11) & 31;
      unCompressedData[outOffset + 17] = (i2 >>> 6) & 31;
      unCompressedData[outOffset + 18] = (i2 >>> 1) & 31;
      unCompressedData[outOffset + 19] = ((i2 << 4) | (i3 >>> 28)) & 31;
      unCompressedData[outOffset + 20] = (i3 >>> 23) & 31;
      unCompressedData[outOffset + 21] = (i3 >>> 18) & 31;
      unCompressedData[outOffset + 22] = (i3 >>> 13) & 31;
      unCompressedData[outOffset + 23] = (i3 >>> 8) & 31;
      unCompressedData[outOffset + 24] = (i3 >>> 3) & 31;
      unCompressedData[outOffset + 25] = ((i3 << 2) | (i4 >>> 30)) & 31;
      unCompressedData[outOffset + 26] = (i4 >>> 25) & 31;
      unCompressedData[outOffset + 27] = (i4 >>> 20) & 31;
      unCompressedData[outOffset + 28] = (i4 >>> 15) & 31;
      unCompressedData[outOffset + 29] = (i4 >>> 10) & 31;
      unCompressedData[outOffset + 30] = (i4 >>> 5) & 31;
      unCompressedData[outOffset + 31] = i4 & 31;
    }
  }

  public static final class FrameDecompressor6 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 26);
      unCompressedData[outOffset + 1] = (i0 >>> 20) & 63;
      unCompressedData[outOffset + 2] = (i0 >>> 14) & 63;
      unCompressedData[outOffset + 3] = (i0 >>> 8) & 63;
      unCompressedData[outOffset + 4] = (i0 >>> 2) & 63;
      unCompressedData[outOffset + 5] = ((i0 << 4) | (i1 >>> 28)) & 63;
      unCompressedData[outOffset + 6] = (i1 >>> 22) & 63;
      unCompressedData[outOffset + 7] = (i1 >>> 16) & 63;
      unCompressedData[outOffset + 8] = (i1 >>> 10) & 63;
      unCompressedData[outOffset + 9] = (i1 >>> 4) & 63;
      unCompressedData[outOffset + 10] = ((i1 << 2) | (i2 >>> 30)) & 63;
      unCompressedData[outOffset + 11] = (i2 >>> 24) & 63;
      unCompressedData[outOffset + 12] = (i2 >>> 18) & 63;
      unCompressedData[outOffset + 13] = (i2 >>> 12) & 63;
      unCompressedData[outOffset + 14] = (i2 >>> 6) & 63;
      unCompressedData[outOffset + 15] = i2 & 63;
      unCompressedData[outOffset + 16] = (i3 >>> 26);
      unCompressedData[outOffset + 17] = (i3 >>> 20) & 63;
      unCompressedData[outOffset + 18] = (i3 >>> 14) & 63;
      unCompressedData[outOffset + 19] = (i3 >>> 8) & 63;
      unCompressedData[outOffset + 20] = (i3 >>> 2) & 63;
      unCompressedData[outOffset + 21] = ((i3 << 4) | (i4 >>> 28)) & 63;
      unCompressedData[outOffset + 22] = (i4 >>> 22) & 63;
      unCompressedData[outOffset + 23] = (i4 >>> 16) & 63;
      unCompressedData[outOffset + 24] = (i4 >>> 10) & 63;
      unCompressedData[outOffset + 25] = (i4 >>> 4) & 63;
      unCompressedData[outOffset + 26] = ((i4 << 2) | (i5 >>> 30)) & 63;
      unCompressedData[outOffset + 27] = (i5 >>> 24) & 63;
      unCompressedData[outOffset + 28] = (i5 >>> 18) & 63;
      unCompressedData[outOffset + 29] = (i5 >>> 12) & 63;
      unCompressedData[outOffset + 30] = (i5 >>> 6) & 63;
      unCompressedData[outOffset + 31] = i5 & 63;
    }
  }

  public static final class FrameDecompressor7 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 25);
      unCompressedData[outOffset + 1] = (i0 >>> 18) & 127;
      unCompressedData[outOffset + 2] = (i0 >>> 11) & 127;
      unCompressedData[outOffset + 3] = (i0 >>> 4) & 127;
      unCompressedData[outOffset + 4] = ((i0 << 3) | (i1 >>> 29)) & 127;
      unCompressedData[outOffset + 5] = (i1 >>> 22) & 127;
      unCompressedData[outOffset + 6] = (i1 >>> 15) & 127;
      unCompressedData[outOffset + 7] = (i1 >>> 8) & 127;
      unCompressedData[outOffset + 8] = (i1 >>> 1) & 127;
      unCompressedData[outOffset + 9] = ((i1 << 6) | (i2 >>> 26)) & 127;
      unCompressedData[outOffset + 10] = (i2 >>> 19) & 127;
      unCompressedData[outOffset + 11] = (i2 >>> 12) & 127;
      unCompressedData[outOffset + 12] = (i2 >>> 5) & 127;
      unCompressedData[outOffset + 13] = ((i2 << 2) | (i3 >>> 30)) & 127;
      unCompressedData[outOffset + 14] = (i3 >>> 23) & 127;
      unCompressedData[outOffset + 15] = (i3 >>> 16) & 127;
      unCompressedData[outOffset + 16] = (i3 >>> 9) & 127;
      unCompressedData[outOffset + 17] = (i3 >>> 2) & 127;
      unCompressedData[outOffset + 18] = ((i3 << 5) | (i4 >>> 27)) & 127;
      unCompressedData[outOffset + 19] = (i4 >>> 20) & 127;
      unCompressedData[outOffset + 20] = (i4 >>> 13) & 127;
      unCompressedData[outOffset + 21] = (i4 >>> 6) & 127;
      unCompressedData[outOffset + 22] = ((i4 << 1) | (i5 >>> 31)) & 127;
      unCompressedData[outOffset + 23] = (i5 >>> 24) & 127;
      unCompressedData[outOffset + 24] = (i5 >>> 17) & 127;
      unCompressedData[outOffset + 25] = (i5 >>> 10) & 127;
      unCompressedData[outOffset + 26] = (i5 >>> 3) & 127;
      unCompressedData[outOffset + 27] = ((i5 << 4) | (i6 >>> 28)) & 127;
      unCompressedData[outOffset + 28] = (i6 >>> 21) & 127;
      unCompressedData[outOffset + 29] = (i6 >>> 14) & 127;
      unCompressedData[outOffset + 30] = (i6 >>> 7) & 127;
      unCompressedData[outOffset + 31] = i6 & 127;
    }
  }

  public static final class FrameDecompressor8 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 24);
      unCompressedData[outOffset + 1] = (i0 >>> 16) & 255;
      unCompressedData[outOffset + 2] = (i0 >>> 8) & 255;
      unCompressedData[outOffset + 3] = i0 & 255;
      unCompressedData[outOffset + 4] = (i1 >>> 24);
      unCompressedData[outOffset + 5] = (i1 >>> 16) & 255;
      unCompressedData[outOffset + 6] = (i1 >>> 8) & 255;
      unCompressedData[outOffset + 7] = i1 & 255;
      unCompressedData[outOffset + 8] = (i2 >>> 24);
      unCompressedData[outOffset + 9] = (i2 >>> 16) & 255;
      unCompressedData[outOffset + 10] = (i2 >>> 8) & 255;
      unCompressedData[outOffset + 11] = i2 & 255;
      unCompressedData[outOffset + 12] = (i3 >>> 24);
      unCompressedData[outOffset + 13] = (i3 >>> 16) & 255;
      unCompressedData[outOffset + 14] = (i3 >>> 8) & 255;
      unCompressedData[outOffset + 15] = i3 & 255;
      unCompressedData[outOffset + 16] = (i4 >>> 24);
      unCompressedData[outOffset + 17] = (i4 >>> 16) & 255;
      unCompressedData[outOffset + 18] = (i4 >>> 8) & 255;
      unCompressedData[outOffset + 19] = i4 & 255;
      unCompressedData[outOffset + 20] = (i5 >>> 24);
      unCompressedData[outOffset + 21] = (i5 >>> 16) & 255;
      unCompressedData[outOffset + 22] = (i5 >>> 8) & 255;
      unCompressedData[outOffset + 23] = i5 & 255;
      unCompressedData[outOffset + 24] = (i6 >>> 24);
      unCompressedData[outOffset + 25] = (i6 >>> 16) & 255;
      unCompressedData[outOffset + 26] = (i6 >>> 8) & 255;
      unCompressedData[outOffset + 27] = i6 & 255;
      unCompressedData[outOffset + 28] = (i7 >>> 24);
      unCompressedData[outOffset + 29] = (i7 >>> 16) & 255;
      unCompressedData[outOffset + 30] = (i7 >>> 8) & 255;
      unCompressedData[outOffset + 31] = i7 & 255;
    }
  }

  public static final class FrameDecompressor9 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 23);
      unCompressedData[outOffset + 1] = (i0 >>> 14) & 511;
      unCompressedData[outOffset + 2] = (i0 >>> 5) & 511;
      unCompressedData[outOffset + 3] = ((i0 << 4) | (i1 >>> 28)) & 511;
      unCompressedData[outOffset + 4] = (i1 >>> 19) & 511;
      unCompressedData[outOffset + 5] = (i1 >>> 10) & 511;
      unCompressedData[outOffset + 6] = (i1 >>> 1) & 511;
      unCompressedData[outOffset + 7] = ((i1 << 8) | (i2 >>> 24)) & 511;
      unCompressedData[outOffset + 8] = (i2 >>> 15) & 511;
      unCompressedData[outOffset + 9] = (i2 >>> 6) & 511;
      unCompressedData[outOffset + 10] = ((i2 << 3) | (i3 >>> 29)) & 511;
      unCompressedData[outOffset + 11] = (i3 >>> 20) & 511;
      unCompressedData[outOffset + 12] = (i3 >>> 11) & 511;
      unCompressedData[outOffset + 13] = (i3 >>> 2) & 511;
      unCompressedData[outOffset + 14] = ((i3 << 7) | (i4 >>> 25)) & 511;
      unCompressedData[outOffset + 15] = (i4 >>> 16) & 511;
      unCompressedData[outOffset + 16] = (i4 >>> 7) & 511;
      unCompressedData[outOffset + 17] = ((i4 << 2) | (i5 >>> 30)) & 511;
      unCompressedData[outOffset + 18] = (i5 >>> 21) & 511;
      unCompressedData[outOffset + 19] = (i5 >>> 12) & 511;
      unCompressedData[outOffset + 20] = (i5 >>> 3) & 511;
      unCompressedData[outOffset + 21] = ((i5 << 6) | (i6 >>> 26)) & 511;
      unCompressedData[outOffset + 22] = (i6 >>> 17) & 511;
      unCompressedData[outOffset + 23] = (i6 >>> 8) & 511;
      unCompressedData[outOffset + 24] = ((i6 << 1) | (i7 >>> 31)) & 511;
      unCompressedData[outOffset + 25] = (i7 >>> 22) & 511;
      unCompressedData[outOffset + 26] = (i7 >>> 13) & 511;
      unCompressedData[outOffset + 27] = (i7 >>> 4) & 511;
      unCompressedData[outOffset + 28] = ((i7 << 5) | (i8 >>> 27)) & 511;
      unCompressedData[outOffset + 29] = (i8 >>> 18) & 511;
      unCompressedData[outOffset + 30] = (i8 >>> 9) & 511;
      unCompressedData[outOffset + 31] = i8 & 511;
    }
  }

  public static final class FrameDecompressor10 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 22);
      unCompressedData[outOffset + 1] = (i0 >>> 12) & 1023;
      unCompressedData[outOffset + 2] = (i0 >>> 2) & 1023;
      unCompressedData[outOffset + 3] = ((i0 << 8) | (i1 >>> 24)) & 1023;
      unCompressedData[outOffset + 4] = (i1 >>> 14) & 1023;
      unCompressedData[outOffset + 5] = (i1 >>> 4) & 1023;
      unCompressedData[outOffset + 6] = ((i1 << 6) | (i2 >>> 26)) & 1023;
      unCompressedData[outOffset + 7] = (i2 >>> 16) & 1023;
      unCompressedData[outOffset + 8] = (i2 >>> 6) & 1023;
      unCompressedData[outOffset + 9] = ((i2 << 4) | (i3 >>> 28)) & 1023;
      unCompressedData[outOffset + 10] = (i3 >>> 18) & 1023;
      unCompressedData[outOffset + 11] = (i3 >>> 8) & 1023;
      unCompressedData[outOffset + 12] = ((i3 << 2) | (i4 >>> 30)) & 1023;
      unCompressedData[outOffset + 13] = (i4 >>> 20) & 1023;
      unCompressedData[outOffset + 14] = (i4 >>> 10) & 1023;
      unCompressedData[outOffset + 15] = i4 & 1023;
      unCompressedData[outOffset + 16] = (i5 >>> 22);
      unCompressedData[outOffset + 17] = (i5 >>> 12) & 1023;
      unCompressedData[outOffset + 18] = (i5 >>> 2) & 1023;
      unCompressedData[outOffset + 19] = ((i5 << 8) | (i6 >>> 24)) & 1023;
      unCompressedData[outOffset + 20] = (i6 >>> 14) & 1023;
      unCompressedData[outOffset + 21] = (i6 >>> 4) & 1023;
      unCompressedData[outOffset + 22] = ((i6 << 6) | (i7 >>> 26)) & 1023;
      unCompressedData[outOffset + 23] = (i7 >>> 16) & 1023;
      unCompressedData[outOffset + 24] = (i7 >>> 6) & 1023;
      unCompressedData[outOffset + 25] = ((i7 << 4) | (i8 >>> 28)) & 1023;
      unCompressedData[outOffset + 26] = (i8 >>> 18) & 1023;
      unCompressedData[outOffset + 27] = (i8 >>> 8) & 1023;
      unCompressedData[outOffset + 28] = ((i8 << 2) | (i9 >>> 30)) & 1023;
      unCompressedData[outOffset + 29] = (i9 >>> 20) & 1023;
      unCompressedData[outOffset + 30] = (i9 >>> 10) & 1023;
      unCompressedData[outOffset + 31] = i9 & 1023;
    }
  }

  public static final class FrameDecompressor11 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 21);
      unCompressedData[outOffset + 1] = (i0 >>> 10) & 2047;
      unCompressedData[outOffset + 2] = ((i0 << 1) | (i1 >>> 31)) & 2047;
      unCompressedData[outOffset + 3] = (i1 >>> 20) & 2047;
      unCompressedData[outOffset + 4] = (i1 >>> 9) & 2047;
      unCompressedData[outOffset + 5] = ((i1 << 2) | (i2 >>> 30)) & 2047;
      unCompressedData[outOffset + 6] = (i2 >>> 19) & 2047;
      unCompressedData[outOffset + 7] = (i2 >>> 8) & 2047;
      unCompressedData[outOffset + 8] = ((i2 << 3) | (i3 >>> 29)) & 2047;
      unCompressedData[outOffset + 9] = (i3 >>> 18) & 2047;
      unCompressedData[outOffset + 10] = (i3 >>> 7) & 2047;
      unCompressedData[outOffset + 11] = ((i3 << 4) | (i4 >>> 28)) & 2047;
      unCompressedData[outOffset + 12] = (i4 >>> 17) & 2047;
      unCompressedData[outOffset + 13] = (i4 >>> 6) & 2047;
      unCompressedData[outOffset + 14] = ((i4 << 5) | (i5 >>> 27)) & 2047;
      unCompressedData[outOffset + 15] = (i5 >>> 16) & 2047;
      unCompressedData[outOffset + 16] = (i5 >>> 5) & 2047;
      unCompressedData[outOffset + 17] = ((i5 << 6) | (i6 >>> 26)) & 2047;
      unCompressedData[outOffset + 18] = (i6 >>> 15) & 2047;
      unCompressedData[outOffset + 19] = (i6 >>> 4) & 2047;
      unCompressedData[outOffset + 20] = ((i6 << 7) | (i7 >>> 25)) & 2047;
      unCompressedData[outOffset + 21] = (i7 >>> 14) & 2047;
      unCompressedData[outOffset + 22] = (i7 >>> 3) & 2047;
      unCompressedData[outOffset + 23] = ((i7 << 8) | (i8 >>> 24)) & 2047;
      unCompressedData[outOffset + 24] = (i8 >>> 13) & 2047;
      unCompressedData[outOffset + 25] = (i8 >>> 2) & 2047;
      unCompressedData[outOffset + 26] = ((i8 << 9) | (i9 >>> 23)) & 2047;
      unCompressedData[outOffset + 27] = (i9 >>> 12) & 2047;
      unCompressedData[outOffset + 28] = (i9 >>> 1) & 2047;
      unCompressedData[outOffset + 29] = ((i9 << 10) | (i10 >>> 22)) & 2047;
      unCompressedData[outOffset + 30] = (i10 >>> 11) & 2047;
      unCompressedData[outOffset + 31] = i10 & 2047;
    }
  }

  public static final class FrameDecompressor12 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 20);
      unCompressedData[outOffset + 1] = (i0 >>> 8) & 4095;
      unCompressedData[outOffset + 2] = ((i0 << 4) | (i1 >>> 28)) & 4095;
      unCompressedData[outOffset + 3] = (i1 >>> 16) & 4095;
      unCompressedData[outOffset + 4] = (i1 >>> 4) & 4095;
      unCompressedData[outOffset + 5] = ((i1 << 8) | (i2 >>> 24)) & 4095;
      unCompressedData[outOffset + 6] = (i2 >>> 12) & 4095;
      unCompressedData[outOffset + 7] = i2 & 4095;
      unCompressedData[outOffset + 8] = (i3 >>> 20);
      unCompressedData[outOffset + 9] = (i3 >>> 8) & 4095;
      unCompressedData[outOffset + 10] = ((i3 << 4) | (i4 >>> 28)) & 4095;
      unCompressedData[outOffset + 11] = (i4 >>> 16) & 4095;
      unCompressedData[outOffset + 12] = (i4 >>> 4) & 4095;
      unCompressedData[outOffset + 13] = ((i4 << 8) | (i5 >>> 24)) & 4095;
      unCompressedData[outOffset + 14] = (i5 >>> 12) & 4095;
      unCompressedData[outOffset + 15] = i5 & 4095;
      unCompressedData[outOffset + 16] = (i6 >>> 20);
      unCompressedData[outOffset + 17] = (i6 >>> 8) & 4095;
      unCompressedData[outOffset + 18] = ((i6 << 4) | (i7 >>> 28)) & 4095;
      unCompressedData[outOffset + 19] = (i7 >>> 16) & 4095;
      unCompressedData[outOffset + 20] = (i7 >>> 4) & 4095;
      unCompressedData[outOffset + 21] = ((i7 << 8) | (i8 >>> 24)) & 4095;
      unCompressedData[outOffset + 22] = (i8 >>> 12) & 4095;
      unCompressedData[outOffset + 23] = i8 & 4095;
      unCompressedData[outOffset + 24] = (i9 >>> 20);
      unCompressedData[outOffset + 25] = (i9 >>> 8) & 4095;
      unCompressedData[outOffset + 26] = ((i9 << 4) | (i10 >>> 28)) & 4095;
      unCompressedData[outOffset + 27] = (i10 >>> 16) & 4095;
      unCompressedData[outOffset + 28] = (i10 >>> 4) & 4095;
      unCompressedData[outOffset + 29] = ((i10 << 8) | (i11 >>> 24)) & 4095;
      unCompressedData[outOffset + 30] = (i11 >>> 12) & 4095;
      unCompressedData[outOffset + 31] = i11 & 4095;
    }
  }

  public static final class FrameDecompressor13 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 19);
      unCompressedData[outOffset + 1] = (i0 >>> 6) & 8191;
      unCompressedData[outOffset + 2] = ((i0 << 7) | (i1 >>> 25)) & 8191;
      unCompressedData[outOffset + 3] = (i1 >>> 12) & 8191;
      unCompressedData[outOffset + 4] = ((i1 << 1) | (i2 >>> 31)) & 8191;
      unCompressedData[outOffset + 5] = (i2 >>> 18) & 8191;
      unCompressedData[outOffset + 6] = (i2 >>> 5) & 8191;
      unCompressedData[outOffset + 7] = ((i2 << 8) | (i3 >>> 24)) & 8191;
      unCompressedData[outOffset + 8] = (i3 >>> 11) & 8191;
      unCompressedData[outOffset + 9] = ((i3 << 2) | (i4 >>> 30)) & 8191;
      unCompressedData[outOffset + 10] = (i4 >>> 17) & 8191;
      unCompressedData[outOffset + 11] = (i4 >>> 4) & 8191;
      unCompressedData[outOffset + 12] = ((i4 << 9) | (i5 >>> 23)) & 8191;
      unCompressedData[outOffset + 13] = (i5 >>> 10) & 8191;
      unCompressedData[outOffset + 14] = ((i5 << 3) | (i6 >>> 29)) & 8191;
      unCompressedData[outOffset + 15] = (i6 >>> 16) & 8191;
      unCompressedData[outOffset + 16] = (i6 >>> 3) & 8191;
      unCompressedData[outOffset + 17] = ((i6 << 10) | (i7 >>> 22)) & 8191;
      unCompressedData[outOffset + 18] = (i7 >>> 9) & 8191;
      unCompressedData[outOffset + 19] = ((i7 << 4) | (i8 >>> 28)) & 8191;
      unCompressedData[outOffset + 20] = (i8 >>> 15) & 8191;
      unCompressedData[outOffset + 21] = (i8 >>> 2) & 8191;
      unCompressedData[outOffset + 22] = ((i8 << 11) | (i9 >>> 21)) & 8191;
      unCompressedData[outOffset + 23] = (i9 >>> 8) & 8191;
      unCompressedData[outOffset + 24] = ((i9 << 5) | (i10 >>> 27)) & 8191;
      unCompressedData[outOffset + 25] = (i10 >>> 14) & 8191;
      unCompressedData[outOffset + 26] = (i10 >>> 1) & 8191;
      unCompressedData[outOffset + 27] = ((i10 << 12) | (i11 >>> 20)) & 8191;
      unCompressedData[outOffset + 28] = (i11 >>> 7) & 8191;
      unCompressedData[outOffset + 29] = ((i11 << 6) | (i12 >>> 26)) & 8191;
      unCompressedData[outOffset + 30] = (i12 >>> 13) & 8191;
      unCompressedData[outOffset + 31] = i12 & 8191;
    }
  }

  public static final class FrameDecompressor14 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 18);
      unCompressedData[outOffset + 1] = (i0 >>> 4) & 16383;
      unCompressedData[outOffset + 2] = ((i0 << 10) | (i1 >>> 22)) & 16383;
      unCompressedData[outOffset + 3] = (i1 >>> 8) & 16383;
      unCompressedData[outOffset + 4] = ((i1 << 6) | (i2 >>> 26)) & 16383;
      unCompressedData[outOffset + 5] = (i2 >>> 12) & 16383;
      unCompressedData[outOffset + 6] = ((i2 << 2) | (i3 >>> 30)) & 16383;
      unCompressedData[outOffset + 7] = (i3 >>> 16) & 16383;
      unCompressedData[outOffset + 8] = (i3 >>> 2) & 16383;
      unCompressedData[outOffset + 9] = ((i3 << 12) | (i4 >>> 20)) & 16383;
      unCompressedData[outOffset + 10] = (i4 >>> 6) & 16383;
      unCompressedData[outOffset + 11] = ((i4 << 8) | (i5 >>> 24)) & 16383;
      unCompressedData[outOffset + 12] = (i5 >>> 10) & 16383;
      unCompressedData[outOffset + 13] = ((i5 << 4) | (i6 >>> 28)) & 16383;
      unCompressedData[outOffset + 14] = (i6 >>> 14) & 16383;
      unCompressedData[outOffset + 15] = i6 & 16383;
      unCompressedData[outOffset + 16] = (i7 >>> 18);
      unCompressedData[outOffset + 17] = (i7 >>> 4) & 16383;
      unCompressedData[outOffset + 18] = ((i7 << 10) | (i8 >>> 22)) & 16383;
      unCompressedData[outOffset + 19] = (i8 >>> 8) & 16383;
      unCompressedData[outOffset + 20] = ((i8 << 6) | (i9 >>> 26)) & 16383;
      unCompressedData[outOffset + 21] = (i9 >>> 12) & 16383;
      unCompressedData[outOffset + 22] = ((i9 << 2) | (i10 >>> 30)) & 16383;
      unCompressedData[outOffset + 23] = (i10 >>> 16) & 16383;
      unCompressedData[outOffset + 24] = (i10 >>> 2) & 16383;
      unCompressedData[outOffset + 25] = ((i10 << 12) | (i11 >>> 20)) & 16383;
      unCompressedData[outOffset + 26] = (i11 >>> 6) & 16383;
      unCompressedData[outOffset + 27] = ((i11 << 8) | (i12 >>> 24)) & 16383;
      unCompressedData[outOffset + 28] = (i12 >>> 10) & 16383;
      unCompressedData[outOffset + 29] = ((i12 << 4) | (i13 >>> 28)) & 16383;
      unCompressedData[outOffset + 30] = (i13 >>> 14) & 16383;
      unCompressedData[outOffset + 31] = i13 & 16383;
    }
  }

  public static final class FrameDecompressor15 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 17);
      unCompressedData[outOffset + 1] = (i0 >>> 2) & 32767;
      unCompressedData[outOffset + 2] = ((i0 << 13) | (i1 >>> 19)) & 32767;
      unCompressedData[outOffset + 3] = (i1 >>> 4) & 32767;
      unCompressedData[outOffset + 4] = ((i1 << 11) | (i2 >>> 21)) & 32767;
      unCompressedData[outOffset + 5] = (i2 >>> 6) & 32767;
      unCompressedData[outOffset + 6] = ((i2 << 9) | (i3 >>> 23)) & 32767;
      unCompressedData[outOffset + 7] = (i3 >>> 8) & 32767;
      unCompressedData[outOffset + 8] = ((i3 << 7) | (i4 >>> 25)) & 32767;
      unCompressedData[outOffset + 9] = (i4 >>> 10) & 32767;
      unCompressedData[outOffset + 10] = ((i4 << 5) | (i5 >>> 27)) & 32767;
      unCompressedData[outOffset + 11] = (i5 >>> 12) & 32767;
      unCompressedData[outOffset + 12] = ((i5 << 3) | (i6 >>> 29)) & 32767;
      unCompressedData[outOffset + 13] = (i6 >>> 14) & 32767;
      unCompressedData[outOffset + 14] = ((i6 << 1) | (i7 >>> 31)) & 32767;
      unCompressedData[outOffset + 15] = (i7 >>> 16) & 32767;
      unCompressedData[outOffset + 16] = (i7 >>> 1) & 32767;
      unCompressedData[outOffset + 17] = ((i7 << 14) | (i8 >>> 18)) & 32767;
      unCompressedData[outOffset + 18] = (i8 >>> 3) & 32767;
      unCompressedData[outOffset + 19] = ((i8 << 12) | (i9 >>> 20)) & 32767;
      unCompressedData[outOffset + 20] = (i9 >>> 5) & 32767;
      unCompressedData[outOffset + 21] = ((i9 << 10) | (i10 >>> 22)) & 32767;
      unCompressedData[outOffset + 22] = (i10 >>> 7) & 32767;
      unCompressedData[outOffset + 23] = ((i10 << 8) | (i11 >>> 24)) & 32767;
      unCompressedData[outOffset + 24] = (i11 >>> 9) & 32767;
      unCompressedData[outOffset + 25] = ((i11 << 6) | (i12 >>> 26)) & 32767;
      unCompressedData[outOffset + 26] = (i12 >>> 11) & 32767;
      unCompressedData[outOffset + 27] = ((i12 << 4) | (i13 >>> 28)) & 32767;
      unCompressedData[outOffset + 28] = (i13 >>> 13) & 32767;
      unCompressedData[outOffset + 29] = ((i13 << 2) | (i14 >>> 30)) & 32767;
      unCompressedData[outOffset + 30] = (i14 >>> 15) & 32767;
      unCompressedData[outOffset + 31] = i14 & 32767;
    }
  }

  public static final class FrameDecompressor16 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 16);
      unCompressedData[outOffset + 1] = i0 & 65535;
      unCompressedData[outOffset + 2] = (i1 >>> 16);
      unCompressedData[outOffset + 3] = i1 & 65535;
      unCompressedData[outOffset + 4] = (i2 >>> 16);
      unCompressedData[outOffset + 5] = i2 & 65535;
      unCompressedData[outOffset + 6] = (i3 >>> 16);
      unCompressedData[outOffset + 7] = i3 & 65535;
      unCompressedData[outOffset + 8] = (i4 >>> 16);
      unCompressedData[outOffset + 9] = i4 & 65535;
      unCompressedData[outOffset + 10] = (i5 >>> 16);
      unCompressedData[outOffset + 11] = i5 & 65535;
      unCompressedData[outOffset + 12] = (i6 >>> 16);
      unCompressedData[outOffset + 13] = i6 & 65535;
      unCompressedData[outOffset + 14] = (i7 >>> 16);
      unCompressedData[outOffset + 15] = i7 & 65535;
      unCompressedData[outOffset + 16] = (i8 >>> 16);
      unCompressedData[outOffset + 17] = i8 & 65535;
      unCompressedData[outOffset + 18] = (i9 >>> 16);
      unCompressedData[outOffset + 19] = i9 & 65535;
      unCompressedData[outOffset + 20] = (i10 >>> 16);
      unCompressedData[outOffset + 21] = i10 & 65535;
      unCompressedData[outOffset + 22] = (i11 >>> 16);
      unCompressedData[outOffset + 23] = i11 & 65535;
      unCompressedData[outOffset + 24] = (i12 >>> 16);
      unCompressedData[outOffset + 25] = i12 & 65535;
      unCompressedData[outOffset + 26] = (i13 >>> 16);
      unCompressedData[outOffset + 27] = i13 & 65535;
      unCompressedData[outOffset + 28] = (i14 >>> 16);
      unCompressedData[outOffset + 29] = i14 & 65535;
      unCompressedData[outOffset + 30] = (i15 >>> 16);
      unCompressedData[outOffset + 31] = i15 & 65535;
    }
  }

  public static final class FrameDecompressor17 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 15);
      unCompressedData[outOffset + 1] = ((i0 << 2) | (i1 >>> 30)) & 131071;
      unCompressedData[outOffset + 2] = (i1 >>> 13) & 131071;
      unCompressedData[outOffset + 3] = ((i1 << 4) | (i2 >>> 28)) & 131071;
      unCompressedData[outOffset + 4] = (i2 >>> 11) & 131071;
      unCompressedData[outOffset + 5] = ((i2 << 6) | (i3 >>> 26)) & 131071;
      unCompressedData[outOffset + 6] = (i3 >>> 9) & 131071;
      unCompressedData[outOffset + 7] = ((i3 << 8) | (i4 >>> 24)) & 131071;
      unCompressedData[outOffset + 8] = (i4 >>> 7) & 131071;
      unCompressedData[outOffset + 9] = ((i4 << 10) | (i5 >>> 22)) & 131071;
      unCompressedData[outOffset + 10] = (i5 >>> 5) & 131071;
      unCompressedData[outOffset + 11] = ((i5 << 12) | (i6 >>> 20)) & 131071;
      unCompressedData[outOffset + 12] = (i6 >>> 3) & 131071;
      unCompressedData[outOffset + 13] = ((i6 << 14) | (i7 >>> 18)) & 131071;
      unCompressedData[outOffset + 14] = (i7 >>> 1) & 131071;
      unCompressedData[outOffset + 15] = ((i7 << 16) | (i8 >>> 16)) & 131071;
      unCompressedData[outOffset + 16] = ((i8 << 1) | (i9 >>> 31)) & 131071;
      unCompressedData[outOffset + 17] = (i9 >>> 14) & 131071;
      unCompressedData[outOffset + 18] = ((i9 << 3) | (i10 >>> 29)) & 131071;
      unCompressedData[outOffset + 19] = (i10 >>> 12) & 131071;
      unCompressedData[outOffset + 20] = ((i10 << 5) | (i11 >>> 27)) & 131071;
      unCompressedData[outOffset + 21] = (i11 >>> 10) & 131071;
      unCompressedData[outOffset + 22] = ((i11 << 7) | (i12 >>> 25)) & 131071;
      unCompressedData[outOffset + 23] = (i12 >>> 8) & 131071;
      unCompressedData[outOffset + 24] = ((i12 << 9) | (i13 >>> 23)) & 131071;
      unCompressedData[outOffset + 25] = (i13 >>> 6) & 131071;
      unCompressedData[outOffset + 26] = ((i13 << 11) | (i14 >>> 21)) & 131071;
      unCompressedData[outOffset + 27] = (i14 >>> 4) & 131071;
      unCompressedData[outOffset + 28] = ((i14 << 13) | (i15 >>> 19)) & 131071;
      unCompressedData[outOffset + 29] = (i15 >>> 2) & 131071;
      unCompressedData[outOffset + 30] = ((i15 << 15) | (i16 >>> 17)) & 131071;
      unCompressedData[outOffset + 31] = i16 & 131071;
    }
  }

  public static final class FrameDecompressor18 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 14);
      unCompressedData[outOffset + 1] = ((i0 << 4) | (i1 >>> 28)) & 262143;
      unCompressedData[outOffset + 2] = (i1 >>> 10) & 262143;
      unCompressedData[outOffset + 3] = ((i1 << 8) | (i2 >>> 24)) & 262143;
      unCompressedData[outOffset + 4] = (i2 >>> 6) & 262143;
      unCompressedData[outOffset + 5] = ((i2 << 12) | (i3 >>> 20)) & 262143;
      unCompressedData[outOffset + 6] = (i3 >>> 2) & 262143;
      unCompressedData[outOffset + 7] = ((i3 << 16) | (i4 >>> 16)) & 262143;
      unCompressedData[outOffset + 8] = ((i4 << 2) | (i5 >>> 30)) & 262143;
      unCompressedData[outOffset + 9] = (i5 >>> 12) & 262143;
      unCompressedData[outOffset + 10] = ((i5 << 6) | (i6 >>> 26)) & 262143;
      unCompressedData[outOffset + 11] = (i6 >>> 8) & 262143;
      unCompressedData[outOffset + 12] = ((i6 << 10) | (i7 >>> 22)) & 262143;
      unCompressedData[outOffset + 13] = (i7 >>> 4) & 262143;
      unCompressedData[outOffset + 14] = ((i7 << 14) | (i8 >>> 18)) & 262143;
      unCompressedData[outOffset + 15] = i8 & 262143;
      unCompressedData[outOffset + 16] = (i9 >>> 14);
      unCompressedData[outOffset + 17] = ((i9 << 4) | (i10 >>> 28)) & 262143;
      unCompressedData[outOffset + 18] = (i10 >>> 10) & 262143;
      unCompressedData[outOffset + 19] = ((i10 << 8) | (i11 >>> 24)) & 262143;
      unCompressedData[outOffset + 20] = (i11 >>> 6) & 262143;
      unCompressedData[outOffset + 21] = ((i11 << 12) | (i12 >>> 20)) & 262143;
      unCompressedData[outOffset + 22] = (i12 >>> 2) & 262143;
      unCompressedData[outOffset + 23] = ((i12 << 16) | (i13 >>> 16)) & 262143;
      unCompressedData[outOffset + 24] = ((i13 << 2) | (i14 >>> 30)) & 262143;
      unCompressedData[outOffset + 25] = (i14 >>> 12) & 262143;
      unCompressedData[outOffset + 26] = ((i14 << 6) | (i15 >>> 26)) & 262143;
      unCompressedData[outOffset + 27] = (i15 >>> 8) & 262143;
      unCompressedData[outOffset + 28] = ((i15 << 10) | (i16 >>> 22)) & 262143;
      unCompressedData[outOffset + 29] = (i16 >>> 4) & 262143;
      unCompressedData[outOffset + 30] = ((i16 << 14) | (i17 >>> 18)) & 262143;
      unCompressedData[outOffset + 31] = i17 & 262143;
    }
  }

  public static final class FrameDecompressor19 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 13);
      unCompressedData[outOffset + 1] = ((i0 << 6) | (i1 >>> 26)) & 524287;
      unCompressedData[outOffset + 2] = (i1 >>> 7) & 524287;
      unCompressedData[outOffset + 3] = ((i1 << 12) | (i2 >>> 20)) & 524287;
      unCompressedData[outOffset + 4] = (i2 >>> 1) & 524287;
      unCompressedData[outOffset + 5] = ((i2 << 18) | (i3 >>> 14)) & 524287;
      unCompressedData[outOffset + 6] = ((i3 << 5) | (i4 >>> 27)) & 524287;
      unCompressedData[outOffset + 7] = (i4 >>> 8) & 524287;
      unCompressedData[outOffset + 8] = ((i4 << 11) | (i5 >>> 21)) & 524287;
      unCompressedData[outOffset + 9] = (i5 >>> 2) & 524287;
      unCompressedData[outOffset + 10] = ((i5 << 17) | (i6 >>> 15)) & 524287;
      unCompressedData[outOffset + 11] = ((i6 << 4) | (i7 >>> 28)) & 524287;
      unCompressedData[outOffset + 12] = (i7 >>> 9) & 524287;
      unCompressedData[outOffset + 13] = ((i7 << 10) | (i8 >>> 22)) & 524287;
      unCompressedData[outOffset + 14] = (i8 >>> 3) & 524287;
      unCompressedData[outOffset + 15] = ((i8 << 16) | (i9 >>> 16)) & 524287;
      unCompressedData[outOffset + 16] = ((i9 << 3) | (i10 >>> 29)) & 524287;
      unCompressedData[outOffset + 17] = (i10 >>> 10) & 524287;
      unCompressedData[outOffset + 18] = ((i10 << 9) | (i11 >>> 23)) & 524287;
      unCompressedData[outOffset + 19] = (i11 >>> 4) & 524287;
      unCompressedData[outOffset + 20] = ((i11 << 15) | (i12 >>> 17)) & 524287;
      unCompressedData[outOffset + 21] = ((i12 << 2) | (i13 >>> 30)) & 524287;
      unCompressedData[outOffset + 22] = (i13 >>> 11) & 524287;
      unCompressedData[outOffset + 23] = ((i13 << 8) | (i14 >>> 24)) & 524287;
      unCompressedData[outOffset + 24] = (i14 >>> 5) & 524287;
      unCompressedData[outOffset + 25] = ((i14 << 14) | (i15 >>> 18)) & 524287;
      unCompressedData[outOffset + 26] = ((i15 << 1) | (i16 >>> 31)) & 524287;
      unCompressedData[outOffset + 27] = (i16 >>> 12) & 524287;
      unCompressedData[outOffset + 28] = ((i16 << 7) | (i17 >>> 25)) & 524287;
      unCompressedData[outOffset + 29] = (i17 >>> 6) & 524287;
      unCompressedData[outOffset + 30] = ((i17 << 13) | (i18 >>> 19)) & 524287;
      unCompressedData[outOffset + 31] = i18 & 524287;
    }
  }

  public static final class FrameDecompressor20 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 12);
      unCompressedData[outOffset + 1] = ((i0 << 8) | (i1 >>> 24)) & 1048575;
      unCompressedData[outOffset + 2] = (i1 >>> 4) & 1048575;
      unCompressedData[outOffset + 3] = ((i1 << 16) | (i2 >>> 16)) & 1048575;
      unCompressedData[outOffset + 4] = ((i2 << 4) | (i3 >>> 28)) & 1048575;
      unCompressedData[outOffset + 5] = (i3 >>> 8) & 1048575;
      unCompressedData[outOffset + 6] = ((i3 << 12) | (i4 >>> 20)) & 1048575;
      unCompressedData[outOffset + 7] = i4 & 1048575;
      unCompressedData[outOffset + 8] = (i5 >>> 12);
      unCompressedData[outOffset + 9] = ((i5 << 8) | (i6 >>> 24)) & 1048575;
      unCompressedData[outOffset + 10] = (i6 >>> 4) & 1048575;
      unCompressedData[outOffset + 11] = ((i6 << 16) | (i7 >>> 16)) & 1048575;
      unCompressedData[outOffset + 12] = ((i7 << 4) | (i8 >>> 28)) & 1048575;
      unCompressedData[outOffset + 13] = (i8 >>> 8) & 1048575;
      unCompressedData[outOffset + 14] = ((i8 << 12) | (i9 >>> 20)) & 1048575;
      unCompressedData[outOffset + 15] = i9 & 1048575;
      unCompressedData[outOffset + 16] = (i10 >>> 12);
      unCompressedData[outOffset + 17] = ((i10 << 8) | (i11 >>> 24)) & 1048575;
      unCompressedData[outOffset + 18] = (i11 >>> 4) & 1048575;
      unCompressedData[outOffset + 19] = ((i11 << 16) | (i12 >>> 16)) & 1048575;
      unCompressedData[outOffset + 20] = ((i12 << 4) | (i13 >>> 28)) & 1048575;
      unCompressedData[outOffset + 21] = (i13 >>> 8) & 1048575;
      unCompressedData[outOffset + 22] = ((i13 << 12) | (i14 >>> 20)) & 1048575;
      unCompressedData[outOffset + 23] = i14 & 1048575;
      unCompressedData[outOffset + 24] = (i15 >>> 12);
      unCompressedData[outOffset + 25] = ((i15 << 8) | (i16 >>> 24)) & 1048575;
      unCompressedData[outOffset + 26] = (i16 >>> 4) & 1048575;
      unCompressedData[outOffset + 27] = ((i16 << 16) | (i17 >>> 16)) & 1048575;
      unCompressedData[outOffset + 28] = ((i17 << 4) | (i18 >>> 28)) & 1048575;
      unCompressedData[outOffset + 29] = (i18 >>> 8) & 1048575;
      unCompressedData[outOffset + 30] = ((i18 << 12) | (i19 >>> 20)) & 1048575;
      unCompressedData[outOffset + 31] = i19 & 1048575;
    }
  }

  public static final class FrameDecompressor21 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 11);
      unCompressedData[outOffset + 1] = ((i0 << 10) | (i1 >>> 22)) & 2097151;
      unCompressedData[outOffset + 2] = (i1 >>> 1) & 2097151;
      unCompressedData[outOffset + 3] = ((i1 << 20) | (i2 >>> 12)) & 2097151;
      unCompressedData[outOffset + 4] = ((i2 << 9) | (i3 >>> 23)) & 2097151;
      unCompressedData[outOffset + 5] = (i3 >>> 2) & 2097151;
      unCompressedData[outOffset + 6] = ((i3 << 19) | (i4 >>> 13)) & 2097151;
      unCompressedData[outOffset + 7] = ((i4 << 8) | (i5 >>> 24)) & 2097151;
      unCompressedData[outOffset + 8] = (i5 >>> 3) & 2097151;
      unCompressedData[outOffset + 9] = ((i5 << 18) | (i6 >>> 14)) & 2097151;
      unCompressedData[outOffset + 10] = ((i6 << 7) | (i7 >>> 25)) & 2097151;
      unCompressedData[outOffset + 11] = (i7 >>> 4) & 2097151;
      unCompressedData[outOffset + 12] = ((i7 << 17) | (i8 >>> 15)) & 2097151;
      unCompressedData[outOffset + 13] = ((i8 << 6) | (i9 >>> 26)) & 2097151;
      unCompressedData[outOffset + 14] = (i9 >>> 5) & 2097151;
      unCompressedData[outOffset + 15] = ((i9 << 16) | (i10 >>> 16)) & 2097151;
      unCompressedData[outOffset + 16] = ((i10 << 5) | (i11 >>> 27)) & 2097151;
      unCompressedData[outOffset + 17] = (i11 >>> 6) & 2097151;
      unCompressedData[outOffset + 18] = ((i11 << 15) | (i12 >>> 17)) & 2097151;
      unCompressedData[outOffset + 19] = ((i12 << 4) | (i13 >>> 28)) & 2097151;
      unCompressedData[outOffset + 20] = (i13 >>> 7) & 2097151;
      unCompressedData[outOffset + 21] = ((i13 << 14) | (i14 >>> 18)) & 2097151;
      unCompressedData[outOffset + 22] = ((i14 << 3) | (i15 >>> 29)) & 2097151;
      unCompressedData[outOffset + 23] = (i15 >>> 8) & 2097151;
      unCompressedData[outOffset + 24] = ((i15 << 13) | (i16 >>> 19)) & 2097151;
      unCompressedData[outOffset + 25] = ((i16 << 2) | (i17 >>> 30)) & 2097151;
      unCompressedData[outOffset + 26] = (i17 >>> 9) & 2097151;
      unCompressedData[outOffset + 27] = ((i17 << 12) | (i18 >>> 20)) & 2097151;
      unCompressedData[outOffset + 28] = ((i18 << 1) | (i19 >>> 31)) & 2097151;
      unCompressedData[outOffset + 29] = (i19 >>> 10) & 2097151;
      unCompressedData[outOffset + 30] = ((i19 << 11) | (i20 >>> 21)) & 2097151;
      unCompressedData[outOffset + 31] = i20 & 2097151;
    }
  }

  public static final class FrameDecompressor22 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 10);
      unCompressedData[outOffset + 1] = ((i0 << 12) | (i1 >>> 20)) & 4194303;
      unCompressedData[outOffset + 2] = ((i1 << 2) | (i2 >>> 30)) & 4194303;
      unCompressedData[outOffset + 3] = (i2 >>> 8) & 4194303;
      unCompressedData[outOffset + 4] = ((i2 << 14) | (i3 >>> 18)) & 4194303;
      unCompressedData[outOffset + 5] = ((i3 << 4) | (i4 >>> 28)) & 4194303;
      unCompressedData[outOffset + 6] = (i4 >>> 6) & 4194303;
      unCompressedData[outOffset + 7] = ((i4 << 16) | (i5 >>> 16)) & 4194303;
      unCompressedData[outOffset + 8] = ((i5 << 6) | (i6 >>> 26)) & 4194303;
      unCompressedData[outOffset + 9] = (i6 >>> 4) & 4194303;
      unCompressedData[outOffset + 10] = ((i6 << 18) | (i7 >>> 14)) & 4194303;
      unCompressedData[outOffset + 11] = ((i7 << 8) | (i8 >>> 24)) & 4194303;
      unCompressedData[outOffset + 12] = (i8 >>> 2) & 4194303;
      unCompressedData[outOffset + 13] = ((i8 << 20) | (i9 >>> 12)) & 4194303;
      unCompressedData[outOffset + 14] = ((i9 << 10) | (i10 >>> 22)) & 4194303;
      unCompressedData[outOffset + 15] = i10 & 4194303;
      unCompressedData[outOffset + 16] = (i11 >>> 10);
      unCompressedData[outOffset + 17] = ((i11 << 12) | (i12 >>> 20)) & 4194303;
      unCompressedData[outOffset + 18] = ((i12 << 2) | (i13 >>> 30)) & 4194303;
      unCompressedData[outOffset + 19] = (i13 >>> 8) & 4194303;
      unCompressedData[outOffset + 20] = ((i13 << 14) | (i14 >>> 18)) & 4194303;
      unCompressedData[outOffset + 21] = ((i14 << 4) | (i15 >>> 28)) & 4194303;
      unCompressedData[outOffset + 22] = (i15 >>> 6) & 4194303;
      unCompressedData[outOffset + 23] = ((i15 << 16) | (i16 >>> 16)) & 4194303;
      unCompressedData[outOffset + 24] = ((i16 << 6) | (i17 >>> 26)) & 4194303;
      unCompressedData[outOffset + 25] = (i17 >>> 4) & 4194303;
      unCompressedData[outOffset + 26] = ((i17 << 18) | (i18 >>> 14)) & 4194303;
      unCompressedData[outOffset + 27] = ((i18 << 8) | (i19 >>> 24)) & 4194303;
      unCompressedData[outOffset + 28] = (i19 >>> 2) & 4194303;
      unCompressedData[outOffset + 29] = ((i19 << 20) | (i20 >>> 12)) & 4194303;
      unCompressedData[outOffset + 30] = ((i20 << 10) | (i21 >>> 22)) & 4194303;
      unCompressedData[outOffset + 31] = i21 & 4194303;
    }
  }

  public static final class FrameDecompressor23 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 9);
      unCompressedData[outOffset + 1] = ((i0 << 14) | (i1 >>> 18)) & 8388607;
      unCompressedData[outOffset + 2] = ((i1 << 5) | (i2 >>> 27)) & 8388607;
      unCompressedData[outOffset + 3] = (i2 >>> 4) & 8388607;
      unCompressedData[outOffset + 4] = ((i2 << 19) | (i3 >>> 13)) & 8388607;
      unCompressedData[outOffset + 5] = ((i3 << 10) | (i4 >>> 22)) & 8388607;
      unCompressedData[outOffset + 6] = ((i4 << 1) | (i5 >>> 31)) & 8388607;
      unCompressedData[outOffset + 7] = (i5 >>> 8) & 8388607;
      unCompressedData[outOffset + 8] = ((i5 << 15) | (i6 >>> 17)) & 8388607;
      unCompressedData[outOffset + 9] = ((i6 << 6) | (i7 >>> 26)) & 8388607;
      unCompressedData[outOffset + 10] = (i7 >>> 3) & 8388607;
      unCompressedData[outOffset + 11] = ((i7 << 20) | (i8 >>> 12)) & 8388607;
      unCompressedData[outOffset + 12] = ((i8 << 11) | (i9 >>> 21)) & 8388607;
      unCompressedData[outOffset + 13] = ((i9 << 2) | (i10 >>> 30)) & 8388607;
      unCompressedData[outOffset + 14] = (i10 >>> 7) & 8388607;
      unCompressedData[outOffset + 15] = ((i10 << 16) | (i11 >>> 16)) & 8388607;
      unCompressedData[outOffset + 16] = ((i11 << 7) | (i12 >>> 25)) & 8388607;
      unCompressedData[outOffset + 17] = (i12 >>> 2) & 8388607;
      unCompressedData[outOffset + 18] = ((i12 << 21) | (i13 >>> 11)) & 8388607;
      unCompressedData[outOffset + 19] = ((i13 << 12) | (i14 >>> 20)) & 8388607;
      unCompressedData[outOffset + 20] = ((i14 << 3) | (i15 >>> 29)) & 8388607;
      unCompressedData[outOffset + 21] = (i15 >>> 6) & 8388607;
      unCompressedData[outOffset + 22] = ((i15 << 17) | (i16 >>> 15)) & 8388607;
      unCompressedData[outOffset + 23] = ((i16 << 8) | (i17 >>> 24)) & 8388607;
      unCompressedData[outOffset + 24] = (i17 >>> 1) & 8388607;
      unCompressedData[outOffset + 25] = ((i17 << 22) | (i18 >>> 10)) & 8388607;
      unCompressedData[outOffset + 26] = ((i18 << 13) | (i19 >>> 19)) & 8388607;
      unCompressedData[outOffset + 27] = ((i19 << 4) | (i20 >>> 28)) & 8388607;
      unCompressedData[outOffset + 28] = (i20 >>> 5) & 8388607;
      unCompressedData[outOffset + 29] = ((i20 << 18) | (i21 >>> 14)) & 8388607;
      unCompressedData[outOffset + 30] = ((i21 << 9) | (i22 >>> 23)) & 8388607;
      unCompressedData[outOffset + 31] = i22 & 8388607;
    }
  }

  public static final class FrameDecompressor24 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));
      int i23 = ((compressedArray[inOffset + 92] & 0xFF) << 24) | ((compressedArray[inOffset + 93] & 0xFF) << 16) | ((compressedArray[inOffset + 94] & 0xFF) << 8) | ((compressedArray[inOffset + 95] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 8);
      unCompressedData[outOffset + 1] = ((i0 << 16) | (i1 >>> 16)) & 16777215;
      unCompressedData[outOffset + 2] = ((i1 << 8) | (i2 >>> 24)) & 16777215;
      unCompressedData[outOffset + 3] = i2 & 16777215;
      unCompressedData[outOffset + 4] = (i3 >>> 8);
      unCompressedData[outOffset + 5] = ((i3 << 16) | (i4 >>> 16)) & 16777215;
      unCompressedData[outOffset + 6] = ((i4 << 8) | (i5 >>> 24)) & 16777215;
      unCompressedData[outOffset + 7] = i5 & 16777215;
      unCompressedData[outOffset + 8] = (i6 >>> 8);
      unCompressedData[outOffset + 9] = ((i6 << 16) | (i7 >>> 16)) & 16777215;
      unCompressedData[outOffset + 10] = ((i7 << 8) | (i8 >>> 24)) & 16777215;
      unCompressedData[outOffset + 11] = i8 & 16777215;
      unCompressedData[outOffset + 12] = (i9 >>> 8);
      unCompressedData[outOffset + 13] = ((i9 << 16) | (i10 >>> 16)) & 16777215;
      unCompressedData[outOffset + 14] = ((i10 << 8) | (i11 >>> 24)) & 16777215;
      unCompressedData[outOffset + 15] = i11 & 16777215;
      unCompressedData[outOffset + 16] = (i12 >>> 8);
      unCompressedData[outOffset + 17] = ((i12 << 16) | (i13 >>> 16)) & 16777215;
      unCompressedData[outOffset + 18] = ((i13 << 8) | (i14 >>> 24)) & 16777215;
      unCompressedData[outOffset + 19] = i14 & 16777215;
      unCompressedData[outOffset + 20] = (i15 >>> 8);
      unCompressedData[outOffset + 21] = ((i15 << 16) | (i16 >>> 16)) & 16777215;
      unCompressedData[outOffset + 22] = ((i16 << 8) | (i17 >>> 24)) & 16777215;
      unCompressedData[outOffset + 23] = i17 & 16777215;
      unCompressedData[outOffset + 24] = (i18 >>> 8);
      unCompressedData[outOffset + 25] = ((i18 << 16) | (i19 >>> 16)) & 16777215;
      unCompressedData[outOffset + 26] = ((i19 << 8) | (i20 >>> 24)) & 16777215;
      unCompressedData[outOffset + 27] = i20 & 16777215;
      unCompressedData[outOffset + 28] = (i21 >>> 8);
      unCompressedData[outOffset + 29] = ((i21 << 16) | (i22 >>> 16)) & 16777215;
      unCompressedData[outOffset + 30] = ((i22 << 8) | (i23 >>> 24)) & 16777215;
      unCompressedData[outOffset + 31] = i23 & 16777215;
    }
  }

  public static final class FrameDecompressor25 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));
      int i23 = ((compressedArray[inOffset + 92] & 0xFF) << 24) | ((compressedArray[inOffset + 93] & 0xFF) << 16) | ((compressedArray[inOffset + 94] & 0xFF) << 8) | ((compressedArray[inOffset + 95] & 0xFF));
      int i24 = ((compressedArray[inOffset + 96] & 0xFF) << 24) | ((compressedArray[inOffset + 97] & 0xFF) << 16) | ((compressedArray[inOffset + 98] & 0xFF) << 8) | ((compressedArray[inOffset + 99] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 7);
      unCompressedData[outOffset + 1] = ((i0 << 18) | (i1 >>> 14)) & 33554431;
      unCompressedData[outOffset + 2] = ((i1 << 11) | (i2 >>> 21)) & 33554431;
      unCompressedData[outOffset + 3] = ((i2 << 4) | (i3 >>> 28)) & 33554431;
      unCompressedData[outOffset + 4] = (i3 >>> 3) & 33554431;
      unCompressedData[outOffset + 5] = ((i3 << 22) | (i4 >>> 10)) & 33554431;
      unCompressedData[outOffset + 6] = ((i4 << 15) | (i5 >>> 17)) & 33554431;
      unCompressedData[outOffset + 7] = ((i5 << 8) | (i6 >>> 24)) & 33554431;
      unCompressedData[outOffset + 8] = ((i6 << 1) | (i7 >>> 31)) & 33554431;
      unCompressedData[outOffset + 9] = (i7 >>> 6) & 33554431;
      unCompressedData[outOffset + 10] = ((i7 << 19) | (i8 >>> 13)) & 33554431;
      unCompressedData[outOffset + 11] = ((i8 << 12) | (i9 >>> 20)) & 33554431;
      unCompressedData[outOffset + 12] = ((i9 << 5) | (i10 >>> 27)) & 33554431;
      unCompressedData[outOffset + 13] = (i10 >>> 2) & 33554431;
      unCompressedData[outOffset + 14] = ((i10 << 23) | (i11 >>> 9)) & 33554431;
      unCompressedData[outOffset + 15] = ((i11 << 16) | (i12 >>> 16)) & 33554431;
      unCompressedData[outOffset + 16] = ((i12 << 9) | (i13 >>> 23)) & 33554431;
      unCompressedData[outOffset + 17] = ((i13 << 2) | (i14 >>> 30)) & 33554431;
      unCompressedData[outOffset + 18] = (i14 >>> 5) & 33554431;
      unCompressedData[outOffset + 19] = ((i14 << 20) | (i15 >>> 12)) & 33554431;
      unCompressedData[outOffset + 20] = ((i15 << 13) | (i16 >>> 19)) & 33554431;
      unCompressedData[outOffset + 21] = ((i16 << 6) | (i17 >>> 26)) & 33554431;
      unCompressedData[outOffset + 22] = (i17 >>> 1) & 33554431;
      unCompressedData[outOffset + 23] = ((i17 << 24) | (i18 >>> 8)) & 33554431;
      unCompressedData[outOffset + 24] = ((i18 << 17) | (i19 >>> 15)) & 33554431;
      unCompressedData[outOffset + 25] = ((i19 << 10) | (i20 >>> 22)) & 33554431;
      unCompressedData[outOffset + 26] = ((i20 << 3) | (i21 >>> 29)) & 33554431;
      unCompressedData[outOffset + 27] = (i21 >>> 4) & 33554431;
      unCompressedData[outOffset + 28] = ((i21 << 21) | (i22 >>> 11)) & 33554431;
      unCompressedData[outOffset + 29] = ((i22 << 14) | (i23 >>> 18)) & 33554431;
      unCompressedData[outOffset + 30] = ((i23 << 7) | (i24 >>> 25)) & 33554431;
      unCompressedData[outOffset + 31] = i24 & 33554431;
    }
  }

  public static final class FrameDecompressor26 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));
      int i23 = ((compressedArray[inOffset + 92] & 0xFF) << 24) | ((compressedArray[inOffset + 93] & 0xFF) << 16) | ((compressedArray[inOffset + 94] & 0xFF) << 8) | ((compressedArray[inOffset + 95] & 0xFF));
      int i24 = ((compressedArray[inOffset + 96] & 0xFF) << 24) | ((compressedArray[inOffset + 97] & 0xFF) << 16) | ((compressedArray[inOffset + 98] & 0xFF) << 8) | ((compressedArray[inOffset + 99] & 0xFF));
      int i25 = ((compressedArray[inOffset + 100] & 0xFF) << 24) | ((compressedArray[inOffset + 101] & 0xFF) << 16) | ((compressedArray[inOffset + 102] & 0xFF) << 8) | ((compressedArray[inOffset + 103] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 6);
      unCompressedData[outOffset + 1] = ((i0 << 20) | (i1 >>> 12)) & 67108863;
      unCompressedData[outOffset + 2] = ((i1 << 14) | (i2 >>> 18)) & 67108863;
      unCompressedData[outOffset + 3] = ((i2 << 8) | (i3 >>> 24)) & 67108863;
      unCompressedData[outOffset + 4] = ((i3 << 2) | (i4 >>> 30)) & 67108863;
      unCompressedData[outOffset + 5] = (i4 >>> 4) & 67108863;
      unCompressedData[outOffset + 6] = ((i4 << 22) | (i5 >>> 10)) & 67108863;
      unCompressedData[outOffset + 7] = ((i5 << 16) | (i6 >>> 16)) & 67108863;
      unCompressedData[outOffset + 8] = ((i6 << 10) | (i7 >>> 22)) & 67108863;
      unCompressedData[outOffset + 9] = ((i7 << 4) | (i8 >>> 28)) & 67108863;
      unCompressedData[outOffset + 10] = (i8 >>> 2) & 67108863;
      unCompressedData[outOffset + 11] = ((i8 << 24) | (i9 >>> 8)) & 67108863;
      unCompressedData[outOffset + 12] = ((i9 << 18) | (i10 >>> 14)) & 67108863;
      unCompressedData[outOffset + 13] = ((i10 << 12) | (i11 >>> 20)) & 67108863;
      unCompressedData[outOffset + 14] = ((i11 << 6) | (i12 >>> 26)) & 67108863;
      unCompressedData[outOffset + 15] = i12 & 67108863;
      unCompressedData[outOffset + 16] = (i13 >>> 6);
      unCompressedData[outOffset + 17] = ((i13 << 20) | (i14 >>> 12)) & 67108863;
      unCompressedData[outOffset + 18] = ((i14 << 14) | (i15 >>> 18)) & 67108863;
      unCompressedData[outOffset + 19] = ((i15 << 8) | (i16 >>> 24)) & 67108863;
      unCompressedData[outOffset + 20] = ((i16 << 2) | (i17 >>> 30)) & 67108863;
      unCompressedData[outOffset + 21] = (i17 >>> 4) & 67108863;
      unCompressedData[outOffset + 22] = ((i17 << 22) | (i18 >>> 10)) & 67108863;
      unCompressedData[outOffset + 23] = ((i18 << 16) | (i19 >>> 16)) & 67108863;
      unCompressedData[outOffset + 24] = ((i19 << 10) | (i20 >>> 22)) & 67108863;
      unCompressedData[outOffset + 25] = ((i20 << 4) | (i21 >>> 28)) & 67108863;
      unCompressedData[outOffset + 26] = (i21 >>> 2) & 67108863;
      unCompressedData[outOffset + 27] = ((i21 << 24) | (i22 >>> 8)) & 67108863;
      unCompressedData[outOffset + 28] = ((i22 << 18) | (i23 >>> 14)) & 67108863;
      unCompressedData[outOffset + 29] = ((i23 << 12) | (i24 >>> 20)) & 67108863;
      unCompressedData[outOffset + 30] = ((i24 << 6) | (i25 >>> 26)) & 67108863;
      unCompressedData[outOffset + 31] = i25 & 67108863;
    }
  }

  public static final class FrameDecompressor27 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));
      int i23 = ((compressedArray[inOffset + 92] & 0xFF) << 24) | ((compressedArray[inOffset + 93] & 0xFF) << 16) | ((compressedArray[inOffset + 94] & 0xFF) << 8) | ((compressedArray[inOffset + 95] & 0xFF));
      int i24 = ((compressedArray[inOffset + 96] & 0xFF) << 24) | ((compressedArray[inOffset + 97] & 0xFF) << 16) | ((compressedArray[inOffset + 98] & 0xFF) << 8) | ((compressedArray[inOffset + 99] & 0xFF));
      int i25 = ((compressedArray[inOffset + 100] & 0xFF) << 24) | ((compressedArray[inOffset + 101] & 0xFF) << 16) | ((compressedArray[inOffset + 102] & 0xFF) << 8) | ((compressedArray[inOffset + 103] & 0xFF));
      int i26 = ((compressedArray[inOffset + 104] & 0xFF) << 24) | ((compressedArray[inOffset + 105] & 0xFF) << 16) | ((compressedArray[inOffset + 106] & 0xFF) << 8) | ((compressedArray[inOffset + 107] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 5);
      unCompressedData[outOffset + 1] = ((i0 << 22) | (i1 >>> 10)) & 134217727;
      unCompressedData[outOffset + 2] = ((i1 << 17) | (i2 >>> 15)) & 134217727;
      unCompressedData[outOffset + 3] = ((i2 << 12) | (i3 >>> 20)) & 134217727;
      unCompressedData[outOffset + 4] = ((i3 << 7) | (i4 >>> 25)) & 134217727;
      unCompressedData[outOffset + 5] = ((i4 << 2) | (i5 >>> 30)) & 134217727;
      unCompressedData[outOffset + 6] = (i5 >>> 3) & 134217727;
      unCompressedData[outOffset + 7] = ((i5 << 24) | (i6 >>> 8)) & 134217727;
      unCompressedData[outOffset + 8] = ((i6 << 19) | (i7 >>> 13)) & 134217727;
      unCompressedData[outOffset + 9] = ((i7 << 14) | (i8 >>> 18)) & 134217727;
      unCompressedData[outOffset + 10] = ((i8 << 9) | (i9 >>> 23)) & 134217727;
      unCompressedData[outOffset + 11] = ((i9 << 4) | (i10 >>> 28)) & 134217727;
      unCompressedData[outOffset + 12] = (i10 >>> 1) & 134217727;
      unCompressedData[outOffset + 13] = ((i10 << 26) | (i11 >>> 6)) & 134217727;
      unCompressedData[outOffset + 14] = ((i11 << 21) | (i12 >>> 11)) & 134217727;
      unCompressedData[outOffset + 15] = ((i12 << 16) | (i13 >>> 16)) & 134217727;
      unCompressedData[outOffset + 16] = ((i13 << 11) | (i14 >>> 21)) & 134217727;
      unCompressedData[outOffset + 17] = ((i14 << 6) | (i15 >>> 26)) & 134217727;
      unCompressedData[outOffset + 18] = ((i15 << 1) | (i16 >>> 31)) & 134217727;
      unCompressedData[outOffset + 19] = (i16 >>> 4) & 134217727;
      unCompressedData[outOffset + 20] = ((i16 << 23) | (i17 >>> 9)) & 134217727;
      unCompressedData[outOffset + 21] = ((i17 << 18) | (i18 >>> 14)) & 134217727;
      unCompressedData[outOffset + 22] = ((i18 << 13) | (i19 >>> 19)) & 134217727;
      unCompressedData[outOffset + 23] = ((i19 << 8) | (i20 >>> 24)) & 134217727;
      unCompressedData[outOffset + 24] = ((i20 << 3) | (i21 >>> 29)) & 134217727;
      unCompressedData[outOffset + 25] = (i21 >>> 2) & 134217727;
      unCompressedData[outOffset + 26] = ((i21 << 25) | (i22 >>> 7)) & 134217727;
      unCompressedData[outOffset + 27] = ((i22 << 20) | (i23 >>> 12)) & 134217727;
      unCompressedData[outOffset + 28] = ((i23 << 15) | (i24 >>> 17)) & 134217727;
      unCompressedData[outOffset + 29] = ((i24 << 10) | (i25 >>> 22)) & 134217727;
      unCompressedData[outOffset + 30] = ((i25 << 5) | (i26 >>> 27)) & 134217727;
      unCompressedData[outOffset + 31] = i26 & 134217727;
    }
  }

  public static final class FrameDecompressor28 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));
      int i23 = ((compressedArray[inOffset + 92] & 0xFF) << 24) | ((compressedArray[inOffset + 93] & 0xFF) << 16) | ((compressedArray[inOffset + 94] & 0xFF) << 8) | ((compressedArray[inOffset + 95] & 0xFF));
      int i24 = ((compressedArray[inOffset + 96] & 0xFF) << 24) | ((compressedArray[inOffset + 97] & 0xFF) << 16) | ((compressedArray[inOffset + 98] & 0xFF) << 8) | ((compressedArray[inOffset + 99] & 0xFF));
      int i25 = ((compressedArray[inOffset + 100] & 0xFF) << 24) | ((compressedArray[inOffset + 101] & 0xFF) << 16) | ((compressedArray[inOffset + 102] & 0xFF) << 8) | ((compressedArray[inOffset + 103] & 0xFF));
      int i26 = ((compressedArray[inOffset + 104] & 0xFF) << 24) | ((compressedArray[inOffset + 105] & 0xFF) << 16) | ((compressedArray[inOffset + 106] & 0xFF) << 8) | ((compressedArray[inOffset + 107] & 0xFF));
      int i27 = ((compressedArray[inOffset + 108] & 0xFF) << 24) | ((compressedArray[inOffset + 109] & 0xFF) << 16) | ((compressedArray[inOffset + 110] & 0xFF) << 8) | ((compressedArray[inOffset + 111] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 4);
      unCompressedData[outOffset + 1] = ((i0 << 24) | (i1 >>> 8)) & 268435455;
      unCompressedData[outOffset + 2] = ((i1 << 20) | (i2 >>> 12)) & 268435455;
      unCompressedData[outOffset + 3] = ((i2 << 16) | (i3 >>> 16)) & 268435455;
      unCompressedData[outOffset + 4] = ((i3 << 12) | (i4 >>> 20)) & 268435455;
      unCompressedData[outOffset + 5] = ((i4 << 8) | (i5 >>> 24)) & 268435455;
      unCompressedData[outOffset + 6] = ((i5 << 4) | (i6 >>> 28)) & 268435455;
      unCompressedData[outOffset + 7] = i6 & 268435455;
      unCompressedData[outOffset + 8] = (i7 >>> 4);
      unCompressedData[outOffset + 9] = ((i7 << 24) | (i8 >>> 8)) & 268435455;
      unCompressedData[outOffset + 10] = ((i8 << 20) | (i9 >>> 12)) & 268435455;
      unCompressedData[outOffset + 11] = ((i9 << 16) | (i10 >>> 16)) & 268435455;
      unCompressedData[outOffset + 12] = ((i10 << 12) | (i11 >>> 20)) & 268435455;
      unCompressedData[outOffset + 13] = ((i11 << 8) | (i12 >>> 24)) & 268435455;
      unCompressedData[outOffset + 14] = ((i12 << 4) | (i13 >>> 28)) & 268435455;
      unCompressedData[outOffset + 15] = i13 & 268435455;
      unCompressedData[outOffset + 16] = (i14 >>> 4);
      unCompressedData[outOffset + 17] = ((i14 << 24) | (i15 >>> 8)) & 268435455;
      unCompressedData[outOffset + 18] = ((i15 << 20) | (i16 >>> 12)) & 268435455;
      unCompressedData[outOffset + 19] = ((i16 << 16) | (i17 >>> 16)) & 268435455;
      unCompressedData[outOffset + 20] = ((i17 << 12) | (i18 >>> 20)) & 268435455;
      unCompressedData[outOffset + 21] = ((i18 << 8) | (i19 >>> 24)) & 268435455;
      unCompressedData[outOffset + 22] = ((i19 << 4) | (i20 >>> 28)) & 268435455;
      unCompressedData[outOffset + 23] = i20 & 268435455;
      unCompressedData[outOffset + 24] = (i21 >>> 4);
      unCompressedData[outOffset + 25] = ((i21 << 24) | (i22 >>> 8)) & 268435455;
      unCompressedData[outOffset + 26] = ((i22 << 20) | (i23 >>> 12)) & 268435455;
      unCompressedData[outOffset + 27] = ((i23 << 16) | (i24 >>> 16)) & 268435455;
      unCompressedData[outOffset + 28] = ((i24 << 12) | (i25 >>> 20)) & 268435455;
      unCompressedData[outOffset + 29] = ((i25 << 8) | (i26 >>> 24)) & 268435455;
      unCompressedData[outOffset + 30] = ((i26 << 4) | (i27 >>> 28)) & 268435455;
      unCompressedData[outOffset + 31] = i27 & 268435455;
    }
  }

  public static final class FrameDecompressor29 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));
      int i23 = ((compressedArray[inOffset + 92] & 0xFF) << 24) | ((compressedArray[inOffset + 93] & 0xFF) << 16) | ((compressedArray[inOffset + 94] & 0xFF) << 8) | ((compressedArray[inOffset + 95] & 0xFF));
      int i24 = ((compressedArray[inOffset + 96] & 0xFF) << 24) | ((compressedArray[inOffset + 97] & 0xFF) << 16) | ((compressedArray[inOffset + 98] & 0xFF) << 8) | ((compressedArray[inOffset + 99] & 0xFF));
      int i25 = ((compressedArray[inOffset + 100] & 0xFF) << 24) | ((compressedArray[inOffset + 101] & 0xFF) << 16) | ((compressedArray[inOffset + 102] & 0xFF) << 8) | ((compressedArray[inOffset + 103] & 0xFF));
      int i26 = ((compressedArray[inOffset + 104] & 0xFF) << 24) | ((compressedArray[inOffset + 105] & 0xFF) << 16) | ((compressedArray[inOffset + 106] & 0xFF) << 8) | ((compressedArray[inOffset + 107] & 0xFF));
      int i27 = ((compressedArray[inOffset + 108] & 0xFF) << 24) | ((compressedArray[inOffset + 109] & 0xFF) << 16) | ((compressedArray[inOffset + 110] & 0xFF) << 8) | ((compressedArray[inOffset + 111] & 0xFF));
      int i28 = ((compressedArray[inOffset + 112] & 0xFF) << 24) | ((compressedArray[inOffset + 113] & 0xFF) << 16) | ((compressedArray[inOffset + 114] & 0xFF) << 8) | ((compressedArray[inOffset + 115] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 3);
      unCompressedData[outOffset + 1] = ((i0 << 26) | (i1 >>> 6)) & 536870911;
      unCompressedData[outOffset + 2] = ((i1 << 23) | (i2 >>> 9)) & 536870911;
      unCompressedData[outOffset + 3] = ((i2 << 20) | (i3 >>> 12)) & 536870911;
      unCompressedData[outOffset + 4] = ((i3 << 17) | (i4 >>> 15)) & 536870911;
      unCompressedData[outOffset + 5] = ((i4 << 14) | (i5 >>> 18)) & 536870911;
      unCompressedData[outOffset + 6] = ((i5 << 11) | (i6 >>> 21)) & 536870911;
      unCompressedData[outOffset + 7] = ((i6 << 8) | (i7 >>> 24)) & 536870911;
      unCompressedData[outOffset + 8] = ((i7 << 5) | (i8 >>> 27)) & 536870911;
      unCompressedData[outOffset + 9] = ((i8 << 2) | (i9 >>> 30)) & 536870911;
      unCompressedData[outOffset + 10] = (i9 >>> 1) & 536870911;
      unCompressedData[outOffset + 11] = ((i9 << 28) | (i10 >>> 4)) & 536870911;
      unCompressedData[outOffset + 12] = ((i10 << 25) | (i11 >>> 7)) & 536870911;
      unCompressedData[outOffset + 13] = ((i11 << 22) | (i12 >>> 10)) & 536870911;
      unCompressedData[outOffset + 14] = ((i12 << 19) | (i13 >>> 13)) & 536870911;
      unCompressedData[outOffset + 15] = ((i13 << 16) | (i14 >>> 16)) & 536870911;
      unCompressedData[outOffset + 16] = ((i14 << 13) | (i15 >>> 19)) & 536870911;
      unCompressedData[outOffset + 17] = ((i15 << 10) | (i16 >>> 22)) & 536870911;
      unCompressedData[outOffset + 18] = ((i16 << 7) | (i17 >>> 25)) & 536870911;
      unCompressedData[outOffset + 19] = ((i17 << 4) | (i18 >>> 28)) & 536870911;
      unCompressedData[outOffset + 20] = ((i18 << 1) | (i19 >>> 31)) & 536870911;
      unCompressedData[outOffset + 21] = (i19 >>> 2) & 536870911;
      unCompressedData[outOffset + 22] = ((i19 << 27) | (i20 >>> 5)) & 536870911;
      unCompressedData[outOffset + 23] = ((i20 << 24) | (i21 >>> 8)) & 536870911;
      unCompressedData[outOffset + 24] = ((i21 << 21) | (i22 >>> 11)) & 536870911;
      unCompressedData[outOffset + 25] = ((i22 << 18) | (i23 >>> 14)) & 536870911;
      unCompressedData[outOffset + 26] = ((i23 << 15) | (i24 >>> 17)) & 536870911;
      unCompressedData[outOffset + 27] = ((i24 << 12) | (i25 >>> 20)) & 536870911;
      unCompressedData[outOffset + 28] = ((i25 << 9) | (i26 >>> 23)) & 536870911;
      unCompressedData[outOffset + 29] = ((i26 << 6) | (i27 >>> 26)) & 536870911;
      unCompressedData[outOffset + 30] = ((i27 << 3) | (i28 >>> 29)) & 536870911;
      unCompressedData[outOffset + 31] = i28 & 536870911;
    }
  }

  public static final class FrameDecompressor30 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));
      int i23 = ((compressedArray[inOffset + 92] & 0xFF) << 24) | ((compressedArray[inOffset + 93] & 0xFF) << 16) | ((compressedArray[inOffset + 94] & 0xFF) << 8) | ((compressedArray[inOffset + 95] & 0xFF));
      int i24 = ((compressedArray[inOffset + 96] & 0xFF) << 24) | ((compressedArray[inOffset + 97] & 0xFF) << 16) | ((compressedArray[inOffset + 98] & 0xFF) << 8) | ((compressedArray[inOffset + 99] & 0xFF));
      int i25 = ((compressedArray[inOffset + 100] & 0xFF) << 24) | ((compressedArray[inOffset + 101] & 0xFF) << 16) | ((compressedArray[inOffset + 102] & 0xFF) << 8) | ((compressedArray[inOffset + 103] & 0xFF));
      int i26 = ((compressedArray[inOffset + 104] & 0xFF) << 24) | ((compressedArray[inOffset + 105] & 0xFF) << 16) | ((compressedArray[inOffset + 106] & 0xFF) << 8) | ((compressedArray[inOffset + 107] & 0xFF));
      int i27 = ((compressedArray[inOffset + 108] & 0xFF) << 24) | ((compressedArray[inOffset + 109] & 0xFF) << 16) | ((compressedArray[inOffset + 110] & 0xFF) << 8) | ((compressedArray[inOffset + 111] & 0xFF));
      int i28 = ((compressedArray[inOffset + 112] & 0xFF) << 24) | ((compressedArray[inOffset + 113] & 0xFF) << 16) | ((compressedArray[inOffset + 114] & 0xFF) << 8) | ((compressedArray[inOffset + 115] & 0xFF));
      int i29 = ((compressedArray[inOffset + 116] & 0xFF) << 24) | ((compressedArray[inOffset + 117] & 0xFF) << 16) | ((compressedArray[inOffset + 118] & 0xFF) << 8) | ((compressedArray[inOffset + 119] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 2);
      unCompressedData[outOffset + 1] = ((i0 << 28) | (i1 >>> 4)) & 1073741823;
      unCompressedData[outOffset + 2] = ((i1 << 26) | (i2 >>> 6)) & 1073741823;
      unCompressedData[outOffset + 3] = ((i2 << 24) | (i3 >>> 8)) & 1073741823;
      unCompressedData[outOffset + 4] = ((i3 << 22) | (i4 >>> 10)) & 1073741823;
      unCompressedData[outOffset + 5] = ((i4 << 20) | (i5 >>> 12)) & 1073741823;
      unCompressedData[outOffset + 6] = ((i5 << 18) | (i6 >>> 14)) & 1073741823;
      unCompressedData[outOffset + 7] = ((i6 << 16) | (i7 >>> 16)) & 1073741823;
      unCompressedData[outOffset + 8] = ((i7 << 14) | (i8 >>> 18)) & 1073741823;
      unCompressedData[outOffset + 9] = ((i8 << 12) | (i9 >>> 20)) & 1073741823;
      unCompressedData[outOffset + 10] = ((i9 << 10) | (i10 >>> 22)) & 1073741823;
      unCompressedData[outOffset + 11] = ((i10 << 8) | (i11 >>> 24)) & 1073741823;
      unCompressedData[outOffset + 12] = ((i11 << 6) | (i12 >>> 26)) & 1073741823;
      unCompressedData[outOffset + 13] = ((i12 << 4) | (i13 >>> 28)) & 1073741823;
      unCompressedData[outOffset + 14] = ((i13 << 2) | (i14 >>> 30)) & 1073741823;
      unCompressedData[outOffset + 15] = i14 & 1073741823;
      unCompressedData[outOffset + 16] = (i15 >>> 2);
      unCompressedData[outOffset + 17] = ((i15 << 28) | (i16 >>> 4)) & 1073741823;
      unCompressedData[outOffset + 18] = ((i16 << 26) | (i17 >>> 6)) & 1073741823;
      unCompressedData[outOffset + 19] = ((i17 << 24) | (i18 >>> 8)) & 1073741823;
      unCompressedData[outOffset + 20] = ((i18 << 22) | (i19 >>> 10)) & 1073741823;
      unCompressedData[outOffset + 21] = ((i19 << 20) | (i20 >>> 12)) & 1073741823;
      unCompressedData[outOffset + 22] = ((i20 << 18) | (i21 >>> 14)) & 1073741823;
      unCompressedData[outOffset + 23] = ((i21 << 16) | (i22 >>> 16)) & 1073741823;
      unCompressedData[outOffset + 24] = ((i22 << 14) | (i23 >>> 18)) & 1073741823;
      unCompressedData[outOffset + 25] = ((i23 << 12) | (i24 >>> 20)) & 1073741823;
      unCompressedData[outOffset + 26] = ((i24 << 10) | (i25 >>> 22)) & 1073741823;
      unCompressedData[outOffset + 27] = ((i25 << 8) | (i26 >>> 24)) & 1073741823;
      unCompressedData[outOffset + 28] = ((i26 << 6) | (i27 >>> 26)) & 1073741823;
      unCompressedData[outOffset + 29] = ((i27 << 4) | (i28 >>> 28)) & 1073741823;
      unCompressedData[outOffset + 30] = ((i28 << 2) | (i29 >>> 30)) & 1073741823;
      unCompressedData[outOffset + 31] = i29 & 1073741823;
    }
  }

  public static final class FrameDecompressor31 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));
      int i23 = ((compressedArray[inOffset + 92] & 0xFF) << 24) | ((compressedArray[inOffset + 93] & 0xFF) << 16) | ((compressedArray[inOffset + 94] & 0xFF) << 8) | ((compressedArray[inOffset + 95] & 0xFF));
      int i24 = ((compressedArray[inOffset + 96] & 0xFF) << 24) | ((compressedArray[inOffset + 97] & 0xFF) << 16) | ((compressedArray[inOffset + 98] & 0xFF) << 8) | ((compressedArray[inOffset + 99] & 0xFF));
      int i25 = ((compressedArray[inOffset + 100] & 0xFF) << 24) | ((compressedArray[inOffset + 101] & 0xFF) << 16) | ((compressedArray[inOffset + 102] & 0xFF) << 8) | ((compressedArray[inOffset + 103] & 0xFF));
      int i26 = ((compressedArray[inOffset + 104] & 0xFF) << 24) | ((compressedArray[inOffset + 105] & 0xFF) << 16) | ((compressedArray[inOffset + 106] & 0xFF) << 8) | ((compressedArray[inOffset + 107] & 0xFF));
      int i27 = ((compressedArray[inOffset + 108] & 0xFF) << 24) | ((compressedArray[inOffset + 109] & 0xFF) << 16) | ((compressedArray[inOffset + 110] & 0xFF) << 8) | ((compressedArray[inOffset + 111] & 0xFF));
      int i28 = ((compressedArray[inOffset + 112] & 0xFF) << 24) | ((compressedArray[inOffset + 113] & 0xFF) << 16) | ((compressedArray[inOffset + 114] & 0xFF) << 8) | ((compressedArray[inOffset + 115] & 0xFF));
      int i29 = ((compressedArray[inOffset + 116] & 0xFF) << 24) | ((compressedArray[inOffset + 117] & 0xFF) << 16) | ((compressedArray[inOffset + 118] & 0xFF) << 8) | ((compressedArray[inOffset + 119] & 0xFF));
      int i30 = ((compressedArray[inOffset + 120] & 0xFF) << 24) | ((compressedArray[inOffset + 121] & 0xFF) << 16) | ((compressedArray[inOffset + 122] & 0xFF) << 8) | ((compressedArray[inOffset + 123] & 0xFF));

      unCompressedData[outOffset + 0] = (i0 >>> 1);
      unCompressedData[outOffset + 1] = ((i0 << 30) | (i1 >>> 2)) & 2147483647;
      unCompressedData[outOffset + 2] = ((i1 << 29) | (i2 >>> 3)) & 2147483647;
      unCompressedData[outOffset + 3] = ((i2 << 28) | (i3 >>> 4)) & 2147483647;
      unCompressedData[outOffset + 4] = ((i3 << 27) | (i4 >>> 5)) & 2147483647;
      unCompressedData[outOffset + 5] = ((i4 << 26) | (i5 >>> 6)) & 2147483647;
      unCompressedData[outOffset + 6] = ((i5 << 25) | (i6 >>> 7)) & 2147483647;
      unCompressedData[outOffset + 7] = ((i6 << 24) | (i7 >>> 8)) & 2147483647;
      unCompressedData[outOffset + 8] = ((i7 << 23) | (i8 >>> 9)) & 2147483647;
      unCompressedData[outOffset + 9] = ((i8 << 22) | (i9 >>> 10)) & 2147483647;
      unCompressedData[outOffset + 10] = ((i9 << 21) | (i10 >>> 11)) & 2147483647;
      unCompressedData[outOffset + 11] = ((i10 << 20) | (i11 >>> 12)) & 2147483647;
      unCompressedData[outOffset + 12] = ((i11 << 19) | (i12 >>> 13)) & 2147483647;
      unCompressedData[outOffset + 13] = ((i12 << 18) | (i13 >>> 14)) & 2147483647;
      unCompressedData[outOffset + 14] = ((i13 << 17) | (i14 >>> 15)) & 2147483647;
      unCompressedData[outOffset + 15] = ((i14 << 16) | (i15 >>> 16)) & 2147483647;
      unCompressedData[outOffset + 16] = ((i15 << 15) | (i16 >>> 17)) & 2147483647;
      unCompressedData[outOffset + 17] = ((i16 << 14) | (i17 >>> 18)) & 2147483647;
      unCompressedData[outOffset + 18] = ((i17 << 13) | (i18 >>> 19)) & 2147483647;
      unCompressedData[outOffset + 19] = ((i18 << 12) | (i19 >>> 20)) & 2147483647;
      unCompressedData[outOffset + 20] = ((i19 << 11) | (i20 >>> 21)) & 2147483647;
      unCompressedData[outOffset + 21] = ((i20 << 10) | (i21 >>> 22)) & 2147483647;
      unCompressedData[outOffset + 22] = ((i21 << 9) | (i22 >>> 23)) & 2147483647;
      unCompressedData[outOffset + 23] = ((i22 << 8) | (i23 >>> 24)) & 2147483647;
      unCompressedData[outOffset + 24] = ((i23 << 7) | (i24 >>> 25)) & 2147483647;
      unCompressedData[outOffset + 25] = ((i24 << 6) | (i25 >>> 26)) & 2147483647;
      unCompressedData[outOffset + 26] = ((i25 << 5) | (i26 >>> 27)) & 2147483647;
      unCompressedData[outOffset + 27] = ((i26 << 4) | (i27 >>> 28)) & 2147483647;
      unCompressedData[outOffset + 28] = ((i27 << 3) | (i28 >>> 29)) & 2147483647;
      unCompressedData[outOffset + 29] = ((i28 << 2) | (i29 >>> 30)) & 2147483647;
      unCompressedData[outOffset + 30] = ((i29 << 1) | (i30 >>> 31)) & 2147483647;
      unCompressedData[outOffset + 31] = i30 & 2147483647;
    }
  }

  public static final class FrameDecompressor32 extends FrameDecompressor {
    public final void decompress(final AbstractFrameOfRef frameOfRef) {
      final int[] unCompressedData = frameOfRef.unCompressedData;
      final byte[] compressedArray = frameOfRef.compressedArray;
      int inOffset = frameOfRef.index;
      int outOffset = frameOfRef.offset;
      int i0 = ((compressedArray[inOffset + 0] & 0xFF) << 24) | ((compressedArray[inOffset + 1] & 0xFF) << 16) | ((compressedArray[inOffset + 2] & 0xFF) << 8) | ((compressedArray[inOffset + 3] & 0xFF));
      int i1 = ((compressedArray[inOffset + 4] & 0xFF) << 24) | ((compressedArray[inOffset + 5] & 0xFF) << 16) | ((compressedArray[inOffset + 6] & 0xFF) << 8) | ((compressedArray[inOffset + 7] & 0xFF));
      int i2 = ((compressedArray[inOffset + 8] & 0xFF) << 24) | ((compressedArray[inOffset + 9] & 0xFF) << 16) | ((compressedArray[inOffset + 10] & 0xFF) << 8) | ((compressedArray[inOffset + 11] & 0xFF));
      int i3 = ((compressedArray[inOffset + 12] & 0xFF) << 24) | ((compressedArray[inOffset + 13] & 0xFF) << 16) | ((compressedArray[inOffset + 14] & 0xFF) << 8) | ((compressedArray[inOffset + 15] & 0xFF));
      int i4 = ((compressedArray[inOffset + 16] & 0xFF) << 24) | ((compressedArray[inOffset + 17] & 0xFF) << 16) | ((compressedArray[inOffset + 18] & 0xFF) << 8) | ((compressedArray[inOffset + 19] & 0xFF));
      int i5 = ((compressedArray[inOffset + 20] & 0xFF) << 24) | ((compressedArray[inOffset + 21] & 0xFF) << 16) | ((compressedArray[inOffset + 22] & 0xFF) << 8) | ((compressedArray[inOffset + 23] & 0xFF));
      int i6 = ((compressedArray[inOffset + 24] & 0xFF) << 24) | ((compressedArray[inOffset + 25] & 0xFF) << 16) | ((compressedArray[inOffset + 26] & 0xFF) << 8) | ((compressedArray[inOffset + 27] & 0xFF));
      int i7 = ((compressedArray[inOffset + 28] & 0xFF) << 24) | ((compressedArray[inOffset + 29] & 0xFF) << 16) | ((compressedArray[inOffset + 30] & 0xFF) << 8) | ((compressedArray[inOffset + 31] & 0xFF));
      int i8 = ((compressedArray[inOffset + 32] & 0xFF) << 24) | ((compressedArray[inOffset + 33] & 0xFF) << 16) | ((compressedArray[inOffset + 34] & 0xFF) << 8) | ((compressedArray[inOffset + 35] & 0xFF));
      int i9 = ((compressedArray[inOffset + 36] & 0xFF) << 24) | ((compressedArray[inOffset + 37] & 0xFF) << 16) | ((compressedArray[inOffset + 38] & 0xFF) << 8) | ((compressedArray[inOffset + 39] & 0xFF));
      int i10 = ((compressedArray[inOffset + 40] & 0xFF) << 24) | ((compressedArray[inOffset + 41] & 0xFF) << 16) | ((compressedArray[inOffset + 42] & 0xFF) << 8) | ((compressedArray[inOffset + 43] & 0xFF));
      int i11 = ((compressedArray[inOffset + 44] & 0xFF) << 24) | ((compressedArray[inOffset + 45] & 0xFF) << 16) | ((compressedArray[inOffset + 46] & 0xFF) << 8) | ((compressedArray[inOffset + 47] & 0xFF));
      int i12 = ((compressedArray[inOffset + 48] & 0xFF) << 24) | ((compressedArray[inOffset + 49] & 0xFF) << 16) | ((compressedArray[inOffset + 50] & 0xFF) << 8) | ((compressedArray[inOffset + 51] & 0xFF));
      int i13 = ((compressedArray[inOffset + 52] & 0xFF) << 24) | ((compressedArray[inOffset + 53] & 0xFF) << 16) | ((compressedArray[inOffset + 54] & 0xFF) << 8) | ((compressedArray[inOffset + 55] & 0xFF));
      int i14 = ((compressedArray[inOffset + 56] & 0xFF) << 24) | ((compressedArray[inOffset + 57] & 0xFF) << 16) | ((compressedArray[inOffset + 58] & 0xFF) << 8) | ((compressedArray[inOffset + 59] & 0xFF));
      int i15 = ((compressedArray[inOffset + 60] & 0xFF) << 24) | ((compressedArray[inOffset + 61] & 0xFF) << 16) | ((compressedArray[inOffset + 62] & 0xFF) << 8) | ((compressedArray[inOffset + 63] & 0xFF));
      int i16 = ((compressedArray[inOffset + 64] & 0xFF) << 24) | ((compressedArray[inOffset + 65] & 0xFF) << 16) | ((compressedArray[inOffset + 66] & 0xFF) << 8) | ((compressedArray[inOffset + 67] & 0xFF));
      int i17 = ((compressedArray[inOffset + 68] & 0xFF) << 24) | ((compressedArray[inOffset + 69] & 0xFF) << 16) | ((compressedArray[inOffset + 70] & 0xFF) << 8) | ((compressedArray[inOffset + 71] & 0xFF));
      int i18 = ((compressedArray[inOffset + 72] & 0xFF) << 24) | ((compressedArray[inOffset + 73] & 0xFF) << 16) | ((compressedArray[inOffset + 74] & 0xFF) << 8) | ((compressedArray[inOffset + 75] & 0xFF));
      int i19 = ((compressedArray[inOffset + 76] & 0xFF) << 24) | ((compressedArray[inOffset + 77] & 0xFF) << 16) | ((compressedArray[inOffset + 78] & 0xFF) << 8) | ((compressedArray[inOffset + 79] & 0xFF));
      int i20 = ((compressedArray[inOffset + 80] & 0xFF) << 24) | ((compressedArray[inOffset + 81] & 0xFF) << 16) | ((compressedArray[inOffset + 82] & 0xFF) << 8) | ((compressedArray[inOffset + 83] & 0xFF));
      int i21 = ((compressedArray[inOffset + 84] & 0xFF) << 24) | ((compressedArray[inOffset + 85] & 0xFF) << 16) | ((compressedArray[inOffset + 86] & 0xFF) << 8) | ((compressedArray[inOffset + 87] & 0xFF));
      int i22 = ((compressedArray[inOffset + 88] & 0xFF) << 24) | ((compressedArray[inOffset + 89] & 0xFF) << 16) | ((compressedArray[inOffset + 90] & 0xFF) << 8) | ((compressedArray[inOffset + 91] & 0xFF));
      int i23 = ((compressedArray[inOffset + 92] & 0xFF) << 24) | ((compressedArray[inOffset + 93] & 0xFF) << 16) | ((compressedArray[inOffset + 94] & 0xFF) << 8) | ((compressedArray[inOffset + 95] & 0xFF));
      int i24 = ((compressedArray[inOffset + 96] & 0xFF) << 24) | ((compressedArray[inOffset + 97] & 0xFF) << 16) | ((compressedArray[inOffset + 98] & 0xFF) << 8) | ((compressedArray[inOffset + 99] & 0xFF));
      int i25 = ((compressedArray[inOffset + 100] & 0xFF) << 24) | ((compressedArray[inOffset + 101] & 0xFF) << 16) | ((compressedArray[inOffset + 102] & 0xFF) << 8) | ((compressedArray[inOffset + 103] & 0xFF));
      int i26 = ((compressedArray[inOffset + 104] & 0xFF) << 24) | ((compressedArray[inOffset + 105] & 0xFF) << 16) | ((compressedArray[inOffset + 106] & 0xFF) << 8) | ((compressedArray[inOffset + 107] & 0xFF));
      int i27 = ((compressedArray[inOffset + 108] & 0xFF) << 24) | ((compressedArray[inOffset + 109] & 0xFF) << 16) | ((compressedArray[inOffset + 110] & 0xFF) << 8) | ((compressedArray[inOffset + 111] & 0xFF));
      int i28 = ((compressedArray[inOffset + 112] & 0xFF) << 24) | ((compressedArray[inOffset + 113] & 0xFF) << 16) | ((compressedArray[inOffset + 114] & 0xFF) << 8) | ((compressedArray[inOffset + 115] & 0xFF));
      int i29 = ((compressedArray[inOffset + 116] & 0xFF) << 24) | ((compressedArray[inOffset + 117] & 0xFF) << 16) | ((compressedArray[inOffset + 118] & 0xFF) << 8) | ((compressedArray[inOffset + 119] & 0xFF));
      int i30 = ((compressedArray[inOffset + 120] & 0xFF) << 24) | ((compressedArray[inOffset + 121] & 0xFF) << 16) | ((compressedArray[inOffset + 122] & 0xFF) << 8) | ((compressedArray[inOffset + 123] & 0xFF));
      int i31 = ((compressedArray[inOffset + 124] & 0xFF) << 24) | ((compressedArray[inOffset + 125] & 0xFF) << 16) | ((compressedArray[inOffset + 126] & 0xFF) << 8) | ((compressedArray[inOffset + 127] & 0xFF));

      unCompressedData[outOffset + 0] = i0;
      unCompressedData[outOffset + 1] = i1;
      unCompressedData[outOffset + 2] = i2;
      unCompressedData[outOffset + 3] = i3;
      unCompressedData[outOffset + 4] = i4;
      unCompressedData[outOffset + 5] = i5;
      unCompressedData[outOffset + 6] = i6;
      unCompressedData[outOffset + 7] = i7;
      unCompressedData[outOffset + 8] = i8;
      unCompressedData[outOffset + 9] = i9;
      unCompressedData[outOffset + 10] = i10;
      unCompressedData[outOffset + 11] = i11;
      unCompressedData[outOffset + 12] = i12;
      unCompressedData[outOffset + 13] = i13;
      unCompressedData[outOffset + 14] = i14;
      unCompressedData[outOffset + 15] = i15;
      unCompressedData[outOffset + 16] = i16;
      unCompressedData[outOffset + 17] = i17;
      unCompressedData[outOffset + 18] = i18;
      unCompressedData[outOffset + 19] = i19;
      unCompressedData[outOffset + 20] = i20;
      unCompressedData[outOffset + 21] = i21;
      unCompressedData[outOffset + 22] = i22;
      unCompressedData[outOffset + 23] = i23;
      unCompressedData[outOffset + 24] = i24;
      unCompressedData[outOffset + 25] = i25;
      unCompressedData[outOffset + 26] = i26;
      unCompressedData[outOffset + 27] = i27;
      unCompressedData[outOffset + 28] = i28;
      unCompressedData[outOffset + 29] = i29;
      unCompressedData[outOffset + 30] = i30;
      unCompressedData[outOffset + 31] = i31;
    }
  }

}
