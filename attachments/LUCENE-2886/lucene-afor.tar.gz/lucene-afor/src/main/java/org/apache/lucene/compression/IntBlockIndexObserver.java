/**
 * Copyright 2010, Renaud Delbru
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.lucene.compression;

import java.util.HashMap;
import java.util.Map;

import org.apache.lucene.index.codecs.intblock.FixedIntBlockIndexInput.BlockReader;
import org.apache.lucene.index.codecs.intblock.IntBlockCodec;

/**
 * Observer for a {@link IntBlockCodec} that records the number of bytes read.
 * <br>
 * Thread-safe, record the number of bytes read per thread.
 */
public class IntBlockIndexObserver  {

  Map<Long,Map<BlockReader, Long>> bytesRead;

  public static boolean OBSERVE = true;

  private IntBlockIndexObserver() {
    bytesRead = new HashMap<Long,Map<BlockReader, Long>>();
  }

  /**
   * IntBlockIndexObserverHolder is loaded on the first execution of
   * IntBlockIndexObserver.getInstance() or the first access to
   * IntBlockIndexObserverHolder.INSTANCE, not before.
   */
  private static class IntBlockIndexObserverHolder {
    private static final IntBlockIndexObserver INSTANCE = new IntBlockIndexObserver();
  }

  public static IntBlockIndexObserver getInstance() {
    return IntBlockIndexObserverHolder.INSTANCE;
  }

  public void register(final long threadId, final BlockReader reader) {
    if (!OBSERVE) return;
    if (!bytesRead.containsKey(threadId)) {
      bytesRead.put(threadId, new HashMap<BlockReader,Long>());
    }
    bytesRead.get(threadId).put(reader, 0L);
  }

  public void update(final long threadId, final BlockReader reader, final long numBytes) {
    if (!OBSERVE) return;
    bytesRead.get(threadId).put(reader, bytesRead.get(threadId).get(reader) + numBytes);
  }

  /**
   * Return the number of byte reads by the current thread, and remove them
   * from the underlying storage of the observer. That means that this method
   * can be called only one time.
   */
  public long getBytesRead(final long threadId) {
    if (!bytesRead.containsKey(threadId)) { // unknown thread
      return 0;
    }

    long totalNumBytes = 0;
    for (final long numBytes : bytesRead.get(threadId).values()) {
      totalNumBytes += numBytes;
    }
    // Remove elements from the associated thread
    bytesRead.remove(threadId);
    return totalNumBytes;
  }

}
