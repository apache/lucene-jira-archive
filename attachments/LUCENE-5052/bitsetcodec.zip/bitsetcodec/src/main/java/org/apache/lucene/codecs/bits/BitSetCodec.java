package org.apache.lucene.codecs.bits;

import org.apache.lucene.codecs.FilterCodec;
import org.apache.lucene.codecs.PostingsFormat;
import org.apache.lucene.codecs.lucene46.Lucene46Codec;

public class BitSetCodec extends FilterCodec {

  public BitSetCodec() {
    super("BitSetCodec", new Lucene46Codec());
  }

  @Override
  public PostingsFormat postingsFormat() {
    return new BitSetPostingsFormat();
  }
}
