package org.apache.lucene.codecs.bits;

import org.apache.lucene.codecs.BlockTermState;
import org.apache.lucene.index.TermState;

class BitSetBlockTermState extends BlockTermState {
  public long startPostingsPosition;

  @Override
  public void copyFrom(TermState _other) {
    super.copyFrom(_other);
    this.startPostingsPosition = ((BitSetBlockTermState) _other).startPostingsPosition;
  }
}
