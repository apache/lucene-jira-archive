package org.apache.lucene.codecs.bits;

import org.apache.lucene.codecs.BlockTermState;
import org.apache.lucene.codecs.PostingsReaderBase;
import org.apache.lucene.index.*;
import org.apache.lucene.store.*;
import org.apache.lucene.util.Bits;

import java.io.IOException;

class BitSetPostingsReader extends PostingsReaderBase {

  private IndexInput pst;
  private SegmentReadState segmentReadState;

  BitSetPostingsReader(SegmentReadState state) throws IOException {
    this.segmentReadState = state;
    pst = state.directory.openInput(
        BitSetPostingsFormat.getPostingsFileName(state.segmentInfo.name, state.segmentSuffix),
        state.context);
  }

  @Override
  public void init(IndexInput termsIn) throws IOException {
  }

  @Override
  public BlockTermState newTermState() throws IOException {
    return new BitSetBlockTermState();
  }

  @Override
  public void decodeTerm(long[] longs, DataInput in, FieldInfo fieldInfo, BlockTermState state, boolean absolute) throws IOException {
    assert longs.length == BitSetPostingsWriter.METADATA_LONG_SIZE;
    ((BitSetBlockTermState) state).startPostingsPosition = in.readVLong();
  }

  @Override
  public DocsEnum docs(FieldInfo fieldInfo, BlockTermState state, Bits skipDocs, DocsEnum reuse, int flags) throws IOException {
    BitSetBlockTermState postingTermsState = (BitSetBlockTermState) state;
    return new BitSetDocsEnum(postingTermsState.startPostingsPosition, skipDocs, pst, segmentReadState.segmentInfo.getDocCount());
  }

  @Override
  public DocsAndPositionsEnum docsAndPositions(FieldInfo fieldInfo, BlockTermState state, Bits skipDocs, DocsAndPositionsEnum reuse, int flags) throws IOException {
    return null;
  }

  @Override
  public long ramBytesUsed() {
    return 0;
  }

  @Override
  public void close() throws IOException {
    pst.close();
  }
}
