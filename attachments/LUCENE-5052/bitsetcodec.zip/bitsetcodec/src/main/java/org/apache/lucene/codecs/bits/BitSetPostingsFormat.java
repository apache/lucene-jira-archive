package org.apache.lucene.codecs.bits;

import org.apache.lucene.codecs.FieldsConsumer;
import org.apache.lucene.codecs.FieldsProducer;
import org.apache.lucene.codecs.PostingsFormat;
import org.apache.lucene.codecs.PostingsReaderBase;
import org.apache.lucene.codecs.blockterms.*;
import org.apache.lucene.index.IndexFileNames;
import org.apache.lucene.index.SegmentReadState;
import org.apache.lucene.index.SegmentWriteState;
import org.apache.lucene.util.BytesRef;

import java.io.IOException;

public class BitSetPostingsFormat extends PostingsFormat {

  static final String POSTINGS_EXTENSION = "pst";

  public BitSetPostingsFormat() {
    super("BitSetPostingsFormat");
  }

  static String getPostingsFileName(String segment, String segmentSuffix) {
    return IndexFileNames.segmentFileName(segment, segmentSuffix, POSTINGS_EXTENSION);
  }

  @Override
  public FieldsConsumer fieldsConsumer(SegmentWriteState state) throws IOException {
    TermsIndexWriterBase indexWriter = new FixedGapTermsIndexWriter(state);
    BitSetPostingsWriter postingsWriter = new BitSetPostingsWriter(state);
    return new BlockTermsWriter(indexWriter, state, postingsWriter);
  }

  @Override
  public FieldsProducer fieldsProducer(SegmentReadState state) throws IOException {
    PostingsReaderBase postings = new BitSetPostingsReader(state);
    TermsIndexReaderBase indexReader = new FixedGapTermsIndexReader(state.directory,
        state.fieldInfos,
        state.segmentInfo.name,
        BytesRef.getUTF8SortedAsUnicodeComparator(),
        state.segmentSuffix,
        state.context);
    return new BlockTermsReader(indexReader,
        state.directory,
        state.fieldInfos,
        state.segmentInfo,
        postings,
        state.context,
        state.segmentSuffix);
  }
}
