package org.apache.lucene.codecs.bits;

import org.apache.lucene.index.DocsEnum;
import org.apache.lucene.store.IndexInput;
import org.apache.lucene.util.Bits;

import java.io.IOException;

class BitSetDocsEnum extends DocsEnum {

  private final long filePosition;
  private final Bits liveDocs;
  private final IndexInput pstClone;
  private final int docCount;
  private final int postingsListLength;

  private int currentBytePosition = -1;
  private int readByte = 0;
  private int docID = -1;

  BitSetDocsEnum(long filePosition, Bits liveDocs, IndexInput pst, int docCount) throws IOException {
    this.filePosition = filePosition;
    pstClone = pst.clone();
    pstClone.seek(filePosition);
    this.docCount = docCount;
    this.liveDocs = liveDocs;
    if ((this.docCount & 0x07) == 0) {
      postingsListLength = this.docCount >> 3;
    } else {
      postingsListLength = (this.docCount >> 3) + 1;
    }
    pstClone.seek(filePosition);
  }

  @Override
  public int freq() throws IOException {
    return 1;
  }

  @Override
  public int docID() {
    return docID;
  }

  @Override
  public int nextDoc() throws IOException {
    do {
      docID++;
      final int subIndex = docID & 0x7; // index within the readByte
      if (subIndex == 0) {
        if (++currentBytePosition == postingsListLength) {
          return docID = NO_MORE_DOCS;
        }
        readByte = pstClone.readByte() & 0xff;
      }
      int word = readByte >> subIndex; // skip all the bits to the right of index
      if (word != 0) {
        docID = docID + Long.numberOfTrailingZeros(word);
      } else {
        while (++currentBytePosition < postingsListLength) {
          readByte = pstClone.readByte() & 0xff;
          if (readByte != 0) {
            docID = (currentBytePosition << 3) + Long.numberOfTrailingZeros(readByte);
            break;
          }
        }
        if (currentBytePosition == postingsListLength) {
          return docID = NO_MORE_DOCS;
        }
      }
    } while (!(liveDocs == null || liveDocs.get(docID)));
    return docID;
  }

  @Override
  public int advance(int target) throws IOException {
    if (docID == NO_MORE_DOCS || target >= docCount) {
      return docID = NO_MORE_DOCS;
    }
    if (target > 0) {
      docID = target - 1;
      currentBytePosition = docID >> 3;
      if ((target & 0x7) != 0) {
        pstClone.seek(filePosition + currentBytePosition);
        readByte = pstClone.readByte() & 0xff;
      } else {
        pstClone.seek(filePosition + currentBytePosition + 1);
      }
    }
    return nextDoc();
  }

  @Override
  public long cost() {
    return 1;
  }
}
