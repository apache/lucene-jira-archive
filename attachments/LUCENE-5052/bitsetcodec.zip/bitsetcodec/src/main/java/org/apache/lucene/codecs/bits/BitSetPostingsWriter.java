package org.apache.lucene.codecs.bits;

import org.apache.lucene.codecs.BlockTermState;
import org.apache.lucene.codecs.PushPostingsWriterBase;
import org.apache.lucene.index.FieldInfo;
import org.apache.lucene.index.SegmentWriteState;
import org.apache.lucene.store.DataOutput;
import org.apache.lucene.store.IndexOutput;
import org.apache.lucene.util.BytesRef;

import java.io.IOException;

class BitSetPostingsWriter extends PushPostingsWriterBase {
  static final int METADATA_LONG_SIZE = 0;
  private final IndexOutput pst;
  private final SegmentWriteState state;
  private BitSetPostingsFileWriter postingsWriter;
  private long startPostingPosition;

  BitSetPostingsWriter(SegmentWriteState state) throws IOException {
    String fileName = BitSetPostingsFormat.getPostingsFileName(state.segmentInfo.name, state.segmentSuffix);
    pst = state.directory.createOutput(fileName, state.context);
    this.state = state;
  }

  @Override
  public void startTerm() throws IOException {
    startPostingPosition = pst.getFilePointer();
    postingsWriter.startPostingsList();
  }

  @Override
  public void finishTerm(BlockTermState state) throws IOException {
    postingsWriter.finishPostingsList();
    if (pst.getFilePointer() - startPostingPosition > 0) {
      ((BitSetBlockTermState) state).startPostingsPosition = startPostingPosition;
    }
  }

  @Override
  public BlockTermState newTermState() throws IOException {
    return new BitSetBlockTermState();
  }

  @Override
  public void encodeTerm(long[] longs, DataOutput out, FieldInfo fieldInfo, BlockTermState state, boolean absolute) throws IOException {
    assert longs.length == METADATA_LONG_SIZE;
    out.writeVLong(((BitSetBlockTermState) state).startPostingsPosition);
    assert fieldInfo.getIndexOptions() == FieldInfo.IndexOptions.DOCS_ONLY ? state.totalTermFreq == -1 : state.totalTermFreq != -1;
  }

  @Override
  public int setField(FieldInfo fieldInfo) {
    super.setField(fieldInfo);
    postingsWriter = new BitSetPostingsFileWriter(state.segmentInfo.getDocCount(), pst);
    return METADATA_LONG_SIZE;
  }

  @Override
  public void close() throws IOException {
    try {
      pst.writeString("END");
    } finally {
      pst.close();
    }
  }

  @Override
  public void startDoc(int docID, int freq) throws IOException {
    postingsWriter.startDoc(docID);
  }

  @Override
  public void addPosition(int position, BytesRef payload, int startOffset, int endOffset) throws IOException {
  }

  @Override
  public void finishDoc() throws IOException {
  }

  @Override
  public void init(IndexOutput termsOut) throws IOException {
  }
}
