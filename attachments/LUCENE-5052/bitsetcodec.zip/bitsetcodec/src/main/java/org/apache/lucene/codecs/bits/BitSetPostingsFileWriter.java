package org.apache.lucene.codecs.bits;

import org.apache.lucene.store.IndexOutput;

import java.io.IOException;

class BitSetPostingsFileWriter {

  private static final byte ZERO = 0;
  private final IndexOutput pst;
  private final int docCount;
  private boolean started = false;
  private int currentWordPosition = 0;
  private byte word = 0;

  BitSetPostingsFileWriter(int docCount, IndexOutput pst) {
    this.pst = pst;
    this.docCount = docCount;
  }

  void startPostingsList() {
    if (started) {
      throw new IllegalStateException("Posting writer was started already");
    }
    started = true;
    currentWordPosition = 0;
  }

  void finishPostingsList() throws IOException {
    if (!started) {
      throw new IllegalStateException("Posting writer was not started");
    } else {
      started = false;
    }
    currentWordPosition++;
    pst.writeByte(word);
    word = 0;
    int postingsListLength;
    if ((docCount & 0x07) == 0) {
      postingsListLength = docCount >> 3;
    } else {
      postingsListLength = (docCount >> 3) + 1;
    }
    while ((currentWordPosition) <= postingsListLength) {
      currentWordPosition++;
      pst.writeByte(ZERO);
    }
    pst.flush();
  }

  void startDoc(int docID) throws IOException {
    int wordNumber = docID >> 3;
    int bitPosition = docID & 0x07;
    if (currentWordPosition < wordNumber) {
      currentWordPosition++;
      pst.writeByte(word);
      while (currentWordPosition < wordNumber) {
        currentWordPosition++;
        pst.writeByte(ZERO);
      }
      word = 0;
      word |= (byte) (1 << bitPosition);
    } else if (wordNumber == currentWordPosition) {
      word |= (byte) (1 << bitPosition);
    } else {
      throw new IllegalArgumentException("Docs must be added in ascending order.");
    }
  }
}
