package org.apache.lucene.codecs.bits;

import org.apache.lucene.codecs.Codec;
import org.apache.lucene.codecs.bits.BitSetCodec;
import org.apache.lucene.index.BasePostingsFormatTestCase;
import org.junit.Ignore;

public class BitSetCodecTest extends BasePostingsFormatTestCase {

    private Codec codec = new BitSetCodec();

    @Override
    protected Codec getCodec() {
        return codec;
    }

    @Override
    @Ignore
    public void testDocsAndFreqs() throws Exception {
        super.testDocsAndFreqs(); // not supported
    }

    @Override
    @Ignore
    public void testDocsAndFreqsAndPositions() throws Exception {
        super.testDocsAndFreqsAndPositions(); // not supported
    }

    @Override
    @Ignore
    public void testDocsAndFreqsAndPositionsAndPayloads() throws Exception {
        super.testDocsAndFreqsAndPositionsAndPayloads();  // not supported
    }

    @Override
    @Ignore
    public void testDocsAndFreqsAndPositionsAndOffsets() throws Exception {
        super.testDocsAndFreqsAndPositionsAndOffsets();  // not supported
    }

    @Override
    @Ignore
    public void testDocsAndFreqsAndPositionsAndOffsetsAndPayloads() throws Exception {
        super.testDocsAndFreqsAndPositionsAndOffsetsAndPayloads();  // not supported
    }

    @Override
    @Ignore
    public void testRandom() throws Exception {
        super.testRandom();  // not supported
    }

    @Override
    @Ignore
    public void testInvertedWrite() throws Exception {
        super.testInvertedWrite();   // not supported
    }
}
