ICUNormalizer2CharFilter
========================

Lucene CharFilter that applies Unicode Normalization using ICU4J.