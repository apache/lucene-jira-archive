package org.apache.lucene.jira;

import org.apache.lucene.codecs.FilterCodec;
import org.apache.lucene.codecs.lucene42.Lucene42Codec;

public final class Hybase42StandardCodec extends FilterCodec {

	public Hybase42StandardCodec() {
		super("hybaseStd42x", new Lucene42Codec());
	}
}