import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.AtomicReaderContext;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.*;
import org.apache.lucene.search.highlight.*;
import org.apache.lucene.store.FSDirectory;
import org.apache.lucene.util.Version;

import java.io.File;
import java.util.BitSet;

public class myApp
{
    public myApp()throws Exception
    {
        IndexSearcher defaultSearcher = new IndexSearcher(DirectoryReader.open(FSDirectory.open(new File("index"))));

        ArabicAnalyzer analyzer = new ArabicAnalyzer();
        final QueryParser queryParser = new QueryParser(Version.LUCENE_40, "Line", analyzer);
        final Query query = queryParser.parse("مقدمة");

        final BitSet bits = new BitSet(defaultSearcher.getIndexReader().maxDoc());
        defaultSearcher.search(query, new Collector()
        {
            private int docBase;
            public void setScorer(org.apache.lucene.search.Scorer scorer) {}
            public boolean acceptsDocsOutOfOrder() {return true;}
            public void collect(int doc) {bits.set(doc + docBase);}
            public void setNextReader(AtomicReaderContext context) {this.docBase = context.docBase;}
        });

        final Highlighter highlighter = new Highlighter(new SimpleHTMLFormatter("<font color=red>", "</font>"), new QueryScorer(query));
        for(int j=0, size=bits.length(); j<size; j++)
        {
            if(bits.get(j))
            {
                final Document doc = defaultSearcher.doc(j);
                String line="";
                final TokenStream tokenStream = TokenSources.getAnyTokenStream(defaultSearcher.getIndexReader(), j, "Line", analyzer);
                final TextFragment[] frag = highlighter.getBestTextFragments(tokenStream, doc.get("Line"), false, 10);

                for(TextFragment tf : frag)
                    if((tf != null) && (tf.getScore() > 0F))
                        line=line+" ... "+tf.toString();

                System.out.println("<HTML>"+line);
            }
        }
    }

    public static void main(String args[]) throws Exception
    {
        new myApp();
    }
}


