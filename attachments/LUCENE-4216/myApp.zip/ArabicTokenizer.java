/*
Copyright (C) 2003  Pierrick Brihaye
pierrick.brihaye@wanadoo.fr

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the
Free Software Foundation, Inc.
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
or connect to:
http://www.fsf.org/copyleft/gpl.html
*/

import java.io.*;
import java.util.regex.*;
import org.apache.lucene.analysis.*;
import org.apache.lucene.analysis.tokenattributes.*;

/** A tokenizer that will return tokens in the arabic alphabet. This tokenizer
 * is a bit rude since it also filters digits and punctuation, even in an arabic
 * part of stream. Well... I've planned to write a
 * "universal", highly configurable, character tokenizer.
 * @author Pierrick Brihaye, 2003
 */
class ArabicTokenizer extends Tokenizer
{
	private final CharTermAttribute termAtt;

	// to resolve the problem of the Highlighter
	private final OffsetAttribute offsetAtt;
	//private PositionIncrementAttribute posIncrAtt;
	//private TypeAttribute typeAtt;

	/** Constructs a tokenizer that will return tokens in the arabic alphabet.
	 * @param input The reader
	 */
	ArabicTokenizer(Reader input)
	{
		super(input);
		termAtt = addAttribute(CharTermAttribute.class);
		offsetAtt = addAttribute(OffsetAttribute.class);
		//posIncrAtt = addAttribute(PositionIncrementAttribute.class);
		//typeAtt = addAttribute(TypeAttribute.class);
	}

	/** Whether or not a character is in the arabic alphabet.
	 * @param c The char
	 * @return The result
	 */
	private static boolean isArabicChar(char c)
	{
		switch(c)
		{
			case 'ء': return true; //U+0621
			case 'آ': return true; //U+0622
			case 'أ': return true; //U+0623
			case 'ؤ': return true; //U+0624
			case 'إ': return true; //U+0625
			case 'ئ': return true; //U+0626
			case 'ا': return true; //U+0627
			case 'ب': return true; //U+0628
			case 'ة': return true; //U+0629
			case 'ت': return true; //U+062A
			case 'ث': return true; //U+062B
			case 'ج': return true; //U+062C
			case 'ح': return true; //U+062D
			case 'خ': return true; //U+062E
			case 'د': return true; //U+062F
			case 'ذ': return true; //U+0630
			case 'ر': return true; //U+0631
			case 'ز': return true; //U+0632
			case 'س': return true; //U+0633
			case 'ش': return true; //U+0634
			case 'ص': return true; //U+0635
			case 'ض': return true; //U+0636
			case 'ط': return true; //U+0637
			case 'ظ': return true; //U+0638
			case 'ع': return true; //U+0639
			case 'غ': return true; //U+063A
			case 'ـ': return true; //U+0640
			case 'ف': return true; //U+0641
			case 'ق': return true; //U+0642
			case 'ك': return true; //U+0643
			case 'ل': return true; //U+0644
			case 'م': return true; //U+0645
			case 'ن': return true; //U+0646
			case 'ه': return true; //U+0647
			case 'و': return true; //U+0648
			case 'ى': return true; //U+0649
			case 'ي': return true; //U+064A
			case 'ً': return true; //U+064B : ARABIC FATHATAN
			case 'ٌ': return true; //U+064C : ARABIC DAMMATAN
			case 'ٍ': return true; //U+064D : ARABIC KASRATAN
			case 'َ': return true; //U+064E : ARABIC FATHA
			case 'ُ': return true; //U+064F : ARABIC DAMMA
			case 'ِ': return true; //U+0650 : ARABIC KASRA
			case 'ّ': return true; //U+0651 : ARABIC SHADDA
			case 'ْ': return true; //U+0652 : ARABIC SUKUN
			default: return false;
		}
	}

	private int offset = 0, bufferIndex=0, dataLen=0;
	private static final int MAX_WORD_LEN = 255;
	private static final int IO_BUFFER_SIZE = 1024;
	private final char[] buffer = new char[MAX_WORD_LEN];
	private final char[] ioBuffer = new char[IO_BUFFER_SIZE];

    private final static Pattern pattern = Pattern.compile("[\u0650\u064D\u064E\u064B\u064F\u064C\u0652\u0651]"); // Performance gain
    
	/** Returns the next token in the stream, or <CODE>null</CODE> at EOS.
	 * @throws IOException If a problem occurs
	 * @return The token with its type set to <CODE>ARABIC</CODE>
	 */
	public boolean incrementToken() throws IOException
	{
		clearAttributes();
		int length = 0;
		int start = offset;
		while(true)
		{
			final char c;
			offset++;

			//Is buffer empty ?
			if(bufferIndex >= dataLen)
			{
				//Get a chunk
				dataLen = input.read(ioBuffer);
				bufferIndex = 0;
			}

			//Test for EOS
			if (dataLen == -1)
			{
				//Output the current token if any
				if (length > 0)	break;
				//Or return without any token
				else return false;
			}
			else c = ioBuffer[bufferIndex++];

			//If it's an arabic char...
			if(isArabicChar(c))
			{
				//Set start of token
				if (length == 0) start = offset - 1;

				//Buffer it
				buffer[length++] = c;

				//Buffer overflow : output the current token
				if (length == MAX_WORD_LEN) break;
			}
			//Not an arabic char : output the current token if any. space is not arabic ' ' i.e. the loop will break
			else if (length > 0) break;
		}

		String txt = new String(buffer, 0, length);

		// This is to avoid TASHKEEL
        txt = pattern.matcher(txt).replaceAll("");

		termAtt.copyBuffer(txt.toCharArray(), 0, txt.length());
		offsetAtt.setOffset(start, start+length);
		return true;
	}
}