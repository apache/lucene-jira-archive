import java.io.*;
import org.apache.lucene.analysis.*;
import org.apache.lucene.analysis.core.*;
import org.apache.lucene.analysis.util.CharArraySet;
import org.apache.lucene.util.*;

class ArabicAnalyzer extends Analyzer
{
	private final CharArraySet arabicStopSet;
	ArabicAnalyzer()
	{
		super();
		final String[] ARABIC_STOP_WORDS = {"أو", "و"};
		arabicStopSet = StopFilter.makeStopSet(Version.LUCENE_40, ARABIC_STOP_WORDS);
	}

	public TokenStreamComponents createComponents(String fieldName, Reader reader)
	{
		ArabicTokenizer source = new ArabicTokenizer(reader);
		return new TokenStreamComponents(source, new StopFilter(Version.LUCENE_40, source, arabicStopSet));
	}
}