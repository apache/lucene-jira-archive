package org.apache.lucene.misc;

/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2004 The Apache Software Foundation.  All rights
 * reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution,
 *    if any, must include the following acknowledgment:
 *       "This product includes software developed by the
 *        Apache Software Foundation (http://www.apache.org/)."
 *    Alternately, this acknowledgment may appear in the software itself,
 *    if and wherever such third-party acknowledgments normally appear.
 *
 * 4. The names "Apache" and "Apache Software Foundation" and
 *    "Apache Lucene" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For
 *    written permission, please contact apache@apache.org.
 *
 * 5. Products derived from this software may not be called "Apache",
 *    "Apache Lucene", nor may "Apache" appear in their name, without
 *    prior written permission of the Apache Software Foundation.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL THE APACHE SOFTWARE FOUNDATION OR
 * ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by many
 * individuals on behalf of the Apache Software Foundation.  For more
 * information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 */

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.jar.JarInputStream;

import junit.framework.TestCase;

/**
 * Test class for the TrigramLanguageGuesser
 * 
 * Tests just try to stress compliance to the API, not to
 * measure the quelity of the guesser
 * 
 * @author Jean-Fran�ois Halleux
 * @version $version$
 */
public class TestTrigramLanguageGuesser extends TestCase {

	private String dataDir;
	private LanguageGuesser lg;
	
	protected void setUp() throws IOException {
		dataDir = System.getProperty("dataDir");
		
		lg = new TrigramLanguageGuesser(
				new JarInputStream(
					new FileInputStream(
						dataDir + "/org/apache/lucene/misc/Trigrams.jar")));
	}

	public void testGuessLanguage() throws IOException {
		//0. Constructor
		boolean rteFlag = false;
		try {
			new TrigramLanguageGuesser(null);
		} catch (RuntimeException rte) {
			rteFlag = true;
		}
		assertEquals(true, rteFlag);

		String guessedLanguage;

		//1. guessLanguage(Reader)

		//Test null reader
		boolean iaeFlag = false;
		try {
			lg.guessLanguage(null);
		} catch (LanguageGuesserException lge) {
			iaeFlag = true;
		}
		assertEquals(iaeFlag, true);

		//Test empty reader
		guessedLanguage = lg.guessLanguage(new StringReader(""));
		assertEquals(guessedLanguage.length(), 2);

		//Test normal case
		guessedLanguage = lg.guessLanguage(new StringReader("hello world"));
		assertEquals(guessedLanguage.length(), 2);

		//2. guessLanguage(Reader,int)

		//Test null reader
		iaeFlag = false;
		try {
			lg.guessLanguage(null, 0);
		} catch (LanguageGuesserException lge) {
			iaeFlag = true;
		}
		assertEquals(iaeFlag, true);

		//maxTrigrams < 1
		iaeFlag = false;
		try {
			lg.guessLanguage(null, -100);
		} catch (LanguageGuesserException lge) {
			iaeFlag = true;
		}
		assertEquals(iaeFlag, true);

		//Test empty reader
		guessedLanguage = lg.guessLanguage(new StringReader(""), 10);
		assertEquals(guessedLanguage.length(), 2);

		//maxTrigrams == 1
		String guessedLanguage1 =
			lg.guessLanguage(new StringReader("Hello World"), 1);
		assertEquals(guessedLanguage1.length(), 2);

		//Less maxTrigrams than what there are
		String guessedLanguage2 =
			lg.guessLanguage(new StringReader("Hello World"), 3);
		assertEquals(guessedLanguage2.length(), 2);

		//More maxTrigrams than what there really are
		String guessedLanguage3 =
			lg.guessLanguage(new StringReader("Hello World"), 100);
		assertEquals(guessedLanguage3.length(), 2);

		//Much more maxTrigrams than what there really are
		String guessedLanguage4 =
			lg.guessLanguage(new StringReader("Hello World"), 10000);
		assertEquals(guessedLanguage4.length(), 2);

		//3 and 4 should give the same results - TrigramLangageGuesser is deterministic
		assertEquals(guessedLanguage3, guessedLanguage4);

	}

	public void testGuessLanguages() throws IOException {
		//Test null reader
		boolean iaeFlag = false;

		try {
			lg.guessLanguages(null);
		} catch (LanguageGuesserException lge) {
			iaeFlag = true;
		}
		assertEquals(iaeFlag, true);

		//Test empty reader
		LanguageProbability[] lpa = lg.guessLanguages(new StringReader(""));
		if (lpa.length > 0)
			assertTrue(true);
		else
			assertTrue(false);
		for (int i = 0; i < lpa.length; i++) {
			LanguageProbability lp = lpa[i];
			//all prob should be 0.0
			assertEquals(lp.getProbability(), 0.0f, 0.0001);
			//Codes should be ISO
			assertEquals(lp.getIsoCode().length(), 2);
		}

		//Test non-empty reader
		lpa = lg.guessLanguages(new StringReader("Hello World"));
		if (lpa.length > 0)
			assertTrue(true);
		else
			assertTrue(false);
		for (int i = 0; i < lpa.length; i++) {
			LanguageProbability lp = lpa[i];
			//first prob should be 1.0
			if (i == 0) {
				assertEquals(lp.getProbability(), 1.0f, 0.0001);
			}
			//Codes should be ISO
			assertEquals(lp.getIsoCode().length(), 2);
			//Sorted in decreasing order of probability
			if (i > 0) {
				if (lp.getProbability() < lpa[i - 1].getProbability())
					assertTrue(true);
				else
					assertTrue(false);
			}
		}
	} 	

	public void testRestriction() throws IOException {
		lg.restrictToLanguages(null);
		String[] sl=lg.supportedLanguages(); 
		String[] rl=lg.recognizedLanguages();
		
		assertEquals(sl.length,rl.length);
		
		for (int i=0;i<sl.length;i++) {
			if (sl[i].compareTo(rl[i])!=0) fail();	
		}
		 
		LanguageProbability[] lp=lg.guessLanguages(new StringReader("Hello World"));
		assertEquals(rl.length,lp.length);
		
		lg.restrictToLanguages(new String[]{});
		sl=lg.supportedLanguages(); 
		rl=lg.recognizedLanguages();
		
		assertEquals(sl.length,rl.length);
		
		for (int i=0;i<sl.length;i++) {
			if (sl[i].compareTo(rl[i])!=0) fail();	
		}
		 
		lp=lg.guessLanguages(new StringReader("Hello World"));
		assertEquals(rl.length,lp.length);
		
		lg.restrictToLanguages(new String[] {"en","fr"});
		String l=lg.guessLanguage(new StringReader("hello world"));
		assertEquals(l.compareTo("en")==0||l.compareTo("fr")==0,true);
		lp=lg.guessLanguages(new StringReader("Hello World"));
		assertEquals(lp.length,2);
	} 

	private void testQualityForOneLanguage(String testFile,String language) throws IOException {
	
		int[] probProfile=new int[]{30,30,30,30,30,
									40,40,40,40,40,
									50,50,50,50,50,
									53,56,59,62,65,
									68,71,74,77,80,
									82,84,86,88,90};
	
		InputStream is =
			new BufferedInputStream(
				new FileInputStream(testFile));
				
		is.mark(1000000);
	
		System.out.print(language);
		
		for (int length = 30; length >= 3; length--) {
			int correctguess = 0;
			byte[] buf = new byte[length];
			for (int i = 1; i <= 100; i++) {
				is.skip((long) (Math.random() * 800000));
				is.read(buf, 0, length);
				String s = new String(buf);
				if (lg.guessLanguage(new StringReader(s)).compareTo(language) == 0)
					correctguess++;
				is.reset();
			}
			
			System.out.print("|"+correctguess);	
			if (correctguess<probProfile[length-1]) {
				fail("Quality check fails for length="+length+" language : "+language+" expected : "+probProfile[length-1]+" achieved : "+correctguess);
			}
		}
		
		System.out.println();
	}

	public void testQuality() throws IOException {
		testQualityForOneLanguage("c:/LanguageSamples/fr/8roug08.txt","fr");
		testQualityForOneLanguage("c:/LanguageSamples/en/otoos11.txt","en");
		testQualityForOneLanguage("c:/LanguageSamples/da/bbldo10.txt","da");
		testQualityForOneLanguage("c:/LanguageSamples/de/8ikc210.txt","de");
		testQualityForOneLanguage("c:/LanguageSamples/sv/10117-8.txt","sv");
		testQualityForOneLanguage("c:/LanguageSamples/it/8ofur10.txt","it");
	}

}