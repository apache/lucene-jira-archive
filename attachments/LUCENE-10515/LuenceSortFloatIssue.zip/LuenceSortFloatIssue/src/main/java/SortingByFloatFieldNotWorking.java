import static java.util.stream.Collectors.toList;
import static org.apache.lucene.search.BooleanClause.Occur.MUST;
import static org.apache.lucene.search.NumericRangeQuery.newFloatRange;

import org.apache.lucene.analysis.miscellaneous.PerFieldAnalyzerWrapper;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.FieldType;
import org.apache.lucene.document.FloatField;
import org.apache.lucene.document.IntField;
import org.apache.lucene.document.LongField;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DocValuesType;
import org.apache.lucene.index.IndexOptions;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.search.BooleanClause;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.SearcherFactory;
import org.apache.lucene.search.SearcherManager;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.apache.lucene.search.TopFieldDocs;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.NumericUtils;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * When we use float field to sort. Decimal values are getting rounded off and results is erroneous.
 * Even after upgrading version to 6.0.0 FloatPoint results are also erroneous. We are getting correct results only when we user field as
 * FloatDocValues.
 *
 * Please run the below code to see the results
 */

public class SortingByFloatFieldNotWorking {

    public static void main(String[] args) {

        final PerFieldAnalyzerWrapper analyzers = new PerFieldAnalyzerWrapper(new StandardAnalyzer());
        final RAMDirectory index = new RAMDirectory();
        final SearcherManager manager;
        try {
            try (final IndexWriter writer = new IndexWriter(index, new IndexWriterConfig(analyzers))) {
                writer.addDocument(new Document());
            }
            manager = new SearcherManager(index, new SearcherFactory());

            final IndexWriterConfig writerConfig = new IndexWriterConfig(analyzers);
            final List<BigDecimal> bigDecimals =
                Arrays.asList(new BigDecimal(0.4), new BigDecimal(15), new BigDecimal(12.5),new BigDecimal(12),
                              new BigDecimal(0.2));
            try (final IndexWriter writer = new IndexWriter(index, writerConfig)) {
                for (BigDecimal i : bigDecimals) {
                    Document doc = new Document();
                    doc.add(Fields.ENTRY_FEE.buildStoreField(i));
                    writer.addDocument(doc);
                }
            }
            manager.maybeRefresh();
            BooleanQuery.Builder builder = new BooleanQuery.Builder();
            builder.add(buildFloatQuery(Fields.ENTRY_FEE,
                                        0f,
                                        1000f));

            final List<SortField> sorts = Arrays.asList(new SortField(Fields.ENTRY_FEE.getName(),
                                                                      Fields.ENTRY_FEE
                                                                          .getSortType()));
            final Sort sort = new Sort(sorts.stream().toArray(SortField[]::new));

            final IndexSearcher searcher = manager.acquire();
            final TopFieldDocs hits = searcher.search(builder.build(), 10, sort);
            if (hits.scoreDocs.length == 0 || hits.scoreDocs.length <= 0) {
                System.out.println("empty");
            }
            final List<Document> documentList = Arrays.stream(hits.scoreDocs, 0, Math.min(hits.scoreDocs.length, 10))
                .map(hit -> {
                    try {
                        return searcher.doc(hit.doc);
                    } catch (final IOException e) {
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .collect(toList());
            documentList.stream().forEach(doc -> System.out.println(doc.getField("entryFee")));
            manager.release(searcher);
        } catch (IOException e) {
            throw new RuntimeException("SearcherManager Init", e);
        }
    }

    public static BooleanClause buildFloatQuery(final Fields field,
                                                final Float min,
                                                final Float max) {
        return new BooleanClause(newFloatRange(
            field.name, min, max, true, true), MUST);
    }

    public enum Fields {
        ENTRY_FEE("entryFee", FloatField.class, SortField.Type.FLOAT);

        private final String name;
        private final Class<? extends Field> fieldClass;
        private final SortField.Type sortType;

        Fields(final String name, final Class<? extends Field> fieldClass, SortField.Type sortType) {
            this.name = name;
            this.fieldClass = fieldClass;
            this.sortType = sortType;
        }

        public String getName() {
            return name;
        }

        public Class<? extends Field> getFieldClass() {
            return fieldClass;
        }

        public SortField.Type getSortType() {
            return sortType;
        }

        private static final FieldType FLOAT_TYPE_STORED_INDEXED = new FieldType();

        static {
            FLOAT_TYPE_STORED_INDEXED.setTokenized(true);
            FLOAT_TYPE_STORED_INDEXED.setOmitNorms(true);
            FLOAT_TYPE_STORED_INDEXED.setIndexOptions(IndexOptions.DOCS);
            FLOAT_TYPE_STORED_INDEXED.setNumericType(FieldType.NumericType.FLOAT);
            FLOAT_TYPE_STORED_INDEXED.setNumericPrecisionStep(NumericUtils.PRECISION_STEP_DEFAULT_32);
            FLOAT_TYPE_STORED_INDEXED.setStored(true);
            FLOAT_TYPE_STORED_INDEXED.setDocValuesType(DocValuesType.NUMERIC);
            FLOAT_TYPE_STORED_INDEXED.freeze();
        }

        private static final FieldType INT_TYPE_STORED_INDEXED = new FieldType();

        static {
            INT_TYPE_STORED_INDEXED.setTokenized(true);
            INT_TYPE_STORED_INDEXED.setOmitNorms(true);
            INT_TYPE_STORED_INDEXED.setIndexOptions(IndexOptions.DOCS);
            INT_TYPE_STORED_INDEXED.setNumericType(FieldType.NumericType.INT);
            INT_TYPE_STORED_INDEXED.setNumericPrecisionStep(NumericUtils.PRECISION_STEP_DEFAULT_32);
            INT_TYPE_STORED_INDEXED.setStored(true);
            INT_TYPE_STORED_INDEXED.setDocValuesType(DocValuesType.NUMERIC);
            INT_TYPE_STORED_INDEXED.freeze();
        }

        private static final FieldType LONG_TYPE_STORED_INDEXED = new FieldType();

        static {
            LONG_TYPE_STORED_INDEXED.setTokenized(true);
            LONG_TYPE_STORED_INDEXED.setOmitNorms(true);
            LONG_TYPE_STORED_INDEXED.setIndexOptions(IndexOptions.DOCS);
            LONG_TYPE_STORED_INDEXED.setNumericType(FieldType.NumericType.LONG);
            LONG_TYPE_STORED_INDEXED.setStored(true);
            LONG_TYPE_STORED_INDEXED.setDocValuesType(DocValuesType.NUMERIC);
            LONG_TYPE_STORED_INDEXED.freeze();
        }

        public Field buildStoreField(final Object value) {
            if (getFieldClass().isAssignableFrom(FloatField.class)) {
                return new FloatField(getName(), ((BigDecimal) value).floatValue(), FLOAT_TYPE_STORED_INDEXED);
            } else if (getFieldClass().isAssignableFrom(IntField.class)) {
                return new IntField(getName(), (int) value, INT_TYPE_STORED_INDEXED);
            } else if (getFieldClass().isAssignableFrom(LongField.class)) {
                return new LongField(getName(), (long) value, LONG_TYPE_STORED_INDEXED);
            } else if (getFieldClass().isAssignableFrom(StringField.class)) {
                return new StringField(getName(), (String) (value == null ? "" : value), Field.Store.YES);
            } else if (getFieldClass().isAssignableFrom(TextField.class)) {
                return new TextField(getName(), (String) value, Field.Store.YES);
            } else {
                return null;
            }
        }
    }

}
