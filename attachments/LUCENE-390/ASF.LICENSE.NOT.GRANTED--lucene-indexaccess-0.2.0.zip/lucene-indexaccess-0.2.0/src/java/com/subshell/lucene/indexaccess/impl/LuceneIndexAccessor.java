/*
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.subshell.lucene.indexaccess.impl;

import java.io.IOException;
import java.util.Collections;
import java.util.EventListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.swing.event.EventListenerList;

import org.apache.log4j.Logger;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Similarity;
import org.apache.lucene.store.Directory;

import com.subshell.lucene.indexaccess.ClosingSearcherEvent;
import com.subshell.lucene.indexaccess.IIndexAccessProvider;
import com.subshell.lucene.indexaccess.ILuceneIndexAccessListener;
import com.subshell.lucene.indexaccess.ILuceneIndexAccessor;
import com.subshell.lucene.indexaccess.LuceneIndexAccessEvent;

/**
 * Default ILuceneIndexAccessor implementation. It features the following provisions:
 *
 * <ul>
 * <li>Searchers and IndexReaders (read-only) will be cached and reused.</li>
 * <li>Searchers and IndexReaders (read-only) will be closed whenever an IndexWriter is
 * released. This enables subsequently opened Searchers to find documents just added by
 * the IndexWriter.</li>
 * <li>IndexReaders (read/write) and IndexWriters will be reused when accessed concurrently,
 * but will be closed when use count reaches zero.</li>
 * </ul>
 * 
 * @author Maik Schreiber (blizzy AT blizzy DOT de)
 */
public class LuceneIndexAccessor implements ILuceneIndexAccessor {
	private static final Logger log = Logger.getLogger(LuceneIndexAccessor.class);
	
	private IIndexAccessProvider accessProvider;
	private IndexReader cachedWritingReader = null;
	private int writingReaderUseCount = 0;
	private IndexWriter cachedWriter = null;
	private int writerUseCount = 0;
	private int readingReaderUseCount = 0;
	private int searcherUseCount = 0;
	private IndexReader cachedReadingReader = null;
	// SearcherConfiguration -> Searcher
	private Map cachedSearchers = new HashMap();
	private Directory cachedReadingDirectory = null;
	private int readingDirectoryUseCount = 0;
	private boolean writingDirectoryInUse = false;
	private Directory writingDirectory;
	private boolean closed = true;
	private EventListenerList listeners = new EventListenerList();

	public LuceneIndexAccessor(IIndexAccessProvider accessProvider) {
		this.accessProvider = accessProvider;
	}
	
	public IndexReader getReader(boolean write) throws IOException {
		return write ? getWritingReader() : getReadingReader();
	}
	
	private IndexReader getWritingReader() throws IOException {
		IndexReader result;
		synchronized (this) {
			checkClosed();
			
			while ((writerUseCount > 0) ||
					writingDirectoryInUse ||
					(readingDirectoryUseCount > 0)) {

				try {
					wait();
				} catch (InterruptedException e) {
					// okay
				}
			}

			closeCachedReadingDirectory();
			
			if (cachedWritingReader != null) {
				log.debug("returning cached writing reader");
				result = cachedWritingReader;
				writingReaderUseCount++;
			} else {
				log.debug("opening new writing reader");
				result = accessProvider.getReader();
				cachedWritingReader = result;
				writingReaderUseCount = 1;
			}

			notifyAll();
		}
		return result;
	}

	private IndexReader getReadingReader() throws IOException {
		IndexReader result;
		synchronized (this) {
			checkClosed();
			
			while (writingDirectoryInUse) {
				try {
					wait();
				} catch (InterruptedException e) {
					// okay
				}
			}

			if (cachedReadingReader != null) {
				log.debug("returning cached reading reader");
				result = cachedReadingReader;
				readingReaderUseCount++;
			} else {
				log.debug("opening new reading reader and caching it");
				result = accessProvider.getReader();
				cachedReadingReader = result;
				readingReaderUseCount = 1;
			}
			
			notifyAll();
		}
		return result;
	}
	
	public IndexWriter getWriter() throws IOException {
		IndexWriter result;
		synchronized (this) {
			checkClosed();

			while ((writingReaderUseCount > 0) ||
					writingDirectoryInUse ||
					(readingDirectoryUseCount > 0)) {

				try {
					wait();
				} catch (InterruptedException e) {
					// okay
				}
			}

			closeCachedReadingDirectory();

			if (cachedWriter != null) {
				log.debug("returning cached writer");
				result = cachedWriter;
				writerUseCount++;
			} else {
				log.debug("opening new writer and caching it");
				result = accessProvider.getWriter();
				cachedWriter = result;
				writerUseCount = 1;
			}
			
			notifyAll();
		}
		return result;
	}
	
	public Searcher getSearcher() throws IOException {
		return getSearcher(Similarity.getDefault());
	}
	
	public Searcher getSearcher(Similarity similarity) throws IOException {
		return getSearcher(similarity, Collections.EMPTY_SET);
	}

	public Searcher getSearcher(Similarity similarity,
			Set underlyingSearchers) throws IOException {

		Searcher result = null;
		synchronized (this) {
			checkClosed();

			while (writingDirectoryInUse) {
				try {
					wait();
				} catch (InterruptedException e) {
					// okay
				}
			}

			SearcherConfiguration config =
				new SearcherConfiguration(similarity, underlyingSearchers);
			result = (Searcher) cachedSearchers.get(config);
			if (result != null) {
				if (log.isDebugEnabled()) {
					log.debug("returning cached searcher");
				}

				searcherUseCount++;
			} else {
				if (log.isDebugEnabled()) {
					log.debug("opening new searcher and caching it");
				}
				
				result = accessProvider.getSearcher(similarity, underlyingSearchers);
				cachedSearchers.put(config, result);

				searcherUseCount = 1;
			}

			notifyAll();
		}
		return result;
	}
	
	public Directory getDirectory(boolean write) throws IOException {
		return write ? getWritingDirectory() : getReadingDirectory();
	}
	
	private Directory getWritingDirectory() throws IOException {
		Directory result;
		synchronized (this) {
			checkClosed();

			while ((writingReaderUseCount > 0) ||
					(writerUseCount > 0) ||
					(readingReaderUseCount > 0) ||
					(searcherUseCount > 0) ||
					(readingDirectoryUseCount > 0) ||
					writingDirectoryInUse) {

				try {
					wait();
				} catch (InterruptedException e) {
					// okay
				}
			}
			
			closeCachedWritingReader();
			closeCachedWriter();
			closeCachedReadingReader();
			closeCachedSearchers();
			closeCachedReadingDirectory();
			
			log.debug("opening new writing directory");
			result = accessProvider.getDirectory();
			
			writingDirectory = result;

			writingDirectoryInUse = true;
			notifyAll();
		}
		return result;
	}
	
	private Directory getReadingDirectory() throws IOException {
		Directory result;
		synchronized (this) {
			checkClosed();

			while ((writerUseCount > 0) || (writingReaderUseCount > 0) ||
					writingDirectoryInUse) {

				try {
					wait();
				} catch (InterruptedException e) {
					// okay
				}
			}
			
			closeCachedWriter();
			closeCachedWritingReader();
			
			if (cachedReadingDirectory != null) {
				log.debug("returning cached reading directory");
				result = cachedReadingDirectory;
				readingDirectoryUseCount++;
			} else {
				log.debug("opening new reading directory and caching it");
				result = accessProvider.getDirectory();
				cachedReadingDirectory = result;
				readingDirectoryUseCount = 1;
			}

			notifyAll();
		}
		return result;
	}

	public void release(IndexReader reader, boolean write) {
		if (reader != null) {
			if (write) {
				releaseWritingReader(reader);
			} else {
				releaseReadingReader(reader);
			}
		}
	}

	private void releaseWritingReader(IndexReader reader) {
		if (reader == null)
			return;
		synchronized (this) {
			try {
				if (reader != cachedWritingReader) {
					throw new IllegalArgumentException(
							"writing reader not opened by this index accessor");
				}
				
				writingReaderUseCount--;
				
				if (writingReaderUseCount == 0) {
					log.debug("closing cached writing reader");
					try {
						accessProvider.close(cachedWritingReader);
					} finally {
						cachedWritingReader = null;
					}
				}
			} finally {
				notifyAll();
			}

			// make sure there are no readers before returning
			// (this is so that new readers will get our newly-added data)
			if (writingReaderUseCount == 0) {
				waitForReadersAndCloseCached();
			}
		}
	}
	
	private void releaseReadingReader(IndexReader reader) {
		if (reader == null)
			return;
		synchronized (this) {
			if (reader != cachedReadingReader) {
				throw new IllegalArgumentException(
						"reading reader not opened by this index accessor");
			}
			
			readingReaderUseCount--;
			notifyAll();
		}
	}
	
	public void release(IndexWriter writer) {
		if (writer != null) {
			synchronized (this) {
				try {
					if (writer != cachedWriter) {
						throw new IllegalArgumentException(
								"writer not opened by this index accessor");
					}
					
					writerUseCount--;
					
					if (writerUseCount == 0) {
						log.debug("closing cached writer");
						try {
							accessProvider.close(cachedWriter);
						} finally {
							cachedWriter = null;
						}
					}
				} finally {
					notifyAll();
				}
	
				// make sure there are no readers before returning
				// (this is so that new readers will get our newly-added data)
				if (writerUseCount == 0) {
					waitForReadersAndCloseCached();
				}
			}
		}
	}

	public void release(Searcher searcher) {
		if (searcher != null) {
			synchronized (this) {
				if (!cachedSearchers.containsValue(searcher)) {
					throw new IllegalArgumentException("searcher not opened by this index accessor");
				}
				
				searcherUseCount--;
				notifyAll();
			}
		}
	}

	public void release(Directory directory, boolean write) {
		if (directory != null) {
			if (write) {
				releaseWritingDirectory(directory);
			} else {
				releaseReadingDirectory(directory);
			}
		}
	}
	
	private void releaseWritingDirectory(Directory directory) {
		synchronized (this) {
			if (directory != writingDirectory) {
				throw new IllegalArgumentException(
						"writing directory not opened by this index accessor");
			}
			
			try {
				log.debug("closing writing directory");
				accessProvider.close(directory);
			} finally {
				writingDirectoryInUse = false;
				writingDirectory = null;
			}
			
			// no need to wait for readers here since we're closing them in getWritingDirectory()
		}
	}
	
	private void releaseReadingDirectory(Directory directory) {
		if (directory == null)
			return;
		synchronized (this) {
			try {
				if (directory != cachedReadingDirectory) {
					throw new IllegalArgumentException(
							"reading directory not opened by this index accessor");
				}
				
				readingDirectoryUseCount--;
				
				if (readingDirectoryUseCount == 0) {
					log.debug("closing cached reading directory");
					try {
						accessProvider.close(cachedReadingDirectory);
					} finally {
						cachedReadingDirectory = null;
					}
				}
			} finally {
				notifyAll();
			}
		}
	}
	
	// note: this method is invoked in a synchronized context
	protected void waitForReadersAndCloseCached() {
		while ((readingReaderUseCount > 0) || (searcherUseCount > 0)) {
			try {
				wait();
			} catch (InterruptedException e) {
				// okay
			}
		}
		
		closeCachedReadingReader();
		closeCachedSearchers();
		closeCachedReadingDirectory();
	}

	public void close() {
		synchronized (this) {
			if (closed) {
				throw new IllegalStateException("index accessor is already closed");
			}
			
			while ((readingReaderUseCount > 0) ||
					(searcherUseCount > 0) ||
					(writingReaderUseCount > 0) ||
					(writerUseCount > 0) ||
					(readingDirectoryUseCount > 0) ||
					writingDirectoryInUse) {
				
				try {
					wait();
				} catch (InterruptedException e) {
					// okay
				}
			}

			closeCachedReadingReader();
			closeCachedSearchers();
			closeCachedReadingDirectory();
			closeCachedWritingReader();
			closeCachedWriter();
			
			closed = true;
		}
	}

	public void open() {
		synchronized (this) {
			if (!closed) {
				throw new IllegalStateException("index accessor is already open");
			}
			closed = false;
		}
	}
	
	public boolean isOpen() {
		synchronized (this) {
			return !closed;
		}
	}
	
	// note: this method is invoked in a synchronized context
	private void checkClosed() {
		if (closed) {
			throw new IllegalStateException("index accessor has been closed");
		}
	}

	// note: this method is invoked in a synchronized context
	private void closeCachedReadingDirectory() {
		if (cachedReadingDirectory != null) {
			log.debug("closing cached reading directory");
			try {
				accessProvider.close(cachedReadingDirectory);
			} catch (RuntimeException e) {
				log.error("", e);
			} finally {
				cachedReadingDirectory = null;
			}
		}
	}

	// note: this method is invoked in a synchronized context
	private void closeCachedSearchers() {
		if (log.isDebugEnabled()) {
			log.debug("closing cached searchers (" + cachedSearchers.size() + ")");
		}

		for (Iterator i = cachedSearchers.values().iterator(); i.hasNext();) {
			Searcher searcher = (Searcher) i.next();
			fireClosingSearcher(searcher);
			try {
				accessProvider.close(searcher);
			} catch (RuntimeException e) {
				log.error("", e);
			}
		}
		
		cachedSearchers.clear();
	}

	// note: this method is invoked in a synchronized context
	private void closeCachedReadingReader() {
		if (cachedReadingReader != null) {
			log.debug("closing cached reading reader");
			try {
				accessProvider.close(cachedReadingReader);
			} catch (RuntimeException e) {
				log.error("", e);
			} finally {
				cachedReadingReader = null;
			}
		}
	}

	// note: this method is invoked in a synchronized context
	private void closeCachedWriter() {
		if (cachedWriter != null) {
			log.debug("closing cached writer");
			try {
				accessProvider.close(cachedWriter);
			} catch (RuntimeException e) {
				log.error("", e);
			} finally {
				cachedWriter = null;
			}
		}
	}

	// note: this method is invoked in a synchronized context
	private void closeCachedWritingReader() {
		if (cachedWritingReader != null) {
			log.debug("closing cached writing reader");
			try {
				accessProvider.close(cachedWritingReader);
			} catch (RuntimeException e) {
				log.error("", e);
			} finally {
				cachedWritingReader = null;
			}
		}
	}
	
	public void addListener(ILuceneIndexAccessListener listener) {
		listeners.add(ILuceneIndexAccessListener.class, listener);
	}
	
	public void removeListener(ILuceneIndexAccessListener listener) {
		listeners.remove(ILuceneIndexAccessListener.class, listener);
	}
	
	private void fireClosingSearcher(Searcher searcher) {
		EventListener[] eventListeners =
			listeners.getListeners(ILuceneIndexAccessListener.class);
		LuceneIndexAccessEvent event = new ClosingSearcherEvent(this, searcher);
		for (int i = 0; i < eventListeners.length; i++) {
			try {
				((ILuceneIndexAccessListener) eventListeners[i]).closingSearcher(event);
			} catch (RuntimeException e) {
				log.warn("", e);
			}
		}
	}
}
