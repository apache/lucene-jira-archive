/*
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.subshell.lucene.indexaccess.impl;

import java.io.IOException;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.MultiSearcher;
import org.apache.lucene.search.Searchable;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Similarity;
import org.apache.lucene.store.Directory;

import com.subshell.lucene.indexaccess.IIndexAccessProvider;

/**
 * Default IIndexAccessProvider implementation.
 * 
 * @author Maik Schreiber (blizzy AT blizzy DOT de)
 */
public class IndexAccessProvider implements IIndexAccessProvider {
	private static final Logger log = Logger.getLogger(IndexAccessProvider.class);
	
	private static final Searchable[] EMPTY_SEARCHABLE_ARRAY = new Searchable[0];
	
	private Directory directory;
	private Analyzer analyzer;

	/**
	 * Constructs a new IndexAccessProvider.
	 * 
	 * @param directory the underlying directory
	 * @param analyzer the Analyzer to be used for IndexWriters
	 */
	public IndexAccessProvider(Directory directory, Analyzer analyzer) {
		this.directory = directory;
		this.analyzer = analyzer;
	}
	
	public IndexReader getReader() throws IOException {
		return IndexReader.open(directory);
	}

	public IndexWriter getWriter() throws IOException {
		return new IndexWriter(directory, analyzer, false);
	}

	public Searcher getSearcher(Similarity similarity, Set underlyingSearchers)
		throws IOException {

		Searcher result;
		if ((underlyingSearchers == null) || underlyingSearchers.isEmpty()) {
			result = new IndexSearcher(directory);
		} else {
			result = new MultiSearcher(
					(Searchable[]) underlyingSearchers.toArray(EMPTY_SEARCHABLE_ARRAY));
		}
		result.setSimilarity(similarity);
		return result;
	}

	public Directory getDirectory() {
		return directory;
	}
	
	public void close(IndexReader reader) {
		if (reader != null) {
			try {
				reader.close();
			} catch (IOException e) {
				log.error("", e);
			}
		}
	}

	public void close(IndexWriter writer) {
		if (writer != null) {
			try {
				writer.close();
			} catch (IOException e) {
				log.error("", e);
			}
		}
	}

	public void close(Searcher searcher) {
		if (searcher != null) {
			try {
				searcher.close();
			} catch (IOException e) {
				log.error("", e);
			}
		}
	}
	
	public void close(Directory directory) {
		// nothing to do since we haven't opened it
	}
}
