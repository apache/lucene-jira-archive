/*
 * Copyright 2005 The Apache Software Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.subshell.lucene.indexaccess;

import java.io.IOException;
import java.util.Set;

import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.Searcher;
import org.apache.lucene.search.Similarity;
import org.apache.lucene.store.Directory;

/**
 * <p>Provides high-level index access synchronization.<p>
 * 
 * <p>General use is as follows:<p>
 * 
 * <p><pre>
 *     ILuceneIndexAccessor accessor = ...
 * 
 *     IndexWriter writer = null;
 *     try {
 *         writer = accessor.getWriter();
 *     
 *         // use writer
 *     } catch (IOException e) {
 *         // ...
 *     } finally {
 *         accessor.release(writer);
 *     }
 * </pre></p>
 * 
 * <p>After construction, an ILuceneIndexAccessor is closed, and must be <code>open()</code>ed
 * to make it usable. When done using it (at program exit, for example), it must be
 * <code>close()</code>d to release any cached resources.</p>
 * 
 * @author Maik Schreiber (blizzy AT blizzy DOT de)
 */
public interface ILuceneIndexAccessor {
	/**
	 * Returns an IndexReader.
	 * 
	 * @param write Is this IndexReader to be used for write access?
	 */
	IndexReader getReader(boolean write) throws IOException;
	
	/** Returns an IndexWriter. */
	IndexWriter getWriter() throws IOException;
	
	/** Returns a Searcher. It will use default similarity. */
	Searcher getSearcher() throws IOException;
	
	/** Returns a Searcher using the specified Similarity. */
	Searcher getSearcher(Similarity similarity) throws IOException;
	
	/** Returns a Searcher using the specified Similarity and underlying searchers. */
	Searcher getSearcher(Similarity similarity, Set underlyingSearchers)
			throws IOException;
	
	/**
	 * Returns a Directory.
	 * 
	 * @param write Is this Directory to be used for write access?
	 */
	Directory getDirectory(boolean write) throws IOException;
	
	/**
	 * Releases an IndexReader.
	 * 
	 * @param write Has this IndexReader been opened for write access?
	 */
	void release(IndexReader reader, boolean write);
	
	/** Releases an IndexWriter. */
	void release(IndexWriter writer);
	
	/** Releases a Searcher. */
	void release(Searcher searcher);
	
	/**
	 * Releases a Directory.
	 * 
	 * @param write Has this Directory been opened for write access?
	 */
	void release(Directory directory, boolean write);
	
	/** Closes this ILuceneIndexAccessor and releases any cached resources. */
	void close();
	
	/** Opens this ILuceneIndexAccessor (again) and makes it ready for use. */
	void open();
	
	/** Returns whether this ILuceneIndexAccessor is opened and ready for use. */
	boolean isOpen();
	
	/** Adds an index access event listener. */
	void addListener(ILuceneIndexAccessListener listener);
	
	/** Removes an index access event listener. */
	void removeListener(ILuceneIndexAccessListener listener);
}
